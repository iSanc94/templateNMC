<!-- User Popover AJAX Component -->
<div style="padding: 15px 20px; background: rgba(18,20,28,0.95); backdrop-filter: blur(10px); border: 1px solid var(--border); border-radius: var(--radius-sm); text-align: center; min-width: 250px; box-shadow: 0 10px 30px rgba(0,0,0,0.8);">
    
    <a href="{$PROFILE}">
        <img src="{$AVATAR}" alt="{$USERNAME}" class="adv-avatar" style="width: 70px; height: 70px; box-shadow: 0 0 15px rgba(0,0,0,0.5); margin-bottom: 12px; border: 2px solid var(--accent);">
    </a>
    
    <h3 style="margin: 0; font-family: var(--font-display); font-size: 1.3rem;">
        <a href="{$PROFILE}" style="{$STYLE}">{$NICKNAME}</a>
    </h3>
    
    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.05);">
        {$GROUP}
    </div>
</div>
