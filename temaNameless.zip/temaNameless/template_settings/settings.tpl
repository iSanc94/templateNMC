<!-- Adv Template Settings Panel -->
{if isset($SUCCESS)}
    <div class="alert alert-success">
        {$SUCCESS}
    </div>
{/if}

{if isset($ERRORS)}
    <div class="alert alert-danger">
        {foreach from=$ERRORS item=error}
            {$error}<br />
        {/foreach}
    </div>
{/if}

<form action="" method="post">
    <h4>Hero Section Config</h4>
    
    <div class="form-group">
        <label for="inputHeroTitle">Hero Main Title</label>
        <input type="text" class="form-control" id="inputHeroTitle" name="hero_title" value="{$HERO_TITLE_VALUE}">
    </div>

    <div class="form-group">
        <label for="inputHeroSubtitle">Hero Subtitle</label>
        <input type="text" class="form-control" id="inputHeroSubtitle" name="hero_subtitle" value="{$HERO_SUBTITLE_VALUE}">
    </div>

    <hr>
    <h4>General Connections</h4>

    <div class="form-group">
        <label for="inputServerIp">Server IP (used in widgets / hero)</label>
        <input type="text" class="form-control" id="inputServerIp" name="server_ip" value="{$SERVER_IP_VALUE}">
    </div>

    <div class="form-group">
        <label for="inputDiscord">Discord Invite URL</label>
        <input type="text" class="form-control" id="inputDiscord" name="discord_invite" value="{$DISCORD_INVITE_VALUE}">
    </div>

    <hr>
    <h4>Animation Effects</h4>

    <div class="form-group">
        <label for="inputParticles">Enable Particles (Gold dust effect)</label>
        <select name="particles_enabled" id="inputParticles" class="form-control">
            <option value="1"{if $PARTICLES_ENABLED_VALUE == 1} selected{/if}>Yes</option>
            <option value="0"{if $PARTICLES_ENABLED_VALUE == 0} selected{/if}>No</option>
        </select>
    </div>

    <div class="form-group mt-3">
        <input type="hidden" name="token" value="{$TOKEN}">
        <input type="submit" class="btn btn-primary" value="Save Settings">
    </div>
</form>
