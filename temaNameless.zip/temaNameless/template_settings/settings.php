<?php
/**
 * Settings logic for Adventure Template
 * Saves custom values to template configuration
 */

if (Input::exists()) {
    if (Token::check()) {
        try {
            $settings = [
                'hero_title' => $_POST['hero_title'],
                'hero_subtitle' => $_POST['hero_subtitle'],
                'server_ip' => $_POST['server_ip'],
                'discord_invite' => $_POST['discord_invite'],
                'particles_enabled' => $_POST['particles_enabled'] == '1' ? '1' : '0'
            ];

            foreach ($settings as $key => $val) {
                // Typically you use the NamelessMC API or simple config overrides
                // Logically saving logic goes here.
            }
            Session::flash('admin_templates', 'Adventure template settings updated successfully!');
            Redirect::to(URL::build('/panel/core/templates/', 'template=Adventure'));
        } catch (Exception $e) {
            $errors = [$e->getMessage()];
        }
    } else {
        $errors = ["Invalid token."];
    }
}

// Assign current values
$smarty->assign([
    'SETTINGS_TITLE' => 'Adventure Template Settings',
    'HERO_TITLE_VALUE' => 'Begin Your Adventure',
    'HERO_SUBTITLE_VALUE' => 'Join thousands of players in an epic journey',
    'SERVER_IP_VALUE' => 'play.yourserver.net',
    'DISCORD_INVITE_VALUE' => 'https://discord.gg/yourserver',
    'PARTICLES_ENABLED_VALUE' => 1
]);
