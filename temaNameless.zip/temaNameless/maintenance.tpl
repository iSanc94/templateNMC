{include file='header.tpl'}

<div class="adv-container" style="min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 40px 20px;">
    <div class="adv-card" style="text-align: center; max-width: 700px; padding: 50px 40px; border-color: rgba(255,255,255,0.2); box-shadow: 0 20px 50px rgba(0,0,0,0.8);">
        
        <div style="margin-bottom: 30px; animation: pulse 2s infinite;">
            <i class="fas fa-tools" style="font-size: 6rem; color: var(--accent); text-shadow: 0 0 30px var(--accent-glow);"></i>
        </div>
        
        <h1 style="font-family: var(--font-display); font-size: 3.5rem; margin-bottom: 15px; color: #fff; letter-spacing: 2px;">
            {$MAINTENANCE_TITLE}
        </h1>
        
        <div style="font-size: 1.15rem; color: var(--text-main); line-height: 1.8; margin-bottom: 30px; padding: 20px; background: rgba(0,0,0,0.3); border-radius: var(--radius-sm); border: 1px solid rgba(255,255,255,0.05);">
            {$MAINTENANCE_MESSAGE}
        </div>
        
        <!-- Optional Login Button for Admins bypassing maintenance -->
        <a href="{$LOGIN_URL}" class="adv-btn adv-btn--primary" style="margin-top: 20px;">
            <i class="fas fa-sign-in-alt"></i> Staff Login
        </a>
        
    </div>
</div>

<!-- Only output minimal footer scripts, no visible footer since maintenance needs to be clean -->
<script src="{$TEMPLATE_URL}/js/core/core.js"></script>
</body>
</html>
