/**
 * Adventure Template Core Logic
 * Handles GSAP, Particles, Typed, and UI Interactions
 */

document.addEventListener('DOMContentLoaded', () => {

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // --- 1. Init Particles.js ---
    if (document.getElementById('particles-js')) {
        particlesJS('particles-js', {
            "particles": {
                "number": { "value": 60, "density": { "enable": true, "value_area": 800 } },
                "color": { "value": ["#D4AF37", "#C84B11", "#F0D060"] },
                "shape": { "type": ["circle", "triangle"], "stroke": { "width": 1, "color": "#D4AF37" } },
                "opacity": { "value": 0.3, "random": true, "anim": { "enable": true, "speed": 0.5, "opacity_min": 0.05 } },
                "size": { "value": 3, "random": true, "anim": { "enable": true, "speed": 2, "size_min": 0.3 } },
                "line_linked": { "enable": true, "distance": 150, "color": "#D4AF37", "opacity": 0.1, "width": 1 },
                "move": { "enable": true, "speed": 1.2, "direction": "none", "random": true, "straight": false, "out_mode": "out", "bounce": false }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": { "enable": true, "mode": "grab" },
                    "onclick": { "enable": true, "mode": "push" },
                    "resize": true
                },
                "modes": {
                    "grab": { "distance": 140, "line_linked": { "opacity": 0.5 } },
                    "push": { "particles_nb": 4 }
                }
            },
            "retina_detect": true
        });
    }

    // --- 2. GSAP Animations ---
    if (!prefersReducedMotion && typeof gsap !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);

        // Hero Content Reveal
        if(document.querySelector('.adv-hero-title')) {
            gsap.from(".adv-hero-title", { y: 60, opacity: 0, duration: 1.2, ease: "power4.out", delay: 0.3 });
            gsap.from(".adv-hero-subtitle", { y: 20, opacity: 0, duration: 1, ease: "power3.out", delay: 0.6 });
            gsap.from(".adv-hero-cta", { y: 20, opacity: 0, duration: 1, ease: "power3.out", delay: 0.9, stagger: 0.2 });
        }

        // Stats Counters
        gsap.utils.toArray(".adv-stat-number").forEach(el => {
            gsap.from(el, {
                textContent: 0,
                duration: 2,
                ease: "power2.out",
                snap: { textContent: 1 },
                scrollTrigger: { trigger: el, start: "top 80%" }
            });
        });

        // Card Staggers
        gsap.utils.toArray(".adv-stagger-cards .adv-card").forEach((card, i) => {
            gsap.from(card, {
                y: 40, opacity: 0, duration: 0.8,
                delay: i * 0.1, ease: "power3.out",
                scrollTrigger: { trigger: card, start: "top 85%" }
            });
        });
    }

    // --- 3. Navbar Scroll Effect ---
    const navbar = document.querySelector('.adv-navbar');
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });
    }

    // --- 4. Typed.js ---
    if (typeof Typed !== 'undefined' && document.querySelector('.adv-typed')) {
        let typedStrings = document.querySelector('.adv-typed').getAttribute('data-strings');
        if (typedStrings) {
            new Typed('.adv-typed', {
                strings: typedStrings.split('|'),
                typeSpeed: 50,
                backSpeed: 30,
                backDelay: 2000,
                loop: true
            });
        }
    }

    // --- 5. Toast Notifications System ---
    window.advToast = (message, type = 'info') => {
        let container = document.querySelector('.adv-toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'adv-toast-container';
            document.body.appendChild(container);
        }
        
        const toast = document.createElement('div');
        toast.className = `adv-toast adv-alert--${type}`;
        toast.innerText = message;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    };
});
