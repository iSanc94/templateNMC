{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- Notice Handling -->
<div class="adv-container" style="margin-top: 20px;">
    {if isset($HOME_SESSION_FLASH)}
        <div class="adv-alert adv-alert--success">
            <strong>{$SUCCESS_TITLE}</strong><br>
            {$HOME_SESSION_FLASH}
        </div>
    {/if}

    {if isset($HOME_SESSION_ERROR_FLASH)}
        <div class="adv-alert adv-alert--error">
            <strong>{$ERROR_TITLE}</strong><br>
            {$HOME_SESSION_ERROR_FLASH}
        </div>
    {/if}
</div>

<!-- Premium Hero Section -->
<header class="adv-hero" {if isset($BANNER_IMAGE)}style="background-image: url('{$BANNER_IMAGE}');"{/if}>
    <div id="particles-js"></div>
    
    <div class="adv-hero-content">
        <h1 class="adv-hero-title">
            <span class="adv-typed" data-strings="Welcome to {$SITE_NAME}|Begin Your Adventure|Forged in Legend"></span>
        </h1>
        
        {if isset($MINECRAFT) && isset($SERVER_QUERY)}
            {if isset($SERVER_QUERY.status_value) && ($SERVER_QUERY.status_value == 1)}
                <!-- Copier Box -->
                <div class="adv-ip-box" onclick="navigator.clipboard.writeText('{$CONNECT_WITH}'); window.advToast('IP Copied to Clipboard!', 'success')">
                    <span class="adv-ip-text">{$CONNECT_WITH}</span>
                    <span class="adv-ip-sub"><i class="fas fa-mouse-pointer"></i> {if isset($CLICK_TO_COPY_TOOLTIP)}{$CLICK_TO_COPY_TOOLTIP}{else}Click to copy IP{/if}</span>
                </div>
                
                <!-- Status Badge -->
                <div>
                    <div style="display: inline-flex; align-items: center; background: rgba(0,0,0,0.5); padding: 8px 16px; border-radius: 50px; border: 1px solid rgba(255,255,255,0.05); box-shadow: 0 4px 15px rgba(0,0,0,0.5);">
                        <span class="adv-status-dot"></span>
                        <span style="font-weight: 600; letter-spacing: 1px; font-size: 0.85rem; color: #fff;">
                            {if isset($SERVER_QUERY.status_full)}
                                {$SERVER_QUERY.status_full}
                            {else}
                                {$SERVER_QUERY.x_players_online} PLAYERS ONLINE
                            {/if}
                        </span>
                    </div>
                </div>
            {else}
                <button class="adv-btn" disabled style="background: var(--error); color: white; border: none; font-size: 1rem; padding: 15px 30px; box-shadow: 0 5px 20px rgba(239, 68, 68, 0.4);">
                    <i class="fas fa-times-circle"></i> {$SERVER_OFFLINE}
                </button>
            {/if}
        {/if}
    </div>
</header>

<div class="adv-container mt-4 mb-4" style="margin-top: 50px;">
    <!-- Advanced CSS Grid for Layout -->
    <div class="adv-grid-2">
        
        <!-- Left Widgets -->
        {if isset($WIDGETS_LEFT) && is_array($WIDGETS_LEFT) && count($WIDGETS_LEFT)}
            <aside>
                {foreach from=$WIDGETS_LEFT item=widget}
                    {$widget}
                {/foreach}
            </aside>
        {/if}

        <!-- Main Content (News / Custom) -->
        <main>
            {if $HOME_TYPE === 'news'}
                {foreach from=$NEWS item=item}
                    <div class="adv-card " style="padding: 35px; margin-bottom: 30px;">
                        <!-- Post Header -->
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid var(--border-light); padding-bottom: 20px; margin-bottom: 25px;">
                            <div>
                                <h2 style="margin: 0;">
                                    {if isset($item.label)}{$item.label}{/if}
                                    <a href="{$item.url}" style="color: var(--accent); font-family: var(--font-display); font-size: 1.8rem; letter-spacing: 1px; text-shadow: 0 2px 10px rgba(229,169,60,0.2);">{$item.title}</a>
                                </h2>
                                <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 8px;">
                                    <i class="fas fa-calendar-alt" style="color: var(--accent);"></i> {$item.date} &middot; <span class="adv-tooltip" data-tooltip="{$item.time_ago}">{$item.time_ago}</span>
                                </div>
                            </div>
                            
                            <!-- Author -->
                            <div style="text-align: right; display: flex; align-items: center; gap: 15px;">
                                <div style="display: flex; flex-direction: column;">
                                    <a style="{$item.author_style}; font-weight: 700; font-size: 1.1rem; letter-spacing: 0.5px;" href="{$item.author_url}">{$item.author_name}</a>
                                    <span style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Author</span>
                                </div>
                                <img src="{$item.author_avatar}" alt="{$item.author_name}" class="adv-avatar" style="width: 50px; height: 50px; border-width: 2px;">
                            </div>
                        </div>

                        <!-- Post Content -->
                        <div class="forum_post" style="color: var(--text-main); font-size: 1.05rem; line-height: 1.8; margin-bottom: 35px;">
                            {$item.content}
                        </div>

                        <!-- Post Footer -->
                        <div style="text-align: right;">
                            <a href="{$item.url}" class="adv-btn adv-btn--primary" style="padding: 12px 25px;">
                                {$READ_FULL_POST} <i class="fas fa-arrow-right" style="margin-left:5px;"></i>
                            </a>
                        </div>
                    </div>
                {foreachelse}
                    <div class="adv-alert adv-alert--error">
                        {$NO_NEWS}
                    </div>
                {/foreach}
            {elseif $HOME_TYPE === 'custom'}
                <div class="adv-card">
                    {$CUSTOM_HOME_CONTENT}
                </div>
            {/if}
        </main>

        <!-- Right Widgets -->
        {if isset($WIDGETS_RIGHT) && is_array($WIDGETS_RIGHT) && count($WIDGETS_RIGHT)}
            <aside>
                {foreach from=$WIDGETS_RIGHT item=widget}
                    {$widget}
                {/foreach}
            </aside>
        {/if}
        
    </div>
</div>

{include file='footer.tpl'}
