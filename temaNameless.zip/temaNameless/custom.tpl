{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 50px;">
    <div class="adv-grid-2 {if isset($WIDGETS_LEFT) && is_array($WIDGETS_LEFT) && count($WIDGETS_LEFT)}has-left{/if}">
        {if isset($WIDGETS_LEFT) && is_array($WIDGETS_LEFT) && count($WIDGETS_LEFT)}
            <aside>
                {foreach from=$WIDGETS_LEFT item=widget}{$widget}{/foreach}
            </aside>
        {/if}

        <main>
            <div class="adv-card">
                <div class="forum_post" style="color: var(--text-main); line-height: 1.8;">
                    {$CONTENT}
                </div>
            </div>
        </main>

        {if isset($WIDGETS_RIGHT) && is_array($WIDGETS_RIGHT) && count($WIDGETS_RIGHT)}
            <aside>
                {foreach from=$WIDGETS_RIGHT item=widget}{$widget}{/foreach}
            </aside>
        {/if}
    </div>
</div>

{include file='footer.tpl'}
