{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 50px; min-height: 70vh;">
    
    <!-- Hero Header -->
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl); text-align: center; width: 100%;">
        {$PRIVACY_POLICY}
    </h1>

    <style>
    /* Default (Dark Mode) Variables */
    :root {
        --scroll-bg: #1e1812;
        --scroll-roller: linear-gradient(to bottom, #1a130c 0%, #0d0905 50%, #050302 100%);
        --scroll-roller-border: #000;
        --scroll-shadow-inner: rgba(0, 0, 0, 0.9);
        --scroll-text: #e2d5c5;
        --scroll-heading: #e5a93c;
        --scroll-link: #e5a93c;
        --scroll-link-hover: #ffc254;
        --scroll-shading: rgba(0, 0, 0, 0.8);
        --scroll-divider: rgba(229, 169, 60, 0.3);
    }

    /* Light Mode Variables */
    [data-theme="light"] {
        --scroll-bg: #dcb37b;
        --scroll-roller: linear-gradient(to bottom, #5a381e 0%, #3e2210 30%, #201107 100%);
        --scroll-roller-border: #1a0d05;
        --scroll-shadow-inner: rgba(101, 67, 33, 0.4);
        --scroll-text: #3b2416;
        --scroll-heading: #1a0d05;
        --scroll-link: #8b0000;
        --scroll-link-hover: #5c0000;
        --scroll-shading: rgba(82, 51, 21, 0.6);
        --scroll-divider: rgba(59, 36, 22, 0.2);
    }

    .adv-scroll-wrapper {
        padding: 50px 20px;
        position: relative;
        z-index: 10;
        text-align: center;
    }
    
    .adv-scroll-paper {
        background-color: var(--scroll-bg);
        background-image: url('https://www.transparenttextures.com/patterns/parchment.png'), 
                          linear-gradient(to right, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0) 10%, rgba(0,0,0,0) 90%, rgba(0,0,0,0.1) 100%);
        box-shadow: 
            inset 0 0 60px var(--scroll-shadow-inner),
            0 15px 40px rgba(0,0,0,0.6);
        position: relative;
        padding: 80px 60px;
        margin: 0 auto;
        max-width: 900px;
        border-radius: 2px;
        text-align: left;
        transition: background-color 0.4s;
    }
    .adv-scroll-paper::before, .adv-scroll-paper::after {
        content: '';
        position: absolute;
        left: -30px; right: -30px;
        height: 36px;
        background: var(--scroll-roller);
        border-radius: 18px;
        box-shadow: 0 10px 20px rgba(0,0,0,0.6), inset 0 2px 4px rgba(255,255,255,0.15), inset 0 -2px 5px rgba(0,0,0,0.5);
        z-index: 2;
        border: 1px solid var(--scroll-roller-border);
        transition: background 0.4s;
    }
    .adv-scroll-paper::before { top: -18px; }
    .adv-scroll-paper::after { bottom: -18px; }

    .adv-scroll-paper-shading::before, .adv-scroll-paper-shading::after {
        content: '';
        position: absolute;
        left: 0; right: 0;
        height: 60px;
        z-index: 1;
        pointer-events: none;
    }
    .adv-scroll-paper-shading::before {
        top: 0;
        background: linear-gradient(to bottom, var(--scroll-shading) 0%, transparent 100%);
    }
    .adv-scroll-paper-shading::after {
        bottom: 0;
        background: linear-gradient(to top, var(--scroll-shading) 0%, transparent 100%);
    }

    .adv-scroll-prose {
        color: var(--scroll-text);
        font-family: 'Georgia', 'Times New Roman', serif;
        line-height: 1.8;
        font-size: 1.15rem;
        position: relative;
        z-index: 3;
        text-shadow: 0 1px 1px rgba(0,0,0,0.1);
        transition: color 0.4s;
    }
    .adv-scroll-prose h1, .adv-scroll-prose h2, .adv-scroll-prose h3, .adv-scroll-prose h4 {
        color: var(--scroll-heading);
        font-family: 'Cinzel', 'Georgia', serif;
        font-weight: 700;
        text-align: center;
        margin-top: 1.5em; 
        margin-bottom: 1em;
        text-transform: uppercase;
        letter-spacing: 2px;
        border-bottom: 1px solid var(--scroll-divider);
        padding-bottom: 10px;
        transition: color 0.4s;
    }
    .adv-scroll-prose h1:first-child, .adv-scroll-prose h2:first-child { margin-top: 0; }
    .adv-scroll-prose p { margin-bottom: 1.2em; text-align: justify; }
    .adv-scroll-prose ul, .adv-scroll-prose ol { padding-left: 25px; margin-bottom: 1.5em; }
    .adv-scroll-prose li { margin-bottom: 0.5em; }
    .adv-scroll-prose a { color: var(--scroll-link); text-decoration: none; border-bottom: 1px dashed var(--scroll-link); font-weight: bold; transition: 0.2s; }
    .adv-scroll-prose a:hover { color: var(--scroll-link-hover); border-bottom-style: solid; }
    .adv-scroll-prose strong, .adv-scroll-prose b { color: var(--scroll-heading); font-weight: 900; }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .adv-scroll-paper { padding: 40px 20px; }
        .adv-scroll-paper::before, .adv-scroll-paper::after { left: -15px; right: -15px; }
    }
    </style>

    <div class="adv-scroll-wrapper">
        <div class="adv-scroll-paper">
            <div class="adv-scroll-paper-shading"></div>
            <div class="adv-scroll-prose">
                {$POLICY}
            </div>
        </div>
    </div>

</div>

{include file='footer.tpl'}
