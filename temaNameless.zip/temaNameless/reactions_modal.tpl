<!-- Reactions Modal Component -->
<div style="display: flex; flex-direction: column; gap: 10px;">
    {foreach from=$REACTIONS item=reaction}
        <div style="display: flex; align-items: center; gap: 15px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: var(--radius-sm);">
            <img src="{$reaction.avatar}" alt="{$reaction.nickname}" style="width: 35px; height: 35px; border-radius: 4px;">
            <a style="{$reaction.style}; font-weight: 600;" href="{$reaction.profile}">{$reaction.nickname}</a>
        </div>
    {foreachelse}
        <div style="color: var(--text-muted); text-align: center; padding: 20px;">
            No reactions yet.
        </div>
    {/foreach}
</div>
