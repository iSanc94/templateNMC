{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 60px; min-height: 60vh; display: flex; align-items: center; justify-content: center;">
    <div class="adv-card" style="width: 100%; max-width: 500px; padding: 40px;">
        <h1 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 25px; text-align: center; border-bottom: 1px solid var(--border); padding-bottom: 15px;">
            <i class="fas fa-key"></i> {$FORGOT_PASSWORD}
        </h1>
        
        {if isset($ERROR)}
            <div class="adv-alert adv-alert--error mb-4">
                {$ERROR}
            </div>
        {/if}
        
        {if isset($SUCCESS)}
            <div class="adv-alert adv-alert--success mb-4">
                {$SUCCESS}
            </div>
        {else}
            <div style="color: var(--text-secondary); margin-bottom: 25px; text-align: center; font-size: 0.95rem;">
                {$FORGOT_PASSWORD_INSTRUCTIONS}
            </div>

            <form action="" method="post">
                <div style="margin-bottom: 20px;">
                    <label for="email" style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main);">{$EMAIL_ADDRESS}</label>
                    <input type="email" name="email" id="email" class="adv-input" placeholder="{$EMAIL_ADDRESS}" tabindex="1">
                </div>
                
                <input type="hidden" name="token" value="{$TOKEN}">
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="adv-btn adv-btn--primary" style="width: 100%;" tabindex="2">
                        {$SUBMIT} <i class="fas fa-paper-plane" style="margin-left: 5px;"></i>
                    </button>
                </div>
            </form>
        {/if}
    </div>
</div>

{include file='footer.tpl'}
