{* Adventure Premium Footer *}
</div> <!-- End adv-main-content (started in header.tpl) -->

<footer class="adv-footer">
    <div class="adv-container">
        <div class="adv-footer-grid">
            <div class="adv-footer-col">
                <h3>About {$SITE_NAME}</h3>
                <p class="text-secondary">Join the most epic adventure. Conquer dungeons, level up, and build your legacy on our server.</p>
                {if isset($SERVER_STATUS)}
                <div class="adv-badge mt-4">
                    <span class="status-indicator active"></span> {$ONLINE_PLAYERS} Players Online
                </div>
                {/if}
            </div>

            <div class="adv-footer-col">
                <h3>Quick Links</h3>
                <ul class="adv-footer-links">
                    {foreach from=$NAVBAR_ITEMS item=item key=name}
                        <li><a href="{$item.link|escape}">{$item.title}</a></li>
                    {/foreach}
                </ul>
            </div>

            <div class="adv-footer-col">
                <h3>Legal</h3>
                <ul class="adv-footer-links">
                    <li><a href="{if isset($TERMS_LINK)}{$TERMS_LINK}{else}{$SITE_URL}/terms{/if}">Terms of Service</a></li>
                    <li><a href="{if isset($PRIVACY_LINK)}{$PRIVACY_LINK}{else}{$SITE_URL}/privacy{/if}">Privacy Policy</a></li>
                    <li><a href="{if isset($CONTACT_LINK)}{$CONTACT_LINK}{else}{$SITE_URL}/contact{/if}">Contact Us</a></li>
                </ul>
            </div>
            
            <div class="adv-footer-col">
                <h3>Theme Settings</h3>
                <button class="adv-btn adv-btn--primary" id="adv-theme-toggle" style="width: 100%;">Toggle Dark/Light Mode</button>
            </div>
        </div>
        
        <div class="adv-footer-bottom">
            <p>&copy; {$smarty.now|date_format:"%Y"} {$SITE_NAME}. Not affiliated with Mojang AB.</p>
        </div>
    </div>
</footer>

<!-- Toast Notifications Container -->
<div class="adv-toast-container"></div>

<!-- JS -->
<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js" defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12" defer></script>

{foreach from=$TEMPLATE_JS item=script}
    {$script}
{/foreach}

<script src="{$TEMPLATE_URL}/js/core/core.js" defer></script>

<script>
    // Persistent dark/light mode toggler
    document.addEventListener('DOMContentLoaded', () => {
        const toggleBtn = document.getElementById('adv-theme-toggle');
        const savedTheme = localStorage.getItem('adv_theme') || 'dark';
        document.documentElement.setAttribute('data-theme', savedTheme);

        if(toggleBtn) {
            toggleBtn.addEventListener('click', () => {
                const current = document.documentElement.getAttribute('data-theme');
                const newTheme = current === 'dark' ? 'light' : 'dark';
                document.documentElement.setAttribute('data-theme', newTheme);
                localStorage.setItem('adv_theme', newTheme);
            });
        }
    });

    // Alert Handling
    {if isset($ALERTS) && is_array($ALERTS) && count($ALERTS)}
        {foreach from=$ALERTS item=alert}
            setTimeout(() => {
                if(window.advToast) window.advToast("{$alert.info|escape}", "info");
            }, 500);
        {/foreach}
    {/if}
</script>

</body>
</html>
