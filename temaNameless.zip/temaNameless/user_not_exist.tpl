{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 60px; min-height: 60vh; display: flex; align-items: center; justify-content: center;">
    <div class="adv-card" style="text-align: center; max-width: 600px; padding: 50px 30px; border-color: rgba(239,68,68,0.3);">
        <i class="fas fa-user-times" style="font-size: 5rem; color: var(--error); margin-bottom: 20px; text-shadow: 0 0 20px rgba(239, 68, 68, 0.4);"></i>
        
        <h1 style="font-family: var(--font-display); font-size: 2.5rem; margin-bottom: 15px; color: #fff;">
            User Not Found
        </h1>
        
        <div class="adv-alert adv-alert--error" style="margin-bottom: 25px; display: inline-block;">
            {$USER_NOT_FOUND}
        </div>
        
        <p style="font-size: 1rem; color: var(--text-secondary); margin-bottom: 30px;">
            The adventurer you are looking for does not exist in our realm.
        </p>
        
        <div style="display: flex; gap: 15px; justify-content: center;">
            <button class="adv-btn" onclick="history.go(-1)">
                <i class="fas fa-arrow-left"></i> {$BACK}
            </button>
            <a href="{$SITE_HOME}" class="adv-btn adv-btn--primary">
                <i class="fas fa-home"></i> {$HOME}
            </a>
        </div>
    </div>
</div>

{include file='footer.tpl'}
