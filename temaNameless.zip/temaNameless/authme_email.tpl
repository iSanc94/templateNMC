{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 60px; min-height: 60vh; display: flex; align-items: center; justify-content: center;">
    <div class="adv-card" style="width: 100%; max-width: 500px; padding: 40px;">
        <h1 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 15px; text-align: center;">
            <i class="fas fa-envelope"></i> {$CONNECT_WITH_AUTHME}
        </h1>
        <p style="text-align: center; color: var(--text-secondary); margin-bottom: 25px; font-size: 0.95rem;">
            {$AUTHME_INFO}
        </p>

        {if isset($ERRORS)}
            <div class="adv-alert adv-alert--error mb-4">
                {foreach from=$ERRORS item=error}
                    {$error}<br />
                {/foreach}
            </div>
        {/if}

        <form action="" method="post">
            <div style="margin-bottom: 25px;">
                <label for="email" style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main);">{$EMAIL}</label>
                <input type="email" name="email" id="email" class="adv-input" placeholder="{$EMAIL}" tabindex="1">
            </div>

            <input type="hidden" name="token" value="{$TOKEN}">
            
            <button type="submit" class="adv-btn adv-btn--primary" style="width: 100%;" tabindex="2">
                {$SUBMIT} <i class="fas fa-arrow-right" style="margin-left: 5px;"></i>
            </button>
        </form>
    </div>
</div>

{include file='footer.tpl'}
