<div class="adv-card adv-stagger-cards mb-4">
    <h3 style="border-bottom: 1px solid var(--border-color); padding-bottom: 10px; margin-bottom: 15px;"><i class="fas fa-server"></i> Server Status</h3>
    
    <div class="text-center">
        {if isset($SERVER_STATUS)}
            {if $SERVER_STATUS == 'online'}
                <div style="font-size: 3rem; color: var(--success); text-shadow: 0 0 20px rgba(46, 204, 113, 0.4); margin-bottom: 10px;">
                    <i class="fas fa-signal"></i>
                </div>
                <div style="font-family: var(--font-display); font-size: 1.5rem; color: var(--text-primary); margin-bottom: 5px;">
                    {$ONLINE_PLAYERS} / {$MAX_PLAYERS}
                </div>
                <div style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: var(--space-md);">
                    Warriors Online
                </div>
                <div style="background: rgba(0,0,0,0.3); padding: 10px; border-radius: 4px; border: 1px dashed var(--border-color); cursor: pointer;" onclick="window.advToast('IP Coppied: play.yourserver.net', 'success')">
                    <span style="color: var(--accent); font-family: var(--font-mono);">play.yourserver.net</span>
                    <i class="fas fa-copy" style="margin-left: 5px; color: var(--text-secondary);"></i>
                </div>
            {else}
                <div style="font-size: 3rem; color: var(--error); margin-bottom: 10px;">
                    <i class="fas fa-times-circle"></i>
                </div>
                <div style="font-family: var(--font-display); font-size: 1.5rem; color: var(--text-primary); margin-bottom: 5px;">
                    Realm Offline
                </div>
                <div style="color: var(--text-secondary); font-size: 0.9rem;">
                    The portals are currently closed.
                </div>
            {/if}
        {else}
            <div class="adv-alert adv-alert--warning">Status unknown.</div>
        {/if}
    </div>
</div>
