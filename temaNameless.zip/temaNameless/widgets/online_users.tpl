<div class="adv-card adv-stagger-cards mb-4">
    <h3 style="border-bottom: 1px solid var(--border-color); padding-bottom: 10px; margin-bottom: 15px;">
        <i class="fas fa-users"></i> {$ONLINE_USERS}
    </h3>
    
    {if isset($ONLINE_USERS_LIST) && is_array($ONLINE_USERS_LIST) && count($ONLINE_USERS_LIST)}
        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
            {foreach from=$ONLINE_USERS_LIST item=user}
                <div style="position: relative;">
                    <a href="{$user.profile}" class="adv-tooltip" data-tooltip="{$user.nickname}">
                        <img src="{$user.avatar}" alt="{$user.nickname}" class="adv-avatar" style="width: 35px; height: 35px; border-radius: 4px;">
                    </a>
                </div>
            {/foreach}
        </div>
    {else}
        <div style="text-align: center; color: var(--text-secondary); padding: 15px 0;">
            <i class="fas fa-bed" style="font-size: 2rem; opacity: 0.3; margin-bottom: 10px; display: block;"></i>
            {$NO_USERS_ONLINE}
        </div>
    {/if}
</div>
