<div class="adv-card adv-stagger-cards mb-4">
    <h3 style="border-bottom: 1px solid var(--border-color); padding-bottom: 10px; margin-bottom: 15px;">
        <i class="fas fa-chart-bar"></i> {$STATISTICS}
    </h3>
    
    <div style="color: var(--text-secondary); font-size: 0.95rem;">
        <div style="display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid rgba(255,255,255,0.05);">
            <span>{$USERS_REGISTERED}</span>
            <strong style="color: var(--text-primary);">{$USERS_REGISTERED_VALUE}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; padding: 5px 0;">
            <span>{$LATEST_MEMBER}</span>
            <a href="{$LATEST_MEMBER_VALUE.profile}" style="color: {$LATEST_MEMBER_VALUE.style}; font-weight: 600;">{$LATEST_MEMBER_VALUE.nickname}</a>
        </div>
    </div>
</div>
