<div class="adv-card adv-stagger-cards mb-4" style="border-left: 4px solid var(--error);">
    <div style="font-family: var(--font-display); color: var(--error); margin-bottom: 10px; font-size: 1.2rem;">
        <i class="fas fa-exclamation-triangle"></i> Widget Error
    </div>
    
    <div style="color: var(--text-secondary); font-size: 0.9rem;">
        {if isset($ERROR)}
            {$ERROR}
        {else}
            There was a problem loading this widget. The magical connection was severed.
        {/if}
    </div>
</div>
