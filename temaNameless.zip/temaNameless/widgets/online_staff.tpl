<div class="adv-card adv-stagger-cards mb-4">
    <h3 style="border-bottom: 1px solid var(--border-color); padding-bottom: 10px; margin-bottom: 15px;"><i class="fas fa-shield-alt"></i> Online Staff</h3>
    
    {if isset($ONLINE_STAFF_LIST) && count($ONLINE_STAFF_LIST)}
        <div style="display: flex; flex-direction: column; gap: 10px;">
            {foreach from=$ONLINE_STAFF_LIST item=user}
                <div style="display: flex; align-items: center; gap: 12px; padding: 6px; border-radius: 4px; transition: background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.05)'" onmouseleave="this.style.background='transparent'">
                    <div style="position: relative;">
                        <a href="{$user.profile}">
                            <img src="{$user.avatar}" alt="{$user.username}" class="adv-avatar" style="width: 40px; height: 40px;">
                        </a>
                        <!-- Online Indicator Dot -->
                        <span style="position: absolute; bottom: -2px; right: -2px; width: 12px; height: 12px; border-radius: 50%; background: var(--success); border: 2px solid var(--bg-card);"></span>
                    </div>
                    <div style="flex: 1; overflow: hidden;">
                        <a href="{$user.profile}" style="color: {$user.style}; font-weight: 600; font-size: 1.1rem; text-overflow: ellipsis; white-space: nowrap; overflow: hidden; display: block;">{$user.username}</a>
                        <div style="color: var(--text-secondary); font-size: 0.8rem; text-overflow: ellipsis; white-space: nowrap; overflow: hidden;">{$user.group}</div>
                    </div>
                </div>
            {/foreach}
        </div>
    {else}
        <div class="text-center text-secondary py-3">
            <i class="fas fa-bed" style="font-size: 2rem; opacity: 0.3; margin-bottom: 10px; display: block;"></i>
            No staff members are currently observing the realm.
        </div>
    {/if}
</div>
