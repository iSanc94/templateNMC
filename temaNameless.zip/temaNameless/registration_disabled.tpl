{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 60px; min-height: 60vh; display: flex; align-items: center; justify-content: center;">
    <div class="adv-card" style="text-align: center; max-width: 600px; padding: 50px 30px; border-color: rgba(229,169,60,0.3);">
        <i class="fas fa-lock" style="font-size: 5rem; color: var(--accent); margin-bottom: 20px; text-shadow: 0 0 20px var(--accent-glow);"></i>
        
        <h1 style="font-family: var(--font-display); font-size: 2.5rem; margin-bottom: 15px; color: #fff;">
            Registration Disabled
        </h1>
        
        <div class="adv-alert adv-alert--warning" style="margin-bottom: 30px; display: inline-block;">
            {$REGISTRATION_DISABLED}
        </div>
        
        <div style="display: flex; gap: 15px; justify-content: center;">
            <a href="{$LOGIN_URL}" class="adv-btn adv-btn--primary">
                <i class="fas fa-sign-in-alt"></i> Login Instead
            </a>
            <a href="{$SITE_HOME}" class="adv-btn">
                <i class="fas fa-home"></i> {$HOME}
            </a>
        </div>
    </div>
</div>

{include file='footer.tpl'}
