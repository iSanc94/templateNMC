{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 50px;">
    <div class="adv-card">
        <div class="forum_post" style="color: var(--text-main); line-height: 1.8;">
            {$CONTENT}
        </div>
    </div>
</div>

{include file='footer.tpl'}
