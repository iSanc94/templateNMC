{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 60px; margin-bottom: 100px; min-height: 60vh; display: flex; align-items: center; justify-content: center;">
    <div class="adv-card adv-stagger-cards" style="width: 100%; max-width: 500px; padding: 40px;">
        <h1 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 10px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 15px;">
            <i class="fas fa-sign-in-alt"></i> {$SIGN_IN}
        </h1>
        <p style="text-align: center; color: var(--text-secondary); margin-bottom: 25px; font-size: 0.95rem;">
            Welcome back to the adventure.
        </p>

        {if count($ERROR)}
            <div class="adv-alert adv-alert--error">
                <strong>{$ERROR_TITLE}</strong>
                <ul style="margin: 5px 0 0 20px; padding: 0;">
                    {foreach from=$ERROR item=error}
                        <li>{$error}</li>
                    {/foreach}
                </ul>
            </div>
        {/if}

        <form action="" method="post" id="form-login">
            {if isset($EMAIL)}
                <div style="margin-bottom: 20px;">
                    <label for="email" style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main);">{$EMAIL}</label>
                    <input type="email" name="email" id="email" class="adv-input" value="{$USERNAME_INPUT}" placeholder="{$EMAIL}" tabindex="1">
                </div>
            {else}
                <div style="margin-bottom: 20px;">
                    <label for="username" style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main);">{$USERNAME}</label>
                    <input type="text" name="username" id="username" class="adv-input" value="{$USERNAME_INPUT}" placeholder="{$USERNAME}" tabindex="1">
                </div>
            {/if}
            
            <div style="margin-bottom: 20px;">
                <label for="password" style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main);">{$PASSWORD}</label>
                <input type="password" name="password" id="password" class="adv-input" placeholder="{$PASSWORD}" tabindex="2">
            </div>

            {if $CAPTCHA}
                <div style="margin-bottom: 20px;">
                    {$CAPTCHA}
                </div>
            {/if}

            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; font-size: 0.95rem;">
                <label style="cursor: pointer; display: flex; align-items: center; gap: 8px; color: var(--text-secondary);">
                    <input type="checkbox" name="remember" id="remember" value="1" tabindex="3" style="width: 18px; height: 18px; accent-color: var(--accent);">
                    {$REMEMBER_ME}
                </label>
                <a href="{$FORGOT_PASSWORD_URL}" style="color: var(--info); font-weight: 500;">{$FORGOT_PASSWORD}</a>
            </div>

            <input type="hidden" name="token" value="{$FORM_TOKEN}">
            
            <button type="submit" class="adv-btn adv-btn--primary" style="width: 100%;" tabindex="5">
                {$SIGN_IN} <i class="fas fa-arrow-right" style="margin-left: 5px;"></i>
            </button>
        </form>

        {if $OAUTH_AVAILABLE}
            <div style="margin: 30px 0; text-align: center; position: relative;">
                <hr style="border-top: 1px solid rgba(255,255,255,0.1); border-bottom: none;">
                <span style="position: absolute; top: -12px; left: 50%; transform: translateX(-50%); background: var(--bg-card); padding: 0 15px; color: var(--text-muted); font-size: 0.9rem;">{$OR}</span>
            </div>

            <div style="display: flex; gap: 15px; flex-wrap: wrap; justify-content: center;">
                {foreach $OAUTH_PROVIDERS as $name => $meta}
                    <a href="{$meta.url}" class="adv-btn" style="flex: 1; min-width: 150px; display:flex; gap: 10px; justify-content: center; align-items: center; {if $meta.button_css}{$meta.button_css}{/if}">
                        {if $meta.logo_url}
                            <img src="{$meta.logo_url}" {if $meta.logo_css}style="{$meta.logo_css}"{/if} alt="{$name|ucfirst}">
                        {elseif $meta.icon}
                            <i class="{$meta.icon} fa-lg"></i>
                        {/if}
                        <span {if $meta.text_css}style="{$meta.text_css}"{/if}>{$meta.log_in_with}</span>
                    </a>
                {/foreach}
            </div>
        {/if}

        <div style="margin: 30px 0 20px 0; text-align: center; position: relative;">
            <hr style="border-top: 1px dotted rgba(255,255,255,0.1); border-bottom: none;">
            <span style="position: absolute; top: -12px; left: 50%; transform: translateX(-50%); background: var(--bg-card); padding: 0 15px; color: var(--text-muted); font-size: 0.9rem;">{$NOT_REGISTERED_YET}</span>
        </div>

        <div style="text-align: center;">
            <a href="{$REGISTER_URL}" class="adv-btn" style="border-color: var(--success); color: var(--success); width: 100%;">
                <i class="fas fa-user-plus"></i> {$REGISTER}
            </a>
        </div>
    </div>
</div>

{include file='footer.tpl'}
