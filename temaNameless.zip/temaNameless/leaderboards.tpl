{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- Premium Leaderboards Portal -->
<header class="adv-hero" style="min-height: 40vh; height: auto; padding: 100px 0 50px 0; border-bottom: 2px solid var(--accent); box-shadow: 0 10px 30px rgba(0,0,0,0.8);">
    <div id="particles-js" style="opacity: 0.5;"></div>
    
    <div class="adv-hero-content" style="max-width: 1000px; width: 100%; margin: 0 auto; display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <h1 class="adv-hero-title" style="margin-bottom: 30px; font-size: 4rem; letter-spacing: 4px; text-transform: uppercase;">
            <i class="fas fa-trophy" style="color: var(--accent);"></i> {$LEADERBOARDS}
        </h1>
    </div>
</header>

<div class="adv-container mt-4 mb-4" style="margin-top: 50px;">
    {if count($LEADERBOARD_PLACEHOLDERS)}
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            {foreach from=$LEADERBOARD_PLACEHOLDERS item=leaderboard}
                <div class="adv-card">
                    <h3 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 20px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 15px;">
                        {$leaderboard.name}
                    </h3>
                    
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        {assign var=i value=1}
                        {foreach from=$leaderboard.players item=player}
                            <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(0,0,0,0.3); padding: 12px 15px; border-radius: var(--radius-sm); border-left: 3px solid {if $i eq 1}#FFD700{elseif $i eq 2}#C0C0C0{elseif $i eq 3}#cd7f32{else}var(--border){/if};">
                                <div style="display: flex; align-items: center; gap: 15px;">
                                    <strong style="color: {if $i eq 1}#FFD700{elseif $i eq 2}#C0C0C0{elseif $i eq 3}#cd7f32{else}var(--text-secondary){/if}; font-size: 1.2rem;">#{$i}</strong>
                                    <img src="{$player.avatar}" alt="{$player.username}" style="width: 32px; height: 32px; border-radius: 4px;">
                                    <a style="{$player.style}" href="{$player.profile}">{$player.username}</a>
                                </div>
                                <div style="font-weight: bold; color: #fff;">
                                    {$player.score}
                                </div>
                            </div>
                            {assign var=i value=$i+1}
                        {/foreach}
                    </div>
                </div>
            {/foreach}
        </div>
    {else}
         <div class="adv-alert adv-alert--error">
            No leaderboards found.
        </div>
    {/if}
</div>

{include file='footer.tpl'}
