{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 60px; min-height: 60vh; display: flex; align-items: center; justify-content: center;">
    <div class="adv-card" style="width: 100%; max-width: 500px; padding: 40px;">
        <h1 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 25px; text-align: center; border-bottom: 1px solid var(--border); padding-bottom: 15px;">
            {$REGISTER}
        </h1>
        
        {if isset($ERRORS)}
            <div class="adv-alert adv-alert--error mb-4">
                {foreach from=$ERRORS item=error}
                    {$error}<br />
                {/foreach}
            </div>
        {/if}

        <form action="" method="post" id="form-complete-signup">
            <div style="margin-bottom: 20px;">
                <label for="password" style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main);">{$PASSWORD}</label>
                <input type="password" name="password" id="password" class="adv-input" placeholder="{$PASSWORD}" tabindex="1">
            </div>

            <div style="margin-bottom: 20px;">
                <label for="password_again" style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main);">{$CONFIRM_PASSWORD}</label>
                <input type="password" name="password_again" id="password_again" class="adv-input" placeholder="{$CONFIRM_PASSWORD}" tabindex="2">
            </div>
            
            <!-- Terms Validation -->
            {if isset($AGREE_TO_TERMS)}
            <div style="margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                <input type="checkbox" name="t_and_c" id="t_and_c" value="1" tabindex="3" style="width: 20px; height: 20px;">
                <label for="t_and_c" style="color: var(--text-secondary); cursor: pointer;">{$AGREE_TO_TERMS}</label>
            </div>
            {/if}

            <input type="hidden" name="token" value="{$TOKEN}">
            
            <div style="margin-top: 30px;">
                <button type="submit" class="adv-btn adv-btn--primary" style="width: 100%;" tabindex="4">
                    {$REGISTER} <i class="fas fa-arrow-right" style="margin-left: 5px;"></i>
                </button>
            </div>
        </form>
    </div>
</div>

{include file='footer.tpl'}
