{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- Premium Status Page -->
<header class="adv-hero" style="min-height: 40vh; height: auto; padding: 100px 0 50px 0; border-bottom: 2px solid var(--accent); box-shadow: 0 10px 30px rgba(0,0,0,0.8);">
    <div id="particles-js" style="opacity: 0.5;"></div>
    
    <div class="adv-hero-content" style="max-width: 1000px; width: 100%; margin: 0 auto; display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <h1 class="adv-hero-title" style="margin-bottom: 30px; font-size: 4.5rem; letter-spacing: 4px; text-transform: uppercase;">
            {$STATUS}
        </h1>
    </div>
</header>

<div class="adv-container mt-4 mb-4" style="margin-top: 50px;">
    {if isset($SERVERS) && count($SERVERS)}
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            {foreach from=$SERVERS item=server}
                <div class="adv-card" style="text-align: center; padding: 40px 20px;">
                    <h2 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 15px;">{$server.name}</h2>
                    
                    {if $server.status_value eq 1}
                        <div style="font-size: 3rem; color: var(--success); margin-bottom: 15px;">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <p style="font-size: 1.2rem; font-weight: bold; color: #fff;">
                            {$server.player_count} / {$server.player_count_max} <span style="font-weight: normal; font-size: 1rem; color: var(--text-secondary);">Players</span>
                        </p>
                    {else}
                        <div style="font-size: 3rem; color: var(--error); margin-bottom: 15px;">
                            <i class="fas fa-times-circle"></i>
                        </div>
                        <p style="font-size: 1.2rem; font-weight: bold; color: var(--error);">
                            {$SERVER_OFFLINE}
                        </p>
                    {/if}
                    
                    {if isset($server.format_player_list) && count($server.format_player_list)}
                        <div style="margin-top: 20px; text-align: left; background: rgba(0,0,0,0.4); padding: 15px; border-radius: var(--radius-sm); max-height: 150px; overflow-y: auto;">
                            {foreach from=$server.format_player_list item=player}
                                <div style="display: inline-block; margin-right: 15px; margin-bottom: 10px;">
                                    <img src="{$player.avatar}" alt="{$player.username}" style="width: 24px; height: 24px; vertical-align: middle; border-radius: 4px;"> 
                                    <span style="{$player.style}">{$player.username}</span>
                                </div>
                            {/foreach}
                        </div>
                    {/if}
                </div>
            {/foreach}
        </div>
    {else}
        <div class="adv-alert adv-alert--warning">
            {$NO_SERVERS}
        </div>
    {/if}
</div>

{include file='footer.tpl'}
