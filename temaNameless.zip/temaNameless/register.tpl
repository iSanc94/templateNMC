{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 60px; margin-bottom: 100px; min-height: 60vh; display: flex; align-items: center; justify-content: center;">
    <div class="adv-card adv-stagger-cards" style="width: 100%; max-width: 700px; padding: 40px;">
        <h1 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 10px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 15px;">
            <i class="fas fa-user-plus"></i> {$CREATE_AN_ACCOUNT}
        </h1>
        {if $OAUTH_FLOW}
            <p style="text-align: center; color: var(--text-secondary); margin-bottom: 25px; font-size: 0.95rem;">{$OAUTH_MESSAGE_CONTINUE}</p>
        {else}
            <p style="text-align: center; color: var(--text-secondary); margin-bottom: 25px; font-size: 0.95rem;">Begin your journey today.</p>
        {/if}

        {if isset($REGISTRATION_ERROR)}
            <div class="adv-alert adv-alert--error">
                <strong>{$ERROR_TITLE}</strong>
                <ul style="margin: 5px 0 0 20px; padding: 0;">
                    {foreach from=$REGISTRATION_ERROR item=error}
                        <li>{$error}</li>
                    {/foreach}
                </ul>
            </div>
        {/if}

        <form action="" method="post" id="form-register">
            <div class="adv-grid-2" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
                {assign var=counter value=1}
                {foreach $FIELDS as $field_key => $field}
                    <div {if $field.type eq 2 || $field.type eq 8 || $field.type eq 9}style="grid-column: 1 / -1;"{/if}>
                        <label for="{$field_key}" style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main);">{$field.name}</label>
                        
                        {if $field.type eq 1}
                            <input type="text" name="{$field_key}" id="{$field_key}" class="adv-input" value="{$field.value}" placeholder="{$field.placeholder}" tabindex="{$counter++}" {if $field.required}required{/if}>
                        
                        {else if $field.type eq 2}
                            <textarea name="{$field_key}" id="{$field_key}" class="adv-input" style="min-height: 80px;" placeholder="{$field.placeholder}" tabindex="{$counter++}"></textarea>
                        
                        {else if $field.type eq 3}
                            <input type="date" name="{$field_key}" id="{$field_key}" class="adv-input" value="{$field.value}" tabindex="{$counter++}">
                        
                        {else if $field.type eq 4}
                            <input type="password" name="{$field_key}" id="{$field_key}" class="adv-input" value="{$field.value}" placeholder="{$field.placeholder}" tabindex="{$counter++}" {if $field.required}required{/if}>
                        
                        {else if $field.type eq 5}
                            <select name="{$field_key}" id="{$field_key}" class="adv-input" tabindex="{$counter++}" {if $field.required}required{/if}>
                                {foreach from=$field.options item=option}
                                    <option value="{$option.value}" style="color: black;" {if $option.value eq $field.value} selected{/if}>{$option.option}</option>
                                {/foreach}
                            </select>
                        
                        {else if $field.type eq 6}
                            <input type="number" name="{$field_key}" id="{$field_key}" class="adv-input" value="{$field.value}" placeholder="{$field.name}" tabindex="{$counter++}" {if $field.required}required{/if}>
                        
                        {else if $field.type eq 7}
                            <input type="email" name="{$field_key}" id="{$field_key}" class="adv-input" value="{$field.value}" placeholder="{$field.placeholder}" tabindex="{$counter++}" {if $field.required}required{/if}>
                        
                        {else if $field.type eq 8}
                            <div style="display: flex; gap: 15px; margin-top: 5px;">
                                {foreach from=$field.options item=option}
                                    <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                                        <input type="radio" name="{$field_key}" value="{$option.value}" tabindex="{$counter++}" {if $field.value eq $option.value}checked{/if} {if $field.required}required{/if} style="width: 16px; height: 16px; accent-color: var(--accent);">
                                        {$option.option}
                                    </label>
                                {/foreach}
                            </div>
                        
                        {else if $field.type eq 9}
                            <div style="display: flex; gap: 15px; flex-wrap: wrap; margin-top: 5px;">
                                {foreach from=$field.options item=option}
                                    <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                                        <input type="checkbox" name="{$field_key}[]" value="{$option.value}" tabindex="{$counter++}" {if is_array($field.value) && in_array($option.value, $field.value)}checked{/if} style="width: 16px; height: 16px; accent-color: var(--accent);">
                                        {$option.option}
                                    </label>
                                {/foreach}
                            </div>
                        {/if}
                    </div>
                {/foreach}
            </div>

            {if $CAPTCHA}
                <div style="margin-top: 25px;">
                    {$CAPTCHA}
                </div>
            {/if}

            <div style="margin: 25px 0 30px 0; font-size: 0.95rem;">
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" name="t_and_c" id="t_and_c" value="1" tabindex="7" style="width: 18px; height: 18px; accent-color: var(--accent);">
                    <span style="color: var(--text-secondary);">{$AGREE_TO_TERMS}</span>
                </label>
            </div>

            <input type="hidden" name="token" value="{$TOKEN}">
            <input id="timezone" type="hidden" name="timezone" value="">
            
            <div style="display: flex; gap: 15px;">
                <button type="submit" class="adv-btn adv-btn--primary" style="flex: 1;" tabindex="8">
                    {$REGISTER} <i class="fas fa-arrow-right" style="margin-left: 5px;"></i>
                </button>
                {if $OAUTH_FLOW}
                    <a href="{$OAUTH_CANCEL_REGISTER_URL}" class="adv-btn" style="border-color: var(--error); color: var(--error);">{$CANCEL}</a>
                {/if}
            </div>
        </form>

        {if $OAUTH_AVAILABLE and !$OAUTH_FLOW}
            <div style="margin: 30px 0; text-align: center; position: relative;">
                <hr style="border-top: 1px solid rgba(255,255,255,0.1); border-bottom: none;">
                <span style="position: absolute; top: -12px; left: 50%; transform: translateX(-50%); background: var(--bg-card); padding: 0 15px; color: var(--text-muted); font-size: 0.9rem;">{$OR}</span>
            </div>

            <div style="display: flex; gap: 15px; flex-wrap: wrap; justify-content: center;">
                {foreach $OAUTH_PROVIDERS as $name => $meta}
                    <a href="{$meta.url}" class="adv-btn" style="flex: 1; min-width: 150px; display:flex; justify-content:center; align-items: center; gap: 10px; {if $meta.button_css}{$meta.button_css}{/if}">
                        {if $meta.logo_url}
                            <img src="{$meta.logo_url}" {if $meta.logo_css}style="{$meta.logo_css}"{/if} alt="{$name|ucfirst}">
                        {elseif $meta.icon}
                            <i class="{$meta.icon} fa-lg"></i>
                        {/if}
                        <span {if $meta.text_css}style="{$meta.text_css}"{/if}>{$meta.continue_with}</span>
                    </a>
                {/foreach}
            </div>
        {/if}

        {if !$OAUTH_FLOW}
            <div style="margin: 30px 0 20px 0; text-align: center; position: relative;">
                <hr style="border-top: 1px dotted rgba(255,255,255,0.1); border-bottom: none;">
                <span style="position: absolute; top: -12px; left: 50%; transform: translateX(-50%); background: var(--bg-card); padding: 0 15px; color: var(--text-muted); font-size: 0.9rem;">{$ALREADY_REGISTERED}</span>
            </div>

            <div style="text-align: center;">
                <a href="{$LOGIN_URL}" class="adv-btn" style="border-color: var(--info); color: var(--info); width: 100%;">
                    <i class="fas fa-sign-in-alt"></i> {$LOG_IN}
                </a>
            </div>
        {/if}
    </div>
</div>

{if $OAUTH_FLOW && $OAUTH_EMAIL_VERIFIED}
    <script>
        document.getElementById('email').addEventListener('keyup', (e) => {
            checkEmailValidity(e.target.value);
        });

        const checkEmailValidity = (email) => {
            const emailInput = document.getElementById('email');
            let caption = document.getElementById('email-caption');
            if(!caption) {
                caption = document.createElement('div');
                caption.id = 'email-caption';
                caption.style.marginTop = '5px';
                caption.style.fontSize = '0.85rem';
                emailInput.parentElement.appendChild(caption);
            }

            if ('{$OAUTH_EMAIL_VERIFIED}' && email !== '{$OAUTH_EMAIL_ORIGINAL}') {
                caption.innerText = '{$OAUTH_EMAIL_NOT_VERIFIED_MESSAGE}';
                caption.style.color = 'var(--warning)';
            } else {
                caption.innerText = '{$OAUTH_EMAIL_VERIFIED_MESSAGE}';
                caption.style.color = 'var(--success)';
            }
        }
        window.onload = () => checkEmailValidity('{$EMAIL_INPUT}');
    </script>
{/if}

{include file='footer.tpl'}
