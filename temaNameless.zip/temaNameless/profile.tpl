{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 40px; margin-bottom: 80px;">
    
    <div class="adv-grid-2" style="grid-template-columns: minmax(0, 1fr) 300px; gap: 25px;">
        
        <!-- Left Main Column -->
        <main>
            <div style="background: var(--bg-card); border-radius: var(--radius-md); border: 1px solid var(--border); overflow: hidden; box-shadow: var(--shadow-sm); position: relative;">
                
                <!-- Banner -->
                <div style="height: 220px; background: url('{if isset($BANNER)}{$BANNER}{else}{$TEMPLATE_URL}/css/themes/default/assets/images/layer-bg.jpg{/if}') center/cover no-repeat; position: relative;">
                    <!-- Banner Overlays for Joined/Last Seen if desired, or keep it clean -->
                </div>

                <!-- Profile Info Card (Overlapping Banner) -->
                <div style="margin: -60px 20px 20px 20px; background: var(--bg-secondary); border-radius: var(--radius-sm); padding: 20px; position: relative; z-index: 2; border: 1px solid var(--border); box-shadow: 0 5px 20px rgba(0,0,0,0.5);">
                    
                    <div style="display: flex; gap: 20px; align-items: flex-end; border-bottom: 1px solid var(--border-light); padding-bottom: 20px;">
                        <!-- Avatar -->
                        <div style="position: relative;">
                            <img src="{$AVATAR}" alt="{$NICKNAME}" style="width: 75px; height: 75px; border-radius: 8px; object-fit: cover; background: var(--bg-main); border: 2px solid var(--bg-secondary); box-shadow: 0 4px 10px rgba(0,0,0,0.5);">
                        </div>
                        
                        <!-- Name & Badges -->
                        <div style="flex: 1; padding-bottom: 2px;">
                            <h1 style="margin: 0; font-size: 1.8rem; display: flex; align-items: center; gap: 12px; font-family: var(--font-body); font-weight: 700; letter-spacing: 0.5px;">
                                <span style="{if isset($USER_STYLE)}{$USER_STYLE}{/if}">{$NICKNAME}</span>
                                {if isset($USER_TITLE)}
                                    <span style="font-size: 0.8rem; background: var(--success); color: white; padding: 4px 12px; border-radius: 4px; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; box-shadow: 0 2px 5px rgba(16,185,129,0.3);">{$USER_TITLE}</span>
                                {/if}
                                {if isset($GROUPS) && !isset($USER_TITLE)}
                                    {foreach from=$GROUPS item=group}
                                        <span style="font-size: 0.8rem; background: rgba(255,255,255,0.1); color: var(--text-main); padding: 4px 12px; border-radius: 4px; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; border: 1px solid rgba(255,255,255,0.1);">{$group}</span>
                                        {break} <!-- Just show first group as primary badge -->
                                    {/foreach}
                                {/if}
                            </h1>
                        </div>
                        
                        <!-- Actions -->
                        <div style="padding-bottom: 5px; display: flex; gap: 10px;">
                            {if isset($LOGGED_IN)}
                                {if isset($OWN_PROFILE)}
                                    <a href="{$SETTINGS_LINK}" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: var(--text-main); width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 4px; transition: all 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'"><i class="fas fa-cog"></i></a>
                                {else}
                                    <a href="{$MESSAGE_LINK}" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: var(--text-main); width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 4px; transition: all 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'"><i class="fas fa-envelope"></i></a>
                                    {if isset($IGNORE_LINK)}
                                        <a href="{$IGNORE_LINK}" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: var(--text-main); width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 4px; transition: all 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'"><i class="fas fa-ban"></i></a>
                                    {/if}
                                {/if}
                            {/if}
                        </div>
                    </div>

                    <!-- XenForo Style Tabs Row -->
                    <div style="display: flex; gap: 25px; margin-top: 15px; padding-left: 10px; flex-wrap: wrap;">
                        {assign var=i value=1}
                        {foreach from=$TABS key=key item=tab}
                            <div class="adv-tab-btn {if $i eq 1}active{/if}" data-tab="{$key}" style="cursor: pointer; font-weight: 500; font-size: 0.95rem; color: {if $i eq 1}var(--accent){else}var(--text-secondary){/if}; position: relative; padding-bottom: 12px; margin-bottom: -20px; transition: all 0.2s; border-bottom: {if $i eq 1}2px solid var(--accent){else}2px solid transparent{/if};">
                                <i class="fas fa-angle-right" style="margin-right: 5px; opacity: 0.5;"></i> {$tab.title}
                            </div>
                            {assign var=i value=$i+1}
                        {/foreach}
                    </div>

                </div>
                
                <!-- Tab Panes Container -->
                <div style="padding: 20px; min-height: 200px;">
                    {assign var=i value=1}
                    {foreach from=$TABS key=key item=tab}
                        <div class="adv-tab-pane {if $i eq 1}active{else}hidden{/if}" id="pane-{$key}" {if $i neq 1}style="display: none;"{/if}>
                            <!-- In XenForo, the content often has a custom container styling -->
                            <div style="background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.03); border-radius: var(--radius-sm); padding: 20px;">
                                {if isset($tab.include)}
                                    {include file=$tab.include}
                                {else}
                                    {$tab.content}
                                {/if}
                            </div>
                        </div>
                        {assign var=i value=$i+1}
                    {/foreach}
                </div>

            </div>
        </main>
        
        <!-- Right Sidebar -->
        <aside style="display: flex; flex-direction: column; gap: 25px;">
            <!-- Statistics Card -->
            <div style="background: var(--bg-card); border-radius: var(--radius-md); border: 1px solid var(--border); overflow: hidden; padding: 20px; box-shadow: var(--shadow-sm);">
                <h3 style="color: #38b2ac; font-size: 1.1rem; margin-top: 0; margin-bottom: 20px; font-weight: 600;">Statistics</h3>
                
                <div style="display: flex; flex-direction: column; gap: 12px; font-size: 0.9rem; color: var(--text-secondary);">
                    
                    <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-light); padding-bottom: 8px;">
                        <span><i class="far fa-calendar-alt" style="width: 20px; opacity: 0.7;"></i> Joined</span>
                        <strong style="color: var(--text-primary);">{$REGISTER_DATE}</strong>
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-light); padding-bottom: 8px;">
                        <span><i class="far fa-clock" style="width: 20px; opacity: 0.7;"></i> Last Seen</span>
                        <strong style="color: var(--text-primary);">{$LAST_SEEN_SHORT}</strong>
                    </div>

                    <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-light); padding-bottom: 8px;">
                        <span><i class="far fa-eye" style="width: 20px; opacity: 0.7;"></i> Profile Views</span>
                        <strong style="color: var(--text-primary);">{$VIEWS}</strong>
                    </div>
                    
                    {if isset($POSTS)}
                    <div style="display: flex; justify-content: space-between; padding-bottom: 8px;">
                        <span><i class="far fa-comments" style="width: 20px; opacity: 0.7;"></i> Forum Posts</span>
                        <strong style="color: var(--text-primary);">{$POSTS}</strong>
                    </div>
                    {/if}
                    
                </div>
            </div>
            
            {if isset($ABOUT)}
            <!-- About Card -->
            <div style="background: var(--bg-card); border-radius: var(--radius-md); border: 1px solid var(--border); overflow: hidden; padding: 20px; box-shadow: var(--shadow-sm);">
                <h3 style="color: #38b2ac; font-size: 1.1rem; margin-top: 0; margin-bottom: 15px; font-weight: 600;">About</h3>
                <div style="color: var(--text-secondary); font-size: 0.9rem; line-height: 1.6;">
                    {$ABOUT}
                </div>
            </div>
            {/if}
        </aside>
    </div>

</div>

<!-- Tabs Javascript -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const tabBtns = document.querySelectorAll('.adv-tab-btn');
    const tabPanes = document.querySelectorAll('.adv-tab-pane');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Reset all
            tabBtns.forEach(b => {
                b.style.color = 'var(--text-secondary)';
                b.style.borderBottomColor = 'transparent';
                b.classList.remove('active');
            });
            tabPanes.forEach(p => p.style.display = 'none');

            // Set active
            btn.style.color = 'var(--accent)';
            btn.style.borderBottomColor = 'var(--accent)';
            btn.classList.add('active');
            
            const paneId = 'pane-' + btn.getAttribute('data-tab');
            const targetPane = document.getElementById(paneId);
            if(targetPane) {
                targetPane.style.display = 'block';
                targetPane.style.opacity = '0';
                setTimeout(() => targetPane.style.opacity = '1', 50);
            }
        });
    });
});
</script>

{include file='footer.tpl'}
