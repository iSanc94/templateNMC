{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    <div class="adv-grid-2 has-left" id="alerts">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card adv-stagger-cards mb-4">
                <div style="border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="margin: 0; color: var(--accent);">{$ALERTS}</h3>
                    {if count($ALERTS_LIST)}
                    <form action="{$DELETE_ALL_LINK}" method="post" style="display:inline">
                        <input type="hidden" name="token" value="{$TOKEN}">
                        <button type="submit" class="adv-btn adv-btn--danger" style="padding: 5px 10px; font-size: 0.85rem;"><i class="fas fa-trash"></i> {$DELETE_ALL}</button>
                    </form>
                    {/if}
                </div>

                {if isset($ERROR)}
                <div class="adv-alert adv-alert--danger">{$ERROR}</div>
                {/if}

                <div style="display: flex; flex-direction: column;">
                    {nocache}
                    {if count($ALERTS_LIST)}
                        {foreach from=$ALERTS_LIST item=alert}
                        <a href="{$alert.view_link}" class="adv-post-card" style="display: flex; align-items: center; padding: 15px; text-decoration: none; margin-bottom: 10px; transition: var(--transition);">
                            <div style="width: 30px; color: var(--accent); font-size: 1.2rem; text-align: center;">
                                <i class="fas fa-bell"></i>
                            </div>
                            <div style="flex: 1; padding-left: 15px;">
                                {if $alert.read eq 0}
                                <strong style="color: var(--text-primary); display: block; font-size: 1.05rem;">{$alert.title}</strong>
                                {else}
                                <span style="color: var(--text-primary); display: block; font-size: 1.05rem; opacity: 0.8;">{$alert.title}</span>
                                {/if}
                                <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 5px;"><i class="fas fa-clock"></i> {$alert.date_nice}</div>
                            </div>
                            <div style="width: 30px; color: var(--text-secondary); text-align: right;">
                                <i class="fas fa-chevron-right"></i>
                            </div>
                        </a>
                        {/foreach}
                    {else}
                        <div class="adv-alert adv-alert--info">
                            <i class="fas fa-info-circle"></i> {$NO_ALERTS}
                        </div>
                    {/if}
                    {/nocache}
                </div>
            </div>
        </main>
        
    </div>
</div>

{include file='footer.tpl'}
