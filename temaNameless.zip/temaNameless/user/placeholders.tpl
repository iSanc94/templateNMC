{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    {if isset($SUCCESS)}
    <div class="adv-alert adv-alert--success">
        <i class="fas fa-check-circle"></i> <strong>{$SUCCESS_TITLE}</strong><br />
        {$SUCCESS}
    </div>
    {/if}

    {if isset($ERRORS)}
    <div class="adv-alert adv-alert--danger">
        <div style="display: flex; gap: 10px;">
            <i class="fas fa-times-circle" style="margin-top: 2px;"></i>
            <div>
                {foreach from=$ERRORS item=error}
                <div style="margin-bottom: 5px;">{$error}</div>
                {/foreach}
            </div>
        </div>
    </div>
    {/if}

    <div class="adv-grid-2 has-left" id="placeholders">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card adv-stagger-cards mb-4">
                <h3 style="margin-top: 0; color: var(--accent); border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 15px;">
                    {$PLACEHOLDERS}
                </h3>

                <div style="overflow-x: auto;">
                    {nocache}
                    {if count($PLACEHOLDERS_LIST)}
                    <table style="width: 100%; border-collapse: collapse; margin-bottom: 5px;">
                        <thead>
                            <tr style="border-bottom: 1px solid var(--border-light); background: rgba(0,0,0,0.2);">
                                <th style="text-align: left; padding: 12px 15px; color: var(--text-secondary); font-size: 0.9rem;">{$NAME}</th>
                                <th style="text-align: left; padding: 12px 15px; color: var(--text-secondary); font-size: 0.9rem;">{$VALUE}</th>
                                <th style="text-align: left; padding: 12px 15px; color: var(--text-secondary); font-size: 0.9rem;">{$LAST_UPDATED}</th>
                                <th style="text-align: center; padding: 12px 15px; color: var(--text-secondary); font-size: 0.9rem; white-space: nowrap;">{$SHOW_ON_PROFILE}</th>
                                <th style="text-align: center; padding: 12px 15px; color: var(--text-secondary); font-size: 0.9rem; white-space: nowrap;">{$SHOW_ON_FORUM}</th>
                            </tr>
                        </thead>
                        <tbody>

                            {foreach from=$PLACEHOLDERS_LIST item=data}
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.2s;">
                                <td style="padding: 15px; font-weight: bold; color: var(--text-primary);">
                                    {$data.friendly_name}
                                </td>
                                <td style="padding: 15px; font-family: monospace; background: rgba(255,255,255,0.02);">
                                    {$data.value}
                                </td>
                                <td style="padding: 15px; color: var(--text-secondary); font-size: 0.9rem;">
                                    {$data.last_updated}
                                </td>
                                <td style="text-align: center; padding: 15px; font-size: 1.2rem;">
                                    {if $data.show_on_profile eq 1}
                                    <i class="fas fa-check-circle" style="color: #28a745;"></i>
                                    {else}
                                    <i class="fas fa-times-circle" style="color: #dc3545;"></i>
                                    {/if}
                                </td>
                                <td style="text-align: center; padding: 15px; font-size: 1.2rem;">
                                    {if $data.show_on_forum eq 1}
                                    <i class="fas fa-check-circle" style="color: #28a745;"></i>
                                    {else}
                                    <i class="fas fa-times-circle" style="color: #dc3545;"></i>
                                    {/if}
                                </td>
                            </tr>
                            {/foreach}
                        </tbody>
                    </table>
                    {else}
                    <div class="adv-alert adv-alert--info">
                        <i class="fas fa-info-circle"></i> {$NO_PLACEHOLDERS}
                    </div>
                    {/if}
                    {/nocache}
                </div>
            </div>
        </main>
        
    </div>
</div>

{include file='footer.tpl'}
