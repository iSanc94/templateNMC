{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    <div style="display: flex; flex-wrap: wrap;">
        
        <!-- Navigation Sidebar -->
        <aside style="flex: 1; min-width: 250px; margin-right: 25px; margin-bottom: 25px;">
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Dashboard -->
        <main style="flex: 3; min-width: 300px;">
            <div class="adv-card adv-stagger-cards mb-4">
                <h3 style="margin-top: 0; color: var(--accent); border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px;">{$OVERVIEW}</h3>
                
                <div style="display: flex; flex-direction: column; margin-top: 15px;">
                    {nocache}
                    {foreach from=$USER_DETAILS_VALUES key=name item=value}
                        <div style="display: flex; align-items: center; margin-bottom: 15px; padding: 10px; background: rgba(0,0,0,0.3); border-radius: var(--radius-sm); border-left: 3px solid var(--accent);">
                            <div style="color: var(--text-secondary); width: 35px; text-align: center;">
                                <i class="fas fa-chevron-right"></i>
                            </div>
                            <div style="flex: 1;">
                                <strong style="color: var(--text-primary); display: block;">{$name}</strong>
                                <span style="font-size: 0.95rem; color: var(--text-secondary);">{$value}</span>
                            </div>
                        </div>
                    {/foreach}
                    {/nocache}
                </div>
            </div>

            {if isset($FORUM_GRAPH)}
                <div class="adv-card adv-stagger-cards mb-4">
                    <h3 style="margin-top: 0; color: var(--accent); border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px;">{$FORUM_GRAPH}</h3>
                    <div id="chartWrapper" style="background: rgba(0,0,0,0.4); padding: 15px; border-radius: var(--radius-sm); margin-top: 15px;">
                        <canvas id="dataChart" width="100%" height="40"></canvas>
                    </div>
                </div>
            {/if}
        </main>
        
    </div>
</div>

{include file='footer.tpl'}
