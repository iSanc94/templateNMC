{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    {if isset($SUCCESS_MESSAGE)}
    <div class="adv-alert adv-alert--success">
        <i class="fas fa-check-circle"></i> <strong>{$SUCCESS}</strong><br />
        {$SUCCESS_MESSAGE}
    </div>
    {/if}

    {if isset($ERROR_MESSAGE)}
    <div class="adv-alert adv-alert--danger">
        <i class="fas fa-times-circle"></i> <strong>{$ERROR}</strong><br />
        {$ERROR_MESSAGE}
    </div>
    {/if}

    <div class="adv-grid-2 has-left" id="sessions">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card adv-stagger-cards mb-4">
                <div style="border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="margin: 0; color: var(--accent);">{$SESSIONS}</h3>
                    {if $CAN_LOGOUT_ALL}
                    <button type="button" class="adv-btn adv-btn--danger" style="padding: 5px 15px; font-size: 0.85rem;" data-toggle="modal" data-target="#modal-logout-all">
                        <i class="fas fa-sign-out-alt"></i> {$LOGOUT_OTHER_SESSIONS}
                    </button>
                    {/if}
                </div>

                <div style="display: flex; flex-direction: column; gap: 15px;">
                    {foreach from=$SESSIONS_LIST item=session}
                    <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; padding: 15px; background: rgba(0,0,0,0.2); border: 1px solid var(--border); border-radius: var(--radius-sm); border-left: 3px solid {if $session.is_current}#28a745{else}var(--border-light){/if};">
                        
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <div style="width: 40px; text-align: center; font-size: 1.8rem; color: var(--accent);">
                                <i class="{if $session.device_type === 'phone'}fas fa-mobile-alt{elseif $session.device_type === 'tablet'}fas fa-tablet-alt{elseif $session.device_type === 'laptop'}fas fa-laptop{else}fas fa-desktop{/if}"></i>
                            </div>
                            <div>
                                <strong style="color: var(--text-primary); font-size: 1.1rem; display: block;">{$session.device_os} &middot; {$session.device_browser} {$session.device_browser_version}</strong>
                                <div style="color: var(--text-secondary); font-size: 0.9rem; margin-top: 3px;">
                                    {$session.location}, 
                                    {if $session.is_current}
                                    <span style="color: #28a745; font-weight: bold;">{$THIS_DEVICE}</span>
                                    {else}
                                    <span data-toggle="tooltip" data-content="{$session.last_seen}">{$session.last_active}</span>
                                    {/if}
                                </div>
                                
                                <div style="display: flex; gap: 5px; margin-top: 5px;">
                                {if $session.is_admin}
                                    <span style="background: rgba(220,53,69,0.2); color: #dc3545; border: 1px solid #dc3545; padding: 2px 8px; border-radius: 3px; font-size: 0.75rem; font-weight: bold;"><i class="fas fa-user-secret"></i> {$ADMIN_LOGGED_IN}</span>
                                {elseif $session.is_remembered}
                                    <span style="background: rgba(40,167,69,0.2); color: #28a745; border: 1px solid #28a745; padding: 2px 8px; border-radius: 3px; font-size: 0.75rem; font-weight: bold;"><i class="fas fa-check"></i> {$REMEMBERED}</span>
                                {/if}
                                </div>
                            </div>
                        </div>

                        <div>
                            {if !$session.is_current}
                                <button type="button" class="adv-btn adv-btn--danger" style="padding: 6px 15px; font-size: 0.85rem;" data-toggle="modal" data-target="#modal-logout-{$session.id}">
                                    <i class="fas fa-sign-out-alt"></i> {$LOGOUT}
                                </button>
                            {else}
                                <span style="font-size: 0.85rem; color: #28a745; font-weight: bold; background: rgba(40,167,69,0.1); padding: 5px 10px; border-radius: 3px;">Active</span>
                            {/if}
                        </div>
                    </div>
                    {/foreach}
                </div>

            </div>
        </main>
        
    </div>
</div>

{if $CAN_LOGOUT_ALL}
    <div class="ui small modal" id="modal-logout-all">
        <div class="header">
            {$LOGOUT}
        </div>
        <div class="content">
            {$LOGOUT_ALL_CONFIRM}
        </div>
        <div class="actions">
            <a class="ui negative button">{$NO}</a>
            <form action="" method="post" style="display: inline;">
                <input type="hidden" name="token" value="{$TOKEN}" />
                <input type="hidden" name="action" value="logout_other_sessions" />
                <input type="submit" class="ui green button" value="{$YES}" />
            </form>
        </div>
    </div>
{/if}

{foreach from=$SESSIONS_LIST item=session}
    <div class="ui small modal" id="modal-logout-{$session.id}">
        <div class="header">
            {$LOGOUT}
        </div>
        <div class="content">
            {$LOGOUT_CONFIRM}
        </div>
        <div class="actions">
            <a class="ui negative button">{$NO}</a>
            <form action="" method="post" style="display: inline;">
                <input type="hidden" name="token" value="{$TOKEN}" />
                <input type="hidden" name="session_hash" value="{$session.id}" />
                <input type="submit" class="ui green button" value="{$YES}" />
            </form>
        </div>
    </div>
{/foreach}

{include file='footer.tpl'}
