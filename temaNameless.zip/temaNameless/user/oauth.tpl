{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$USER_CP}
    </h1>

    {if isset($SUCCESS_MESSAGE)}
    <div class="adv-alert adv-alert--success">
        <i class="fas fa-check-circle"></i> <strong>{$SUCCESS}</strong><br />
        {$SUCCESS_MESSAGE}
    </div>
    {/if}

    {if isset($ERROR_MESSAGE)}
    <div class="adv-alert adv-alert--danger">
        <i class="fas fa-times-circle"></i> <strong>{$ERROR}</strong><br />
        {$ERROR_MESSAGE}
    </div>
    {/if}

    <div class="adv-grid-2 has-left" id="oauth">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card adv-stagger-cards mb-4">
                <h3 style="margin-top: 0; color: var(--accent); border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 15px;">
                    {$OAUTH}
                </h3>

                <div style="display: flex; flex-direction: column; gap: 15px;">
                    {nocache}
                    {if count($OAUTH_PROVIDERS)}
                        {foreach $OAUTH_PROVIDERS as $provider_name => $provider_data}
                        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; padding: 15px; background: rgba(0,0,0,0.2); border: 1px solid var(--border); border-radius: var(--radius-sm); border-left: 3px solid {if isset($USER_OAUTH_PROVIDERS[$provider_name])}#28a745{else}var(--border-light){/if};">
                            <div style="display: flex; align-items: center; gap: 15px;">
                                {if $provider_data.icon}
                                <div style="width: 35px; text-align: center; font-size: 1.5rem; color: var(--text-main);">
                                    <i class="{$provider_data.icon}"></i>
                                </div>
                                {/if}
                                <div>
                                    <strong style="color: var(--text-primary); font-size: 1.1rem; text-transform: capitalize;">{$provider_name}</strong>
                                    {if isset($USER_OAUTH_PROVIDERS[$provider_name])}
                                    <div style="color: var(--text-secondary); font-size: 0.9rem; margin-top: 3px;">
                                        ID: <code style="background: rgba(255,255,255,0.05); padding: 2px 6px; border-radius: 3px; font-family: monospace;">{$USER_OAUTH_PROVIDERS[$provider_name]->provider_id}</code>
                                    </div>
                                    {/if}
                                </div>
                            </div>

                            <div>
                                {if isset($USER_OAUTH_PROVIDERS[$provider_name])}
                                    <button type="button" class="adv-btn adv-btn--danger" style="padding: 8px 15px; font-size: 0.85rem;" data-toggle="modal" data-target="#modal-unlink-{$provider_name}">
                                        <i class="fas fa-unlink"></i> {$UNLINK}
                                    </button>
                                {else}
                                    <button type="button" class="adv-btn" style="background: #28a745; color: #fff; padding: 8px 15px; border-color: #1e7e34; font-size: 0.85rem;" data-toggle="modal" data-target="#modal-link-{$provider_name}">
                                        <i class="fas fa-link"></i> {$LINK}
                                    </button>
                                {/if}
                            </div>
                        </div>
                        {/foreach}
                    {else}
                        <div class="adv-alert adv-alert--info">
                            <i class="fas fa-info-circle"></i> {$NO_PROVIDERS}
                        </div>
                    {/if}
                    {/nocache}
                </div>
            </div>
        </main>
        
    </div>
</div>

{foreach $OAUTH_PROVIDERS as $provider_name => $provider_data}
<div class="ui small modal" id="modal-unlink-{$provider_name}">
    <div class="header">
        {$UNLINK} {$provider_name|ucfirst}
    </div>
    <div class="content">
        {$OAUTH_MESSAGES[$provider_name]['unlink_confirm']}
    </div>
    <div class="actions">
        <a class="ui negative button">{$NO}</a>
        <form action="" method="post" style="display: inline">
            <input type="hidden" name="token" value="{$TOKEN}">
            <input type="hidden" name="action" value="unlink">
            <input type="hidden" name="provider" value="{$provider_name}">
            <input type="submit" class="ui green button" value="{$YES}">
        </form>
    </div>
</div>

<div class="ui small modal" id="modal-link-{$provider_name}">
    <div class="header">
        {$LINK} {$provider_name|ucfirst}
    </div>
    <div class="content">
        {$OAUTH_MESSAGES[$provider_name]['link_confirm']}
    </div>
    <div class="actions">
        <a class="ui negative button">{$NO}</a>
        <a class="ui green button" href="{$provider_data.url}">{$CONFIRM}</a>
    </div>
</div>
{/foreach}

{include file='footer.tpl'}
