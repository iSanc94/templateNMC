{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    <div class="adv-grid-2 has-left" id="messages">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card adv-stagger-cards mb-4">
                <div style="border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="margin: 0; color: var(--accent);">{$MESSAGING}</h3>
                    {if isset($NEW_MESSAGE)}
                    <a class="adv-btn adv-btn--primary" href="{$NEW_MESSAGE_LINK}" style="padding: 5px 15px; font-size: 0.85rem;">
                        <i class="fas fa-plus"></i> {$NEW_MESSAGE}
                    </a>
                    {/if}
                </div>

                {nocache}
                {if count($MESSAGES)}
                
                <div class="adv-post-card" style="flex-direction: column; overflow: hidden; margin-bottom: 15px; padding: 0;">
                    <div style="display: flex; background: rgba(0,0,0,0.2); border-bottom: 1px solid var(--border-light); padding: 12px 20px; font-weight: bold; color: var(--text-secondary); font-size: 0.9rem;">
                        <div style="flex: 2;">{$MESSAGE_TITLE}</div>
                        <div style="flex: 1; text-align: right;">{$LAST_MESSAGE}</div>
                    </div>
                
                    <div style="display: flex; flex-direction: column;">
                        {foreach from=$MESSAGES item=message name=msgLoop}
                        <div style="display: flex; justify-content: space-between; padding: 15px 20px; {if not $smarty.foreach.msgLoop.last}border-bottom: 1px solid var(--border-light);{/if} align-items: center; flex-wrap: wrap; gap: 10px;">
                            <div style="flex: 1; min-width: 150px;">
                                <a href="{$message.link}" style="color: var(--accent); font-weight: bold; font-size: 1.05rem; display: block; margin-bottom: 5px; text-decoration: none;">{$message.title}</a>
                                <div style="font-size: 0.85rem; color: var(--text-secondary);"><i class="fas fa-users"></i> {$message.participants}</div>
                            </div>
                            <div style="display: flex; align-items: center; justify-content: flex-end; gap: 10px; text-align: right;">
                                <div>
                                    <a href="{$message.last_message_user_profile}" style="{$message.last_message_user_style}; font-weight: bold; display: block; text-decoration: none;">{$message.last_message_user}</a>
                                    <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 3px;" data-toggle="tooltip" data-content="{$message.last_message_date_full}"><i class="fas fa-clock"></i> {$message.last_message_date}</div>
                                </div>
                                <img src="{$message.last_message_user_avatar}" style="width: 35px; height: 35px; border-radius: 5px; border: 1px solid var(--border-light); object-fit: cover;">
                            </div>
                        </div>
                        {/foreach}
                    </div>
                </div>
                
                <div style="text-align: center;">
                    {$PAGINATION}
                </div>
                
                {else}
                <div class="adv-alert adv-alert--info">
                    <i class="fas fa-inbox"></i> {$NO_MESSAGES}
                </div>
                {/if}
                {/nocache}
            </div>
        </main>
        
    </div>
</div>

{include file='footer.tpl'}
