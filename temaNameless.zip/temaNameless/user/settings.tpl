{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 50px;">
    
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    {if !empty($SUCCESS)}
        <div class="adv-alert adv-alert--success mb-4">
            <strong><i class="fas fa-check-circle"></i> {$SUCCESS_TITLE}</strong><br>
            {$SUCCESS}
        </div>
    {/if}

    {if (isset($ERRORS) || isset($ERROR))}
        <div class="adv-alert adv-alert--danger mb-4">
            <strong><i class="fas fa-exclamation-circle"></i> Error</strong><br>
            <ul style="margin: 5px 0 0 20px;">
                {foreach from=$ERRORS item=error}
                    <li>{$error}</li>
                {/foreach}
                {if isset($ERROR)}
                    <li>{$ERROR}</li>
                {/if}
            </ul>
        </div>
    {/if}

    <div class="adv-grid-2 has-left">
        <!-- Sidebar Navigation -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <!-- General Settings -->
            <div class="adv-card mb-4">
                <h3 style="color: var(--accent); margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px solid var(--border);">{$SETTINGS}</h3>
                
                <form action="" method="post" id="form-user-settings">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; align-items: start; margin-bottom: 20px;">
                        {nocache}
                        {foreach from=$PROFILE_FIELDS key=name item=field}
                            <div class="adv-form-group" {if $field.type == "textarea"}style="grid-column: 1 / -1;"{/if}>
                                {if !isset($field.disabled)}
                                    <label for="input{$field.id}" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">
                                        {$field.name}{if $field.required}<span style="color: #e74c3c;"> *</span>{/if}
                                    </label>
                                    {if $field.type == "text"}
                                        <input type="text" name="{if $name == 'nickname'}nickname{else}profile_fields[{$field.id}]{/if}"
                                            id="input{$field.id}" value="{$field.value}" placeholder="{$field.description}" class="adv-input">
                                    {elseif $field.type == "textarea"}
                                        <textarea name="profile_fields[{$field.id}]" id="input{$field.id}"
                                            placeholder="{$field.description}" class="adv-input" style="min-height: 100px;">{$field.value}</textarea>
                                    {elseif $field.type == "date"}
                                        <input type="date" name="profile_fields[{$field.id}]" id="input{$field.id}"
                                            value="{$field.value}" class="adv-input">
                                    {/if}
                                {/if}
                            </div>
                        {/foreach}

                        {if isset($TOPIC_UPDATES)}
                            <div class="adv-form-group">
                                <label for="inputTopicUpdates" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$TOPIC_UPDATES}</label>
                                <select name="topicUpdates" id="inputTopicUpdates" class="adv-input">
                                    <option value="1" {if ($TOPIC_UPDATES_ENABLED==true)} selected {/if}>{$ENABLED}</option>
                                    <option value="0" {if ($TOPIC_UPDATES_ENABLED==false)} selected {/if}>{$DISABLED}</option>
                                </select>
                            </div>
                        {/if}
                        
                        {if isset($AUTHME_SYNC_PASSWORD)}
                            <div class="adv-form-group">
                                <label for="inputAuthmeSync" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">
                                    {$AUTHME_SYNC_PASSWORD} <i class="fas fa-question-circle" title="{$AUTHME_SYNC_PASSWORD_INFO}" style="cursor: help;"></i>
                                </label>
                                <select name="authmeSync" id="inputAuthmeSync" class="adv-input">
                                    <option value="1" {if ($AUTHME_SYNC_PASSWORD_ENABLED == true)} selected {/if}>{$ENABLED}</option>
                                    <option value="0" {if ($AUTHME_SYNC_PASSWORD_ENABLED == false)} selected {/if}>{$DISABLED}</option>
                                </select>
                            </div>
                        {/if}

                        {if isset($PRIVATE_PROFILE)}
                            <div class="adv-form-group">
                                <label for="inputPrivateProfile" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$PRIVATE_PROFILE}</label>
                                <select name="privateProfile" id="inputPrivateProfile" class="adv-input">
                                    <option value="1" {if ($PRIVATE_PROFILE_ENABLED==true)} selected {/if}>{$ENABLED}</option>
                                    <option value="0" {if ($PRIVATE_PROFILE_ENABLED==false)} selected {/if}>{$DISABLED}</option>
                                </select>
                            </div>
                        {/if}

                        {if isset($CUSTOM_AVATARS)}
                            <div class="adv-form-group">
                                <label for="inputGravatar" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$GRAVATAR}</label>
                                <select name="gravatar" id="inputGravatar" class="adv-input">
                                    <option value="0" {if ($GRAVATAR_VALUE=='0' )} selected {/if}>{$DISABLED}</option>
                                    <option value="1" {if ($GRAVATAR_VALUE=='1' )} selected {/if}>{$ENABLED}</option>
                                </select>
                            </div>
                        {/if}

                        <div class="adv-form-group">
                            <label for="inputLanguage" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$ACTIVE_LANGUAGE}</label>
                            <select name="language" id="inputLanguage" class="adv-input">
                                {foreach from=$LANGUAGES item=language}
                                    <option value="{$language.name}" {if $language.active} selected{/if}>
                                        {$language.name}
                                    </option>
                                {/foreach}
                            </select>
                        </div>

                        {if count($TEMPLATES) > 2}
                            <div class="adv-form-group">
                                <label for="inputTemplate" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$ACTIVE_TEMPLATE}</label>
                                <select name="template" id="inputTemplate" class="adv-input">
                                    {foreach from=$TEMPLATES item=template}
                                        <option value="{$template.id}" {if $template.active==true} selected{/if}>{$template.name}</option>
                                    {/foreach}
                                </select>
                            </div>
                        {/if}

                        <div class="adv-form-group">
                            <label for="inputTimezone" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$TIMEZONE}</label>
                            <select name="timezone" id="inputTimezone" class="adv-input">
                                {foreach from=$TIMEZONES key=KEY item=ITEM}
                                    <option value="{$KEY}" {if $SELECTED_TIMEZONE eq $KEY} selected{/if}>
                                        ({$ITEM.offset}) {$ITEM.name} &middot; ({$ITEM.time})
                                    </option>
                                {/foreach}
                            </select>
                        </div>

                        {if isset($SIGNATURE)}
                            <div class="adv-form-group" style="grid-column: 1 / -1;">
                                <label for="inputSignature" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$SIGNATURE}</label>
                                <textarea name="signature" id="inputSignature" class="adv-input" style="min-height: 100px;">{$SIGNATURE_VALUE}</textarea>
                            </div>
                        {/if}
                        {/nocache}
                    </div>

                    <div style="border-top: 1px solid var(--border-light); padding-top: 15px;">
                        <input type="hidden" name="action" value="settings">
                        <input type="hidden" name="token" value="{$TOKEN}">
                        <button type="submit" class="adv-btn adv-btn--primary">{$SUBMIT}</button>
                    </div>
                </form>
            </div>

            <!-- Secondary Settings Grid (Compact Layout) -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
                
                <!-- Email Settings -->
                <div class="adv-card" style="display: flex; flex-direction: column;">
                    <h3 style="color: var(--accent); margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px solid var(--border);">{$CHANGE_EMAIL_ADDRESS}</h3>
                    <form action="" method="post" id="form-user-email" style="display: flex; flex-direction: column; gap: 15px; flex: 1;">
                        <div class="adv-form-group">
                            <label for="inputPassword2" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$CURRENT_PASSWORD}</label>
                            <input type="password" name="password" id="inputPassword2" class="adv-input">
                        </div>
                        <div class="adv-form-group">
                            <label for="inputEmail" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$EMAIL_ADDRESS}</label>
                            <input type="email" name="email" id="inputEmail" value="{$CURRENT_EMAIL}" class="adv-input">
                        </div>
                        <div style="margin-top: auto; padding-top: 15px;">
                            <input type="hidden" name="action" value="email">
                            <input type="hidden" name="token" value="{$TOKEN}">
                            <button type="submit" class="adv-btn adv-btn--primary">{$SUBMIT}</button>
                        </div>
                    </form>
                </div>

                <!-- Password Settings -->
                <div class="adv-card" style="display: flex; flex-direction: column;">
                    <h3 style="color: var(--accent); margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px solid var(--border);">{$CHANGE_PASSWORD}</h3>
                    <form action="" method="post" id="form-user-password" style="display: flex; flex-direction: column; gap: 15px; flex: 1;">
                        <div class="adv-form-group">
                            <label for="inputOldPassword" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$CURRENT_PASSWORD}</label>
                            <input type="password" name="old_password" id="inputOldPassword" class="adv-input">
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                            <div class="adv-form-group">
                                <label for="inputNewPassword" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$NEW_PASSWORD}</label>
                                <input type="password" name="new_password" id="inputNewPassword" class="adv-input">
                            </div>
                            <div class="adv-form-group">
                                <label for="inputNewPasswordAgain" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$CONFIRM_NEW_PASSWORD}</label>
                                <input type="password" name="new_password_again" id="inputNewPasswordAgain" class="adv-input">
                            </div>
                        </div>
                        <div style="margin-top: auto; padding-top: 15px;">
                            <input type="hidden" name="action" value="password">
                            <input type="hidden" name="token" value="{$TOKEN}">
                            <button type="submit" class="adv-btn adv-btn--primary">{$SUBMIT}</button>
                        </div>
                    </form>
                </div>

                <!-- Security & Avatar Settings -->
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <!-- Two Factor Auth -->
                    <div class="adv-card">
                        <h3 style="color: var(--accent); margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px solid var(--border);">{$TWO_FACTOR_AUTH}</h3>
                        {if isset($ENABLE)}
                            <a class="adv-btn adv-btn--primary" href="{$ENABLE_LINK}" style="background: #27ae60 !important; color: #fff;">{$ENABLE}</a>
                        {elseif isset($FORCED)}
                            <button class="adv-btn" style="background: rgba(231, 76, 60, 0.2); color: #e74c3c;" disabled>{$DISABLE}</button>
                        {else}
                            <form action="{$DISABLE_LINK}" method="post">
                                <input type="hidden" name="token" value="{$TOKEN}">
                                <button type="submit" class="adv-btn" style="background: rgba(231, 76, 60, 0.2); color: #e74c3c; border: 1px solid #e74c3c;">{$DISABLE}</button>
                            </form>
                        {/if}
                    </div>

                    <!-- Avatar Upload -->
                    {if isset($CUSTOM_AVATARS)}
                        <div class="adv-card">
                            <h3 style="color: var(--accent); margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px solid var(--border);">{$UPLOAD_NEW_PROFILE_IMAGE}</h3>
                            <form action="{$CUSTOM_AVATARS_SCRIPT}" method="post" enctype="multipart/form-data" id="form-user-avatar" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                                <label class="adv-btn" style="cursor: pointer; margin: 0;">
                                    <i class="fas fa-upload"></i> {$BROWSE}
                                    <input type="file" name="file" style="display: none;" />
                                </label>
                                <input type="hidden" name="type" value="avatar">
                                <input type="hidden" name="token" value="{$TOKEN}">
                                <button type="submit" class="adv-btn adv-btn--primary" style="margin: 0;">{$SUBMIT}</button>
                            </form>
                            
                            {if $HAS_CUSTOM_AVATAR}
                                <form action="" method="post" id="form-reset-avatar" style="margin-top: 15px; border-top: 1px solid var(--border-light); padding-top: 15px;">
                                    <input type="hidden" name="action" value="reset_avatar">
                                    <input type="hidden" name="token" value="{$TOKEN}">
                                    <button type="submit" class="adv-btn" style="background: rgba(231, 76, 60, 0.2); color: #e74c3c; border: 1px solid #e74c3c;">{$REMOVE_AVATAR} {$REMOVE}</button>
                                </form>
                            {/if}
                        </div>
                    {/if}
                </div>

            </div>
        </main>
    </div>
</div>

{include file='footer.tpl'}
