{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    {if isset($ERROR)}
    <div class="adv-alert adv-alert--danger">
        <i class="fas fa-times-circle"></i> <strong>{$ERROR_TITLE}</strong><br />
        {$ERROR}
    </div>
    {/if}

    <div class="adv-grid-2 has-left" id="new-message">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card mb-4" style="padding: 25px;">
                <h3 style="margin-top: 0; color: var(--accent); border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 20px;">
                    <i class="fas fa-envelope-open-text"></i> {$NEW_MESSAGE}
                </h3>

                <form class="ui form" action="" method="post" id="form-new-message">
                    
                    <div style="margin-bottom: 15px;">
                        <label for="inputTitle" style="display: block; font-weight: bold; margin-bottom: 5px; color: var(--text-secondary);">{$MESSAGE_TITLE}</label>
                        <input type="text" name="title" id="inputTitle" class="adv-input" style="width: 100%; box-sizing: border-box;" placeholder="{$MESSAGE_TITLE}" value="{$MESSAGE_TITLE_VALUE}">
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label for="InputTo" style="display: block; font-weight: bold; margin-bottom: 5px; color: var(--text-secondary);">{$TO}</label>
                        
                        <!-- Semantic UI Dropdown -->
                        <div class="ui fluid multiple search selection dropdown" style="background: var(--bg-level-1); border-color: var(--border); color: var(--text-main);">
                            <input name="to" id="InputTo" type="hidden" {if isset($TO_USER)}value="{$TO_USER}" {/if}>
                            <i class="dropdown icon"></i>
                            <div class="default text">{$TO}</div>
                            <div class="menu" style="background: var(--bg-level-2); border-color: var(--border);">
                                {if count($ALL_USERS) > 0}
                                    {foreach from=$ALL_USERS item="username"}
                                        <div class="item" data-value="{$username}" style="color: var(--text-main);">{$username}</div>
                                    {/foreach}
                                {/if}
                            </div>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <textarea name="content" id="reply"></textarea>
                    </div>
                    
                    <input type="hidden" name="token" value="{$TOKEN}">
                    <button type="submit" class="adv-btn adv-btn--primary" style="padding: 10px 30px;"><i class="fas fa-paper-plane"></i> {$SUBMIT}</button>
                    
                </form>
            </div>
        </main>
        
    </div>
</div>

{include file='footer.tpl'}
