{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    {if isset($SUCCESS)}
    <div class="adv-alert adv-alert--success">
        <i class="fas fa-check-circle"></i> <strong>{$SUCCESS_TITLE}</strong><br />
        {$SUCCESS}
    </div>
    {/if}

    {if isset($ERRORS)}
    <div class="adv-alert adv-alert--danger">
        <div style="display: flex; gap: 10px;">
            <i class="fas fa-times-circle" style="margin-top: 2px;"></i>
            <div>
                {foreach from=$ERRORS item=error}
                <div style="margin-bottom: 5px;">{$error}</div>
                {/foreach}
            </div>
        </div>
    </div>
    {/if}

    <div class="adv-grid-2 has-left" id="connections">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card adv-stagger-cards mb-4">
                <h3 style="margin-top: 0; color: var(--accent); border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 15px;">
                    {$CONNECTIONS}
                </h3>

                <div style="display: flex; flex-direction: column; gap: 15px;">
                    {foreach from=$INTEGRATIONS item=integration}
                    <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; padding: 15px; background: rgba(0,0,0,0.2); border: 1px solid var(--border); border-radius: var(--radius-sm); {if $integration.connected}{if $integration.verified}border-left: 3px solid #28a745;{else}border-left: 3px solid #ffc107;{/if}{else}border-left: 3px solid #dc3545;{/if}">
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <div style="width: 25px; text-align: center; font-size: 1.2rem; color: {if $integration.connected}{if $integration.verified}#28a745{else}#ffc107{/if}{else}#dc3545{/if};">
                                <i class="fas fa-link"></i>
                            </div>
                            <div>
                                <strong style="color: var(--text-primary); font-size: 1.1rem;">{$integration.name}</strong>
                                <div style="display: flex; align-items: center; gap: 5px; margin-top: 5px;">
                                    {if $integration.connected && !$integration.verified}
                                        <span style="font-size: 0.75rem; padding: 2px 6px; background: #ffc107; color: #000; border-radius: 3px; font-weight: bold;">{$PENDING_VERIFICATION}</span>
                                        {if $integration.required}
                                        <span style="font-size: 0.75rem; padding: 2px 6px; background: #dc3545; color: #fff; border-radius: 3px; font-weight: bold;">{$REQUIRED}</span>
                                        {/if}
                                    {else if !$integration.connected && $integration.required}
                                        <span style="font-size: 0.75rem; padding: 2px 6px; background: #dc3545; color: #fff; border-radius: 3px; font-weight: bold;">{$REQUIRED}</span>
                                    {/if}
                                </div>
                                <div style="color: var(--text-secondary); font-size: 0.9rem; margin-top: 5px;">
                                    {if $integration.connected}
                                    Ext Username: <strong style="color: var(--text-primary);">{$integration.username}</strong>
                                    {else}
                                    {$NOT_CONNECTED}
                                    {/if}
                                </div>
                            </div>
                        </div>

                        <div style="display: flex; gap: 10px;">
                            {if $integration.connected}
                                {if $integration.connected && !$integration.verified}
                                <form action="" method="post" style="margin: 0;">
                                    <input type="hidden" name="token" value="{$TOKEN}">
                                    <input type="hidden" name="action" value="verify">
                                    <input type="hidden" name="integration" value="{$integration.name}">
                                    <button type="submit" class="adv-btn" style="background: #ffc107; color: #000; padding: 8px 15px; font-size: 0.85rem;"><i class="fas fa-check"></i> {$VERIFY}</button>
                                </form>
                                {/if}
                                {if $integration.can_unlink}
                                <form action="" method="post" style="margin: 0;">
                                    <input type="hidden" name="token" value="{$TOKEN}">
                                    <input type="hidden" name="action" value="unlink">
                                    <input type="hidden" name="integration" value="{$integration.name}">
                                    <button type="submit" class="adv-btn adv-btn--danger" style="padding: 8px 15px; font-size: 0.85rem;"><i class="fas fa-unlink"></i> {$UNLINK}</button>
                                </form>
                                {/if}
                            {else}
                                <form action="" method="post" style="margin: 0;">
                                    <input type="hidden" name="token" value="{$TOKEN}">
                                    <input type="hidden" name="action" value="link">
                                    <input type="hidden" name="integration" value="{$integration.name}">
                                    <button type="submit" class="adv-btn" style="background: #28a745; color: #fff; padding: 8px 15px; border-color: #1e7e34; font-size: 0.85rem;"><i class="fas fa-link"></i> {$CONNECT}</button>
                                </form>
                            {/if}
                        </div>
                    </div>
                    {/foreach}
                </div>

            </div>
        </main>
        
    </div>
</div>

{include file='footer.tpl'}
