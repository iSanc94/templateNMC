{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    {if isset($ERROR)}
    <div class="adv-alert adv-alert--danger">
        <i class="fas fa-times-circle"></i> <strong>{$ERROR_TITLE}</strong><br />
        {$ERROR}
    </div>
    {/if}
    {if isset($MESSAGE_SENT)}
    <div class="adv-alert adv-alert--success">
        <i class="fas fa-check-circle"></i> <strong>{$SUCCESS_TITLE}</strong><br />
        {$MESSAGE_SENT}
    </div>
    {/if}

    <div class="adv-grid-2 has-left" id="view-message">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card adv-stagger-cards" style="padding: 20px;">
                <div style="border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 15px;">
                    <div>
                        <h2 style="margin: 0; color: var(--accent);">{$MESSAGE_TITLE}</h2>
                        <div style="color: var(--text-secondary); font-size: 0.9rem; margin-top: 5px;"><i class="fas fa-users" style="margin-right: 5px;"></i> {$PARTICIPANTS_TEXT}: {$PARTICIPANTS}</div>
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <a class="adv-btn" href="{$BACK_LINK}" style="padding: 8px 15px; font-size: 0.85rem;"><i class="fas fa-arrow-left"></i> {$BACK}</a>
                        <button class="adv-btn adv-btn--danger" type="button" data-toggle="modal" data-target="#modal-leave" style="padding: 8px 15px; font-size: 0.85rem;"><i class="fas fa-sign-out-alt"></i> {$LEAVE_CONVERSATION}</button>
                    </div>
                </div>

                <div style="margin-bottom: 15px; text-align: center;">
                    {$PAGINATION}
                </div>

                <div style="display: flex; flex-direction: column; gap: 15px;">
                    {foreach from=$MESSAGES item=message}
                    <div class="adv-post-card" style="display: flex; flex-direction: column; padding: 20px; transition: var(--transition);">
                        <div style="display: flex; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 15px; margin-bottom: 15px;">
                            <img class="adv-avatar-nav" src="{$message.author_avatar}" style="margin-right: 15px; width: 45px; height: 45px;">
                            <div style="flex: 1;">
                                <a href="{$message.author_profile}" data-poload="{$USER_INFO_URL}{$message.author_id}" style="{$message.author_style}; font-weight: bold; font-size: 1.1rem; display: block;">{$message.author_username}</a>
                                <div style="color: var(--text-secondary); font-size: 0.85rem; margin-top: 3px;">
                                    <i class="fas fa-clock"></i> <span data-toggle="tooltip" data-content="{$message.message_date_full}">{$message.message_date}</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="forum_post" style="color: var(--text-main); line-height: 1.7;">
                            {$message.content}
                        </div>
                    </div>
                    {/foreach}
                </div>

                <div style="margin: 20px 0; text-align: center;">
                    {$PAGINATION}
                </div>

                <div style="background: rgba(0,0,0,0.2); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 20px; margin-top: 30px;">
                    <h3 style="margin-top: 0; border-bottom: 1px solid var(--border-light); padding-bottom: 10px; margin-bottom: 15px; color: var(--accent);">
                        <i class="fas fa-reply"></i> {$NEW_REPLY}
                    </h3>
                    <form action="" method="post">
                        <div style="margin-bottom: 15px;">
                            <textarea name="content" id="reply"></textarea>
                        </div>
                        <input type="hidden" name="token" value="{$TOKEN}">
                        <button type="submit" class="adv-btn adv-btn--primary" style="padding: 10px 30px;"><i class="fas fa-paper-plane"></i> {$SUBMIT}</button>
                    </form>
                </div>
            </div>
        </main>
        
    </div>
</div>

<div class="ui small modal" id="modal-leave">
    <div class="header">
        {$LEAVE_CONVERSATION}
    </div>
    <div class="content">
        {$CONFIRM_LEAVE}
        <form action="{$LEAVE_CONVERSATION_LINK}" method="post" id="leave-form">
            <input type="hidden" name="token" value="{$TOKEN}">
        </form>
    </div>
    <div class="actions">
        <a class="ui negative button">{$NO}</a>
        <a class="ui positive button" onclick="$('#leave-form').submit();">{$YES}</a>
    </div>
</div>

{include file='footer.tpl'}
