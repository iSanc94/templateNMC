{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    {if isset($SUCCESS)}
    <div class="adv-alert adv-alert--success">
        <i class="fas fa-check-circle"></i> <strong>{$SUCCESS_TITLE}</strong><br />
        {$SUCCESS}
    </div>
    {/if}

    {if isset($ERRORS)}
    <div class="adv-alert adv-alert--danger">
        <div style="display: flex; gap: 10px;">
            <i class="fas fa-times-circle" style="margin-top: 2px;"></i>
            <div>
                {foreach from=$ERRORS item=error}
                <div style="margin-bottom: 5px;">{$error}</div>
                {/foreach}
            </div>
        </div>
    </div>
    {/if}

    <div class="adv-grid-2 has-left" id="notification_settings">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card adv-stagger-cards mb-4">
                <h3 style="margin-top: 0; color: var(--accent); border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 15px;">
                    {$NOTIFICATION_SETTINGS_TITLE}
                </h3>

                <form action="" method="post">
                    <div style="overflow-x: auto;">
                        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                            <thead>
                                <tr style="border-bottom: 1px solid var(--border-light);">
                                    <th style="text-align: left; padding: 15px 10px; color: var(--text-secondary);"></th>
                                    <th style="text-align: center; padding: 15px 10px; color: var(--text-secondary);">{$ALERT}</th>
                                    <th style="text-align: center; padding: 15px 10px; color: var(--text-secondary);">{$EMAIL}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {foreach $NOTIFICATION_SETTINGS as $setting}
                                    <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.2s;">
                                        <td style="padding: 15px 10px; font-weight: bold; color: var(--text-primary);">{$setting.value}</td>
                                        <td style="text-align: center; padding: 15px 10px;">
                                            <label style="position: relative; display: inline-block; width: 44px; height: 24px;">
                                                <input type="checkbox" name="{$setting.type}:alert" {if $setting.alert}checked{/if} style="opacity: 0; width: 0; height: 0; position: absolute;">
                                                <span class="adv-toggle-slider" style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: var(--border-light); transition: .4s; border-radius: 24px;"></span>
                                            </label>
                                        </td>
                                        <td style="text-align: center; padding: 15px 10px;">
                                            <label style="position: relative; display: inline-block; width: 44px; height: 24px;">
                                                <input type="checkbox" name="{$setting.type}:email" {if $setting.email}checked{/if} style="opacity: 0; width: 0; height: 0; position: absolute;">
                                                <span class="adv-toggle-slider" style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: var(--border-light); transition: .4s; border-radius: 24px;"></span>
                                            </label>
                                        </td>
                                    </tr>
                                {/foreach}
                            </tbody>
                        </table>
                    </div>

                    <div style="text-align: right;">
                        <input type="hidden" name="token" value="{$TOKEN}">
                        <button type="submit" class="adv-btn adv-btn--primary" style="padding: 10px 25px;"><i class="fas fa-save"></i> {$SUBMIT}</button>
                    </div>
                </form>
            </div>
        </main>
        
    </div>
</div>

<style>
/* CSS for toggle switch visually mapping to Semantic UI's toggle slider */
.adv-toggle-slider:before {
    position: absolute;
    content: "";
    height: 18px;
    width: 18px;
    left: 3px;
    bottom: 3px;
    background-color: #fff;
    transition: .4s;
    border-radius: 50%;
}
input:checked + .adv-toggle-slider {
    background-color: var(--accent);
}
input:checked + .adv-toggle-slider:before {
    transform: translateX(20px);
}
</style>

{include file='footer.tpl'}
