<div class="adv-card adv-stagger-cards" style="padding: 10px;">
    <h3 style="margin-top: 5px; margin-bottom: 15px; color: var(--accent); padding-left: 10px;">User Panel</h3>
    <div style="display: flex; flex-direction: column; padding: 5px;">
        {foreach from=$CC_NAV_LINKS key=name item=item}
        <a class="adv-btn {if isset($item.active)}adv-btn--primary{/if}" style="justify-content: flex-start !important; width: 100%; text-align: left; padding: 12px 15px; margin-bottom: 12px; {if !isset($item.active)}background: transparent; border-color: rgba(255,255,255,0.05); color: var(--text-primary);{/if}" href="{$item.link}" target="{$item.target}">
            {if !empty($item.icon)}<span style="display:inline-flex; width: 25px; justify-content: center; margin-right: 5px;">{$item.icon}</span> {else}<i class="fas fa-angle-right" style="width: 25px; text-align: center; margin-right: 5px;"></i> {/if}{$item.title}
        </a>
        {/foreach}
    </div>
</div>
