{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$TITLE}
    </h1>

    {if isset($ERROR)}
    <div class="adv-alert adv-alert--danger">
        <i class="fas fa-times-circle"></i> <strong>{$ERROR_TITLE}</strong><br />
        {$ERROR}
    </div>
    {/if}
    {if isset($ERRORS)}
    <div class="adv-alert adv-alert--danger">
        <div style="display: flex; gap: 10px;">
            <i class="fas fa-times-circle" style="margin-top: 2px;"></i>
            <div>
                {foreach from=$ERRORS item=error}
                <div style="margin-bottom: 5px;">{$error}</div>
                {/foreach}
            </div>
        </div>
    </div>
    {/if}

    <div class="adv-grid-2 has-left" id="tfa-code">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card mb-4" style="padding: 25px;">
                <h3 style="margin-top: 0; color: var(--accent); border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 20px;">
                    <i class="fas fa-lock"></i> {$TWO_FACTOR_AUTH}
                </h3>
                
                {if isset($TFA_SCAN_CODE_TEXT)}
                <div style="text-align: center; margin-bottom: 25px; background: rgba(0,0,0,0.2); padding: 25px; border-radius: var(--radius-sm); border: 1px solid var(--border-light);">
                    <p style="font-size: 1.1rem; color: var(--text-primary); margin-bottom: 15px;">{$TFA_SCAN_CODE_TEXT}</p>
                    <div style="display: inline-block; padding: 10px; background: #fff; border-radius: 5px;">
                        <img src="{$IMG_SRC}" style="display: block; width: 200px; height: 200px;">
                    </div>
                </div>
                
                <div class="adv-alert adv-alert--info" style="margin-bottom: 25px; font-size: 1.1rem; text-align: center;">
                    {$TFA_CODE_TEXT} <strong style="font-family: monospace; font-size: 1.4rem; letter-spacing: 2px; color: var(--accent); display: block; margin-top: 10px;">{$TFA_CODE}</strong>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: center;">
                    <a class="adv-btn adv-btn--primary" href="{$LINK}" style="padding: 10px 30px;"><i class="fas fa-arrow-right"></i> {$NEXT}</a>
                    <form action="{$CANCEL_LINK}" method="post" style="margin: 0;">
                        <input type="hidden" name="token" value="{$TOKEN}">
                        <button type="submit" class="adv-btn adv-btn--danger" style="padding: 10px 30px;"><i class="fas fa-times"></i> {$CANCEL}</button>
                    </form>
                </div>
                
                {else}
                <form action="" method="post" id="form-tfa-code" style="max-width: 400px; margin: 0 auto; text-align: center;">
                    <div style="margin-bottom: 25px;">
                        <label style="display: block; font-weight: bold; margin-bottom: 10px; color: var(--text-primary); font-size: 1.1rem;">{$TFA_ENTER_CODE}</label>
                        <input type="text" name="tfa_code" class="adv-input" style="width: 100%; text-align: center; font-family: monospace; font-size: 1.5rem; letter-spacing: 5px; padding: 15px;" placeholder="000000" maxlength="6" autofocus>
                    </div>
                    
                    <div style="display: flex; gap: 10px; justify-content: center;">
                        <input type="hidden" name="token" value="{$TOKEN}">
                        <button type="submit" class="adv-btn adv-btn--primary" style="padding: 10px 30px;"><i class="fas fa-check"></i> {$SUBMIT}</button>
                    </form>
                    <form action="{$CANCEL_LINK}" method="post" style="margin: 0;">
                        <input type="hidden" name="token" value="{$TOKEN}">
                        <button type="submit" class="adv-btn adv-btn--danger" style="padding: 10px 30px;"><i class="fas fa-times"></i> {$CANCEL}</button>
                    </form>
                </div>
                {/if}
            </div>
        </main>
        
    </div>
</div>

{include file='footer.tpl'}
