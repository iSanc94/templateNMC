{include file='header.tpl'}

<!-- Portal Intro Layout -->
<div class="adv-hero" style="height: 100vh; position: relative;" id="particles-js">
    <!-- Overlay Content -->
    <div class="adv-hero-content" style="z-index: 2; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 100%; max-width: 800px; text-align: center;">
        
        {if isset($PORTAL_LOGO)}
            <img src="{$PORTAL_LOGO}" alt="{$SITE_NAME}" style="max-width: 300px; margin-bottom: 30px; filter: drop-shadow(0 0 20px rgba(0,0,0,0.8));">
        {else}
            <h1 class="adv-hero-title">{$SITE_NAME}</h1>
        {/if}

        <p style="font-size: 1.2rem; color: var(--text-secondary); margin-bottom: 40px; letter-spacing: 1px;">
            {$PORTAL_INFO}
        </p>

        <div style="display: flex; flex-wrap: wrap; gap: 20px; justify-content: center;">
            <a href="{$PORTAL_INDEX}" class="adv-btn adv-btn--primary" style="font-size: 1.1rem; padding: 15px 40px;">
                <i class="fas fa-door-open" style="margin-right: 10px;"></i> Enter Website
            </a>
            <a href="{$PORTAL_STORE}" class="adv-btn" style="font-size: 1.1rem; padding: 15px 40px;">
                <i class="fas fa-shopping-cart" style="margin-right: 10px;"></i> Store
            </a>
            <a href="{$PORTAL_FORUM}" class="adv-btn" style="font-size: 1.1rem; padding: 15px 40px;">
                <i class="fas fa-comments" style="margin-right: 10px;"></i> Forums
            </a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/tsparticles-preset-firefly@2/tsparticles.preset.firefly.bundle.min.js"></script>
<script>
    tsParticles.load("particles-js", {
        preset: "firefly",
        background: { color: "transparent" },
        particles: { color: { value: "#E5A93C" }, number: { value: 60 } }
    });
</script>

</body>
</html>
