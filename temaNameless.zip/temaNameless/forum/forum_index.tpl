{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- Premium Forum Hero Banner -->
<header class="adv-hero" style="min-height: 40vh; height: auto; padding: 100px 0 50px 0; border-bottom: 2px solid var(--accent); box-shadow: 0 10px 30px rgba(0,0,0,0.8);">
    <div id="particles-js" style="opacity: 0.5;"></div>
    
    <div class="adv-hero-content" style="max-width: 1000px; width: 100%; margin: 0 auto; display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <!-- Breadcrumbs -->
        <div class="adv-hero-breadcrumbs">
            <i class="fas fa-home"></i> <a href="{$BREADCRUMB_URL}">{$BREADCRUMB_TEXT}</a>
        </div>
        
        <!-- Title -->
        <h1 class="adv-hero-title">
            {$TITLE}
        </h1>
        
        <!-- Search Bar (RPG Style) -->
        <form method="post" action="{$SEARCH_URL}" class="adv-hero-search-wrapper">
            <input type="hidden" name="token" value="{$TOKEN}">
            <input type="text" name="forum_search" class="adv-hero-search-input" placeholder="{$SEARCH}..." minlength="3" maxlength="128">
            <button type="submit" class="adv-hero-search-btn">
                <i class="fas fa-search"></i>
            </button>
        </form>
    </div>
</header>

<div class="adv-container mt-4 mb-4" style="margin-top: 50px;">
    <!-- Layout Grid -->
    <div class="adv-grid-2 {if isset($WIDGETS_LEFT) && is_array($WIDGETS_LEFT) && count($WIDGETS_LEFT)}has-left{/if}">
        
        {if isset($WIDGETS_LEFT) && is_array($WIDGETS_LEFT) && count($WIDGETS_LEFT)}
            <aside>
                {foreach from=$WIDGETS_LEFT item=widget}
                    {$widget}
                {/foreach}
            </aside>
        {/if}

        <main>
            <!-- Forum Quick Actions / Menu -->
            <div class="adv-card adv-flex-between mb-4" style="padding: 15px 25px;">
                <div style="display: flex; gap: 15px; flex-wrap: wrap; align-items: center;">
                    <a href="{$SEARCH_URL}" class="adv-btn adv-btn--primary" style="padding: 8px 20px;"><i class="fas fa-search"></i> {$SEARCH}</a>
                    {if isset($LOGGED_IN_USER)}
                        <a href="{$SITE_URL}/forum/search/?action=unread" class="adv-btn" style="padding: 8px 20px;"><i class="fas fa-layer-group"></i> Unread Posts</a>
                        <a href="{$SITE_URL}/forum/search/?action=recent" class="adv-btn" style="padding: 8px 20px;"><i class="fas fa-clock"></i> Recent Activity</a>
                    {/if}
                </div>
            </div>

            {if isset($SPAM_INFO)}
                <div class="adv-alert adv-alert--warning mb-4">
                    <strong><i class="fas fa-exclamation-triangle"></i> {$FORUM_SPAM_WARNING_TITLE}</strong><br>
                    {$SPAM_INFO}
                </div>
            {/if}

            {foreach from=$FORUMS key=category item=forum}
                {if !empty($forum.subforums)}
                    <div class="adv-card adv-stagger-cards mb-4">
                        <!-- Category Header -->
                        <h2 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 20px; border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px;">
                            <a href="{$forum.link}" style="color: inherit;">{$forum.title}</a>
                        </h2>

                        <!-- Subforums Loop -->
                        <div style="display: flex; flex-direction: column; gap: 15px;">
                            {foreach from=$forum.subforums item=subforum}
                                {if $subforum->redirect_forum neq 1}
                                    <!-- Normal Forum Node -->
                                    <div class="forum-node" style="display: flex; gap: 20px; padding: 15px; background: rgba(0,0,0,0.3); border: 1px solid var(--border-color); border-radius: var(--radius-sm); transition: all 0.3s ease;">
                                        
                                        <!-- Icon -->
                                        <div style="font-size: 2.5rem; color: var(--accent); opacity: 0.8; display: flex; align-items: center; justify-content: center; width: 60px;">
                                            {if empty($subforum->icon)}
                                                <i class="fas fa-comments"></i>
                                            {else}
                                                {$subforum->icon}
                                            {/if}
                                        </div>

                                        <!-- Info -->
                                        <div style="flex: 1;">
                                            <h3 style="margin: 0 0 5px 0;">
                                                <a href="{$subforum->link}" style="color: var(--text-primary); font-size: 1.3rem;">{$subforum->forum_title}</a>
                                            </h3>
                                            
                                            <div style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 8px;">
                                                {$TOPICS|capitalize}: <strong style="color: var(--text-primary);">{$subforum->topics}</strong> &middot; 
                                                {$POSTS|capitalize}: <strong style="color: var(--text-primary);">{$subforum->posts}</strong>
                                            </div>

                                            {if isset($subforum->subforums)}
                                                <div style="font-size: 0.85rem; color: var(--text-muted);">
                                                    <strong>{$SUBFORUMS}:</strong>
                                                    {assign i 1}
                                                    {foreach from=$subforum->subforums item=sub_subforum}
                                                        {if $i != 1}&middot; {/if}<a href="{$sub_subforum->link}" style="color: var(--text-secondary);">{$sub_subforum->title}</a>
                                                        {assign i $i+1}
                                                    {/foreach}
                                                </div>
                                            {/if}
                                        </div>

                                        <!-- Last Post -->
                                        <div style="width: 250px; text-align: right; border-left: 1px solid rgba(255,255,255,0.05); padding-left: 15px;">
                                            {if isset($subforum->last_post)}
                                                <div style="margin-bottom: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                                    <a href="{$subforum->last_post->link}" style="color: var(--text-primary); font-weight: 500;">
                                                        {$subforum->last_post->title}
                                                    </a>
                                                </div>
                                                <div style="display: flex; align-items: center; justify-content: flex-end; gap: 8px;">
                                                    <div style="font-size: 0.85rem; color: var(--text-secondary);">
                                                        <a style="{$subforum->last_post->user_style}" href="{$subforum->last_post->profile}">{$subforum->last_post->username}</a>
                                                        <br>
                                                        <span class="adv-tooltip" data-tooltip="{$subforum->last_post->post_date}">{$subforum->last_post->date_friendly}</span>
                                                    </div>
                                                    <img src="{$subforum->last_post->avatar}" alt="{$subforum->last_post->username}" class="adv-avatar" style="width: 32px; height: 32px;">
                                                </div>
                                            {else}
                                                <div style="color: var(--text-muted); font-style: italic; display: flex; align-items: center; justify-content: center; height: 100%;">
                                                    {$NO_TOPICS}
                                                </div>
                                            {/if}
                                        </div>

                                    </div>
                                {else}
                                    <!-- Redirect Node -->
                                    <div class="forum-node" style="display: flex; gap: 20px; padding: 15px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.05); border-radius: var(--radius-sm);">
                                        <div style="font-size: 2rem; color: var(--info); opacity: 0.6; display: flex; align-items: center; justify-content: center; width: 60px;">
                                            {if empty($subforum->icon)}<i class="fas fa-link"></i>{else}{$subforum->icon}{/if}
                                        </div>
                                        <div style="flex: 1; display: flex; align-items: center;">
                                            <h3 style="margin: 0;">
                                                <a href="{$subforum->redirect_url}" target="_blank" style="color: var(--info);">
                                                    {$subforum->forum_title} <i class="fas fa-external-link-alt" style="font-size: 0.8rem; margin-left: 5px;"></i>
                                                </a>
                                            </h3>
                                        </div>
                                    </div>
                                {/if}
                            {/foreach}
                        </div>
                    </div>
                {/if}
            {/foreach}
        </main>

        {if isset($WIDGETS_RIGHT) && is_array($WIDGETS_RIGHT) && count($WIDGETS_RIGHT)}
            <aside>
                {foreach from=$WIDGETS_RIGHT item=widget}
                    {$widget}
                {/foreach}
            </aside>
        {/if}

    </div>
</div>

<!-- Hover Animation Script for Forum Nodes -->
<script>
    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('.forum-node').forEach(node => {
            node.addEventListener('mouseenter', () => {
                node.style.background = 'rgba(212, 175, 55, 0.05)';
                node.style.borderColor = 'rgba(212, 175, 55, 0.3)';
                node.style.transform = 'translateY(-2px)';
            });
            node.addEventListener('mouseleave', () => {
                node.style.background = 'rgba(0,0,0,0.3)';
                node.style.borderColor = 'var(--border-color)';
                node.style.transform = 'translateY(0)';
            });
        });
    });
</script>

{include file='footer.tpl'}
