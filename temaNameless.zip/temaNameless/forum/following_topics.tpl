{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$USER_CP}
    </h1>

    {if isset($SUCCESS_MESSAGE)}
    <div class="adv-alert adv-alert--success">
        <i class="fas fa-check-circle"></i> <strong>{$SUCCESS}</strong><br />
        {$SUCCESS_MESSAGE}
    </div>
    {/if}

    <div class="adv-grid-2 has-left" id="following_topics">
        
        <!-- Navigation Sidebar -->
        <aside>
            {include file='user/navigation.tpl'}
        </aside>

        <!-- Main Content -->
        <main>
            <div class="adv-card adv-stagger-cards mb-4">
                <div style="border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                    <h3 style="margin: 0; color: var(--accent);">{$FOLLOWING_TOPICS}</h3>
                    {if count($TOPICS_LIST)}
                    <button type="button" class="adv-btn adv-btn--danger" style="padding: 5px 15px; font-size: 0.85rem;" data-toggle="modal" data-target="#modal-delete">
                        <i class="fas fa-trash-alt"></i> {$UNFOLLOW_ALL}
                    </button>
                    {/if}
                </div>

                <div style="display: flex; flex-direction: column; gap: 15px;">
                    {nocache}
                    {if count($TOPICS_LIST)}
                        {foreach from=$TOPICS_LIST item=topic}
                        <div style="display: flex; align-items: stretch; justify-content: space-between; flex-wrap: wrap; gap: 10px; padding: 15px; background: rgba(0,0,0,0.2); border: 1px solid var(--border); border-radius: var(--radius-sm); border-left: 3px solid {if $topic.unread}var(--accent){else}var(--border-light){/if}; transition: var(--transition);">
                            
                            <div style="flex: 1; min-width: 250px; cursor: pointer; display: flex; align-items: center;" onclick="window.location.href = '{$topic.last_post_link}'">
                                <div style="display: flex; align-items: center; gap: 15px;">
                                    {if $topic.unread}
                                    <i class="fas fa-bell" style="color: var(--accent); font-size: 1.2rem; filter: drop-shadow(0 0 5px var(--accent-glow));"></i>
                                    <strong style="color: var(--text-primary); font-size: 1.1rem;">{$topic.topic_title}</strong>
                                    {else}
                                    <i class="far fa-bell" style="color: var(--text-secondary); font-size: 1.2rem;"></i>
                                    <span style="color: var(--text-primary); font-size: 1.1rem;">{$topic.topic_title}</span>
                                    {/if}
                                </div>
                            </div>

                            <div style="display: flex; align-items: center; gap: 15px;">
                                <img src="{$topic.reply_author_avatar}" class="adv-avatar-nav" style="width: 35px; height: 35px; border-radius: 5px;">
                                <div>
                                    <a href="{$topic.reply_author_link}" data-toggle="popup" data-poload="{$USER_INFO_URL}{$topic.reply_author_id}" style="{$topic.reply_author_style}; font-weight: bold; display: block;">{$topic.reply_author_nickname}</a>
                                    <div style="color: var(--text-secondary); font-size: 0.8rem;" data-toggle="tooltip" data-content="{$topic.reply_date_full}">
                                        <i class="far fa-clock"></i> {$topic.reply_date}
                                    </div>
                                </div>
                            </div>

                            <div style="display: flex; align-items: center;">
                                <form action="{$topic.unfollow_link}" method="post" style="margin: 0;">
                                    <input type="hidden" value="{$TOKEN}" name="token" />
                                    <button class="adv-btn" style="background: rgba(231, 76, 60, 0.2); color: #e74c3c; border: 1px solid #e74c3c; padding: 6px 12px; font-size: 0.8rem;">
                                        <i class="fas fa-minus-circle"></i> {$UNFOLLOW_TOPIC}
                                    </button>
                                </form>
                            </div>

                        </div>
                        {/foreach}
                        
                        <div style="margin-top: 20px; text-align: center;">
                            {$PAGINATION}
                        </div>
                    {else}
                        <div class="adv-alert adv-alert--info">
                            <i class="fas fa-info-circle"></i> {$NO_TOPICS}
                        </div>
                    {/if}
                    {/nocache}
                </div>
            </div>
        </main>
        
    </div>
</div>

<div class="ui small modal" id="modal-delete">
    <div class="header">
        {$UNFOLLOW_ALL}
    </div>
    <div class="content">
        {$CONFIRM_UNFOLLOW}
    </div>
    <div class="actions">
        <a class="ui negative button">{$NO}</a>
        <form action="" method="post" style="display: inline">
            <input type="hidden" name="token" value="{$TOKEN}">
            <input type="hidden" name="action" value="purge">
            <input type="submit" class="ui green button" value="{$YES}">
        </form>
    </div>
</div>

{include file='footer.tpl'}
