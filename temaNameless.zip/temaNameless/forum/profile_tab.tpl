<h3 style="margin-top: 0; color: var(--accent); border-bottom: 2px solid rgba(212,175,55,0.2); padding-bottom: 10px; margin-bottom: 20px;">
    <i class="fas fa-comments"></i> {$PF_LATEST_POSTS_TITLE}
</h3>

{if isset($NO_POSTS)}
<div class="adv-alert adv-alert--info">
    <i class="fas fa-info-circle"></i> {$NO_POSTS}
</div>
{else}
    <div style="display: flex; flex-direction: column; gap: 15px;">
    {foreach from=$PF_LATEST_POSTS item=post}
        <div class="adv-post-card" style="background: rgba(0,0,0,0.2); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 15px; border-left: 3px solid var(--accent); transition: var(--transition);">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
                <h4 style="margin: 0; font-size: 1.1rem;">
                    <a href="{$post.link}" style="color: var(--text-primary); text-decoration: none; font-weight: bold; transition: color 0.2s;" onmouseover="this.style.color='var(--accent)'" onmouseout="this.style.color='var(--text-primary)'">{$post.title}</a>
                </h4>
                <div style="font-size: 0.85rem; color: var(--text-secondary); white-space: nowrap; margin-left: 15px;" data-toggle="tooltip" data-content="{$post.date_full}">
                    <i class="far fa-clock"></i> {$post.date_friendly}
                </div>
            </div>
            <div class="forum_post" style="color: var(--text-main); font-size: 0.95rem; line-height: 1.6;">
                {$post.content}
            </div>
        </div>
    {/foreach}
    </div>
{/if}
