{include file='header.tpl'}

<div class="adv-container" style="padding-top: var(--space-xl); margin-bottom: var(--space-3xl);">
    
    <!-- Breadcrumb -->
    {include file='forum/search.tpl'}
    
    <div style="font-family: var(--font-ui); font-size: 0.9rem; margin-bottom: var(--space-lg); color: var(--text-secondary);">
        <a href="{$FORUM_INDEX_LINK}" style="color: var(--accent);">Forums</a> 
        <i class="fas fa-chevron-right" style="font-size: 0.7rem; margin: 0 5px;"></i> 
        <span style="color: var(--text-primary);">{$FORUM_TITLE}</span>
    </div>

    <!-- Header Actions -->
    <div class="d-flex justify-between align-center mb-4">
        <div>
            <h1 class="adv-hero-title" style="margin: 0; font-size: 2.5rem;">{$FORUM_TITLE}</h1>
            {if !empty($FORUM_DESCRIPTION)}
                <p class="text-secondary">{$FORUM_DESCRIPTION}</p>
            {/if}
        </div>
        <div>
            {if $CAN_CREATE_TOPIC}
                <a href="{$NEW_TOPIC_LINK}" class="adv-btn adv-btn--primary"><i class="fas fa-pen"></i> New Topic</a>
            {/if}
        </div>
    </div>

    <!-- Topics List -->
    <div class="adv-card adv-stagger-cards" style="padding: 0; overflow: hidden;">
        <div style="background: rgba(212, 175, 55, 0.1); padding: var(--space-md) var(--space-lg); border-bottom: 1px solid var(--border-color); display: grid; grid-template-columns: 1fr 100px 200px;">
            <div style="font-weight: 600; font-family: var(--font-ui); text-transform: uppercase; font-size: 0.85rem; letter-spacing: 1px;">Topic</div>
            <div style="font-weight: 600; font-family: var(--font-ui); text-transform: uppercase; font-size: 0.85rem; letter-spacing: 1px; text-align: center;">Stats</div>
            <div style="font-weight: 600; font-family: var(--font-ui); text-transform: uppercase; font-size: 0.85rem; letter-spacing: 1px; text-align: right;">Last Reply</div>
        </div>

        {if count($LATEST_DISCUSSIONS)}
            {foreach from=$LATEST_DISCUSSIONS item=topic}
                <div style="display: grid; grid-template-columns: 1fr 100px 200px; padding: var(--space-md) var(--space-lg); border-bottom: 1px solid rgba(255,255,255,0.05); transition: background var(--transition-fast);">
                    
                    <!-- Topic Info -->
                    <div style="display: flex; gap: 15px; align-items: center;">
                        <div style="color: {if $topic.locked}var(--text-muted){elseif $topic.pinned}var(--accent){else}var(--text-secondary){/if}; font-size: 1.2rem; width: 24px; text-align: center;">
                            {if $topic.locked}
                                <i class="fas fa-lock"></i>
                            {elseif $topic.pinned}
                                <i class="fas fa-thumbtack"></i>
                            {else}
                                <i class="fas fa-comment"></i>
                            {/if}
                        </div>
                        <div>
                            {if isset($topic.labels) && count($topic.labels)}
                                <div style="margin-bottom: 4px;">
                                    {foreach from=$topic.labels item=label}
                                        {$label}
                                    {/foreach}
                                </div>
                            {/if}
                            <a href="{$topic.link}" style="font-family: var(--font-display); font-size: 1.2rem; color: var(--text-primary); text-decoration: none;">{$topic.topic_title}</a>
                            <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 5px;">
                                Started by <a href="{$topic.topic_created_username_link}" style="color: {$topic.topic_created_color};">{$topic.topic_created_username}</a> &bull; {$topic.topic_created}
                            </div>
                        </div>
                    </div>

                    <!-- Topic Stats -->
                    <div style="display: flex; flex-direction: column; justify-content: center; align-items: center; color: var(--text-secondary); font-size: 0.85rem;">
                        <div><strong style="color: var(--text-primary);">{$topic.views}</strong> Views</div>
                        <div><strong style="color: var(--text-primary);">{$topic.replies}</strong> Replies</div>
                    </div>

                    <!-- Last Post -->
                    <div style="display: flex; flex-direction: column; justify-content: center; align-items: flex-end; font-size: 0.85rem; color: var(--text-secondary); text-align: right;">
                        <a href="{$topic.last_reply_link}" class="adv-tooltip" data-tooltip="View Last Reply">
                            <img src="{$topic.last_reply_avatar}" style="width: 24px; height: 24px; border-radius: 4px; vertical-align: middle; margin-bottom: 4px;">
                        </a>
                        <div>
                            <a href="{$topic.last_reply_profile_link}" style="color: {$topic.last_reply_color}; font-weight: 500;">{$topic.last_reply_username}</a>
                        </div>
                        <div style="color: var(--text-muted);">{$topic.last_reply}</div>
                    </div>

                </div>
            {/foreach}
        {else}
            <div style="padding: var(--space-2xl); text-align: center; color: var(--text-secondary);">
                <i class="fas fa-wind" style="font-size: 3rem; opacity: 0.2; margin-bottom: 15px;"></i>
                <p>No adventurers have chronicled here yet.</p>
            </div>
        {/if}
    </div>

    <!-- Pagination -->
    {if isset($PAGINATION)}
        <div class="mt-4" style="text-align: right;">
            {$PAGINATION}
        </div>
    {/if}

</div>

{include file='footer.tpl'}
