{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container" style="padding-top: var(--space-xl); margin-bottom: var(--space-3xl);">

    <!-- Breadcrumb -->
    <div style="font-family: var(--font-ui); font-size: 0.9rem; margin-bottom: var(--space-lg); color: var(--text-secondary);">
        {assign i 1}
        {foreach from=$BREADCRUMBS item=breadcrumb}
            {if $i ne 1}<i class="fas fa-chevron-right" style="font-size: 0.7rem; margin: 0 5px; opacity: 0.5;"></i>{/if}
            <a href="{$breadcrumb.link}" style="{if isset($breadcrumb.active)}color: var(--text-primary); font-weight: bold;{else}color: var(--accent);{/if}">{$breadcrumb.forum_title}</a>
            {assign i $i+1}
        {/foreach}
    </div>

    <!-- Topic Header -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; flex-wrap: wrap; gap: 15px;">
        <div>
            {if count($TOPIC_LABELS)}
                <div style="margin-bottom: 8px;">
                    {foreach from=$TOPIC_LABELS item=label}{$label} {/foreach}
                </div>
            {/if}
            <h1 class="adv-hero-title" style="margin: 0; font-size: 2.2rem; display: flex; align-items: center; gap: 10px;">
                {if isset($TOPIC_LOCKED)}<i class="fas fa-lock" style="font-size: 1.2rem; color: #e74c3c;"></i>{/if}
                {$TOPIC_TITLE}
            </h1>
            <div style="font-size: 0.9rem; color: var(--text-secondary); margin-top: 5px;">
                {$STARTED_BY}
            </div>
        </div>
        <div>
            {if isset($REPLY_LINK)}
                <a href="#reply-section" class="adv-btn adv-btn--primary" onclick="document.getElementById('reply-section').scrollIntoView({ behavior: 'smooth' });"><i class="fas fa-reply"></i> Reply</a>
            {/if}
        </div>
    </div>

    <!-- Notices -->
    {if isset($SESSION_SUCCESS_POST)}
        <div class="adv-alert adv-alert--success mb-4">
            <strong><i class="fas fa-check"></i> {$SUCCESS}</strong><br>{$SESSION_SUCCESS_POST}
        </div>
    {/if}
    {if isset($ERRORS)}
        <div class="adv-alert adv-alert--danger mb-4">
            <strong><i class="fas fa-exclamation-triangle"></i> {$ERROR_TITLE}</strong>
            <ul style="margin-top: 5px; margin-bottom: 0;">
                {foreach from=$ERRORS item=error}<li>{$error}</li>{/foreach}
            </ul>
        </div>
    {/if}
    {if isset($TOPIC_LOCKED_NOTICE) || isset($TOPIC_LOCKED)}
        <div class="adv-alert adv-alert--warning mb-4">
            <i class="fas fa-lock"></i> {if isset($TOPIC_LOCKED_NOTICE)}{$TOPIC_LOCKED_NOTICE}{else}{$TOPIC_LOCKED}{/if}
        </div>
    {/if}

    <!-- Pagination Top -->
    {if isset($PAGINATION)}
        <div style="display: flex; justify-content: flex-end; margin-bottom: 15px;">
            {$PAGINATION}
        </div>
    {/if}

    <!-- Posts Wrapper -->
    <div class="adv-posts-wrapper">
        {foreach from=$REPLIES item=reply}
            <div id="post-{$reply.id}" class="adv-post-card">
                
                <!-- Author Sidebar -->
                <div class="adv-post-sidebar">
                    <a href="{$reply.profile}">
                        <img src="{$reply.avatar}" alt="{$reply.username}" class="adv-avatar" style="width: 80px; height: 80px; margin-bottom: 10px; border-radius: 8px;">
                    </a>
                    
                    <div style="font-family: var(--font-display); font-size: 1.15rem; margin-bottom: 4px; font-weight: bold;">
                        <a href="{$reply.profile}" style="{$reply.user_style}">{$reply.username}</a>
                    </div>
                    
                    {if isset($reply.user_title)}
                        <div style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 8px;">{$reply.user_title}</div>
                    {/if}

                    <div style="margin-bottom: 15px;">
                        {foreach from=$reply.user_groups item=group}
                            {$group}
                        {/foreach}
                    </div>

                    <div style="font-size: 0.8rem; color: var(--text-secondary); text-align: left; background: rgba(0,0,0,0.15); padding: 10px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;"><span>Joined:</span> <span style="color: var(--text-primary);">{$reply.user_registered|regex_replace:'/[:].*/':''}</span></div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;"><span>Posts:</span> <span style="color: var(--text-primary);">{$reply.user_posts_count|regex_replace:'/[^0-9]+/':''}</span></div>
                        <div style="display: flex; justify-content: space-between;"><span>Topics:</span> <span style="color: var(--text-primary);">{$reply.user_topics_count|regex_replace:'/[^0-9]+/':''}</span></div>
                    </div>
                </div>

                <!-- Post Content -->
                <div class="adv-post-content-wrap">
                    <!-- Post Header -->
                    <div class="adv-post-header">
                        <div>
                            <span title="{$reply.post_date}"><i class="fas fa-clock"></i> {$reply.post_date_rough}</span>
                        </div>
                        <div>
                            <a href="{$reply.url}" style="color: inherit;">#{$reply.id}</a>
                        </div>
                    </div>

                    <!-- Post Body -->
                    <div class="adv-post-body forum_post">
                        {$reply.content}
                        
                        {if $reply.edited !== null}
                            <div style="margin-top: 15px; font-size: 0.85rem; color: var(--text-muted); font-style: italic; opacity: 0.8;">
                                <i class="fas fa-pencil-alt"></i> Last edited: {$reply.edited}
                            </div>
                        {/if}
                    </div>

                    <!-- Signature Area -->
                    {if !empty($reply.signature)}
                        <div style="padding: 10px 20px; border-top: 1px dashed var(--border-light); color: var(--text-secondary); opacity: 0.8; font-size: 0.9rem; max-height: 150px; overflow-y: auto;">
                            {$reply.signature}
                        </div>
                    {/if}

                    <!-- Post Footer / Actions -->
                    <div class="adv-post-footer">
                        {if isset($reply.buttons.spam)}
                            <button class="adv-btn" data-toggle="modal" data-target="#modal-spam-{$reply.id}" title="{$reply.buttons.spam.TEXT}" style="padding: 5px 10px; font-size: 0.85rem;"><i class="fas fa-flag"></i></button>
                        {/if}
                        {if isset($reply.buttons.edit)}
                            <a class="adv-btn" href="{$reply.buttons.edit.URL}" title="{$reply.buttons.edit.TEXT}" style="padding: 5px 10px; font-size: 0.85rem;"><i class="fas fa-edit"></i> Edit</a>
                        {/if}
                        {if isset($reply.buttons.delete)}
                            <button class="adv-btn" data-toggle="modal" data-target="#modal-delete-{$reply.id}" title="{$reply.buttons.delete.TEXT}" style="padding: 5px 10px; font-size: 0.85rem; color: #e74c3c;"><i class="fas fa-trash"></i></button>
                        {/if}
                        {if isset($reply.buttons.report)}
                            <button class="adv-btn" data-toggle="modal" data-target="#modal-report-{$reply.id}" title="{$reply.buttons.report.TEXT}" style="padding: 5px 10px; font-size: 0.85rem;"><i class="fas fa-exclamation-triangle"></i></button>
                        {/if}
                        {if isset($reply.buttons.quote)}
                            <button class="adv-btn adv-btn--primary" onclick="quote({$reply.id})" title="{$reply.buttons.quote.TEXT}" style="padding: 5px 15px; font-size: 0.85rem;"><i class="fas fa-quote-left"></i> Quote</button>
                        {/if}
                    </div>
                </div>

            </div>
        {/foreach}
    </div>

    <!-- Pagination Bottom -->
    {if isset($PAGINATION)}
        <div style="display: flex; justify-content: flex-end; margin-top: 15px;">
            {$PAGINATION}
        </div>
    {/if}

    <!-- Quick Reply Form -->
    {if isset($CAN_REPLY)}
        <div id="reply-section" class="adv-card mt-4">
            <h3 style="margin-bottom: var(--space-md); color: var(--accent); border-bottom: 1px solid var(--border); padding-bottom: 10px;"><i class="fas fa-comment-dots"></i> {$REPLY} / Quick Reply</h3>
            <form action="" method="post" style="display: flex; flex-direction: column; gap: 15px;">
                <div>
                    <textarea name="content" id="quickreply" class="adv-input" style="min-height: 150px; background: rgba(0,0,0,0.15);" placeholder="Write your adventurous chronicle here..."></textarea>
                </div>
                <div>
                    <input type="hidden" name="token" value="{$TOKEN}">
                    <button type="submit" class="adv-btn adv-btn--primary">{$SUBMIT}</button>
                </div>
            </form>
        </div>
    {/if}

</div>

{include file='footer.tpl'}
