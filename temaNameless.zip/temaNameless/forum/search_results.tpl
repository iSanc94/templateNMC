{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 50px; min-height: 60vh;">
    
    <div class="adv-flex-between mb-4" style="align-items: center; border-bottom: 2px solid var(--border-light); padding-bottom: 15px;">
        <h1 class="adv-hero-title" style="margin: 0; font-size: 2rem;">
            {$SEARCH_RESULTS}
        </h1>
        <a href="{$NEW_SEARCH_URL}" class="adv-btn adv-btn--primary">
            <i class="fas fa-search"></i> {$NEW_SEARCH}
        </a>
    </div>

    {if isset($PAGINATION)}
        <div style="margin-bottom: 15px;">{$PAGINATION}</div>
    {/if}

    {if empty($RESULTS)}
        <div class="adv-card" style="text-align: center; padding: 50px;">
            <i class="fas fa-search-minus" style="font-size: 4rem; color: var(--text-muted); opacity: 0.5; margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">{$NO_RESULTS}</h3>
        </div>
    {else}
        <div style="display: flex; flex-direction: column; gap: 20px;">
            {foreach from=$RESULTS item=result}
                <div class="adv-card adv-post-card" style="flex-direction: column; position: relative;">
                    <!-- Post Header -->
                    <div style="padding: 15px 20px; border-bottom: 1px solid var(--border-light); display: flex; justify-content: space-between; align-items: center; background: rgba(0,0,0,0.2);">
                        <div>
                            <h3 style="margin: 0; font-family: var(--font-display);">
                                <a href="{$result.post_url}" style="color: var(--text-primary); text-decoration: none;">{$result.topic_title}</a>
                            </h3>
                            <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 5px;">
                                <i class="fas fa-user"></i> <a href="{$result.post_author_profile}" style="{$result.post_author_style}">{$result.post_author}</a>
                                &nbsp;&middot;&nbsp;
                                <i class="fas fa-clock"></i> <span class="adv-tooltip" data-tooltip="{$result.post_date_full}">{$result.post_date_friendly}</span>
                            </div>
                        </div>
                    </div>

                    <!-- Post Content Highlight -->
                    <div style="padding: 20px; color: var(--text-secondary); line-height: 1.6;">
                        <div class="forum-bbcode-content">
                            {$result.content}
                        </div>
                    </div>

                    <!-- Action Footer -->
                    <div style="padding: 10px 20px; border-top: 1px solid var(--border-light); display: flex; justify-content: flex-end; background: rgba(0,0,0,0.1);">
                        <a href="{$result.post_url}" class="adv-btn adv-btn--primary adv-btn--sm">
                            <i class="fas fa-book-reader" style="margin-right: 5px;"></i> {$READ_FULL_POST}
                        </a>
                    </div>
                </div>
            {/foreach}
        </div>
    {/if}

    {if isset($PAGINATION)}
        <div style="margin-top: 20px;">{$PAGINATION}</div>
    {/if}

</div>

{include file='footer.tpl'}
