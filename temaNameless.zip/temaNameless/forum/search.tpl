{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 50px; min-height: 60vh;">
    <!-- Breadcrumbs & Header -->
    <h1 class="adv-hero-title mb-4" style="text-align: center;">
        <i class="fas fa-search"></i> {$FORUM_SEARCH}
    </h1>

    {if isset($ERROR)}
        <div class="adv-alert adv-alert--danger mb-4">
            <strong><i class="fas fa-exclamation-triangle"></i> {$ERROR_TITLE}</strong><br>
            {$ERROR}
        </div>
    {/if}

    <div class="adv-card" style="padding: 40px; max-width: 600px; margin: 0 auto; text-align: center; box-shadow: var(--shadow-md);">
        <h3 style="color: var(--text-primary); margin-bottom: 20px; font-weight: normal;">{$SEARCH}</h3>
        <form action="" method="post" id="form-forum-search">
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <input type="hidden" name="token" value="{$TOKEN}">
                <input type="text" name="forum_search" class="adv-input" placeholder="{$SEARCH}..." style="flex: 1; min-width: 250px;">
                <button type="submit" class="adv-btn adv-btn--primary">
                    <i class="fas fa-search"></i> {$SEARCH}
                </button>
            </div>
        </form>
    </div>
</div>

{include file='footer.tpl'}
