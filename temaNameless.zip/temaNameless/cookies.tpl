{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 50px;">
    <div class="adv-card">
        <h1 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 15px;">{$COOKIE_POLICY}</h1>
        <div class="forum_post" style="color: var(--text-main); line-height: 1.8;">
            {if isset($COOKIE_POLICY_TEXT)}
                {$COOKIE_POLICY_TEXT}
            {else}
                This site uses cookies to ensure you get the best experience on our website.
            {/if}
        </div>
    </div>
</div>

{include file='footer.tpl'}
