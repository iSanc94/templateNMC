<!-- Premium Navbar (Glassmorphism + GSAP Optimized) -->
<nav class="adv-navbar">
    <div class="adv-navbar-inner">
        <!-- Hamburger Menu -->
        <button class="adv-mobile-toggle" onclick="document.getElementById('adv-mobile-nav').classList.toggle('mobile-active')">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Brand Logo -->
        <a href="{$SITE_HOME}" class="adv-logo-text">{$SITE_NAME}</a>

        <!-- Wrapper for Mobile Sidebar -->
        <div class="adv-nav-wrapper" id="adv-mobile-nav">
        
            <!-- Main Links -->
            <div class="adv-nav">
            {foreach from=$NAV_LINKS key=name item=item}
                {if isset($item.items)}
                    <!-- Dropdown Item -->
                    <div class="adv-dropdown-container">
                        <span class="adv-nav-link {if isset($item.active)}active{/if}">
                            {if isset($item.icon) && !empty($item.icon)}
                                {$item.icon}
                            {elseif $name == 'home'}
                                <i class="fas fa-home"></i>
                            {elseif $name == 'forum'}
                                <i class="fas fa-comments"></i>
                            {elseif $name == 'members'}
                                <i class="fas fa-users"></i>
                            {elseif $name == 'store'}
                                <i class="fas fa-shopping-cart"></i>
                            {elseif $name == 'vote'}
                                <i class="fas fa-thumbs-up"></i>
                            {/if}
                            <span style="margin-left: 8px;">{$item.title}</span> <i class="fas fa-chevron-down" style="margin-left: 6px; font-size: 0.75rem; opacity: 0.7;"></i>
                        </span>
                        <div class="adv-dropdown-menu">
                            {foreach from=$item.items item=dropdown}
                                <a href="{$dropdown.link}" target="{$dropdown.target}" class="adv-dropdown-item">
                                    {if isset($dropdown.icon) && !empty($dropdown.icon)}{$dropdown.icon} {else}<i class="fas fa-caret-right" style="opacity: 0.5;"></i> {/if}{$dropdown.title}
                                </a>
                            {/foreach}
                        </div>
                    </div>
                {else}
                    <!-- Single Item -->
                    <a href="{$item.link}" target="{$item.target}" class="adv-nav-link {if isset($item.active)}active{/if}">
                        {if isset($item.icon) && !empty($item.icon)}
                            {$item.icon}
                        {elseif $name == 'home'}
                            <i class="fas fa-compass"></i>
                        {elseif $name == 'forum'}
                            <i class="fas fa-scroll"></i>
                        {elseif $name == 'members'}
                            <i class="fas fa-users"></i>
                        {elseif $name == 'store'}
                            <i class="fas fa-gem"></i>
                        {elseif $name == 'vote'}
                            <i class="fas fa-star"></i>
                        {/if}
                        <span style="margin-left: 8px;">{$item.title}</span>
                    </a>
                {/if}
            {/foreach}
        </div>

        <!-- User Controls / Auth -->
        <div class="adv-user-section">
            {foreach from=$USER_SECTION key=name item=item}
                {if isset($item.items)}
                    <!-- User Dropdown (Avatar) -->
                    <div class="adv-dropdown-container">
                        <span class="adv-nav-link" style="border: none; padding: 0;">
                            {if $name eq 'account' && isset($LOGGED_IN_USER)}
                                <img src="{$LOGGED_IN_USER.avatar}" alt="{$LOGGED_IN_USER.username}" class="adv-avatar-nav">
                            {else}
                                {if isset($item.icon) && !empty($item.icon)}
                                    <div style="font-size: 1.3rem; padding: 0 5px; color: var(--text-secondary); transition: var(--transition);" onmouseover="this.style.color='var(--accent)'" onmouseout="this.style.color='var(--text-secondary)'">
                                        {$item.icon}
                                    </div>
                                {else}
                                    {$item.title}
                                {/if}
                            {/if}
                        </span>
                        <div class="adv-dropdown-menu">
                            <!-- User Prefix Header -->
                            {if isset($LOGGED_IN_USER)}
                                <div style="padding: 15px 20px; border-bottom: 1px solid var(--border-light); margin-bottom: 5px;">
                                    <strong style="color: var(--text-primary); font-size: 1.05rem;">{$LOGGED_IN_USER.username}</strong>
                                    {* Using typical Nameless variable for group name *}
                                </div>
                            {/if}

                            <!-- Dropdown Links -->
                            {foreach from=$item.items item=dropdown}
                                {if isset($dropdown.separator)}
                                    <div style="height: 1px; background: var(--border-light); margin: 8px 0;"></div>
                                {else}
                                    <a href="{$dropdown.link}" target="{$dropdown.target}" class="adv-dropdown-item">
                                        {if isset($dropdown.icon) && !empty($dropdown.icon)}
                                            {$dropdown.icon} 
                                        {else}
                                            <i class="fas fa-circle" style="font-size: 0.4rem; opacity: 0.5;"></i> 
                                        {/if}
                                        {$dropdown.title}
                                    </a>
                                {/if}
                            {/foreach}
                        </div>
                    </div>
                {else}
                    <!-- Action Buttons (Login / Register) -->
                    <a href="{$item.link}" target="{$item.target}" class="adv-btn {if $name eq 'login'}adv-btn--primary{/if}" style="padding: 10px 22px; font-size: 0.85rem; letter-spacing: 1.5px;">
                        {$item.title}
                    </a>
                {/if}
            {/foreach}
        </div>
        </div> <!-- End Mobile Wrapper -->
        
    </div>
</nav>

<!-- Mobile Dropdown Logic -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    // Add click events to dropdown containers on mobile (both Main Nav and User Section)
    const dropdowns = document.querySelectorAll('#adv-mobile-nav .adv-dropdown-container');
    dropdowns.forEach(dropdown => {
        dropdown.addEventListener('click', function(e) {
            if (window.innerWidth <= 1000) {
                // Toggle open state
                this.classList.toggle('mobile-open');
                
                // Prevent link navigation if it has a submenu, so it acts as an accordion toggle
                if(e.target.closest('.adv-nav-link')) {
                    e.preventDefault();
                }
            }
        });
    });
});
</script>

<!-- Page Content Wrapper Ends in footer.tpl -->
<div class="adv-main-content">
