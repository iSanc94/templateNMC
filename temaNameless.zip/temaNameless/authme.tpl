{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 60px; min-height: 60vh; display: flex; align-items: center; justify-content: center;">
    <div class="adv-card" style="width: 100%; max-width: 500px; padding: 40px;">
        <h1 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 15px; text-align: center;">
            <i class="fas fa-server"></i> {$CONNECT_WITH_AUTHME}
        </h1>
        <p style="text-align: center; color: var(--text-secondary); margin-bottom: 25px; font-size: 0.95rem;">
            {$AUTHME_INFO}
        </p>

        {if isset($ERRORS)}
            <div class="adv-alert adv-alert--error mb-4">
                {foreach from=$ERRORS item=error}
                    {$error}<br />
                {/foreach}
            </div>
        {/if}

        <form action="" method="post">
            <div style="margin-bottom: 20px;">
                <label for="username" style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main);">{$USERNAME}</label>
                <input type="text" name="username" id="username" class="adv-input" placeholder="{$USERNAME}" tabindex="1">
            </div>

            <div style="margin-bottom: 25px;">
                <label for="password" style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-main);">{$PASSWORD}</label>
                <input type="password" name="password" id="password" class="adv-input" placeholder="{$PASSWORD}" tabindex="2">
            </div>

            <input type="hidden" name="token" value="{$TOKEN}">
            
            <button type="submit" class="adv-btn adv-btn--primary" style="width: 100%;" tabindex="3">
                {$SUBMIT} <i class="fas fa-sign-in-alt" style="margin-left: 5px;"></i>
            </button>
        </form>
    </div>
</div>

{include file='footer.tpl'}
