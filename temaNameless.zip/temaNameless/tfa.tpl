{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 60px; min-height: 60vh; display: flex; align-items: center; justify-content: center;">
    <div class="adv-card" style="width: 100%; max-width: 500px; padding: 40px; border-color: rgba(229,169,60,0.4);">
        <h1 style="font-family: var(--font-display); color: var(--accent); margin-bottom: 15px; text-align: center;">
            <i class="fas fa-shield-alt"></i> {$TWO_FACTOR_AUTH}
        </h1>
        <p style="text-align: center; color: var(--text-secondary); margin-bottom: 25px; font-size: 0.95rem;">
            {$TFA_ENTER_CODE}
        </p>

        {if isset($ERROR)}
            <div class="adv-alert adv-alert--error mb-4">
                {$ERROR}
            </div>
        {/if}

        <form action="" method="post">
            <div style="margin-bottom: 25px;">
                <input type="text" name="tfa_code" class="adv-input" style="font-size: 2rem; text-align: center; letter-spacing: 5px; font-family: monospace;" placeholder="000000" tabindex="1">
            </div>

            <input type="hidden" name="token" value="{$TOKEN}">
            
            <button type="submit" class="adv-btn adv-btn--primary" style="width: 100%;" tabindex="2">
                {$SUBMIT} <i class="fas fa-key" style="margin-left: 5px;"></i>
            </button>
        </form>
    </div>
</div>

{include file='footer.tpl'}
