{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 50px; min-height: 70vh;">
    
    <!-- Hero Header -->
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$CONTACT}
    </h1>

    <div class="adv-card" style="max-width: 600px; margin: 0 auto; padding: 40px 30px;">
        
        {if isset($SUCCESS)}
            <div class="adv-alert adv-alert--success mb-4">
                <strong><i class="fas fa-check-circle"></i> Sukses</strong><br>
                {$SUCCESS}
            </div>
        {/if}

        {if isset($ERRORS) && count($ERRORS)}
            <div class="adv-alert adv-alert--danger mb-4">
                <strong><i class="fas fa-exclamation-circle"></i> Error</strong><br>
                <ul style="margin: 5px 0 0 20px;">
                    {foreach from=$ERRORS item=error}
                        <li>{$error}</li>
                    {/foreach}
                </ul>
            </div>
        {/if}
        {if isset($ERROR)}
            <div class="adv-alert adv-alert--danger mb-4">
                <strong><i class="fas fa-exclamation-circle"></i> Error</strong><br>
                {$ERROR}
            </div>
        {/if}

        <form action="" method="post" id="form-contact" style="display: flex; flex-direction: column; gap: 20px;">
            <div class="adv-form-group">
                <label for="inputEmail" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$EMAIL}</label>
                <input type="email" name="email" id="inputEmail" class="adv-input" placeholder="{$EMAIL}">
            </div>

            <div class="adv-form-group">
                <label for="inputMessage" style="color: var(--text-secondary); margin-bottom: 8px; display: block; font-weight: bold;">{$MESSAGE}</label>
                <textarea name="content" id="inputMessage" class="adv-input" placeholder="{$MESSAGE}" style="min-height: 150px;"></textarea>
            </div>

            {if isset($RECAPTCHA)}
                <div class="adv-form-group" style="display: flex; justify-content: center; margin: 10px 0;">
                    {$RECAPTCHA}
                </div>
            {/if}

            <div style="border-top: 1px solid var(--border-light); padding-top: 20px; text-align: center;">
                <input type="hidden" name="token" value="{$TOKEN}">
                <button type="submit" class="adv-btn adv-btn--primary" style="min-width: 200px; padding: 12px 30px; font-size: 1.1rem;">
                    <i class="fas fa-paper-plane" style="margin-right: 8px;"></i> {$SUBMIT}
                </button>
            </div>
        </form>

    </div>

</div>

{include file='footer.tpl'}
