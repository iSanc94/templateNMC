{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="min-height: 70vh;">
    <h1 class="adv-hero-title" style="margin-bottom: var(--space-xl);">
        {$MEMBERS}
    </h1>

    {if isset($ERROR)}
        <div class="adv-alert adv-alert--error mb-4">
            <strong>{$ERROR_TITLE}</strong><br>{$ERROR}
        </div>
    {/if}

    <div style="display: flex; flex-wrap: wrap;">
        <!-- Sidebar -->
        <aside style="flex: 1; min-width: 250px; margin-right: 25px; margin-bottom: 25px;">
            <!-- Category Navigation -->
            <div class="adv-card mb-4" style="padding: 10px;">
                <div style="display: flex; flex-direction: column; padding: 10px 5px;">
                    <a class="adv-btn {if $VIEWING_LIST eq "overview"}adv-btn--primary{/if}" style="justify-content: flex-start !important; width: 100%; text-align: left; margin-bottom: 12px; padding: 12px 15px; {if $VIEWING_LIST neq "overview"}background: transparent; border-color: transparent; color: var(--text-primary);{/if}" href="{$MEMBER_LIST_URL}">
                        <i class="fas fa-users" style="width: 25px; text-align: center; margin-right: 5px;"></i> {$OVERVIEW}
                    </a>
                    {foreach from=$SIDEBAR_MEMBER_LISTS item=list}
                        <a class="adv-btn {if $VIEWING_LIST eq $list->getName()}adv-btn--primary{/if}" style="justify-content: flex-start !important; width: 100%; text-align: left; margin-bottom: 12px; padding: 12px 15px; {if $VIEWING_LIST neq $list->getName()}background: transparent; border-color: transparent; color: var(--text-primary);{/if}" href="{$list->url()}">
                            <i class="{if $list->getIcon()}{$list->getIcon()}{else}fas fa-circle{/if}" style="width: 25px; text-align: center; margin-right: 5px;"></i> {$list->getFriendlyName()}
                        </a>
                    {/foreach}
                </div>
            </div>

            <!-- Find Member -->
            <div class="adv-card mb-4">
                <h3 style="margin-top: 0; color: var(--accent);">{$FIND_MEMBER}</h3>
                <div class="ui search">
                    <div style="position: relative;">
                        <input class="adv-input prompt" type="text" minlength="2" required placeholder="{$NAME}" autocomplete="off" style="padding-left: 35px; width: 100%;">
                        <i class="fas fa-search" style="position: absolute; left: 10px; top: 10px; color: var(--text-secondary);"></i>
                    </div>
                    <div class="results" style="background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--border-color); border-radius: 4px; position: absolute; z-index: 10;"></div>
                </div>
            </div>

            <!-- View Group -->
            {if $GROUPS|count}
                <div class="adv-card mb-4">
                    <h3 style="margin-top: 0; color: var(--accent);">{$VIEW_GROUP}</h3>
                    <select class="adv-input" onchange="window.location.href = '{$VIEW_GROUP_URL}' + this.value;">
                        <option value="">{$GROUP}</option>
                        {foreach from=$GROUPS item=group}
                            <option value="{$group.id}" style="color: black;" {if $VIEWING_GROUP.id == $group.id} selected {/if}>{$group.name}</option>
                        {/foreach}
                    </select>
                </div>
            {/if}

            <!-- Newest Members grid -->
            <div class="adv-card mb-4">
                <h3 style="margin-top: 0; color: var(--accent);">{$NEW_MEMBERS}</h3>
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px;" id="new-members-grid">
                    {foreach from=$NEW_MEMBERS_VALUE item=member}
                        <a href="{$member->getProfileUrl()}" data-tooltip="{$member->getDisplayname()}" style="display: block;">
                            <img src="{$member->getAvatar()}" alt="{$member->getDisplayname()}" class="adv-avatar" style="width: 100%; aspect-ratio: 1/1;">
                        </a>
                    {/foreach}
                </div>
            </div>
        </aside>

        <!-- Main Lists View -->
        <main style="flex: 3; min-width: 300px;">
            {if $VIEWING_LIST == "group" || $MEMBER_LISTS_VIEWING|count}
                <div class="adv-card" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: var(--space-xl);">
                    
                    {if $VIEWING_LIST == "group"}
                        <div style="width: 100%;">
                            <h2 style="font-family: var(--font-display); border-bottom: 2px solid rgba(255,255,255,0.1); padding-bottom: 10px;">{$VIEWING_GROUP.name}</h2>
                            <ul id="member_list_group_{$VIEWING_GROUP.id}" style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 10px;">
                            </ul>
                            <div class="adv-pagination-wrapper" style="margin-top: 30px; display: flex; justify-content: center; width: 100%;">
                                {$PAGINATION}
                            </div>
                        </div>
                    {else}
                        {foreach from=$MEMBER_LISTS_VIEWING item=list}
                            <div style="width: 100%;">
                                <h2 style="font-family: var(--font-display); border-bottom: 2px solid rgba(255,255,255,0.1); padding-bottom: 10px; color: var(--accent);">{$list->getFriendlyName()}</h2>
                                <ul id="member_list_{$list->getName()}" style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 10px;">
                                </ul>
                                
                                <div class="adv-pagination-wrapper" style="margin-top: 30px; display: flex; justify-content: center; width: 100%;">
                                    {if $VIEWING_LIST == "overview"}
                                        <a href="{$list->url()}" class="adv-btn" style="width: 100%; max-width: 300px; text-align: center; border-color: rgba(255,255,255,0.2);">{$VIEW_ALL}</a>
                                    {else}
                                        {$PAGINATION}
                                    {/if}
                                </div>
                            </div>
                        {/foreach}
                    {/if}
                    
                </div>
            {else}
                <div class="adv-alert adv-alert--warning">{$NO_OVERVIEW_LISTS_ENABLED}</div>
            {/if}
        </main>
    </div>
</div>

<!-- Render Scripts exactly like DefaultRevamp, modified DOM class injection -->
<script type="text/javascript">
    const renderList = (name) => {
        const list = document.getElementById('member_list_' + name);
        if(!list) return;

        list.innerHTML = '<div style="text-align:center; padding: 20px;"><i class="fas fa-spinner fa-spin fa-2x"></i></div>';

        fetch(
            '{$QUERIES_URL}'
                .replace({literal}'{{list}}'{/literal}, name)
                .replace({literal}'{{page}}'{/literal}, new URLSearchParams(window.location.search).get('p') ?? 1)
        )
        .then(async response => {
            const data = await response.json();
            if (data.length === 0) {
                list.parentElement.innerHTML = '<div class="adv-alert adv-alert--warning" style="margin-top: 20px;">{$NO_MEMBERS_FOUND}</div>';
                return;
            }

            // Transform UL into a Grid container
            list.style.display = 'grid';
            list.style.gridTemplateColumns = 'repeat(auto-fill, minmax(220px, 1fr))';
            list.style.gap = '20px';
            list.style.padding = '10px';
            list.innerHTML = '';

            for (const member of data) {
                const mainDiv = document.createElement('li');
                mainDiv.classList.add('adv-card');
                mainDiv.style.display = 'flex';
                mainDiv.style.flexDirection = 'column';
                mainDiv.style.alignItems = 'center';
                mainDiv.style.justifyContent = 'center';
                mainDiv.style.padding = '30px 20px';
                mainDiv.style.borderTop = '3px solid var(--accent)';
                mainDiv.style.cursor = 'pointer';
                mainDiv.style.transition = 'all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
                mainDiv.style.position = 'relative';
                
                mainDiv.addEventListener('mouseenter', () => {
                    mainDiv.style.transform = 'translateY(-10px)';
                    mainDiv.style.boxShadow = 'var(--shadow-lg)';
                });
                mainDiv.addEventListener('mouseleave', () => {
                    mainDiv.style.transform = 'translateY(0)';
                    mainDiv.style.boxShadow = 'var(--shadow-sm)';
                });
                mainDiv.onclick = () => window.location.href = member.profile_url;

                // Right Count (Top Right Badge)
                if (member.count !== null) {
                    const countDiv = document.createElement('div');
                    countDiv.style.position = 'absolute';
                    countDiv.style.top = '10px';
                    countDiv.style.right = '10px';
                    countDiv.style.fontSize = '0.9rem';
                    countDiv.style.fontWeight = 'bold';
                    countDiv.style.background = 'var(--accent)';
                    countDiv.style.color = '#000';
                    countDiv.style.padding = '2px 8px';
                    countDiv.style.borderRadius = '20px';
                    countDiv.innerText = member.count;
                    mainDiv.appendChild(countDiv);
                }

                // Avatar
                const avatarDiv = document.createElement('img');
                avatarDiv.classList.add('adv-avatar');
                avatarDiv.style.width = '80px';
                avatarDiv.style.height = '80px';
                avatarDiv.style.border = '2px solid rgba(255,255,255,0.1)';
                avatarDiv.style.marginBottom = '15px';
                avatarDiv.setAttribute('src', member.avatar_url);
                mainDiv.appendChild(avatarDiv);

                // Info Area
                const contentDiv = document.createElement('div');
                contentDiv.style.textAlign = 'center';
                contentDiv.style.width = '100%';

                const nameDiv = document.createElement('div');
                nameDiv.style = member.group_style?.replace('&#039;', "'")?.replace('&quot;', '"');
                nameDiv.style.fontFamily = 'var(--font-display)';
                nameDiv.style.fontWeight = '700';
                nameDiv.style.fontSize = '1.3rem';
                nameDiv.style.letterSpacing = '1px';
                nameDiv.innerText = member.username;
                contentDiv.appendChild(nameDiv);

                {if $VIEWING_LIST != "overview"}
                    // Group HTML
                    if (member.group_html && member.group_html.length > 0) {
                        const groupDiv = document.createElement('div');
                        groupDiv.style.marginTop = '8px';
                        groupDiv.innerHTML = member.group_html.join(' ');
                        contentDiv.appendChild(groupDiv);
                    }

                    const metaDiv = document.createElement('div');
                    metaDiv.style.fontSize = '0.8rem';
                    metaDiv.style.color = 'var(--text-secondary)';
                    metaDiv.style.marginTop = '15px';
                    metaDiv.style.paddingTop = '10px';
                    metaDiv.style.borderTop = '1px solid rgba(255,255,255,0.05)';

                    const memberMeta = member.metadata;
                    if(memberMeta) {
                        metaDiv.innerHTML = Object.keys(memberMeta).map(function(k) {
                            return '<div style="margin-bottom:3px;"><strong>' + k + '</strong>: ' + memberMeta[k] + '</div>';
                        }).join('');
                    }
                    contentDiv.appendChild(metaDiv);
                {/if}

                mainDiv.appendChild(contentDiv);
                list.appendChild(mainDiv)
            }
        });
    }

    window.onload = () => {
        {if $VIEWING_LIST == "group"}
            renderList('group_{$VIEWING_GROUP.id}');
        {else}
            {foreach from=$MEMBER_LISTS_VIEWING item=list}
                renderList('{$list->getName()}');
            {/foreach}
        {/if}

        // Fomantic UI search binding (if Fomantic is loaded)
        if(typeof $.fn.search !== 'undefined') {
            $('.ui.search').search({
                minCharacters: 2,
                maxResults: 5,
                selectFirstResult: true,
                fields: {
                    title: 'username',
                    description: 'nickname',
                    image: 'avatar_url',
                    url: 'profile_url',
                },
                apiSettings: {
                    url: '{$SEARCH_URL}&search={literal}{query}{/literal}&limit=5'
                },
                error: {
                    noResultsHeader: "{$NO_RESULTS_HEADER}",
                    noResults: "{$NO_RESULTS_TEXT}",
                }
            });
        }
    }
</script>

{include file='footer.tpl'}
