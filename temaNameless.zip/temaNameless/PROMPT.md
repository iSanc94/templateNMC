# PROMPT — NamelessMC Adventure Premium Template ($1000+)

---

## Master Prompt (Gunakan ini untuk memulai sesi pembuatan template)

```
Kamu adalah expert NamelessMC template developer. Tugasmu adalah membangun template
NamelessMC bertema "Adventure" berkualitas premium senilai di atas $1000 USD.

Template ini harus mencakup SEMUA aspek NamelessMC tanpa terkecuali, dengan animasi
kompleks yang benar-benar berjalan di browser.

## IDENTITAS TEMPLATE
- Nama: Adventure
- Versi NamelessMC: 2.0.x (Smarty template engine)
- Style: Dark Fantasy / Medieval Adventure / Minecraft RPG
- Harga Target: $1000+
- Primary Color: #D4AF37 (Adventure Gold)
- Dark Mode: Default ON

## STRUKTUR YANG WAJIB DIBUAT (tidak boleh ada yang terlewat):

### File Konfigurasi
1. template.yaml — Mendaftarkan SEMUA pages, widgets, settings
2. template.php — Bootstrap PHP + hook registration

### Global Partials (pages/global/)
3. header.tpl — HTML head, meta OG/Twitter, navbar lengkap, notification bell,
   dark mode toggle, hamburger menu animasi, user dropdown dengan avatar
4. footer.tpl — Footer ornamen Adventure, quick links, social icons,
   server status mini, copyright, back-to-top button animasi
5. navbar.tpl — Navigasi responsif dengan mega menu (opsional)
6. sidebar.tpl — Container untuk semua widget
7. breadcrumb.tpl — Breadcrumb dengan separator rune Adventure
8. pagination.tpl — Pagination bergaya scroll/parchment

### Halaman Publik
9. pages/home/index.tpl — HOMEPAGE LENGKAP:
   - Hero section dengan 3-layer parallax background
   - particles.js (debu/partikel emas melayang)
   - Typed.js mengetik gamemode/feature server
   - Animasi hero title masuk dari bawah (GSAP)
   - CTA "Play Now" + "Learn More" dengan glow effect
   - Stats bar: Member count, Post count, Online players (animasi counter)
   - Featured news 3 artikel terbaru dengan card hover effect
   - Forum preview (3 kategori dengan topic count)
   - Server features section dengan icon cards + scroll reveal
   - Gallery teaser 6 foto grid dengan hover lightbox preview
   - Join server CTA section dengan gradient background
   - "How to Join" steps section

10. pages/forum/index.tpl — Forum index dengan:
    - Category groups dengan ikon per kategori
    - Sub-forum list per kategori
    - Statistik: topic count, post count, last post info
    - Online users di forum
    - Quick post form

11. pages/forum/category.tpl — Daftar topic dengan:
    - Breadcrumb
    - Tombol "New Topic" floating
    - Topic list: pinned + normal
    - Info per topic: avatar, title, replies, views, last post
    - Filter & sort options
    - Pagination

12. pages/forum/topic.tpl — Thread view dengan:
    - Post pertama (original post) dengan styling berbeda
    - Setiap post: avatar, username, badge/rank, post count, join date, like button
    - Quote, Edit, Delete actions per post
    - Spoiler tag support
    - Code block dengan syntax highlight
    - Image embed support
    - Reaction bar emoji
    - Reply form dengan toolbar formatting
    - Pagination

13. pages/forum/new_topic.tpl — Buat topik baru:
    - Title input
    - Category selector
    - Tag input
    - Rich text editor (WYSIWYG)
    - Preview mode toggle
    - Submit animasi

14. pages/forum/edit_post.tpl — Edit post

15. pages/store/index.tpl — Store homepage:
    - Featured/highlighted products di atas
    - Category tabs/filter
    - Product grid dengan card + harga + tombol beli
    - "Best Seller" dan "New" badge

16. pages/store/category.tpl — Produk per kategori

17. pages/store/product.tpl — Detail produk:
    - Gambar produk besar
    - Deskripsi lengkap dengan format HTML
    - Harga + tombol Beli
    - Opsi (jika ada: durasi, jumlah)
    - Syarat & ketentuan checkbox
    - Related products

18. pages/store/checkout.tpl — Checkout:
    - Review order
    - Input username Minecraft
    - Pilih payment gateway
    - Tombol Bayar dengan animasi loading

19. pages/store/purchase_complete.tpl — Success page dengan animasi confetti/sparkle

20. pages/news/index.tpl — Blog/berita:
    - Hero artikel terbaru (large card)
    - Grid artikel selanjutnya
    - Kategori sidebar
    - Pencarian

21. pages/news/article.tpl — Full artikel:
    - Header dengan gambar cover, judul, penulis, tanggal
    - Konten HTML
    - Share buttons
    - Related articles
    - Komentar (jika terintegrasi)

22. pages/user/login.tpl — Login:
    - Form centered dengan animasi masuk
    - Username + password input bergaya Adventure
    - Remember me checkbox
    - Forgot password link
    - Register CTA
    - OAuth buttons (Discord, Steam)

23. pages/user/register.tpl — Register:
    - Multi-step wizard (Step 1: Data, Step 2: Verifikasi)
    - Progress bar steps
    - Animasi transisi antar step
    - Password strength indicator
    - Terms of Service checkbox
    - reCAPTCHA placeholder

24. pages/user/forgot_password.tpl
25. pages/user/reset_password.tpl
26. pages/user/validate.tpl

27. pages/user/profile.tpl — Profil pengguna:
    - Cover image/banner
    - Minecraft body render (Crafatar API)
    - Nama, grup/rank badge, join date, last seen
    - Stats: Post count, Likes, Trophies
    - Trophy showcase dengan hover tooltip
    - About me / bio
    - Recent posts tab
    - Friends tab (jika modul aktif)

28. pages/panel/index.tpl — Dashboard user panel:
    - Greeting dengan avatar
    - Quick stats card
    - Recent notifications
    - Connected accounts (Discord, Minecraft UUID)
    - Activity feed

29. pages/panel/settings.tpl — Pengaturan akun:
    - Upload avatar dengan preview
    - Ganti password
    - Two-Factor Authentication setup
    - Notifikasi preferences
    - Privacy settings
    - Danger zone (hapus akun)

30. pages/panel/alerts.tpl — Notifikasi/alerts list
31. pages/panel/messaging.tpl — Private messages inbox
32. pages/panel/connect/discord.tpl — Connect Discord
33. pages/panel/connect/minecraft.tpl — Link akun Minecraft

34. pages/staff/index.tpl — Halaman staff:
    - Header dengan banner
    - Staff grid dikelompokkan per jabatan/rank
    - Kartu staff: Minecraft skin, nama, jabatan, Discord
    - Hover: flip card atau glow effect

35. pages/staff/application.tpl — Apply staff:
    - Syarat & ketentuan
    - Multi-step form
    - Pertanyaan dinamis

36. pages/ban_appeal/index.tpl — Formulir ban appeal
37. pages/ban_appeal/view.tpl — Status appeal

38. pages/leaderboard/index.tpl — Leaderboard:
    - Top 3 dengan podium animasi
    - Table untuk posisi 4+
    - Filter by: post count, likes, playtime

39. pages/gallery/index.tpl — Album gallery
40. pages/gallery/album.tpl — Foto dalam album + lightbox

41. pages/vote/index.tpl — Vote di server list
42. pages/contact/index.tpl — Kontak

43. pages/errors/404.tpl — 404: Pemain tersesat, animasi karakter bingung
44. pages/errors/403.tpl — 403: Pintu terkunci dengan lock animation
45. pages/errors/500.tpl — 500: Server crash dengan humor

### Widgets (widgets/)
46. online_staff.tpl — Staff online dengan status dot
47. server_status.tpl — IP server, player count, MOTD, status ping
48. recent_posts.tpl — 5 post terbaru
49. new_members.tpl — 5 member baru dengan avatar
50. top_posters.tpl — Top 5 poster all-time
51. social_media.tpl — Links Discord, Twitter, YouTube dll

### Email Templates (email/)
52. layout.tpl — Base email dengan inline CSS
53. registration.tpl — Selamat datang
54. password_reset.tpl — Reset password

### CSS Assets (assets/css/)
55. adventure.css — Design system + semua komponen UI
56. animations.css — SEMUA @keyframes (minimal 15 animasi unik)
57. components.css — Button, Card, Badge, Input, Modal, Tooltip dll
58. dark-mode.css — Dark theme overrides
59. responsive.css — Breakpoints mobile/tablet/desktop

### JavaScript Assets (assets/js/)
60. adventure.js — Main init, utility functions, event listeners
61. animations.js — GSAP ScrollTrigger untuk setiap section utama
62. particles-config.js — Setup particles.js lengkap
63. typed-config.js — Typed.js setup
64. dark-mode.js — Theme toggle + localStorage persist
65. notifications.js — Toast notifications + polling

## ANIMASI WAJIB (HARUS ADA DAN BERFUNGSI):

1. **Parallax Hero** — 3 layer background bergerak berbeda speed saat scroll
2. **Particles Background** — Partikel emas melayang di homepage hero
3. **Typed.js Hero** — Teks gamemode/fitur diketik otomatis dengan cursor
4. **GSAP Hero Reveal** — Judul, subtitle, CTA masuk dengan stagger
5. **Counter Animation** — Stats (member, post, player) menghitung naik saat terlihat
6. **Scroll Reveal Cards** — Setiap card muncul stagger saat scroll ke sana
7. **Navbar Scroll Effect** — Navbar berubah style saat scroll (transparent → solid + shadow)
8. **Hamburger Menu** — 3 garis berubah jadi X dengan smooth animation
9. **Dropdown Hover** — Menu dropdown slide-down dengan fade
10. **Button Hover Glow** — Tombol CTA memancarkan cahaya emas saat hover
11. **Card Hover Lift** — Card terangkat + shadow lebih dalam saat hover
12. **Dark Mode Toggle** — Switch animasi smooth antara tema gelap/terang
13. **Notification Toast** — Notifikasi masuk dari pojok kanan bawah, keluar otomatis
14. **Forum Post Like** — Animasi heart/thumbs up saat klik like
15. **Profile Avatar Float** — Avatar profil floating animation subtle
16. **Loading Skeleton** — Skeleton screen sebelum konten load
17. **Back to Top Button** — Muncul saat scroll 300px, smooth scroll ke atas
18. **Progress Bar** — Animasi shimmer saat loading/upload
19. **Modal Open/Close** — Modal slide-in + backdrop blur
20. **Error Page Character** — Karakter animasi di halaman 404

## DESIGN REQUIREMENTS:

- Font: Cinzel (header/display) + Crimson Text (body) + Inter (UI)
- Primary Background: #0A0A0F (near black)
- Cards: #16161F dengan border rgba(212,175,55,0.2)
- Accent: #D4AF37 (gold) dengan glow rgba(212,175,55,0.4)
- Text Primary: #F0E6D3 (warm white/parchment)
- Hover States: Semua elemen interaktif punya visual feedback
- Dekorasi: Ornamen rune/medieval di section headers, dividers
- Minecraft Integration: Crafatar API untuk skin/avatar render

## KUALITAS KODE:

- Semua variabel Smarty menggunakan nama resmi NamelessMC
- Setiap form mengandung {$TOKEN} untuk CSRF
- Setiap halaman include header.tpl dan footer.tpl
- CSS menggunakan BEM-inspired naming: .adv-[component]__[element]--[modifier]
- JavaScript: ES6+, no jQuery dependency, vanilla JS
- Responsive: Mobile-first, breakpoints 320/768/1024/1200px
- Accessibility: ARIA labels, alt texts, keyboard navigation
- Performance: Lazy loading gambar, deferred JS, font preload

Mulai dengan membuat template.yaml dan adventure.css (design system),
lalu lanjutkan secara berurutan hingga semua 65+ file selesai.
Jangan berhenti sampai semua file selesai dibuat dengan kode lengkap.
```

---

## Prompt Spesifik Per Kebutuhan

### Prompt: Hanya Homepage
```
Buat HANYA pages/home/index.tpl untuk template NamelessMC Adventure premium.
Homepage harus memiliki:
- Hero parallax 3 layer + particles.js + typed.js + GSAP reveal
- Stats counter animasi (member, post, online player)
- News grid 3 artikel
- Forum preview
- Server features section
- CTA join section
Sertakan juga semua CSS dan JS yang dibutuhkan homepage ini.
```

### Prompt: Hanya Forum System
```
Buat sistem forum lengkap untuk template NamelessMC Adventure:
- pages/forum/index.tpl (overview semua kategori)
- pages/forum/category.tpl (daftar topic)
- pages/forum/topic.tpl (thread + posts + reply)
- pages/forum/new_topic.tpl (buat topik baru)
- pages/forum/edit_post.tpl (edit post)
Semua menggunakan variabel Smarty NamelessMC yang benar.
Sertakan CSS animasi untuk forum (hover effects, like animation, quote styling).
```

### Prompt: Hanya Store System
```
Buat sistem store lengkap untuk template NamelessMC Adventure:
- pages/store/index.tpl (homepage store)
- pages/store/category.tpl (produk per kategori)
- pages/store/product.tpl (detail produk)
- pages/store/checkout.tpl (checkout form)
- pages/store/purchase_complete.tpl (sukses + confetti animasi)
Semua menggunakan variabel Smarty NamelessMC resmi.
```

### Prompt: Hanya Design System CSS
```
Buat design system CSS lengkap untuk template NamelessMC Adventure ($1000+).
File: assets/css/adventure.css
Harus mencakup:
- CSS custom properties (semua colors, spacing, typography, shadows, transitions)
- Dark/light mode variables
- Typography scale (h1-h6, body, ui, mono)
- Semua komponen: button, card, badge, input, textarea, select, modal, tooltip,
  progress bar, skeleton loader, notification toast, divider, breadcrumb,
  pagination, avatar, tag/chip, tabs, accordion, dropdown, table
- BEM naming convention
- Minimal 400 baris kode
```

### Prompt: Hanya Animasi JavaScript
```
Buat file animasi JavaScript lengkap untuk template NamelessMC Adventure.
Files yang dibutuhkan:
1. assets/js/animations.js — GSAP + ScrollTrigger untuk semua section
2. assets/js/particles-config.js — Particles.js config lengkap
3. assets/js/typed-config.js — Typed.js config untuk hero
4. assets/js/dark-mode.js — Theme switcher dengan localStorage
5. assets/js/notifications.js — Toast notification system
6. assets/js/adventure.js — Main init + utilities
Semua animasi harus punya prefers-reduced-motion fallback.
Jangan pakai jQuery, pure vanilla JS + GSAP.
```

### Prompt: Hanya User Profile
```
Buat halaman profil pengguna untuk template NamelessMC Adventure:
- pages/user/profile.tpl
Harus mencakup:
- Banner/cover image dengan parallax effect
- Minecraft body render menggunakan Crafatar API dengan {$profile_user.mc_uuid}
- Nama pengguna + badge rank (dari {$USER_GROUP})
- Stats: post count, likes, join date, last seen
- Trophy showcase dengan animasi hover
- Bio/about section
- Recent posts tab
- Avatar float animation
Gunakan variabel Smarty NamelessMC yang benar.
```

### Prompt: Perbaikan/Iterasi
```
Template NamelessMC Adventure sudah ada. Tolong lakukan:
[deskripsikan perubahan yang diinginkan]

Pastikan:
- Tidak mengubah variabel Smarty yang sudah benar
- Mempertahankan design system (CSS variables)
- Animasi tetap berjalan setelah perubahan
- Mobile responsiveness tidak rusak
```

---

## Checklist Validasi Output

Gunakan checklist ini untuk memvalidasi setiap output template:

### ✅ Smarty Syntax
- [ ] Semua tag `{...}` ditutup dengan benar
- [ ] `{foreach}` diakhiri `{/foreach}`
- [ ] `{if}` diakhiri `{/if}`
- [ ] Tidak ada PHP murni di dalam `.tpl` (kecuali yang di-inject NamelessMC)
- [ ] Semua form ada `{$TOKEN}` hidden input

### ✅ HTML Structure
- [ ] Setiap halaman include `{include file='global/header.tpl'}`
- [ ] Setiap halaman include `{include file='global/footer.tpl'}`
- [ ] `<html lang="{$LANGUAGE}">` atau lang yang sesuai
- [ ] Meta viewport ada di header
- [ ] Semua gambar punya `alt` attribute
- [ ] Semua input punya `id` dan `<label for="...">` yang cocok

### ✅ CSS Quality
- [ ] Tidak ada warna hardcoded (#hex) di luar `:root` CSS variables
- [ ] Tidak ada `!important` berlebihan
- [ ] Mobile-first breakpoints konsisten
- [ ] `@media (prefers-reduced-motion: reduce)` ada

### ✅ JavaScript Quality
- [ ] Tidak ada `console.log` yang tertinggal (kecuali debug mode)
- [ ] Error handling untuk API calls
- [ ] Semua querySelector dicek null sebelum dipakai
- [ ] Event listeners di-cleanup jika diperlukan

### ✅ NamelessMC Compatibility
- [ ] `{$TEMPLATE_URL}` digunakan untuk semua path asset
- [ ] `{$SITE_URL}` untuk semua link internal
- [ ] Variabel sesuai dokumentasi NamelessMC v2
- [ ] template.yaml mendaftarkan semua pages yang dibuat

---

## Tips untuk Hasil Maksimal

1. **Selalu buat semua file sekaligus** — jangan partial/sepotong-sepotong kecuali diminta
2. **Gunakan CDN untuk library eksternal** — lebih cepat daripada self-host untuk demo
3. **Inline critical CSS di header** — untuk LCP (Largest Contentful Paint) yang bagus
4. **Test di Chrome + Firefox** — pastikan animasi berjalan di kedua browser
5. **Dokumentasikan setiap CSS variable** — buyer harus bisa custom dengan mudah
6. **Tambahkan loading="lazy"** ke semua gambar di bawah fold
7. **Particle count: 80 desktop, 30 tablet, 0 mobile** — jaga performa HP
8. **Gunakan `will-change: transform`** di elemen yang sering dianimasikan
9. **CSS containment** di card grid untuk rendering performa
10. **Font display: swap** untuk mencegah FOIT (Flash of Invisible Text)
