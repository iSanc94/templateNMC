{include file='header.tpl'}
{include file='navbar.tpl'}

<div class="adv-container mt-4 mb-4" style="margin-top: 60px; min-height: 60vh; display: flex; align-items: center; justify-content: center;">
    <div class="adv-card" style="text-align: center; max-width: 600px; padding: 50px 30px;">
        <i class="fas fa-lock" style="font-size: 5rem; color: var(--error); margin-bottom: 20px; text-shadow: 0 0 20px rgba(239, 68, 68, 0.4);"></i>
        
        <h1 style="font-family: var(--font-display); font-size: 3rem; margin-bottom: 10px; color: #fff;">
            403 - Forbidden
        </h1>
        
        <p style="font-size: 1.1rem; color: var(--text-secondary); margin-bottom: 30px; line-height: 1.6;">
            {$403_MESSAGE}
        </p>
        
        <div style="display: flex; gap: 15px; justify-content: center;">
            <button class="adv-btn adv-btn--primary" onclick="history.go(-1)">
                <i class="fas fa-arrow-left"></i> {$BACK}
            </button>
            <a href="{$SITE_HOME}" class="adv-btn">
                <i class="fas fa-home"></i> {$HOME}
            </a>
        </div>
    </div>
</div>

{include file='footer.tpl'}
