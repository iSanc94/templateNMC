---
name: namelessmc-adventure-template
description: >
  Skill untuk membuat template NamelessMC bertema Adventure premium ($1000+) yang mencakup
  SEMUA aspek NamelessMC: layout, navigasi, homepage, forum, store/shop, user profile,
  staff page, ban appeal, leaderboard, news/blog, galeri, widget sidebar, panel admin,
  dark/light mode, animasi kompleks (parallax, particles, GSAP, typed.js, scroll-triggered),
  integrasi Minecraft skin/avatar, notifikasi real-time, responsive mobile, SEO meta tags,
  custom error pages, dan semua hook/override NamelessMC.
  Gunakan skill ini setiap kali user meminta template NamelessMC, tema Minecraft website,
  community gaming site, atau template PHP Smarty/Twig dengan gaya Adventure/RPG/Gaming.
compatibility:
  tools: [bash, create_file, str_replace, view, present_files]
  dependencies:
    - PHP 8.0+
    - NamelessMC v2.x (Nameless-2.0.0-pr12 atau lebih baru)
    - Smarty Template Engine (sudah bundled di NamelessMC)
    - Node.js (untuk build assets, opsional)
    - Composer (opsional untuk dev dependencies)
---

# NamelessMC Adventure Template Skill

## Overview

Skill ini memandu pembuatan template NamelessMC bertema **Adventure** yang berkualitas
premium ($1000+), mencakup seluruh fitur NamelessMC dari ujung ke ujung — dari halaman
publik hingga panel admin, dari animasi kompleks hingga integrasi Minecraft penuh.

---

## Struktur Direktori NamelessMC Template

NamelessMC menggunakan sistem template berbasis **Smarty** dengan struktur wajib berikut:

```
custom/templates/Adventure/
├── template.yaml              # Metadata & konfigurasi template
├── template.php               # PHP bootstrap template
├── LICENSE
├── README.md
│
├── assets/
│   ├── css/
│   │   ├── adventure.css          # Main stylesheet
│   │   ├── animations.css         # Semua keyframe & transitions
│   │   ├── components.css         # Reusable UI components
│   │   ├── dark-mode.css          # Dark theme overrides
│   │   ├── responsive.css         # Mobile-first breakpoints
│   │   └── vendor/                # Third-party CSS (particles, etc.)
│   ├── js/
│   │   ├── adventure.js           # Main JS logic
│   │   ├── animations.js          # GSAP, ScrollTrigger, parallax
│   │   ├── particles-config.js    # particles.js config
│   │   ├── typed-config.js        # typed.js config
│   │   ├── dark-mode.js           # Theme switcher
│   │   ├── notifications.js       # Real-time notif handler
│   │   └── vendor/
│   │       ├── gsap.min.js
│   │       ├── ScrollTrigger.min.js
│   │       ├── particles.min.js
│   │       └── typed.min.js
│   ├── img/
│   │   ├── bg/                    # Background textures & parallax layers
│   │   ├── icons/                 # Custom SVG icons
│   │   ├── logo/
│   │   └── decorations/           # Adventure decorative assets
│   └── fonts/
│       ├── adventure-font.woff2
│       └── minecraft-font.woff2
│
├── pages/
│   ├── global/
│   │   ├── header.tpl             # Global header + nav
│   │   ├── footer.tpl             # Global footer
│   │   ├── navbar.tpl             # Navigasi utama
│   │   ├── sidebar.tpl            # Sidebar dengan widgets
│   │   ├── breadcrumb.tpl
│   │   └── pagination.tpl
│   │
│   ├── home/
│   │   └── index.tpl              # Homepage (hero, features, stats, news)
│   │
│   ├── forum/
│   │   ├── index.tpl              # Forum index
│   │   ├── topic.tpl              # Thread/topic view
│   │   ├── new_topic.tpl          # Buat topik baru
│   │   ├── category.tpl           # Forum category
│   │   └── edit_post.tpl          # Edit post
│   │
│   ├── store/ (ShopCore / Store Module)
│   │   ├── index.tpl              # Store homepage
│   │   ├── category.tpl           # Store category
│   │   ├── product.tpl            # Detail produk
│   │   ├── checkout.tpl           # Checkout
│   │   └── purchase_complete.tpl  # Konfirmasi pembelian
│   │
│   ├── user/
│   │   ├── profile.tpl            # Profil pengguna publik
│   │   ├── login.tpl              # Halaman login
│   │   ├── register.tpl           # Halaman registrasi
│   │   ├── forgot_password.tpl    # Lupa password
│   │   ├── reset_password.tpl     # Reset password
│   │   └── validate.tpl           # Validasi email
│   │
│   ├── panel/ (User Panel)
│   │   ├── index.tpl              # Dashboard pengguna
│   │   ├── settings.tpl           # Pengaturan akun
│   │   ├── alerts.tpl             # Notifikasi & alerts
│   │   ├── messaging.tpl          # Private messages
│   │   └── connect/               # OAuth / social connect
│   │       ├── discord.tpl
│   │       └── minecraft.tpl
│   │
│   ├── staff/
│   │   ├── index.tpl              # Daftar staff
│   │   └── application.tpl        # Formulir staff apply
│   │
│   ├── ban_appeal/
│   │   ├── index.tpl
│   │   └── view.tpl
│   │
│   ├── leaderboard/
│   │   └── index.tpl
│   │
│   ├── gallery/
│   │   ├── index.tpl
│   │   └── album.tpl
│   │
│   ├── news/
│   │   ├── index.tpl
│   │   └── article.tpl
│   │
│   ├── vote/
│   │   └── index.tpl
│   │
│   ├── contact/
│   │   └── index.tpl
│   │
│   ├── query_page/                # Halaman statis custom
│   │   └── index.tpl
│   │
│   └── errors/
│       ├── 403.tpl
│       ├── 404.tpl
│       └── 500.tpl
│
├── widgets/                       # Widget sidebar
│   ├── online_staff.tpl
│   ├── server_status.tpl          # Minecraft server status
│   ├── recent_posts.tpl
│   ├── new_members.tpl
│   ├── top_posters.tpl
│   └── social_media.tpl
│
└── email/                         # Email templates
    ├── layout.tpl
    ├── registration.tpl
    └── password_reset.tpl
```

---

## template.yaml — Wajib Ada

```yaml
name: Adventure
version: 1.0.0
author: YourName
description: "Premium Adventure themed template for NamelessMC with complex animations"
namelessmc_version: ">=2.0.0"
licence: Commercial

# Daftarkan semua pages yang di-override
pages:
  - home/index
  - forum/index
  - forum/topic
  - forum/new_topic
  - forum/category
  - forum/edit_post
  - store/index
  - store/category
  - store/product
  - store/checkout
  - store/purchase_complete
  - user/profile
  - user/login
  - user/register
  - user/forgot_password
  - user/reset_password
  - panel/index
  - panel/settings
  - panel/alerts
  - panel/messaging
  - staff/index
  - staff/application
  - ban_appeal/index
  - ban_appeal/view
  - leaderboard/index
  - gallery/index
  - gallery/album
  - news/index
  - news/article
  - vote/index
  - contact/index
  - errors/404
  - errors/403
  - errors/500

# Global partials
partials:
  - global/header
  - global/footer
  - global/navbar
  - global/sidebar
  - global/breadcrumb
  - global/pagination

# Widgets
widgets:
  - online_staff
  - server_status
  - recent_posts
  - new_members
  - top_posters
  - social_media

settings:
  colour_scheme:
    type: colour
    default: "#D4AF37"
    label: "Accent Color (Adventure Gold)"
  dark_mode_default:
    type: boolean
    default: true
    label: "Default to Dark Mode"
  particles_enabled:
    type: boolean
    default: true
    label: "Enable Particle Effects"
  parallax_enabled:
    type: boolean
    default: true
    label: "Enable Parallax Background"
  server_ip:
    type: text
    default: "play.yourserver.net"
    label: "Minecraft Server IP"
  server_port:
    type: text
    default: "25565"
    label: "Server Port"
  discord_invite:
    type: text
    default: ""
    label: "Discord Invite URL"
  hero_title:
    type: text
    default: "Begin Your Adventure"
    label: "Homepage Hero Title"
  hero_subtitle:
    type: text
    default: "Join thousands of players in an epic journey"
    label: "Homepage Hero Subtitle"
  typed_strings:
    type: text
    default: "Survival|Creative|Skyblock|Factions|PvP"
    label: "Typed.js strings (pipe separated)"
```

---

## Variabel Smarty NamelessMC yang WAJIB Digunakan

### Global Variables (tersedia di semua halaman)

```smarty
{* Metadata *}
{$SITE_NAME}          - Nama server/website
{$SITE_URL}           - URL utama
{$META_TITLE}         - Title halaman
{$META_DESCRIPTION}   - Meta description
{$META_KEYWORDS}      - Meta keywords
{$TEMPLATE_URL}       - URL folder template ini
{$LANGUAGE}           - Kode bahasa aktif

{* User State *}
{$LOGGED_IN}          - Boolean: user login atau tidak
{$USER_LOGGED_IN}     - Objek user yang login
{$IS_ADMIN_CP}        - Boolean: di halaman admin?
{$USER_AVATAR}        - URL avatar user
{$USER_GROUP}         - Nama grup user

{* Navigasi *}
{$NAVBAR_ITEMS}       - Array item navbar
{$NAVBAR_EXTRAS}      - Extra navbar items (login, register, dll)

{* Notifikasi *}
{$ALERTS}             - Array notifikasi/alerts untuk user
{$NOTIFICATION_COUNT} - Jumlah notif belum dibaca

{* Token CSRF *}
{$TOKEN}              - Token CSRF untuk semua form

{* Widgets *}
{$WIDGETS}            - Semua widget teregistrasi

{* Settings *}
{$SETTINGS}           - Objek settings website
{$TEMPLATE_SETTINGS}  - Objek settings spesifik template ini
```

### Variabel Per-Halaman

```smarty
{* Homepage *}
{$BANNER}             - Banner/slideshow data
{$STATISTICS}         - Statistik server (players, posts, members)
{$NEWS}               - Array berita terbaru
{$ONLINE_PLAYERS}     - Jumlah pemain online

{* Forum *}
{$CATEGORIES}         - Array kategori forum
{$FORUMS}             - Array forum dalam kategori
{$TOPICS}             - Array topik
{$POSTS}              - Array post dalam topik
{$TOPIC}              - Objek topik aktif
{$FORUM}              - Objek forum aktif

{* User Profile *}
{$profile_user}       - Data user yang dilihat profilnya
{$POSTS_COUNT}        - Jumlah post user
{$LIKES_COUNT}        - Jumlah likes
{$TROPHIES}           - Array trophy user
{$PROFILE_FIELDS}     - Custom profile fields

{* Store *}
{$PRODUCTS}           - Array produk
{$PRODUCT}            - Produk aktif
{$CATEGORIES_STORE}   - Kategori store
{$CURRENCY}           - Simbol mata uang

{* Staff *}
{$STAFF_LIST}         - Array data staff per grup
```

---

## Panduan Implementasi CSS (Design System)

### CSS Custom Properties (Wajib di :root)

```css
:root {
  /* === ADVENTURE PALETTE === */
  --adv-gold:        #D4AF37;
  --adv-gold-light:  #F0D060;
  --adv-gold-dark:   #9A7D1A;
  --adv-ember:       #C84B11;
  --adv-forest:      #2D5A27;
  --adv-stone:       #4A4A4A;
  --adv-obsidian:    #0D0D0D;
  --adv-parchment:   #F5E6C8;

  /* === SEMANTIC COLORS === */
  --bg-primary:      #0A0A0F;
  --bg-secondary:    #111118;
  --bg-card:         #16161F;
  --bg-hover:        #1E1E2A;
  --text-primary:    #F0E6D3;
  --text-secondary:  #A09080;
  --text-muted:      #605850;
  --border-color:    rgba(212, 175, 55, 0.2);
  --accent:          var(--adv-gold);
  --accent-glow:     rgba(212, 175, 55, 0.4);

  /* === TYPOGRAPHY === */
  --font-display:    'MedievalSharp', 'Cinzel', serif;
  --font-body:       'Crimson Text', 'Georgia', serif;
  --font-ui:         'Inter', 'Segoe UI', sans-serif;
  --font-mono:       'JetBrains Mono', monospace;

  /* === SPACING === */
  --space-xs:  4px;
  --space-sm:  8px;
  --space-md:  16px;
  --space-lg:  24px;
  --space-xl:  40px;
  --space-2xl: 64px;
  --space-3xl: 96px;

  /* === BORDERS === */
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 16px;
  --radius-xl: 24px;

  /* === SHADOWS === */
  --shadow-card:  0 4px 24px rgba(0,0,0,0.4);
  --shadow-glow:  0 0 20px var(--accent-glow);
  --shadow-deep:  0 8px 48px rgba(0,0,0,0.6);

  /* === TRANSITIONS === */
  --transition-fast:   150ms cubic-bezier(0.4,0,0.2,1);
  --transition-normal: 300ms cubic-bezier(0.4,0,0.2,1);
  --transition-slow:   600ms cubic-bezier(0.4,0,0.2,1);

  /* === Z-INDEX LAYERS === */
  --z-dropdown:  100;
  --z-sticky:    200;
  --z-overlay:   300;
  --z-modal:     400;
  --z-tooltip:   500;
  --z-particles: -1;
}

/* Light Mode Overrides */
[data-theme="light"] {
  --bg-primary:    #F5EDD8;
  --bg-secondary:  #EDE0C4;
  --bg-card:       #FFFBF0;
  --text-primary:  #1A0F00;
  --text-secondary:#4A3B2A;
  --border-color:  rgba(100, 70, 20, 0.2);
}
```

---

## Panduan Animasi Wajib

### 1. Particles.js Config (latar belakang)
```javascript
// assets/js/particles-config.js
const ADVENTURE_PARTICLES = {
  particles: {
    number: { value: 60, density: { enable: true, value_area: 800 } },
    color: { value: ["#D4AF37", "#C84B11", "#F0D060"] },
    shape: {
      type: ["circle", "triangle"],
      stroke: { width: 1, color: "#D4AF37" }
    },
    opacity: {
      value: 0.3,
      random: true,
      anim: { enable: true, speed: 0.5, opacity_min: 0.05 }
    },
    size: {
      value: 3,
      random: true,
      anim: { enable: true, speed: 2, size_min: 0.3 }
    },
    line_linked: {
      enable: true,
      distance: 150,
      color: "#D4AF37",
      opacity: 0.1,
      width: 1
    },
    move: {
      enable: true,
      speed: 1.2,
      direction: "none",
      random: true,
      straight: false,
      out_mode: "out",
      bounce: false
    }
  },
  interactivity: {
    detect_on: "canvas",
    events: {
      onhover: { enable: true, mode: "grab" },
      onclick: { enable: true, mode: "push" },
      resize: true
    },
    modes: {
      grab: { distance: 140, line_linked: { opacity: 0.5 } },
      push: { particles_nb: 4 }
    }
  },
  retina_detect: true
};
```

### 2. GSAP ScrollTrigger Animations
```javascript
// assets/js/animations.js
// Semua animasi GSAP untuk scroll-triggered reveals
gsap.registerPlugin(ScrollTrigger);

// Hero text reveal
gsap.from(".hero-title", {
  y: 60, opacity: 0, duration: 1.2,
  ease: "power4.out", delay: 0.3
});

// Stats counter animation
gsap.utils.toArray(".stat-number").forEach(el => {
  gsap.from(el, {
    textContent: 0,
    duration: 2,
    ease: "power2.out",
    snap: { textContent: 1 },
    scrollTrigger: { trigger: el, start: "top 80%" }
  });
});

// Cards stagger reveal
gsap.utils.toArray(".adv-card").forEach((card, i) => {
  gsap.from(card, {
    y: 40, opacity: 0, duration: 0.8,
    delay: i * 0.1, ease: "power3.out",
    scrollTrigger: { trigger: card, start: "top 85%" }
  });
});
```

### 3. Parallax Layers
```css
/* Multi-layer parallax hero */
.hero-parallax {
  position: relative;
  height: 100vh;
  overflow: hidden;
}
.hero-parallax .layer-bg    { --parallax-speed: 0.2; }
.hero-parallax .layer-mid   { --parallax-speed: 0.4; }
.hero-parallax .layer-front { --parallax-speed: 0.6; }
```

### 4. CSS Keyframe Animations Wajib
```css
@keyframes adventureFloat {
  0%, 100% { transform: translateY(0px); }
  50%       { transform: translateY(-10px); }
}
@keyframes goldGlow {
  0%, 100% { box-shadow: 0 0 10px var(--accent-glow); }
  50%       { box-shadow: 0 0 30px var(--accent-glow), 0 0 60px var(--accent-glow); }
}
@keyframes runeRotate {
  from { transform: rotate(0deg); }
  to   { transform: rotate(360deg); }
}
@keyframes magicPulse {
  0%   { transform: scale(1); opacity: 1; }
  50%  { transform: scale(1.05); opacity: 0.85; }
  100% { transform: scale(1); opacity: 1; }
}
@keyframes textShimmer {
  0%   { background-position: -200% center; }
  100% { background-position: 200% center; }
}
@keyframes borderDraw {
  from { stroke-dashoffset: 1000; }
  to   { stroke-dashoffset: 0; }
}
@keyframes particleRise {
  0%   { transform: translateY(0) scale(1); opacity: 0.8; }
  100% { transform: translateY(-100px) scale(0); opacity: 0; }
}
@keyframes slideInLeft {
  from { transform: translateX(-40px); opacity: 0; }
  to   { transform: translateX(0); opacity: 1; }
}
@keyframes slideInRight {
  from { transform: translateX(40px); opacity: 0; }
  to   { transform: translateX(0); opacity: 1; }
}
@keyframes fadeInUp {
  from { transform: translateY(30px); opacity: 0; }
  to   { transform: translateY(0); opacity: 1; }
}
```

---

## Komponen UI Wajib (components.css)

Setiap komponen harus ada dalam template:

1. **`.adv-btn`** — Tombol dengan border rune, glow effect, hover transform
2. **`.adv-card`** — Card dengan dark bg, gold border, hover lift + glow
3. **`.adv-badge`** — Badge untuk rank/grup dengan warna dinamis
4. **`.adv-avatar`** — Avatar Minecraft skin dengan frame dekoratif
5. **`.adv-input`** — Input field dengan underline gold animasi
6. **`.adv-modal`** — Modal dengan backdrop blur + slide-in
7. **`.adv-tooltip`** — Tooltip custom dengan arrow
8. **`.adv-progress`** — Progress bar dengan shimmer animation
9. **`.adv-divider`** — Divider dengan ornamen rune di tengah
10. **`.adv-notification`** — Toast notification dengan slide+fade
11. **`.adv-skeleton`** — Loading skeleton screens
12. **`.adv-spoiler`** — Spoiler toggle di forum posts
13. **`.adv-code-block`** — Syntax-highlighted code block
14. **`.adv-quote`** — Quote block bergaya parchment scroll
15. **`.adv-breadcrumb`** — Breadcrumb dengan separator rune

---

## Integrasi Minecraft Spesifik

```smarty
{* Avatar dengan Crafatar/Minotar API *}
<img src="https://crafatar.com/avatars/{$profile_user.mc_uuid}?size=64&overlay"
     class="adv-mc-avatar"
     alt="{$profile_user.username}'s Minecraft skin">

{* Body render *}
<img src="https://crafatar.com/renders/body/{$profile_user.mc_uuid}?scale=4&overlay"
     class="adv-mc-body"
     alt="{$profile_user.username}">

{* Server status via NamelessMC built-in *}
{if $SERVER_ONLINE}
  <span class="status-online">● {$ONLINE_PLAYERS}/{$MAX_PLAYERS}</span>
{else}
  <span class="status-offline">● Offline</span>
{/if}
```

---

## Checklist Fitur Wajib Template

Setiap aspek ini HARUS tercakup dalam template:

### Halaman Publik
- [x] Homepage dengan hero parallax + particles + typed.js
- [x] Server status live (ping via NamelessMC)
- [x] Statistik animasi (member count, post count, online players)
- [x] News/artikel terbaru di homepage
- [x] Forum overview di homepage
- [x] Forum lengkap (index, category, topic, post, edit)
- [x] Store/Shop (index, category, product, checkout, success)
- [x] Staff page dengan grid + avatar Minecraft
- [x] Leaderboard (top players, top posters)
- [x] Gallery (album grid, lightbox)
- [x] Vote page
- [x] Contact/ban appeal
- [x] Custom 404/403/500 pages bergaya Adventure

### User System
- [x] Login dengan animasi form
- [x] Register multi-step
- [x] Profil publik dengan Minecraft skin render
- [x] User panel dashboard
- [x] Settings (avatar, password, 2FA, privacy)
- [x] Private messaging
- [x] Alerts/notifications
- [x] OAuth (Discord, Steam jika modul aktif)

### UX/Accessibility
- [x] Dark/Light mode toggle dengan persist localStorage
- [x] Responsive: mobile (320px+), tablet (768px+), desktop (1200px+)
- [x] Keyboard navigation friendly
- [x] ARIA labels di semua komponen interaktif
- [x] Loading states/skeleton screens
- [x] Back to top button animasi
- [x] Smooth scroll behavior
- [x] SEO: OG tags, Twitter card, structured data

### Performa
- [x] Lazy loading gambar
- [x] CSS/JS minified (atau referensi CDN)
- [x] Critical CSS inline di header
- [x] Font preloading
- [x] Particle count adaptif (reduced di mobile)

---

## Tips Smarty NamelessMC

```smarty
{* Include partial *}
{include file='global/header.tpl'}

{* URL helper *}
{$TEMPLATE_URL}/assets/img/logo.png

{* Loop items *}
{foreach from=$CATEGORIES item=category}
  ...
{/foreach}

{* Check permission *}
{if $LOGGED_IN}
  {* konten member *}
{/if}

{* Output URL dengan encode *}
{$SITE_URL|escape}

{* Truncate text *}
{$article.content|truncate:200:"..."}

{* Format date *}
{$post.date|date_format:"%d %b %Y"}

{* CSRF token di form *}
<input type="hidden" name="token" value="{$TOKEN}">

{* Translatable string *}
{$LANGUAGE->get('general', 'home')}
```

---

## Panduan Kualitas Premium ($1000+)

Template harus memenuhi standar ini untuk layak dijual di atas $1000:

1. **Visual Polish** — Tidak ada elemen default/plain, semua punya custom styling
2. **Animation Depth** — Minimal 15 animasi berbeda yang terasa natural, bukan gimmick
3. **Konsistensi** — Design system ketat, tidak ada warna hardcoded di luar CSS variables
4. **Dokumentasi** — README.md lengkap, inline comment di semua file
5. **Customizability** — Semua warna, teks, dan fitur bisa diubah dari template.yaml settings
6. **Support** — Changelog.md, error-handling yang graceful, fallback untuk browser lama
7. **Performance** — PageSpeed Insights score 80+ untuk mobile
8. **Unique Assets** — Custom illustrations/icons, bukan stock icon biasa
9. **Easter Eggs** — Konami code, hover interactions tersembunyi = kesan "made with love"
10. **Mobile UX** — Hamburger menu animasi, bottom navigation bar di mobile
