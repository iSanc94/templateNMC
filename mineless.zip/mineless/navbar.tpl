{* Mineless Theme - Navbar *}
{* Dark Fantasy Mineless Navbar with sticky blur effect *}

{* Mobile Sidebar Off-Canvas *}
<div id="mobile-sidebar" class="mobile-sidebar">
    <div class="mobile-sidebar-overlay" onclick="toggleMobileSidebar()"></div>
    <div class="mobile-sidebar-content">
        <div class="mobile-sidebar-header">
            <a href="{$SITE_HOME}" class="mobile-logo">
                <span class="mineless-logo-text"><i class="fas fa-dragon"></i> {$SITE_NAME}</span>
            </a>
            <button class="mobile-close-btn" onclick="toggleMobileSidebar()" aria-label="Close menu">
                <span></span>
                <span></span>
            </button>
        </div>
        
        <nav class="mobile-nav">
            {foreach from=$NAV_LINKS item=item}
                <div class="mobile-nav-item" style="--delay: {$item@index * 0.05}s">
                    {if isset($item.items)}
                        <div class="mobile-nav-dropdown">
                            <button class="mobile-nav-link has-children" onclick="toggleMobileDropdown(this)">
                                <span>{$item.title}</span>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="mobile-dropdown-menu">
                                {foreach from=$item.items item=subitem}
                                    <a href="{$subitem.link}" class="mobile-dropdown-link {if isset($subitem.active)}active{/if}">
                                        {if isset($subitem.icon)}<i class="{$subitem.icon}"></i>{/if}
                                        <span>{$subitem.title}</span>
                                    </a>
                                {/foreach}
                            </div>
                        </div>
                    {else}
                        <a href="{$item.link}" class="mobile-nav-link {if isset($item.active)}active{/if}">
                            {if isset($item.icon)}<i class="{$item.icon}"></i>{/if}
                            <span>{$item.title}</span>
                        </a>
                    {/if}
                </div>
            {/foreach}
        </nav>
        
        <div class="mobile-sidebar-footer">
            {if $LOGGED_IN_USER}
                <div class="mobile-user-section">
                    <a href="{$USER_SECTION.profile.link}" class="mobile-user-info">
                        <img src="https://cravatar.eu/avatar/{$USER_SECTION.username|default:'Steve'}/48.png" alt="{$USER_SECTION.username}" class="mobile-user-avatar">
                        <div class="mobile-user-details">
                            <span class="mobile-username">{$USER_SECTION.username}</span>
                            <span class="mobile-user-group">{$USER_SECTION.group}</span>
                        </div>
                    </a>
                </div>
                <div class="mobile-user-actions">
                    <a href="{$USER_SECTION.profile.link}" class="mobile-action-btn">
                        <i class="fas fa-user"></i>
                        <span>Profile</span>
                    </a>
                    {if isset($USER_SECTION.panel)}
                        <a href="{$USER_SECTION.panel.link}" class="mobile-action-btn">
                            <i class="fas fa-cog"></i>
                            <span>Panel</span>
                        </a>
                    {/if}
                    {if isset($USER_SECTION.settings)}
                        <a href="{$USER_SECTION.settings.link}" class="mobile-action-btn">
                            <i class="fas fa-sliders-h"></i>
                            <span>Settings</span>
                        </a>
                    {/if}
                    <a href="{$USER_SECTION.logout.link}" class="mobile-action-btn logout">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </div>
            {else}
                <div class="mobile-auth-buttons">
                    <a href="{$LOGIN_LINK}" class="mineless-btn adv-btn-outline adv-btn-block">Login</a>
                    <a href="{$REGISTER_LINK}" class="mineless-btn adv-btn-primary adv-btn-block">Register</a>
                </div>
            {/if}
        </div>
    </div>
</div>

{* Main Navbar *}
<header class="mineless-navbar" id="main-navbar" data-scroll-threshold="80">
    <div class="mineless-navbar-inner">
        {* Left: Logo *}
        <div class="mineless-navbar-brand">
            <a href="{$SITE_HOME}" class="mineless-logo">
                <span class="mineless-logo-text"><i class="fas fa-dragon"></i> {$SITE_NAME}</span>
            </a>
        </div>
        
        {* Center: Desktop Navigation *}
        <nav class="mineless-navbar-nav">
            {foreach from=$NAV_LINKS item=item}
                {if isset($item.items)}
                    <div class="mineless-nav-item adv-dropdown">
                        <button class="mineless-nav-link has-dropdown {if isset($item.active)}active{/if}">
                            <span>{$item.title}</span>
                            <i class="fas fa-chevron-down dropdown-arrow"></i>
                        </button>
                        <div class="mineless-dropdown-menu">
                            <div class="mineless-dropdown-content">
                                {foreach from=$item.items item=subitem}
                                    <a href="{$subitem.link}" class="mineless-dropdown-link {if isset($subitem.active)}active{/if}">
                                        {if isset($subitem.icon)}
                                            <span class="dropdown-icon"><i class="{$subitem.icon}"></i></span>
                                        {/if}
                                        <span class="dropdown-text">{$subitem.title}</span>
                                    </a>
                                {/foreach}
                            </div>
                        </div>
                    </div>
                {else}
                    <div class="mineless-nav-item">
                        <a href="{$item.link}" class="mineless-nav-link {if isset($item.active)}active{/if}">
                            <span>{$item.title}</span>
                        </a>
                    </div>
                {/if}
            {/foreach}
        </nav>
        
        {* Right: Actions *}
        <div class="mineless-navbar-actions">
            {* Dark/Light Toggle *}
            <button class="mineless-theme-toggle" id="theme-toggle" aria-label="Toggle theme">
                <div class="theme-toggle-track">
                    <div class="theme-toggle-thumb">
                        <i class="fas fa-sun sun-icon"></i>
                        <i class="fas fa-moon moon-icon"></i>
                    </div>
                </div>
            </button>
            
            {if $LOGGED_IN_USER}
                {* Notifications *}
                <div class="mineless-nav-item adv-dropdown notification-dropdown">
                    <button class="mineless-nav-icon notification-btn" aria-label="Notifications">
                        <i class="fas fa-bell"></i>
                        {if $NOTIFICATION_COUNT > 0}
                            <span class="notification-badge">{$NOTIFICATION_COUNT}</span>
                        {/if}
                    </button>
                    <div class="mineless-dropdown-menu dropdown-right notification-menu">
                        <div class="mineless-dropdown-header">
                            <span>Notifications</span>
                            {if $NOTIFICATION_COUNT > 0}
                                <a href="{$NOTIFICATIONS_LINK}" class="mark-all-read">Mark all as read</a>
                            {/if}
                        </div>
                        <div class="mineless-dropdown-content notification-list">
                            {if isset($NOTIFICATION_LIST) && is_array($NOTIFICATION_LIST) && count($NOTIFICATION_LIST) > 0}
                                {foreach from=$NOTIFICATION_LIST item=notification}
                                    <a href="{$notification.link}" class="mineless-dropdown-link notification-item {if !$notification.read}unread{/if}">
                                        <img src="https://cravatar.eu/avatar/Steve/40.png" alt="" class="notification-avatar">
                                        <div class="notification-content">
                                            <p class="notification-text">{$notification.text}</p>
                                            <span class="notification-time">{$notification.time}</span>
                                        </div>
                                    </a>
                                {/foreach}
                            {else}
                                <div class="notification-empty">
                                    <i class="fas fa-bell-slash"></i>
                                    <p>No notifications</p>
                                </div>
                            {/if}
                        </div>
                        <div class="mineless-dropdown-footer">
                            <a href="{$NOTIFICATIONS_LINK}">View all notifications</a>
                        </div>
                    </div>
                </div>
                
                {* User Avatar Dropdown *}
                <div class="mineless-nav-item adv-dropdown user-dropdown">
                    <button class="mineless-nav-user">
                        <img src="https://cravatar.eu/avatar/{$USER_SECTION.username|default:'Steve'}/32.png" alt="{$USER_SECTION.username}" class="user-avatar">
                        <span class="user-name">{$USER_SECTION.nickname|default:$USER_SECTION.username}</span>
                        <i class="fas fa-chevron-down user-arrow"></i>
                    </button>
                    <div class="mineless-dropdown-menu dropdown-right user-menu">
                        <div class="mineless-dropdown-userinfo">
                            <img src="https://cravatar.eu/avatar/{$USER_SECTION.username|default:'Steve'}/48.png" alt="{$USER_SECTION.username}" class="userinfo-avatar">
                            <div class="userinfo-details">
                                <span class="userinfo-name">{$USER_SECTION.nickname|default:$USER_SECTION.username}</span>
                                <span class="userinfo-username">@{$USER_SECTION.username}</span>
                                <span class="userinfo-group">{$USER_SECTION.group}</span>
                            </div>
                        </div>
                        <div class="mineless-dropdown-divider"></div>
                        <div class="mineless-dropdown-content">
                            <a href="{$USER_SECTION.profile.link}" class="mineless-dropdown-link">
                                <span class="dropdown-icon"><i class="fas fa-user"></i></span>
                                <span class="dropdown-text">Profile</span>
                            </a>
                            {if isset($USER_SECTION.panel)}
                                <a href="{$USER_SECTION.panel.link}" class="mineless-dropdown-link">
                                    <span class="dropdown-icon"><i class="fas fa-cog"></i></span>
                                    <span class="dropdown-text">Panel</span>
                                </a>
                            {/if}
                            {if isset($USER_SECTION.settings)}
                                <a href="{$USER_SECTION.settings.link}" class="mineless-dropdown-link">
                                    <span class="dropdown-icon"><i class="fas fa-sliders-h"></i></span>
                                    <span class="dropdown-text">Settings</span>
                                </a>
                            {/if}
                        </div>
                        <div class="mineless-dropdown-divider"></div>
                        <div class="mineless-dropdown-content">
                            <a href="{$USER_SECTION.logout.link}" class="mineless-dropdown-link logout">
                                <span class="dropdown-icon"><i class="fas fa-sign-out-alt"></i></span>
                                <span class="dropdown-text">Logout</span>
                            </a>
                        </div>
                    </div>
                </div>
            {else}
                {* Guest Buttons *}
                <div class="mineless-auth-buttons">
                    <a href="{$LOGIN_LINK}" class="mineless-btn adv-btn-outline adv-btn-sm">Login</a>
                    <a href="{$REGISTER_LINK}" class="mineless-btn adv-btn-primary adv-btn-sm">Register</a>
                </div>
            {/if}
            
            {* Mobile Hamburger *}
            <button class="mineless-hamburger" id="mobile-menu-toggle" onclick="toggleMobileSidebar()" aria-label="Toggle menu">
                <span class="hamburger-line line-1"></span>
                <span class="hamburger-line line-2"></span>
                <span class="hamburger-line line-3"></span>
            </button>
        </div>
    </div>
</header>

{* Spacer untuk navbar fixed *}
<div class="navbar-spacer"></div>

<style>
/* ============================================
   Mineless THEME - NAVBAR
   Dark Fantasy Mineless Design System
   ============================================ */

/* CSS Variables */
:root {
    --mineless-navbar-height: 72px;
    --mineless-navbar-height-mobile: 64px;
    --mineless-bg-transparent: transparent;
    --mineless-bg-dark: rgba(13, 15, 20, 0.95);
    --mineless-bg-dark-solid: #0d0f14;
    --mineless-blur-amount: 20px;
    --mineless-transition-fast: 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    --mineless-transition-normal: 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    --mineless-transition-slow: 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    --mineless-glow-primary: 0 0 20px rgba(212, 175, 55, 0.4);
    --mineless-shadow-navbar: 0 4px 30px rgba(0, 0, 0, 0.4);
    --mineless-border-light: rgba(212, 175, 55, 0.15);
    --mineless-border-accent: rgba(212, 175, 55, 0.5);
    --mineless-text-primary: #f5f5f5;
    --mineless-text-secondary: #a0a0a0;
    --mineless-text-accent: #d4af37;
    --mineless-danger: #dc3545;
}

/* Navbar Base */
.mineless-navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    height: var(--mineless-navbar-height);
    transition: all var(--mineless-transition-normal);
    background: var(--mineless-bg-transparent);
    border-bottom: 1px solid transparent;
}

.mineless-navbar.scrolled {
    background: var(--mineless-bg-dark);
    backdrop-filter: blur(var(--mineless-blur-amount));
    -webkit-backdrop-filter: blur(var(--mineless-blur-amount));
    border-bottom-color: var(--mineless-border-light);
    box-shadow: var(--mineless-shadow-navbar);
}

.mineless-navbar-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 100%;
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 24px;
}

.navbar-spacer {
    height: var(--mineless-navbar-height);
}

/* Logo */
.mineless-navbar-brand {
    flex-shrink: 0;
}

.mineless-logo {
    display: flex;
    align-items: center;
    text-decoration: none;
    transition: filter var(--mineless-transition-fast);
}

.mineless-logo:hover {
    filter: drop-shadow(0 0 8px rgba(212, 175, 55, 0.6));
}

.mineless-logo-img {
    height: 40px;
    width: auto;
    transition: transform var(--mineless-transition-fast);
}

.mineless-logo:hover .mineless-logo-img {
    transform: scale(1.02);
}

.mineless-logo-text {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--mineless-text-accent);
    text-transform: uppercase;
    letter-spacing: 1px;
    text-shadow: 0 0 10px rgba(212, 175, 55, 0.3);
}

/* Desktop Navigation */
.mineless-navbar-nav {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    justify-content: center;
}

.mineless-nav-item {
    position: relative;
}

.mineless-nav-link {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 10px 16px;
    color: var(--mineless-text-secondary);
    text-decoration: none;
    font-size: 0.95rem;
    font-weight: 500;
    position: relative;
    transition: color var(--mineless-transition-fast);
    background: none;
    border: none;
    cursor: pointer;
    font-family: inherit;
}

.mineless-nav-link::after {
    content: '';
    position: absolute;
    bottom: 4px;
    left: 16px;
    right: 16px;
    height: 2px;
    background: var(--mineless-text-accent);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform var(--mineless-transition-normal);
    border-radius: 1px;
}

.mineless-nav-link:hover,
.mineless-nav-link.active {
    color: var(--mineless-text-primary);
}

.mineless-nav-link:hover::after,
.mineless-nav-link.active::after {
    transform: scaleX(1);
}

.mineless-nav-link.has-dropdown .dropdown-arrow {
    font-size: 0.75rem;
    transition: transform var(--mineless-transition-fast);
}

.mineless-dropdown:hover .dropdown-arrow,
.mineless-dropdown.active .dropdown-arrow {
    transform: rotate(180deg);
}

/* Dropdown */
.mineless-dropdown-menu {
    position: absolute;
    top: 100%;
    left: 50%;
    transform: translateX(-50%) translateY(10px);
    min-width: 220px;
    background: var(--mineless-bg-dark);
    backdrop-filter: blur(var(--mineless-blur-amount));
    -webkit-backdrop-filter: blur(var(--mineless-blur-amount));
    border: 1px solid var(--mineless-border-light);
    border-radius: 12px;
    padding: 8px;
    opacity: 0;
    visibility: hidden;
    transition: all var(--mineless-transition-fast);
    box-shadow: var(--mineless-shadow-navbar);
    margin-top: 8px;
}

.mineless-dropdown-menu.dropdown-right {
    left: auto;
    right: 0;
    transform: translateX(0) translateY(10px);
}

.mineless-dropdown:hover .mineless-dropdown-menu,
.mineless-dropdown.active .mineless-dropdown-menu {
    opacity: 1;
    visibility: visible;
    transform: translateX(-50%) translateY(0);
}

.mineless-dropdown-menu.dropdown-right:hover,
.mineless-dropdown-menu.dropdown-right.active {
    transform: translateX(0) translateY(0);
}

.mineless-dropdown-content {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.mineless-dropdown-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 16px;
    border-bottom: 1px solid var(--mineless-border-light);
    margin-bottom: 8px;
}

.mineless-dropdown-header span {
    font-weight: 600;
    color: var(--mineless-text-primary);
    font-size: 0.9rem;
}

.mineless-dropdown-header .mark-all-read {
    font-size: 0.75rem;
    color: var(--mineless-text-accent);
    text-decoration: none;
}

.mineless-dropdown-header .mark-all-read:hover {
    text-decoration: underline;
}

.mineless-dropdown-footer {
    padding: 12px 16px;
    border-top: 1px solid var(--mineless-border-light);
    margin-top: 8px;
    text-align: center;
}

.mineless-dropdown-footer a {
    color: var(--mineless-text-accent);
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 500;
}

.mineless-dropdown-footer a:hover {
    text-decoration: underline;
}

.mineless-dropdown-link {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 14px;
    color: var(--mineless-text-secondary);
    text-decoration: none;
    border-radius: 8px;
    transition: all var(--mineless-transition-fast);
    font-size: 0.9rem;
}

.mineless-dropdown-link:hover,
.mineless-dropdown-link.active {
    background: rgba(212, 175, 55, 0.1);
    color: var(--mineless-text-primary);
}

.mineless-dropdown-link.logout:hover {
    background: rgba(220, 53, 69, 0.1);
    color: var(--mineless-danger);
}

.dropdown-icon {
    width: 20px;
    text-align: center;
    color: var(--mineless-text-accent);
}

.mineless-dropdown-divider {
    height: 1px;
    background: var(--mineless-border-light);
    margin: 8px 0;
}

/* Right Actions */
.mineless-navbar-actions {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-shrink: 0;
}

/* Theme Toggle */
.mineless-theme-toggle {
    width: 48px;
    height: 26px;
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
    position: relative;
}

.theme-toggle-track {
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 13px;
    position: relative;
    transition: background var(--mineless-transition-fast);
    border: 1px solid var(--mineless-border-light);
}

.mineless-theme-toggle:hover .theme-toggle-track {
    background: rgba(255, 255, 255, 0.15);
}

.theme-toggle-thumb {
    position: absolute;
    top: 2px;
    left: 2px;
    width: 20px;
    height: 20px;
    background: var(--mineless-text-accent);
    border-radius: 50%;
    transition: transform var(--mineless-transition-normal);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
}

.theme-toggle-thumb i {
    font-size: 10px;
    color: var(--mineless-bg-dark-solid);
    position: absolute;
    transition: opacity var(--mineless-transition-fast), transform var(--mineless-transition-fast);
}

.theme-toggle-thumb .sun-icon {
    opacity: 1;
    transform: rotate(0);
}

.theme-toggle-thumb .moon-icon {
    opacity: 0;
    transform: rotate(-90deg);
}

[data-theme="dark"] .theme-toggle-thumb,
.dark-mode .theme-toggle-thumb {
    transform: translateX(22px);
}

[data-theme="dark"] .sun-icon,
.dark-mode .sun-icon {
    opacity: 0;
    transform: rotate(90deg);
}

[data-theme="dark"] .moon-icon,
.dark-mode .moon-icon {
    opacity: 1;
    transform: rotate(0);
}

/* Notification */
.notification-btn {
    position: relative;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--mineless-text-secondary);
    background: none;
    border: none;
    cursor: pointer;
    border-radius: 10px;
    transition: all var(--mineless-transition-fast);
    font-size: 1.1rem;
}

.notification-btn:hover {
    background: rgba(212, 175, 55, 0.1);
    color: var(--mineless-text-primary);
}

.notification-badge {
    position: absolute;
    top: 4px;
    right: 4px;
    min-width: 18px;
    height: 18px;
    padding: 0 5px;
    background: var(--mineless-danger);
    color: white;
    font-size: 0.65rem;
    font-weight: 700;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

.notification-menu {
    min-width: 320px;
}

.notification-list {
    max-height: 320px;
    overflow-y: auto;
}

.notification-item {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 12px;
}

.notification-item.unread {
    background: rgba(212, 175, 55, 0.05);
}

.notification-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
    flex-shrink: 0;
}

.notification-content {
    flex: 1;
    min-width: 0;
}

.notification-text {
    margin: 0;
    font-size: 0.85rem;
    color: var(--mineless-text-primary);
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.notification-time {
    font-size: 0.75rem;
    color: var(--mineless-text-secondary);
    margin-top: 4px;
    display: block;
}

.notification-empty {
    padding: 32px;
    text-align: center;
    color: var(--mineless-text-secondary);
}

.notification-empty i {
    font-size: 2rem;
    margin-bottom: 8px;
    opacity: 0.5;
}

.notification-empty p {
    margin: 0;
    font-size: 0.9rem;
}

/* User Dropdown */
.mineless-nav-user {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 6px 12px 6px 6px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid var(--mineless-border-light);
    border-radius: 50px;
    cursor: pointer;
    transition: all var(--mineless-transition-fast);
}

.mineless-nav-user:hover {
    background: rgba(255, 255, 255, 0.1);
    border-color: var(--mineless-border-accent);
}

.user-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid var(--mineless-border-accent);
}

.user-name {
    color: var(--mineless-text-primary);
    font-size: 0.9rem;
    font-weight: 500;
    max-width: 120px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.user-arrow {
    font-size: 0.7rem;
    color: var(--mineless-text-secondary);
    transition: transform var(--mineless-transition-fast);
}

.mineless-nav-user:hover .user-arrow {
    transform: rotate(180deg);
}

.user-menu {
    min-width: 260px;
}

.mineless-dropdown-userinfo {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 16px;
}

.userinfo-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid var(--mineless-border-accent);
}

.userinfo-details {
    display: flex;
    flex-direction: column;
    min-width: 0;
}

.userinfo-name {
    color: var(--mineless-text-primary);
    font-weight: 600;
    font-size: 1rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.userinfo-username {
    color: var(--mineless-text-secondary);
    font-size: 0.8rem;
}

.userinfo-group {
    color: var(--mineless-text-accent);
    font-size: 0.75rem;
    margin-top: 2px;
    font-weight: 500;
}

/* Auth Buttons */
.mineless-auth-buttons {
    display: flex;
    align-items: center;
    gap: 10px;
}

.mineless-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 20px;
    font-size: 0.9rem;
    font-weight: 600;
    text-decoration: none;
    border-radius: 8px;
    transition: all var(--mineless-transition-fast);
    cursor: pointer;
    border: none;
    font-family: inherit;
}

.mineless-btn-sm {
    padding: 8px 16px;
    font-size: 0.85rem;
}

.mineless-btn-block {
    width: 100%;
}

.mineless-btn-primary {
    background: linear-gradient(135deg, #d4af37 0%, #c19d2a 100%);
    color: #0d0f14;
    box-shadow: 0 4px 15px rgba(212, 175, 55, 0.3);
}

.mineless-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(212, 175, 55, 0.4);
}

.mineless-btn-outline {
    background: transparent;
    color: var(--mineless-text-accent);
    border: 1px solid var(--mineless-border-accent);
}

.mineless-btn-outline:hover {
    background: rgba(212, 175, 55, 0.1);
    border-color: var(--mineless-text-accent);
}

/* Hamburger Menu */
.mineless-hamburger {
    display: none;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 40px;
    height: 40px;
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
    gap: 6px;
}

.hamburger-line {
    display: block;
    width: 24px;
    height: 2px;
    background: var(--mineless-text-primary);
    border-radius: 1px;
    transition: all var(--mineless-transition-normal);
    transform-origin: center;
}

.mineless-hamburger.active .line-1 {
    transform: translateY(8px) rotate(45deg);
}

.mineless-hamburger.active .line-2 {
    opacity: 0;
    transform: scaleX(0);
}

.mineless-hamburger.active .line-3 {
    transform: translateY(-8px) rotate(-45deg);
}

/* Mobile Sidebar */
.mobile-sidebar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 2000;
    visibility: hidden;
    opacity: 0;
    transition: all var(--mineless-transition-normal);
}

.mobile-sidebar.active {
    visibility: visible;
    opacity: 1;
}

.mobile-sidebar-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(4px);
    opacity: 0;
    transition: opacity var(--mineless-transition-normal);
}

.mobile-sidebar.active .mobile-sidebar-overlay {
    opacity: 1;
}

.mobile-sidebar-content {
    position: absolute;
    top: 0;
    right: 0;
    width: 100%;
    max-width: 360px;
    height: 100%;
    background: var(--mineless-bg-dark-solid);
    transform: translateX(100%);
    transition: transform var(--mineless-transition-slow);
    display: flex;
    flex-direction: column;
    border-left: 1px solid var(--mineless-border-light);
}

.mobile-sidebar.active .mobile-sidebar-content {
    transform: translateX(0);
}

.mobile-sidebar-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 24px;
    border-bottom: 1px solid var(--mineless-border-light);
}

.mobile-logo-img {
    height: 36px;
    width: auto;
}

.mobile-close-btn {
    width: 36px;
    height: 36px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 0;
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
}

.mobile-close-btn span {
    display: block;
    width: 22px;
    height: 2px;
    background: var(--mineless-text-primary);
    border-radius: 1px;
}

.mobile-close-btn span:first-child {
    transform: rotate(45deg);
}

.mobile-close-btn span:last-child {
    transform: rotate(-45deg);
    margin-top: -2px;
}

.mobile-nav {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
}

.mobile-nav-item {
    opacity: 0;
    transform: translateY(10px);
    transition: all var(--mineless-transition-normal);
    transition-delay: var(--delay, 0s);
}

.mobile-sidebar.active .mobile-nav-item {
    opacity: 1;
    transform: translateY(0);
}

.mobile-nav-link {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 16px;
    color: var(--mineless-text-secondary);
    text-decoration: none;
    font-size: 1rem;
    font-weight: 500;
    border-radius: 10px;
    transition: all var(--mineless-transition-fast);
    background: none;
    border: none;
    width: 100%;
    text-align: left;
    cursor: pointer;
    font-family: inherit;
}

.mobile-nav-link i {
    width: 20px;
    text-align: center;
    transition: transform var(--mineless-transition-fast);
}

.mobile-nav-link.has-children {
    justify-content: space-between;
}

.mobile-nav-link.has-children > span {
    display: flex;
    align-items: center;
    gap: 12px;
}

.mobile-nav-link:hover,
.mobile-nav-link.active {
    background: rgba(212, 175, 55, 0.1);
    color: var(--mineless-text-primary);
}

.mobile-dropdown-menu {
    max-height: 0;
    overflow: hidden;
    transition: max-height var(--mineless-transition-normal);
}

.mobile-dropdown-menu.open {
    max-height: 500px;
}

.mobile-dropdown-menu.open + .mobile-nav-link .fa-chevron-down,
.mobile-nav-link.active .fa-chevron-down {
    transform: rotate(180deg);
}

.mobile-dropdown-link {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px 12px 48px;
    color: var(--mineless-text-secondary);
    text-decoration: none;
    font-size: 0.9rem;
    border-radius: 8px;
    transition: all var(--mineless-transition-fast);
}

.mobile-dropdown-link:hover,
.mobile-dropdown-link.active {
    background: rgba(212, 175, 55, 0.05);
    color: var(--mineless-text-primary);
}

.mobile-sidebar-footer {
    padding: 20px 24px;
    border-top: 1px solid var(--mineless-border-light);
    background: rgba(0, 0, 0, 0.2);
}

.mobile-user-section {
    margin-bottom: 16px;
}

.mobile-user-info {
    display: flex;
    align-items: center;
    gap: 14px;
    text-decoration: none;
    padding: 12px;
    border-radius: 12px;
    background: rgba(212, 175, 55, 0.05);
    border: 1px solid var(--mineless-border-light);
    transition: all var(--mineless-transition-fast);
}

.mobile-user-info:hover {
    border-color: var(--mineless-border-accent);
    background: rgba(212, 175, 55, 0.1);
}

.mobile-user-avatar {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid var(--mineless-border-accent);
}

.mobile-user-details {
    display: flex;
    flex-direction: column;
}

.mobile-username {
    color: var(--mineless-text-primary);
    font-weight: 600;
    font-size: 1rem;
}

.mobile-user-group {
    color: var(--mineless-text-accent);
    font-size: 0.8rem;
}

.mobile-user-actions {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
}

.mobile-action-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid var(--mineless-border-light);
    border-radius: 10px;
    color: var(--mineless-text-secondary);
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 500;
    transition: all var(--mineless-transition-fast);
}

.mobile-action-btn:hover {
    background: rgba(212, 175, 55, 0.1);
    border-color: var(--mineless-border-accent);
    color: var(--mineless-text-primary);
}

.mobile-action-btn.logout:hover {
    background: rgba(220, 53, 69, 0.1);
    border-color: var(--mineless-danger);
    color: var(--mineless-danger);
}

.mobile-auth-buttons {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

/* Responsive */
@media (max-width: 1024px) {
    .mineless-navbar-nav {
        display: none;
    }
    
    .mineless-hamburger {
        display: flex;
    }
    
    .user-name {
        display: none;
    }
    
    .mineless-nav-user {
        padding: 4px;
    }
}

@media (max-width: 576px) {
    :root {
        --mineless-navbar-height: var(--mineless-navbar-height-mobile);
    }
    
    .mineless-navbar-inner {
        padding: 0 16px;
    }
    
    .mineless-logo-img {
        height: 32px;
    }
    
    .mineless-auth-buttons {
        display: none;
    }
    
    .notification-menu,
    .user-menu {
        position: fixed;
        top: var(--mineless-navbar-height);
        left: 16px;
        right: 16px;
        min-width: auto;
        transform: translateY(10px);
    }
    
    .mineless-dropdown:hover .mineless-dropdown-menu,
    .mineless-dropdown.active .mineless-dropdown-menu {
        transform: translateY(0);
    }
}

/* Scrollbar Styling */
.mobile-nav::-webkit-scrollbar,
.notification-list::-webkit-scrollbar {
    width: 6px;
}

.mobile-nav::-webkit-scrollbar-track,
.notification-list::-webkit-scrollbar-track {
    background: transparent;
}

.mobile-nav::-webkit-scrollbar-thumb,
.notification-list::-webkit-scrollbar-thumb {
    background: var(--mineless-border-light);
    border-radius: 3px;
}

.mobile-nav::-webkit-scrollbar-thumb:hover,
.notification-list::-webkit-scrollbar-thumb:hover {
    background: var(--mineless-border-accent);
}
</style>

<script>
// ============================================
// Mineless THEME - NAVBAR SCRIPTS
// ============================================

(function() {
    'use strict';
    
    // Navbar Scroll Effect
    const navbar = document.getElementById('main-navbar');
    const scrollThreshold = parseInt(navbar.dataset.scrollThreshold) || 80;
    let lastScroll = 0;
    
    function handleScroll() {
        const currentScroll = window.pageYOffset;
        
        if (currentScroll > scrollThreshold) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
        
        lastScroll = currentScroll;
    }
    
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    
    // Mobile Sidebar Toggle
    window.toggleMobileSidebar = function() {
        const sidebar = document.getElementById('mobile-sidebar');
        const hamburger = document.getElementById('mobile-menu-toggle');
        const body = document.body;
        
        sidebar.classList.toggle('active');
        hamburger.classList.toggle('active');
        
        // Prevent body scroll when sidebar is open
        if (sidebar.classList.contains('active')) {
            body.style.overflow = 'hidden';
        } else {
            body.style.overflow = '';
        }
    };
    
    // Mobile Dropdown Toggle
    window.toggleMobileDropdown = function(btn) {
        const dropdown = btn.nextElementSibling;
        const isOpen = dropdown.classList.contains('open');
        
        // Close all other dropdowns
        document.querySelectorAll('.mobile-dropdown-menu.open').forEach(menu => {
            if (menu !== dropdown) {
                menu.classList.remove('open');
                menu.previousElementSibling.classList.remove('active');
            }
        });
        
        // Toggle current dropdown
        dropdown.classList.toggle('open');
        btn.classList.toggle('active');
    };
    
    // Theme Toggle
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('Mineless-theme', newTheme);
            
            // Dispatch custom event for other components
            window.dispatchEvent(new CustomEvent('themechange', { 
                detail: { theme: newTheme } 
            }));
        });
    }
    
    // Load saved theme
    const savedTheme = localStorage.getItem('Mineless-theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
    }
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.mineless-dropdown')) {
            document.querySelectorAll('.mineless-dropdown.active').forEach(dropdown => {
                dropdown.classList.remove('active');
            });
        }
    });
    
    // Dropdown toggle on click (for mobile support)
    document.querySelectorAll('.mineless-dropdown').forEach(dropdown => {
        const toggle = dropdown.querySelector('.mineless-nav-link, .mineless-nav-icon, .mineless-nav-user');
        if (toggle) {
            toggle.addEventListener('click', function(e) {
                if (window.innerWidth <= 1024) {
                    e.preventDefault();
                    dropdown.classList.toggle('active');
                }
            });
        }
    });
    
    // Close mobile sidebar on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const sidebar = document.getElementById('mobile-sidebar');
            if (sidebar.classList.contains('active')) {
                toggleMobileSidebar();
            }
        }
    });
    
})();
</script>
