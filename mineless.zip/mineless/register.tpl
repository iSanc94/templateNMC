{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-auth-section">
    <div class="mineless-auth-bg">
        <div class="mineless-auth-particles" id="auth-particles"></div>
    </div>
    
    <div class="mineless-auth-container">
        <div class="mineless-auth-card adv-register-card" data-animate="fade-in-up">
            <div class="mineless-auth-border"></div>
            
            <div class="mineless-auth-header">
                <div class="mineless-auth-icon adv-register-icon">
                    <i class="fas fa-scroll"></i>
                </div>
                <h1 class="mineless-auth-title">{$CREATE_AN_ACCOUNT}</h1>
                <p class="mineless-auth-subtitle">Start your adventure now!</p>
            </div>
            
            <!-- Progress Steps -->
            <div class="mineless-register-progress">
                <div class="mineless-progress-line">
                    <div class="mineless-progress-fill" id="progress-fill"></div>
                </div>
                <div class="mineless-progress-steps">
                    <div class="mineless-step active" data-step="1">
                        <div class="mineless-step-number">1</div>
                        <span class="mineless-step-label">Account</span>
                    </div>
                    <div class="mineless-step" data-step="2">
                        <div class="mineless-step-number">2</div>
                        <span class="mineless-step-label">Verification</span>
                    </div>
                    <div class="mineless-step" data-step="3">
                        <div class="mineless-step-number">3</div>
                        <span class="mineless-step-label">Complete</span>
                    </div>
                </div>
            </div>
            
            {if isset($ERROR)}
                <div class="mineless-alert adv-alert-error adv-shake">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>{$ERROR}</span>
                </div>
            {/if}
            
            <!-- Step 1: Account Info -->
            <div class="mineless-register-step active" id="step-1">
                <form class="mineless-form" id="form-step-1">
                    <input type="hidden" name="token" value="{$TOKEN}">
                    
                    <div class="mineless-form-group">
                        <label for="username" class="mineless-form-label">{$USERNAME}</label>
                        <div class="mineless-input-wrapper">
                            <i class="fas fa-user adv-input-icon"></i>
                            <input type="text" id="username" name="username" class="mineless-input" placeholder="Choose username" required>
                        </div>
                        <span class="mineless-input-help">Minimum 3 characters, letters, numbers, and underscores only</span>
                    </div>
                    
                    <div class="mineless-form-group">
                        <label for="email" class="mineless-form-label">{$EMAIL}</label>
                        <div class="mineless-input-wrapper">
                            <i class="fas fa-envelope adv-input-icon"></i>
                            <input type="email" id="email" name="email" class="mineless-input" placeholder="email@example.com" required>
                        </div>
                    </div>
                    
                    <div class="mineless-form-group">
                        <label for="password" class="mineless-form-label">{$PASSWORD}</label>
                        <div class="mineless-input-wrapper">
                            <i class="fas fa-lock adv-input-icon"></i>
                            <input type="password" id="password" name="password" class="mineless-input" placeholder="Create password" required>
                            <button type="button" class="mineless-password-toggle" onclick="togglePassword('password', this)">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        
                        <!-- Password Strength Meter -->
                        <div class="mineless-password-strength">
                            <div class="mineless-strength-bar">
                                <div class="mineless-strength-fill" id="strength-fill"></div>
                            </div>
                            <span class="mineless-strength-text" id="strength-text">Password strength</span>
                        </div>
                        
                        <div class="mineless-password-requirements">
                            <div class="mineless-req-item" data-req="length">
                                <i class="fas fa-circle"></i>
                                <span>Minimum 8 characters</span>
                            </div>
                            <div class="mineless-req-item" data-req="uppercase">
                                <i class="fas fa-circle"></i>
                                <span>Uppercase letters (A-Z)</span>
                            </div>
                            <div class="mineless-req-item" data-req="lowercase">
                                <i class="fas fa-circle"></i>
                                <span>Lowercase letters (a-z)</span>
                            </div>
                            <div class="mineless-req-item" data-req="number">
                                <i class="fas fa-circle"></i>
                                <span>Numbers (0-9)</span>
                            </div>
                            <div class="mineless-req-item" data-req="special">
                                <i class="fas fa-circle"></i>
                                <span>Special characters (!@#$%)</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mineless-form-group">
                        <label for="password_confirm" class="mineless-form-label">{$CONFIRM_PASSWORD}</label>
                        <div class="mineless-input-wrapper">
                            <i class="fas fa-lock adv-input-icon"></i>
                            <input type="password" id="password_confirm" name="password_confirm" class="mineless-input" placeholder="Confirm password" required>
                            <button type="button" class="mineless-password-toggle" onclick="togglePassword('password_confirm', this)">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <span class="mineless-input-help adv-match-help" id="match-help"></span>
                    </div>
                    
                    <button type="button" class="mineless-btn adv-btn-primary adv-btn-block adv-btn-lg" onclick="nextStep(2)">
                        <span class="mineless-btn-text">Continue</span>
                        <i class="fas fa-arrow-right adv-btn-icon"></i>
                    </button>
                </form>
            </div>
            
            <!-- Step 2: Verification -->
            <div class="mineless-register-step" id="step-2">
                <form action="" method="post" class="mineless-form" id="form-step-2">
                    <input type="hidden" name="token" value="{$TOKEN}">
                    <input type="hidden" name="step" value="2">
                    
                    <div class="mineless-verification-info">
                        <div class="mineless-verify-icon">
                            <i class="fas fa-envelope-open-text"></i>
                        </div>
                        <h3>Email Verification</h3>
                        <p>We have sent a verification code to <strong id="email-display">email@example.com</strong></p>
                    </div>
                    
                    <div class="mineless-form-group">
                        <label class="mineless-form-label">Verification Code</label>
                        <div class="mineless-otp-inputs">
                            <input type="text" maxlength="1" class="mineless-otp-input" name="otp[]" required>
                            <input type="text" maxlength="1" class="mineless-otp-input" name="otp[]" required>
                            <input type="text" maxlength="1" class="mineless-otp-input" name="otp[]" required>
                            <input type="text" maxlength="1" class="mineless-otp-input" name="otp[]" required>
                            <input type="text" maxlength="1" class="mineless-otp-input" name="otp[]" required>
                            <input type="text" maxlength="1" class="mineless-otp-input" name="otp[]" required>
                        </div>
                        <input type="hidden" name="otp_code" id="otp-full">
                    </div>
                    
                    <div class="mineless-resend-code">
                        <span id="resend-timer">Resend in 59 seconds</span>
                        <button type="button" class="mineless-link" id="resend-btn" onclick="resendCode()" disabled>Resend</button>
                    </div>
                    
                    <div class="mineless-form-group">
                        <label class="mineless-checkbox adv-tos-check">
                            <input type="checkbox" name="terms" id="terms" required>
                            <span class="mineless-checkbox-check"></span>
                            <span class="mineless-checkbox-label">I agree to the <a href="{$TERMS_URL}" target="_blank" class="mineless-link">Terms and Conditions</a></span>
                        </label>
                    </div>
                    
                    {if isset($RECAPTCHA)}
                        <div class="mineless-form-group">
                            <div class="g-recaptcha" data-sitekey="{$RECAPTCHA_KEY}"></div>
                        </div>
                    {/if}
                    
                    <div class="mineless-form-buttons">
                        <button type="button" class="mineless-btn adv-btn-outline" onclick="prevStep(1)">
                            <i class="fas fa-arrow-left"></i>
                            <span>Back</span>
                        </button>
                        <button type="submit" class="mineless-btn adv-btn-primary">
                            <span>Verify</span>
                            <i class="fas fa-check"></i>
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Step 3: Success -->
            <div class="mineless-register-step" id="step-3">
                <div class="mineless-success-content">
                    <div class="mineless-success-icon">
                        <i class="fas fa-check"></i>
                        <div class="mineless-success-ring"></div>
                    </div>
                    <h2 class="mineless-success-title">Welcome!</h2>
                    <p class="mineless-success-text">Your account has been created. You will be redirected to the dashboard...</p>
                    <div class="mineless-success-redirect">
                        <div class="mineless-redirect-bar">
                            <div class="mineless-redirect-fill" id="redirect-fill"></div>
                        </div>
                        <span class="mineless-redirect-text">Redirect in <span id="redirect-count">3</span> seconds</span>
                    </div>
                </div>
                
                <!-- Confetti Canvas -->
                <canvas id="confetti-canvas" class="mineless-confetti-canvas"></canvas>
            </div>
            
            <div class="mineless-auth-footer">
                <p>Already have an account? <a href="{$LOGIN_URL}" class="mineless-link adv-link-bold">{$SIGN_IN}</a></p>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-register-card {
    max-width: 500px;
}

.mineless-register-icon {
    background: linear-gradient(135deg, var(--mineless-ember), #8B2F0B);
    box-shadow: 0 0 30px rgba(200, 75, 17, 0.3);
}

.mineless-register-progress {
    margin-bottom: 2rem;
    position: relative;
}

.mineless-progress-line {
    position: absolute;
    top: 20px;
    left: 50px;
    right: 50px;
    height: 3px;
    background: rgba(212, 175, 55, 0.2);
    border-radius: 3px;
}

.mineless-progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 3px;
    width: 0%;
    transition: width 0.5s ease;
}

.mineless-progress-steps {
    display: flex;
    justify-content: space-between;
    position: relative;
    z-index: 1;
}

.mineless-step {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.5rem;
}

.mineless-step-number {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: var(--bg-secondary);
    border: 2px solid rgba(212, 175, 55, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    color: var(--text-secondary);
    transition: var(--transition-fast);
}

.mineless-step.active .mineless-step-number,
.mineless-step.completed .mineless-step-number {
    background: var(--mineless-gold);
    border-color: var(--mineless-gold);
    color: var(--bg-primary);
}

.mineless-step.completed .mineless-step-number::after {
    content: '✓';
}

.mineless-step.completed .mineless-step-number span {
    display: none;
}

.mineless-step-label {
    font-size: 0.8rem;
    color: var(--text-secondary);
    transition: var(--transition-fast);
}

.mineless-step.active .mineless-step-label {
    color: var(--mineless-gold);
}

.mineless-register-step {
    display: none;
}

.mineless-register-step.active {
    display: block;
    animation: fadeInUp 0.5s ease;
}

.mineless-input-help {
    display: block;
    margin-top: 0.5rem;
    font-size: 0.8rem;
    color: var(--text-secondary);
}

.mineless-match-help {
    font-weight: 500;
}

.mineless-match-help.match {
    color: #28a745;
}

.mineless-match-help.no-match {
    color: #dc3545;
}

.mineless-password-strength {
    margin-top: 0.75rem;
}

.mineless-strength-bar {
    height: 4px;
    background: var(--bg-secondary);
    border-radius: 2px;
    overflow: hidden;
}

.mineless-strength-fill {
    height: 100%;
    width: 0%;
    border-radius: 2px;
    transition: all 0.3s ease;
}

.mineless-strength-fill.weak { width: 25%; background: #dc3545; }
.mineless-strength-fill.fair { width: 50%; background: #ffc107; }
.mineless-strength-fill.good { width: 75%; background: #17a2b8; }
.mineless-strength-fill.strong { width: 100%; background: #28a745; }

.mineless-strength-text {
    display: block;
    margin-top: 0.5rem;
    font-size: 0.8rem;
    color: var(--text-secondary);
}

.mineless-password-requirements {
    margin-top: 1rem;
    display: grid;
    gap: 0.5rem;
}

.mineless-req-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.85rem;
    color: var(--text-secondary);
    transition: var(--transition-fast);
}

.mineless-req-item i {
    font-size: 0.5rem;
    transition: var(--transition-fast);
}

.mineless-req-item.met {
    color: #28a745;
}

.mineless-req-item.met i {
    transform: scale(1.5);
}

.mineless-verification-info {
    text-align: center;
    margin-bottom: 1.5rem;
    padding: 1.5rem;
    background: rgba(212, 175, 55, 0.05);
    border-radius: var(--radius-md);
    border: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-verify-icon {
    width: 60px;
    height: 60px;
    margin: 0 auto 1rem;
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: var(--bg-primary);
}

.mineless-verification-info h3 {
    color: var(--text-primary);
    margin-bottom: 0.5rem;
}

.mineless-verification-info p {
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.mineless-otp-inputs {
    display: flex;
    gap: 0.5rem;
    justify-content: center;
}

.mineless-otp-input {
    width: 50px;
    height: 60px;
    text-align: center;
    font-size: 1.5rem;
    font-weight: 600;
    background: var(--bg-secondary);
    border: 2px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-md);
    color: var(--text-primary);
    transition: var(--transition-fast);
}

.mineless-otp-input:focus {
    outline: none;
    border-color: var(--mineless-gold);
    box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
    transform: translateY(-2px);
}

.mineless-resend-code {
    text-align: center;
    margin-top: 1rem;
}

.mineless-resend-code span {
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.mineless-tos-check {
    margin-top: 1rem;
}

.mineless-form-buttons {
    display: flex;
    gap: 1rem;
    margin-top: 1.5rem;
}

.mineless-form-buttons .mineless-btn {
    flex: 1;
}

.mineless-btn-outline {
    background: transparent;
    border: 2px solid rgba(212, 175, 55, 0.3);
    color: var(--text-primary);
}

.mineless-btn-outline:hover {
    border-color: var(--mineless-gold);
    color: var(--mineless-gold);
}

.mineless-success-content {
    text-align: center;
    padding: 2rem 0;
    position: relative;
    z-index: 1;
}

.mineless-success-icon {
    width: 100px;
    height: 100px;
    margin: 0 auto 1.5rem;
    background: linear-gradient(135deg, #28a745, #20c997);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    color: white;
    position: relative;
}

.mineless-success-ring {
    position: absolute;
    inset: -10px;
    border: 3px solid #28a745;
    border-radius: 50%;
    animation: ringExpand 1s ease-out forwards;
}

.mineless-success-title {
    font-family: var(--font-display);
    font-size: 2rem;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
}

.mineless-success-text {
    color: var(--text-secondary);
    margin-bottom: 1.5rem;
}

.mineless-success-redirect {
    max-width: 300px;
    margin: 0 auto;
}

.mineless-redirect-bar {
    height: 4px;
    background: var(--bg-secondary);
    border-radius: 2px;
    overflow: hidden;
    margin-bottom: 0.5rem;
}

.mineless-redirect-fill {
    height: 100%;
    width: 0%;
    background: linear-gradient(90deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 2px;
    animation: fillBar 3s ease forwards;
}

.mineless-redirect-text {
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.mineless-confetti-canvas {
    position: absolute;
    inset: 0;
    pointer-events: none;
}

@keyframes ringExpand {
    from { transform: scale(0.8); opacity: 1; }
    to { transform: scale(1.5); opacity: 0; }
}

@keyframes fillBar {
    to { width: 100%; }
}
</style>

<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<script>
let currentStep = 1;
const totalSteps = 3;

function nextStep(step) {
    if (validateStep(currentStep)) {
        document.getElementById(`step-${currentStep}`).classList.remove('active');
        document.querySelector(`.mineless-step[data-step="${currentStep}"]`).classList.add('completed');
        
        currentStep = step;
        document.getElementById(`step-${currentStep}`).classList.add('active');
        document.querySelector(`.mineless-step[data-step="${currentStep}"]`).classList.add('active');
        
        updateProgress();
        
        if (step === 2) {
            startResendTimer();
            initOTP();
        }
        
        if (step === 3) {
            startConfetti();
            startRedirect();
        }
    }
}

function prevStep(step) {
    document.getElementById(`step-${currentStep}`).classList.remove('active');
    document.querySelector(`.mineless-step[data-step="${currentStep}"]`).classList.remove('active');
    
    currentStep = step;
    document.getElementById(`step-${currentStep}`).classList.add('active');
    document.querySelector(`.mineless-step[data-step="${currentStep}"]`).classList.remove('completed');
    document.querySelector(`.mineless-step[data-step="${currentStep}"]`).classList.add('active');
    
    updateProgress();
}

function updateProgress() {
    const progress = ((currentStep - 1) / (totalSteps - 1)) * 100;
    document.getElementById('progress-fill').style.width = `${progress}%`;
}

function validateStep(step) {
    if (step === 1) {
        const password = document.getElementById('password').value;
        const confirm = document.getElementById('password_confirm').value;
        
        if (password !== confirm) {
            alert('Passwords do not match!');
            return false;
        }
        
        const strength = checkPasswordStrength(password);
        if (strength < 3) {
            alert('Password is too weak!');
            return false;
        }
        
        return true;
    }
    return true;
}

// Password Strength
const passwordInput = document.getElementById('password');
const strengthFill = document.getElementById('strength-fill');
const strengthText = document.getElementById('strength-text');
const reqItems = document.querySelectorAll('.mineless-req-item');

passwordInput.addEventListener('input', () => {
    const password = passwordInput.value;
    const strength = checkPasswordStrength(password);
    
    strengthFill.className = 'adv-strength-fill';
    if (strength === 0) {
        strengthText.textContent = 'Password strength';
    } else if (strength === 1) {
        strengthFill.classList.add('weak');
        strengthText.textContent = 'Weak';
    } else if (strength === 2) {
        strengthFill.classList.add('fair');
        strengthText.textContent = 'Fair';
    } else if (strength === 3) {
        strengthFill.classList.add('good');
        strengthText.textContent = 'Good';
    } else {
        strengthFill.classList.add('strong');
        strengthText.textContent = 'Strong!';
    }
    
    // Check requirements
    reqItems.forEach(item => {
        const req = item.dataset.req;
        const met = checkRequirement(password, req);
        item.classList.toggle('met', met);
    });
});

function checkPasswordStrength(password) {
    let strength = 0;
    if (password.length >= 8) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;
    return Math.min(strength, 4);
}

function checkRequirement(password, req) {
    switch(req) {
        case 'length': return password.length >= 8;
        case 'uppercase': return /[A-Z]/.test(password);
        case 'lowercase': return /[a-z]/.test(password);
        case 'number': return /[0-9]/.test(password);
        case 'special': return /[^A-Za-z0-9]/.test(password);
        default: return false;
    }
}

// Password Match
document.getElementById('password_confirm').addEventListener('input', function() {
    const password = document.getElementById('password').value;
    const confirm = this.value;
    const help = document.getElementById('match-help');
    
    if (confirm === '') {
        help.textContent = '';
        help.className = 'adv-input-help adv-match-help';
    } else if (password === confirm) {
        help.textContent = '✓ Password cocok';
        help.className = 'adv-input-help adv-match-help match';
    } else {
        help.textContent = '✗ Password tidak cocok';
        help.className = 'adv-input-help adv-match-help no-match';
    }
});

// OTP Input
function initOTP() {
    const inputs = document.querySelectorAll('.mineless-otp-input');
    const fullInput = document.getElementById('otp-full');
    
    inputs.forEach((input, index) => {
        input.addEventListener('input', () => {
            if (input.value.length === 1) {
                if (index < inputs.length - 1) {
                    inputs[index + 1].focus();
                }
            }
            updateFullOTP();
        });
        
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Backspace' && input.value === '' && index > 0) {
                inputs[index - 1].focus();
            }
        });
    });
    
    function updateFullOTP() {
        let code = '';
        inputs.forEach(inp => code += inp.value);
        fullInput.value = code;
    }
}

// Resend Timer
function startResendTimer() {
    let seconds = 59;
    const timer = document.getElementById('resend-timer');
    const btn = document.getElementById('resend-btn');
    
    btn.disabled = true;
    
    const interval = setInterval(() => {
        timer.textContent = `Resend in ${seconds} seconds`;
        seconds--;
        
        if (seconds < 0) {
            clearInterval(interval);
            timer.textContent = '';
            btn.disabled = false;
        }
    }, 1000);
}

function resendCode() {
    // AJAX call to resend code
    startResendTimer();
}

// Confetti
function startConfetti() {
    const canvas = document.getElementById('confetti-canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    const particles = [];
    const colors = ['#D4AF37', '#C84B11', '#28a745', '#FFD700', '#FFA500'];
    
    for (let i = 0; i < 100; i++) {
        particles.push({
            x: canvas.width / 2,
            y: canvas.height / 2,
            vx: (Math.random() - 0.5) * 10,
            vy: (Math.random() - 0.5) * 10 - 5,
            color: colors[Math.floor(Math.random() * colors.length)],
            size: Math.random() * 8 + 4,
            rotation: Math.random() * 360
        });
    }
    
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        particles.forEach(p => {
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.2; // gravity
            p.rotation += 5;
            
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rotation * Math.PI / 180);
            ctx.fillStyle = p.color;
            ctx.fillRect(-p.size/2, -p.size/2, p.size, p.size);
            ctx.restore();
        });
        
        requestAnimationFrame(animate);
    }
    
    animate();
}

// Redirect
function startRedirect() {
    let count = 3;
    const counter = document.getElementById('redirect-count');
    
    const interval = setInterval(() => {
        count--;
        counter.textContent = count;
        
        if (count <= 0) {
            clearInterval(interval);
            window.location.href = '{$DASHBOARD_URL}';
        }
    }, 1000);
}

function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>

{include file='footer.tpl'}