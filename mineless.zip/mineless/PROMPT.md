# PROMPT — NamelessMC Mineless Premium Template ($1000+)
> Disesuaikan dengan struktur direktori NamelessMC **nyata** (v2.x)

---

## Master Prompt (Gunakan ini untuk memulai sesi pembuatan template)

```
Kamu adalah expert NamelessMC template developer. Tugasmu adalah membangun template
NamelessMC bertema "Mineless" berkualitas premium senilai di atas $1000 USD.

Template ini harus mencakup SEMUA file yang ada di struktur NamelessMC asli,
dengan animasi kompleks yang benar-benar berjalan di browser.

=============================================================
IDENTITAS TEMPLATE
=============================================================
- Nama: Mineless
- Versi NamelessMC: 2.0.x (Smarty template engine)
- Style: Dark Fantasy / Medieval Mineless / Minecraft RPG
- Harga Target: $1000+
- Primary Accent Color: #D4AF37 (Mineless Gold)
- Dark Mode: Default ON

=============================================================
STRUKTUR FILE YANG WAJIB DIBUAT (100% sesuai NamelessMC nyata)
=============================================================

------------------------------------------------------------
ROOT LEVEL .tpl FILES
------------------------------------------------------------

1.  403.tpl
    - Halaman "Akses Ditolak" bertema dungeon/penjara
    - Animasi rantai dan kunci terkunci (CSS keyframe)
    - Tombol kembali dengan glow effect
    - Karakter penjaga dungeon (CSS art atau SVG inline)

2.  404.tpl
    - Halaman "Tidak Ditemukan" bertema pemain tersesat
    - Animasi karakter bingung (CSS idle/walk loop)
    - Kompas berputar mencari arah
    - Tombol pulang ke homepage dengan particle burst onClick
    - Pesan humor bertema Minecraft

3.  authme.tpl
    - Halaman login AuthMe (plugin Minecraft auth)
    - Form PIN/password dengan animasi kunci terbuka
    - Progress dots untuk input PIN

4.  authme_email.tpl
    - Verifikasi email untuk AuthMe
    - Input kode OTP dengan box terpisah per digit
    - Countdown timer resend code

5.  change_password.tpl
    - Form ganti password
    - Password strength meter animasi (lemah → kuat + perubahan warna)
    - Old password + new password + confirm fields
    - Show/hide password toggle

6.  complete_signup.tpl
    - Langkah terakhir registrasi (isi detail tambahan)
    - Form profil awal: display name, date of birth, custom fields
    - Animasi progress "hampir selesai"
    - Welcome animation setelah submit

7.  cookies.tpl
    - Halaman kebijakan cookie
    - Tabel daftar cookies dengan toggle per kategori
    - Accept / Decline / Settings buttons dengan animasi
    - Animated cookie icon

8.  custom.tpl
    - Template halaman custom/statis dengan layout penuh (dengan sidebar)
    - Area konten fleksibel untuk admin insert HTML

9.  custom_basic.tpl
    - Versi simpel custom page tanpa sidebar
    - Layout centered, max-width 800px
    - Typography bagus untuk artikel/info

10. footer.tpl
    - Footer Mineless lengkap:
      * Logo + tagline server
      * 3 kolom quick links: Play, Community, Info
      * Social media icons: Discord, Twitter/X, YouTube, TikTok, Instagram
      * Server status mini: IP + status dot pulse + player count
      * Discord join CTA
      * Copyright + NamelessMC credit
      * Ornamen rune medieval di atas footer
      * Back-to-top button dengan smooth scroll animasi
      * Floating partikel subtle di background footer

11. forgot_password.tpl
    - Form lupa password (input email/username)
    - Animasi amplop terbang setelah submit
    - Countdown untuk kirim ulang email

12. header.tpl
    - HTML <head> LENGKAP:
      * DOCTYPE, meta charset, viewport
      * Meta OG: og:title, og:description, og:image, og:url
      * Twitter Card meta tags
      * {$HEAD_TAGS} — hook NamelessMC
      * Preconnect Google Fonts CDN
      * Preload font Mineless (.woff2) rel="preload"
      * Link CSS: custom.css, toastr.min.css
      * Inline critical CSS (above-the-fold, max 2kb)
      * Favicon + Apple touch icon
    - Langsung {include file='navbar.tpl'} di akhir
    - Toast/notification container div
    - Top loading bar (progress bar tipis di atas halaman)

13. index.tpl  <-- HOMEPAGE UTAMA
    HERO SECTION:
      * 3-layer parallax background (.layer-bg, .layer-mid, .layer-near)
      * <div id="particles-js"> dengan canvas particles.js
      * Typed.js: mengetik "Survival|Factions|Skyblock|Creative|PvP"
      * GSAP reveal: judul masuk dari bawah (y:60, opacity:0, duration:1.2)
      * Subtitle fade-in dengan delay 0.4s
      * Dua CTA button: "Mulai Bermain" (solid gold) + "Pelajari Lebih" (outline)
      * CTA punya animasi glow pulse + ripple saat hover/click
      * Server IP dengan tombol copy-to-clipboard + animasi check ✓
      * Scroll indicator panah animasi bounce ke bawah

    STATS BAR (scroll reveal + counter animasi):
      * Total Member: {$STATISTICS.member_count}
      * Total Post: {$STATISTICS.post_count}
      * Status server: {$SERVER_ONLINE}
      * Player online: {$ONLINE_PLAYERS}/{$MAX_PLAYERS}
      * Counter menghitung dari 0 pakai GSAP saat masuk viewport

    BERITA TERBARU:
      * Grid 3 kolom card artikel {foreach from=$NEWS item=article}
      * Cover image, kategori badge, judul, excerpt truncate, tanggal, penulis
      * Card hover: translateY(-8px) + border glow emas
      * "Lihat Semua Berita" link

    FORUM PREVIEW:
      * 3-4 kategori forum terbesar
      * Per kategori: icon, nama, deskripsi, jumlah topic, last post info
      * "Kunjungi Forum" CTA

    FITUR SERVER SECTION:
      * 6 feature cards dengan icon besar (Survival, Factions, dll)
      * GSAP ScrollTrigger: stagger masuk saat scroll
      * Hover: icon animasi rotate/bounce + card glow

    STAFF ONLINE MINI:
      * Row avatar staff online dengan nama + jabatan

    JOIN STEPS:
      * 3 langkah: Download Minecraft → Tambah Server → Bermain
      * Animated connector line antara steps
      * Nomor langkah dengan animasi

    DISCORD CTA:
      * Banner Discord invite
      * Animated Discord logo
      * Member count widget

14. leaderboards.tpl
    - Header section dengan animated trophy (magicPulse)
    - TOP 3 PODIUM animasi naik dari bawah saat masuk viewport:
      * Gold (1st), Silver (2nd), Bronze (3rd)
      * Avatar Crafatar + nama + score + crown animasi
    - Tabel ranking 4-20 dengan row hover highlight
    - Tab filter: Most Posts / Most Likes / Most Reactions
    - Row masuk dengan stagger animation

15. login.tpl
    - Layout split: kiri illustration Mineless, kanan form
    - Form container border emas animasi (SVG borderDraw)
    - Input username + password (underline gold style)
    - Show/hide password toggle (eye icon)
    - Remember me checkbox custom
    - Forgot password link
    - Divider "atau login dengan" ornamen
    - OAuth buttons: Discord, Steam
    - "Belum punya akun? Daftar" link
    - Error state: shake animation + merah highlight

16. maintenance.tpl
    - Gear/cog berputar (CSS animation spinSlow)
    - Progress bar "perkiraan selesai"
    - Countdown timer jika tersedia
    - Link Discord/sosial media
    - Partikel biru/ungu (maintenance vibe)

17. navbar.tpl
    - Sticky top, backdrop-filter blur
    - Scroll effect: transparent → bg-dark + shadow setelah 80px
    - Logo kiri dengan hover glow
    - Menu items tengah: {foreach from=$NAVBAR_ITEMS}
    - Underline slide dari kiri saat hover
    - Kanan: notification bell + avatar dropdown / login+register
    - Notification bell: badge count {$NOTIFICATION_COUNT}, dropdown list
    - Avatar dropdown: Profile, Panel, Settings, Logout
    - Dark/Light toggle switch animasi
    - Hamburger mobile: 3 garis → X CSS animasi
    - Mobile menu: slide-down fullscreen, item masuk stagger
    - Active page indicator

18. portal.tpl
    - Dashboard untuk user logged-in
    - Greeting animasi: "Selamat datang kembali, {$USERNAME}!"
    - Widget area: server status, recent alerts, quick links
    - Recent activity feed

19. privacy.tpl
    - Kebijakan Privasi
    - Sticky sidebar Table of Contents
    - Typography parchment-styled
    - Section headers dengan rune divider
    - Last updated date

20. profile.tpl
    - Banner/cover area (custom background)
    - Minecraft full body render:
      <img src="https://crafatar.com/renders/body/{$USER_UUID}?scale=4&overlay">
    - Avatar lingkaran:
      <img src="https://crafatar.com/avatars/{$USER_UUID}?size=100&overlay">
    - Nama besar + badge grup/rank (warna dari grup)
    - Stats row: Posts, Reactions diterima, Bergabung, Terakhir aktif
    - Animasi floating pada avatar (gentle bob)
    - Tab nav: Tentang / Posts / Trophies / Friends
    - Tab "Tentang": bio, custom profile fields
    - Tab "Posts": post terbaru + link ke topic
    - Tab "Trophies": showcase trophy dengan sparkle hover
    - Tombol "Kirim Pesan" + "Add Friend" jika bukan profil sendiri
    - user_popover.tpl component integration

21. reactions_modal.tpl
    - Modal popup: siapa yang bereaksi pada suatu konten
    - List user: avatar + nama + jenis reaksi emoji
    - Animasi modal: scale + fade masuk
    - Tab filter per jenis reaksi

22. register.tpl
    - Multi-step wizard 3 langkah:
      * Step 1: Username + Email + Password
      * Step 2: Verifikasi email / detail tambahan
      * Step 3: Selamat datang / link Minecraft (opsional)
    - Progress bar animasi antar langkah
    - Password strength indicator real-time
    - Terms of Service checkbox + link ke terms.tpl
    - reCAPTCHA v2 placeholder div
    - Error per field dengan shake animation
    - Success: animasi confetti + redirect otomatis

23. registration_disabled.tpl
    - Info halaman ketika registrasi ditutup
    - Ilustrasi pintu tertutup (SVG atau CSS)
    - Teks alasan + link Discord

24. status.tpl
    - Status server/website live
    - Status check dengan ping dot animasi (pulse green/red)
    - Uptime percentage dengan circular progress bar
    - Recent incidents/maintenance log
    - Auto-refresh setiap 30 detik via JS

25. template.php
    - PHP bootstrap template Mineless:
      * Tidak berisi HTML
      * define('TEMPLATE', 'Mineless')
      * Registrasi settings template
      * Set template path dan version info

26. terms.tpl
    - Terms of Service
    - Sticky ToC sidebar
    - Sama struktur dengan privacy.tpl
    - "Saya Setuju" button di akhir (jika perlu flow persetujuan)

27. tfa.tpl
    - Two-Factor Authentication login step
    - 6 kotak input OTP individual (auto-focus pindah antar kotak)
    - Countdown timer resend code
    - Opsi "Gunakan kode recovery"
    - Animasi shield/gembok saat kode benar

28. user_not_exist.tpl
    - Profil user tidak ditemukan
    - Ilustrasi scroll kosong / makam "RIP [username]"
    - Pesan humor bertema Minecraft
    - Tombol kembali ke members list

29. user_popover.tpl
    - Mini card popup saat hover username di manapun
    - Avatar Minecraft + nama + grup badge
    - Stats mini: post count, join date
    - Tombol: Lihat Profil / Kirim Pesan
    - Animasi: fade-in scale dari 0.8 → 1

------------------------------------------------------------
FOLDER: css/
------------------------------------------------------------

30. css/custom.css  (MINIMAL 700 BARIS)
    DESIGN SYSTEM:
      :root {
        warna: --mineless-gold #D4AF37, --mineless-ember #C84B11, --mineless-forest #2D5A27
        background: --bg-primary #0A0A0F, --bg-secondary #111118, --bg-card #16161F
        text: --text-primary #F0E6D3, --text-secondary #A09080
        spacing: --space-xs sampai --space-3xl
        typography: --font-display, --font-body, --font-ui, --font-mono
        shadows, transitions, z-index layers, border-radius
      }
      [data-theme="light"] overrides
      Semua KOMPONEN UI:
        .mineless-btn variants (primary, outline, ghost, danger, sm, lg)
        .mineless-card (default, hover, featured, glass)
        .mineless-badge (rank dengan warna dinamis)
        .mineless-avatar (sm/md/lg/xl + MC frame decoration)
        .mineless-input, .mineless-textarea, .mineless-select
        .mineless-modal, .mineless-modal-backdrop
        .mineless-tooltip (arrow, top/bottom/left/right)
        .mineless-progress, .mineless-progress-shimmer
        .mineless-skeleton, .mineless-skeleton-wave
        .mineless-notification toast
        .mineless-divider ornamen rune
        .mineless-breadcrumb separator rune
        .mineless-pagination
        .mineless-tabs + ink-bar slide
        .mineless-accordion
        .mineless-dropdown
        .mineless-table (striped, hover)
        .mineless-tag, .mineless-chip
        .mineless-spoiler (forum)
        .mineless-code-block
        .mineless-quote (forum nested)
        .mineless-navbar semua state
        .mineless-hero parallax container
        .mineless-footer
        .mineless-sidebar + .mineless-widget
        .mineless-forum-* (category, topic row, post, reaction bar)
        .mineless-profile-* (banner, body render, stats, tabs, trophy)
        .mineless-leaderboard-* (podium, table, tabs)
      RESPONSIVE:
        Mobile-first default → @media (min-width: 480px/768px/1024px/1200px/1440px)
        Hamburger mobile nav
        Bottom nav bar mobile (opsional)
      @media (prefers-reduced-motion: reduce) — matikan semua animasi
      Scrollbar custom (webkit)
      ::selection color

    ANIMASI @keyframes (MINIMAL 20 UNIK):
      @keyframes MinelessFloat
      @keyframes goldGlow
      @keyframes runeRotate
      @keyframes magicPulse
      @keyframes textShimmer
      @keyframes borderDraw
      @keyframes particleRise
      @keyframes slideInLeft, slideInRight, slideInUp, slideInDown
      @keyframes fadeInUp, fadeInDown
      @keyframes scaleIn
      @keyframes counterPop
      @keyframes toastSlide
      @keyframes skeletonWave
      @keyframes progressShimmer
      @keyframes spinSlow
      @keyframes heartBeat
      @keyframes shakeError
      @keyframes confettiFall
      @keyframes podiumRise
      @keyframes borderPulse

31. css/toastr.min.css
    - File bawaan, JANGAN dihapus
    - Override warna toastr di custom.css agar sesuai tema Mineless

------------------------------------------------------------
FOLDER: email/
------------------------------------------------------------

32. email/api_register.html
    - Email registrasi via API, inline CSS
    - Background gelap, accent gold
    - Logo + sambutan + detail akun
    - CTA "Verifikasi Email" button bergaya Mineless
    - Footer links + unsubscribe

33. email/change_password.html
    - Konfirmasi perubahan password, inline CSS
    - Warning: jika bukan kamu, hubungi admin
    - CTA reset password link

34. email/forum_topic_reply.html
    - Notifikasi ada reply di topic
    - Preview konten reply (truncated 150 karakter)
    - Avatar pengirim (Crafatar URL)
    - CTA "Lihat Balasan" button

35. email/register.html
    - Email selamat datang member baru
    - Verifikasi email link CTA button besar
    - Info server: IP, gamemode list, Discord link
    - Background pattern medieval inline

36. email/tfa.html
    - Kode Two-Factor Authentication
    - Kotak besar 6 digit kode
    - Info "berlaku 10 menit"
    - Warning jangan share kode

------------------------------------------------------------
FOLDER: forum/
------------------------------------------------------------

37. forum/following_topics.tpl
    - Daftar topic yang di-follow user
    - Filter: semua / unread / recent
    - Per topic: judul, forum, replies, last reply info
    - Unfollow button dengan animasi

38. forum/forum_edit_post.tpl
    - Edit post yang sudah ada
    - WYSIWYG editor dengan toolbar Mineless
    - Preview mode toggle
    - Reason for edit field
    - "Simpan Perubahan" dengan loading state

39. forum/forum_index.tpl
    - INDEX FORUM UTAMA:
      * Search bar forum di header
      * Group per category dengan header bergaya Mineless
      * Per forum: icon, nama, deskripsi, topic count, post count, last post
      * Sub-forum dengan indent
      * Online users di forum
      * Stats footer: total topics, total posts, newest member

40. forum/merge.tpl
    - Form merge dua topic (moderator only)
    - Select topic tujuan dengan search
    - Preview hasil merge
    - Confirm button dengan animasi

41. forum/move.tpl
    - Form pindah topic ke forum lain (moderator only)
    - Dropdown pilih forum tujuan
    - Loading state saat submit

42. forum/new_topic.tpl
    - Judul topic input
    - Dropdown pilih forum/kategori
    - Tag input (multi-tag dengan chip)
    - WYSIWYG rich text editor
    - Attachment file upload dengan drag-drop
    - Preview mode real-time
    - Poll creator (opsional toggle)
    - Submit + "Simpan Draft" buttons

43. forum/profile_tab.tpl
    - Tab "Posts" di halaman profile.tpl
    - List post forum user:
      * Excerpt konten post
      * Link ke topic + nama forum
      * Tanggal post + like count
    - Pagination

44. forum/search.tpl
    - Form pencarian forum
    - Filter advanced: kata kunci, forum tertentu, rentang tanggal, penulis
    - Toggle advanced search

45. forum/search_results.tpl
    - Hasil pencarian forum
    - Highlight keyword dalam hasil
    - Info: "X hasil ditemukan dalam Yms"
    - Pagination

46. forum/view_forum.tpl
    - Daftar topic dalam satu forum:
      * Header: nama forum, deskripsi, breadcrumb
      * Tombol "New Topic" dengan glow animasi
      * Sub-forums jika ada
      * Filter/sort: terbaru, terpopuler, belum dijawab
      * Topic list: pinned (pin icon animasi) + normal
      * Per topic: title, author avatar, replies, views, last post
      * Row hover highlight
      * Pagination atas + bawah

47. forum/view_forum_confirm_redirect.tpl
    - Konfirmasi redirect ke link eksternal
    - Preview domain tujuan
    - Warning keamanan
    - Tombol "Lanjutkan" + "Kembali"

48. forum/view_forum_no_discussions.tpl
    - Empty state forum (belum ada topic)
    - Ilustrasi scroll kosong
    - "Jadilah yang pertama posting!" CTA
    - Tombol New Topic dengan animasi

49. forum/view_topic.tpl
    - THREAD / TOPIC VIEW LENGKAP:
      * Breadcrumb: Home > Forum > Kategori > Topic
      * Judul topic + tag badges
      * Post pertama (OP) styling berbeda dan lebih menonjol
      * Per post:
        - Avatar Minecraft (Crafatar) + avatar website
        - Username (link ke profil) + rank badge
        - Join date, post count, grup
        - Konten HTML rendered
        - [spoiler] tag support dengan toggle animasi
        - Code block dengan syntax highlight + copy button
        - Image embed + lightbox click-to-expand
        - Quote nested [quote] tag
        - Reaction bar emoji: thumbs up, heart, laugh, dll
        - Like button dengan counter + heartBeat animation onClick
        - Actions: Quote, Edit (jika milik sendiri/admin), Delete, Report
      * Reply form di bawah:
        - WYSIWYG toolbar
        - Quote-reply auto-fill
        - Preview toggle
        - Submit dengan loading state
      * Pagination top + bottom
      * Lock/pin status indicator
      * Subscribe / unfollow topic button
      * Share topic (copy link)

------------------------------------------------------------
FOLDER: js/core/
------------------------------------------------------------

50. js/core/core.js
    - Main Mineless JS:
      * DOMContentLoaded event listener sebagai wrapper
      * Dark mode toggle + localStorage persist ('adv-theme')
      * Back to top button (muncul setelah 300px scroll)
      * Navbar scroll effect (tambah class 'scrolled' setelah 80px)
      * Hamburger menu toggle (.is-open class toggle + animasi)
      * GSAP + ScrollTrigger registration
      * IntersectionObserver untuk lazy load gambar
      * Copy to clipboard utility (server IP)
      * Konami Code easter egg: ↑↑↓↓←→←→BA

51. js/core/pages.js
    - Page-specific init berdasarkan body class atau data-page attribute:
      HOMEPAGE:
        * particlesJS('particles-js', config) — 80 desktop, 30 tablet, 0 mobile
        * new Typed('#typed-text', config)
        * Parallax handler: window.scroll → translateY per layer
        * Stats counter: IntersectionObserver + GSAP textContent count-up
        * GSAP ScrollTrigger stagger untuk setiap section
      FORUM:
        * Spoiler toggle click handler
        * Code block copy button
        * Reaction click (optimistic UI + fetch POST)
        * Like button heartBeat animation
      PROFILE:
        * Tab switching dengan ink-bar slide animasi
        * Avatar float animation (GSAP yoyo)
      LEADERBOARD:
        * Podium rise animasi (GSAP ScrollTrigger)
      LOGIN:
        * Form shake on error
        * Show/hide password toggle
      REGISTER:
        * Multi-step wizard (next/prev + progress bar)
        * Password strength real-time (zxcvbn atau custom regex)
        * Confetti on success
      TFA:
        * OTP input auto-advance to next box
        * Auto-submit saat 6 digit terisi
        * Backspace ke box sebelumnya
      ERROR PAGES:
        * 404: CSS character walk via JS class toggle
        * Kompas rotate animation start
      STORE (jika modul aktif):
        * Product image zoom
        * Checkout step wizard

52. js/core/update.js
    - Polling dan live updates:
      * Server status check setiap 60 detik (fetch ke NamelessMC endpoint)
      * Update server status widget DOM tanpa reload
      * Notification count polling setiap 30 detik
      * Online user count refresh

53. js/core/user.js
    - User-specific functionality:
      * User popover: mouseover pada .username-link → fetch preview → show popover
      * Popover position: auto-flip jika terlalu dekat tepi layar
      * Alert mark as read (click handler + fetch)
      * Message unread count update di navbar
      * Avatar upload: input[type=file] preview sebelum submit
      * Session timeout warning modal (setelah X menit inaktif)

------------------------------------------------------------
FOLDER: members/
------------------------------------------------------------

54. members/members.tpl
    - Header + search input
    - Filter bar: grup/rank dropdown, status (online/all), sort by
    - View toggle: Grid / List
    - GRID VIEW:
      * Card per member: avatar MC (Crafatar), username, rank badge,
        post count, join date, online indicator
      * Card hover: lift + border glow
    - LIST VIEW:
      * Row per member: avatar mini, nama, rank, posts, joined
    - Pagination
    - Total member count

------------------------------------------------------------
FOLDER: template_settings/
------------------------------------------------------------

55. template_settings/settings.php
    - Registrasi semua custom settings di NamelessMC admin panel:
      * accent_color (color picker)
      * server_ip (text)
      * server_port (text)
      * typed_strings (text, pipe-separated)
      * particles_enabled (boolean)
      * parallax_enabled (boolean)
      * dark_mode_default (boolean)
      * discord_invite (text)
      * hero_title (text)
      * hero_subtitle (text)
      * footer_tagline (text)
      * hero_bg_url (text)
      * custom_css (textarea)

56. template_settings/settings.tpl
    - Form settings template di admin panel NamelessMC
    - Render semua field dari settings.php
    - Color picker untuk accent color
    - Preview accent color real-time
    - "Simpan Perubahan" dengan AJAX loading state

------------------------------------------------------------
FOLDER: user/
------------------------------------------------------------

57. user/alert.tpl
    - Single alert/notification component
    - Icon sesuai tipe: info, success, warning, danger
    - Teks + link + timestamp (timeago format)
    - Mark as read animasi (fade + slide out)

58. user/alerts.tpl
    - Daftar semua notifikasi user:
      * Header + "Tandai Semua Dibaca" button
      * {foreach} render alert.tpl per item
      * Filter: Semua / Belum Dibaca
      * Pagination
      * Empty state jika tidak ada notif

59. user/connections.tpl
    - Manage connected accounts:
      * Discord: connect/disconnect + tampil avatar Discord jika connected
      * Steam: connect/disconnect
      * Minecraft: link UUID + tampil username MC jika linked
      * Status per koneksi: badge hijau (connected) / merah (not connected)
      * Animasi checkmark pop saat berhasil connect

60. user/index.tpl
    - Dashboard panel user:
      * Greeting card: avatar + nama + rank badge
      * Quick stats: posts, reactions diterima, trophies
      * 5 notifikasi terbaru
      * Shortcut cards: Settings, Messages, Connections, Profile
      * Recent activity timeline dengan animasi

61. user/messaging.tpl
    - Inbox private message:
      * List conversation: avatar + nama + preview pesan + timestamp
      * Unread: bold + badge count
      * Search conversation
      * "Pesan Baru" button

62. user/navigation.tpl
    - Sidebar navigasi panel user (diinclude di semua halaman /user/):
      * Avatar besar + nama + rank
      * Menu items: Dashboard, Messages (+ unread count badge),
        Alerts (+ unread count badge), Settings, Connections,
        Sessions, Two-Factor Auth, Lihat Profil
      * Active state dengan gold left-border indicator

63. user/new_message.tpl
    - Form kirim pesan baru:
      * To: input dengan username autocomplete
      * Subject input
      * WYSIWYG pesan editor
      * Send button dengan loading state

64. user/notification_settings.tpl
    - Preferensi notifikasi:
      * Toggle per tipe: forum reply, mention, private message, dll
      * Email notification toggle
      * Toggle switch animasi (CSS + JS)

65. user/oauth.tpl
    - OAuth callback / connect account handler page
    - Loading spinner saat proses
    - Success state (animasi checkmark) / Error state (animasi X merah)

66. user/placeholders.tpl
    - Render custom profile field types
    - Support: text, select, checkbox, date, url, textarea

67. user/sessions.tpl
    - Daftar active sessions:
      * Per session: device icon (mobile/desktop/tablet), browser, OS,
        IP address, lokasi kota (jika ada), last active
      * "Ini sesi aktif kamu sekarang" indicator badge
      * Revoke button + konfirmasi modal per session
      * "Logout semua sesi lain" button di atas

68. user/settings.tpl
    - Pengaturan akun lengkap (sectioned):
      * AVATAR: upload file + preview before submit + opsi pakai MC skin
      * PROFILE: display name, bio, custom profile fields
      * KEAMANAN: form ganti password + strength meter
      * PRIVASI: toggle siapa bisa lihat profil, posts, dll
      * PREFERENSI: bahasa, tema default, dll
      * DANGER ZONE: tombol hapus akun + konfirmasi modal
      * Save per-section dengan AJAX loading + toast sukses

69. user/tfa.tpl
    - Setup/manage TFA di panel:
      * Step 1: QR Code untuk Google Authenticator + secret key manual
      * Step 2: Verify kode pertama untuk konfirmasi
      * Backup recovery codes (10 kode, tombol download + copy)
      * Disable TFA button (dengan konfirmasi password)

70. user/view_message.tpl
    - Tampilan satu percakapan:
      * Header: foto + nama lawan bicara
      * Bubble chat (kiri = mereka, kanan = kamu)
      * Timestamp per pesan (timeago)
      * Reply form fixed di bawah
      * Delete conversation option

------------------------------------------------------------
FOLDER: widgets/
------------------------------------------------------------

71. widgets/cookie_notice.tpl
    - Cookie consent bar slide-up dari bawah
    - Accept / Decline / More Info buttons
    - Link ke cookies.tpl
    - Slide-down + localStorage dismiss setelah accept

72. widgets/minecraft_account.tpl
    - Jika sudah linked: Minecraft head avatar (Crafatar) + username
    - Jika belum: form input username + tombol link
    - Animasi spin saat verifikasi proses

73. widgets/online_staff.tpl
    - Header "Staff Online" dengan icon shield
    - Grid avatar staff aktif (Crafatar heads)
    - Nama + jabatan per staff
    - Status dot: online (hijau pulse) / AFK (kuning)
    - "Lihat Semua Staff" link
    - Empty state jika tidak ada staff online

74. widgets/online_users.tpl
    - Counter besar animasi user online
    - Row avatar 8 user terbaru online
    - "X members, Y guests online"
    - Auto-refresh count setiap 60 detik

75. widgets/profile_posts.tpl
    - Widget recent posts di sidebar profil
    - 5 post terbaru user:
      * Nama forum + judul topic (truncated 40 char)
      * Tanggal post
    - "Lihat Semua Posts" link

76. widgets/reactions.tpl
    - Komponen reaction bar untuk post/konten
    - Emoji picker popup (hover/click toggle) dengan animasi pop
    - Count per reaksi dengan +1 float animasi saat klik
    - Highlight reaksi yang sudah diklik user

77. widgets/server_status.tpl
    - Server IP yang bisa di-copy (clipboard)
    - Status dot: online (hijau pulse) / offline (merah)
    - Player count: X/Y dengan bar visual
    - MOTD (message of the day) dari server
    - Minecraft versi + tipe server
    - Auto-refresh setiap 60 detik via update.js

78. widgets/statistics.tpl
    - Total Members: {$STATISTICS.member_count}
    - Total Posts: {$STATISTICS.post_count}
    - Total Topics: {$STATISTICS.topic_count}
    - Newest Member: link profil + avatar mini
    - Angka counter animasi saat widget masuk viewport

79. widgets/widget_error.tpl
    - Error fallback saat widget gagal load
    - Icon warning
    - Pesan error friendly
    - Retry / Reload button

80. widgets/forum/latest_posts.tpl
    - Widget 5-10 post forum terbaru
    - Per item: avatar mini, username, forum name, topic title, waktu
    - Hover highlight row
    - Link ke topic

=============================================================
ANIMASI WAJIB — SEMUA HARUS BENAR-BENAR BERJALAN DI BROWSER
=============================================================

1.  Parallax Hero          — 3 layer gerak berbeda speed saat scroll
2.  Particles.js           — Partikel emas interaktif di hero homepage
3.  Typed.js               — Teks gamemode diketik + dihapus otomatis
4.  GSAP Hero Reveal       — Judul + subtitle + CTA masuk dengan stagger
5.  Counter Up Stats       — Angka naik dari 0 saat masuk viewport
6.  ScrollTrigger Reveals  — Section cards stagger muncul saat scroll
7.  Navbar Scroll Effect   — Transparent → solid dark + shadow
8.  Hamburger → X          — 3 garis CSS animasi menjadi X
9.  Dropdown Slide         — Menu dropdown slide + fade
10. Button Glow Pulse      — CTA button glow periodik
11. Card Hover Lift        — translateY(-8px) + shadow dalam
12. Dark Mode Transition   — CSS variable smooth crossfade
13. Toast Notification     — Slide-in kanan bawah + progress bar dismiss
14. Reaction Pop           — Emoji scale pop saat klik
15. Profile Avatar Float   — Bob naik-turun perlahan (GSAP yoyo)
16. Skeleton Loader        — Wave shimmer sebelum konten
17. Back to Top            — Muncul setelah 300px, smooth scroll
18. Progress Bar Shimmer   — Shimmer bergerak di bar
19. Modal Backdrop         — Blur + scale masuk
20. 404 Character          — Karakter CSS berjalan/kebingungan
21. Podium Rise            — GSAP ScrollTrigger naik dari bawah
22. OTP Auto-Focus         — Pindah box saat digit diisi
23. Password Strength Bar  — Panjang + warna berubah real-time
24. Form Shake Error       — shakeError keyframe saat login gagal
25. Confetti Register      — Sparkle/confetti saat register sukses

=============================================================
KUALITAS KODE WAJIB
=============================================================

SMARTY:
  - Semua variabel = nama resmi NamelessMC v2
  - Setiap <form> wajib: <input type="hidden" name="token" value="{$TOKEN}">
  - Path asset: {$TEMPLATE_URL}/css/custom.css (JANGAN hardcode)
  - Link internal: {$SITE_URL}/forum
  - Escape output user: {$var|escape}
  - Teks translatable: {$LANGUAGE->get('section', 'key')}

CSS:
  - Semua warna via var(--nama-variabel), tidak ada hex langsung
  - BEM: .mineless-[component]__[element]--[modifier]
  - Mobile-first: default = mobile, @media(min-width:Npx) untuk lebih besar
  - @media (prefers-reduced-motion: reduce) WAJIB ada

JAVASCRIPT:
  - ES6+ vanilla JS, tidak ada jQuery
  - Selalu cek: const el = document.querySelector('...'); if (el) { ... }
  - GSAP + ScrollTrigger untuk semua animasi scroll
  - particles.js dan typed.js di-init di pages.js
  - prefers-reduced-motion: const noMotion = matchMedia('(prefers-reduced-motion:reduce)').matches

PERFORMA:
  - loading="lazy" untuk semua gambar di bawah fold
  - Font: <link rel="preload" as="font"> di header.tpl
  - Script non-critical: <script defer>
  - Particles: if(window.innerWidth < 480) skip particles
  - will-change: transform untuk elemen animasi berat
  - font-display: swap

=============================================================
URUTAN PEMBUATAN
=============================================================

FASE 1 - Foundation:
  1. css/custom.css (design system lengkap)
  2. template.php
  3. template_settings/settings.php + settings.tpl
  4. header.tpl
  5. navbar.tpl
  6. footer.tpl

FASE 2 - Homepage & Core:
  7. index.tpl
  8. js/core/core.js
  9. js/core/pages.js
  10. js/core/update.js
  11. js/core/user.js

FASE 3 - Forum:
  12-23. Semua file forum/*.tpl

FASE 4 - User System:
  24-33. Semua file user/*.tpl

FASE 5 - Halaman Root:
  34-50. Semua root .tpl (profile, login, register, dll)

FASE 6 - Members, Widgets, Email:
  51-80. Semua file members/, widgets/, email/

Setiap file harus LENGKAP — tidak ada TODO, comment placeholder,
atau kode yang dipotong. Jangan berhenti sampai semua 80 file selesai.
```

---

## Prompt Spesifik Per Bagian

### Prompt: Hanya Homepage (index.tpl)
```
Buat index.tpl di ROOT template NamelessMC Mineless premium.
Harus mencakup: hero 3-layer parallax + particles.js + typed.js + GSAP reveal,
stats counter animasi dengan {$STATISTICS.member_count} dan {$STATISTICS.post_count},
3 card berita terbaru, forum preview, feature server 6 cards scroll reveal,
Discord CTA, join steps section.
Gunakan {include file='header.tpl'} dan {include file='footer.tpl'}.
Sertakan semua CSS class dan JS init yang diperlukan.
```

### Prompt: Hanya Forum System
```
Buat SEMUA file forum/ untuk template NamelessMC Mineless:
forum/forum_index.tpl, forum/view_forum.tpl, forum/view_topic.tpl,
forum/new_topic.tpl, forum/forum_edit_post.tpl, forum/search.tpl,
forum/search_results.tpl, forum/following_topics.tpl,
forum/view_forum_no_discussions.tpl, forum/view_forum_confirm_redirect.tpl,
forum/merge.tpl, forum/move.tpl, forum/profile_tab.tpl
Gunakan variabel Smarty NamelessMC yang benar. Animasi per file.
```

### Prompt: Hanya User Panel
```
Buat SEMUA file user/ untuk template NamelessMC Mineless:
user/index.tpl, user/settings.tpl, user/alerts.tpl, user/alert.tpl,
user/messaging.tpl, user/new_message.tpl, user/view_message.tpl,
user/connections.tpl, user/navigation.tpl, user/sessions.tpl,
user/tfa.tpl, user/notification_settings.tpl, user/oauth.tpl,
user/placeholders.tpl
Semua halaman include user/navigation.tpl sebagai sidebar.
```

### Prompt: Hanya Widgets
```
Buat SEMUA file widgets/ untuk template NamelessMC Mineless:
widgets/server_status.tpl, widgets/online_staff.tpl, widgets/online_users.tpl,
widgets/statistics.tpl, widgets/minecraft_account.tpl, widgets/reactions.tpl,
widgets/profile_posts.tpl, widgets/cookie_notice.tpl, widgets/widget_error.tpl,
widgets/forum/latest_posts.tpl
Setiap widget standalone dengan animasi sendiri.
```

### Prompt: Hanya CSS Design System
```
Buat css/custom.css untuk template NamelessMC Mineless ($1000+ quality).
Minimal 700 baris. Harus mencakup semua CSS variables di :root,
dark/light mode overrides, semua komponen Mineless UI (minimal 25 komponen),
minimal 20 @keyframes animasi unik, mobile-first responsive lengkap,
@media (prefers-reduced-motion: reduce) fallback.
```

### Prompt: Hanya JavaScript
```
Buat SEMUA file js/core/ untuk template NamelessMC Mineless:
js/core/core.js — dark mode, navbar scroll, hamburger, back-to-top, GSAP init,
  lazy load, clipboard, konami code
js/core/pages.js — homepage (particles+typed+parallax+counter), forum (reactions+spoiler),
  profile (tabs+float), leaderboard (podium), login (shake+show-pass),
  register (wizard+strength+confetti), tfa (otp auto-focus), error pages
js/core/update.js — server status polling, notification polling, online count
js/core/user.js — user popover, alerts mark-read, message count, avatar preview
Vanilla JS ES6+, no jQuery. GSAP + ScrollTrigger. prefers-reduced-motion fallback.
```

### Prompt: Hanya Auth Pages
```
Buat semua halaman autentikasi untuk template NamelessMC Mineless (root level):
login.tpl, register.tpl, forgot_password.tpl, change_password.tpl, tfa.tpl,
authme.tpl, authme_email.tpl, registration_disabled.tpl, complete_signup.tpl
Semua form punya {$TOKEN}. Error handling dengan shake animation.
Multi-step wizard di register.tpl. Confetti di sukses register.
```

### Prompt: Hanya Profile & Members
```
Buat halaman profil dan member untuk template NamelessMC Mineless:
- profile.tpl (profil publik dengan Crafatar skin render)
- user_popover.tpl (mini preview card hover)
- user_not_exist.tpl (error profil tidak ada)
- members/members.tpl (daftar member, grid+list view toggle)
- leaderboards.tpl (podium top 3, tabel 4-20)
Crafatar full body: https://crafatar.com/renders/body/{$USER_UUID}?scale=4&overlay
Crafatar avatar: https://crafatar.com/avatars/{$USER_UUID}?size=100&overlay
```

### Prompt: Hanya Error & Special Pages
```
Buat halaman error dan special untuk template NamelessMC Mineless:
- 403.tpl (dungeon theme, rantai + kunci animasi CSS)
- 404.tpl (tersesat, CSS character idle, kompas berputar)
- maintenance.tpl (gear berputar, countdown)
- status.tpl (live server status, uptime, incidents)
- cookies.tpl (cookie policy, toggle per kategori)
- privacy.tpl (kebijakan privasi, sticky ToC)
- terms.tpl (ToS, sticky ToC)
- portal.tpl (dashboard logged-in)
- custom.tpl (halaman statis dengan sidebar)
- custom_basic.tpl (halaman statis sederhana)
```

### Prompt: Iterasi / Perbaikan
```
Template NamelessMC Mineless sudah ada. Perbaiki:
[DESKRIPSIKAN PERUBAHAN]

Aturan iterasi:
- Jangan ubah variabel Smarty yang sudah benar
- Pertahankan CSS custom properties (tidak ada warna hardcode)
- Pastikan animasi tetap berjalan setelah perubahan
- Cek {$TOKEN} masih ada di semua form
- Mobile responsiveness tidak rusak
```

---

## Checklist Validasi Output

### ✅ File Completeness
- [ ] Semua 80 file ada (tidak ada yang dilewati)
- [ ] 29 file root .tpl ada
- [ ] css/ — custom.css + toastr.min.css
- [ ] email/ — 5 file .html
- [ ] forum/ — 13 file .tpl
- [ ] js/core/ — 4 file .js
- [ ] members/ — 1 file .tpl
- [ ] template_settings/ — settings.php + settings.tpl
- [ ] user/ — 14 file .tpl
- [ ] widgets/ — 9 file + widgets/forum/latest_posts.tpl

### ✅ Smarty Syntax
- [ ] `{foreach}` diakhiri `{/foreach}`
- [ ] `{if}` diakhiri `{/if}`
- [ ] Setiap `<form>` ada `<input type="hidden" name="token" value="{$TOKEN}">`
- [ ] `{$TEMPLATE_URL}` untuk semua asset path
- [ ] `{$SITE_URL}` untuk semua link internal
- [ ] Output user di-escape: `{$var|escape}`

### ✅ HTML Structure
- [ ] `{include file='header.tpl'}` di setiap halaman utama
- [ ] `{include file='footer.tpl'}` di setiap halaman utama
- [ ] Semua `<img>` punya `alt`
- [ ] Semua `<input>` punya `<label>`
- [ ] ARIA attributes pada komponen interaktif

### ✅ CSS Quality
- [ ] Tidak ada warna hex hardcoded di luar `:root`
- [ ] BEM naming .mineless-* konsisten
- [ ] Mobile-first breakpoints
- [ ] `@media (prefers-reduced-motion: reduce)` ada
- [ ] Minimal 20 @keyframes didefinisikan

### ✅ JavaScript
- [ ] Tidak ada `console.log` tertinggal
- [ ] `if (element)` cek sebelum DOM manipulasi
- [ ] GSAP + ScrollTrigger digunakan
- [ ] particles.js terinit di homepage
- [ ] typed.js terinit di homepage
- [ ] prefers-reduced-motion fallback ada

### ✅ Animasi Running
- [ ] particles.js terlihat di homepage hero
- [ ] typed.js menulis teks di hero
- [ ] Parallax bergerak saat scroll
- [ ] Stats counter menghitung naik
- [ ] ScrollTrigger reveal berjalan di minimal 6 section
- [ ] Navbar berubah saat scroll

---

## Tips Premium ($1000+ Quality)

1. Tidak satu pun elemen terlihat "default" — semua punya Mineless touch
2. Design system ketat — tidak ada hex di luar :root
3. Animasi 60fps — gunakan `transform` dan `opacity`, hindari `top/left`
4. Tiap halaman error punya ilustrasi/karakter unik relevan
5. Template Settings memungkinkan customisasi tanpa edit kode
6. Inline comment CSS dan JS untuk buyer yang ingin modifikasi
7. Easter egg Konami code: tampilkan karakter special atau pesan tersembunyi
8. Particle adaptive: `window.innerWidth > 1024 ? 80 : window.innerWidth > 768 ? 30 : 0`
9. `font-display: swap` dan `rel="preload"` untuk Core Web Vitals
10. Semua widget ada fallback error state (widget_error.tpl)
