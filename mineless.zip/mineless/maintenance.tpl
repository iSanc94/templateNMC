{include file='header.tpl'}

<section class="mineless-maintenance-section">
    <div class="mineless-maintenance-bg">
        <div class="mineless-gear gear-large" id="gear-large">
            <i class="fas fa-cog"></i>
        </div>
        <div class="mineless-gear gear-medium" id="gear-medium">
            <i class="fas fa-cog"></i>
        </div>
        <div class="mineless-gear gear-small" id="gear-small">
            <i class="fas fa-cog"></i>
        </div>
        
        <!-- Floating particles -->
        <div class="mineless-particles" id="particles"></div>
    </div>
    
    <div class="mineless-maintenance-container">
        <div class="mineless-maintenance-content">
            <div class="mineless-wrench-icon">
                <i class="fas fa-wrench"></i>
                <div class="mineless-spark"></div>
            </div>
            
            <h1 class="mineless-maintenance-title">Sedang Dalam Perbaikan</h1>
            <p class="mineless-maintenance-message">
                Para tukang dan engineer kami sedang bekerja keras untuk meningkatkan pengalaman petualanganmu.
                <br>Mohon tunggu sebentar!
            </p>
            
            {if isset($MAINTENANCE_MESSAGE)}
                <div class="mineless-maintenance-notice">
                    <i class="fas fa-info-circle"></i>
                    <p>{$MAINTENANCE_MESSAGE}</p>
                </div>
            {/if}
            
            <!-- Progress Bar -->
            <div class="mineless-progress-container">
                <div class="mineless-progress-label">
                    <span>Progress Perbaikan</span>
                    <span id="progress-text">65%</span>
                </div>
                <div class="mineless-progress-track">
                    <div class="mineless-progress-fill" id="maintenance-progress">
                        <div class="mineless-progress-shimmer"></div>
                    </div>
                </div>
            </div>
            
            <!-- Countdown Timer -->
            {if isset($MAINTENANCE_TIME)}
                <div class="mineless-countdown-container">
                    <p class="mineless-countdown-label">Perkiraan selesai dalam:</p>
                    <div class="mineless-countdown" id="countdown">
                        <div class="mineless-countdown-item">
                            <span class="mineless-countdown-value" id="hours">02</span>
                            <span class="mineless-countdown-unit">Jam</span>
                        </div>
                        <span class="mineless-countdown-sep">:</span>
                        <div class="mineless-countdown-item">
                            <span class="mineless-countdown-value" id="minutes">45</span>
                            <span class="mineless-countdown-unit">Menit</span>
                        </div>
                        <span class="mineless-countdown-sep">:</span>
                        <div class="mineless-countdown-item">
                            <span class="mineless-countdown-value" id="seconds">30</span>
                            <span class="mineless-countdown-unit">Detik</span>
                        </div>
                    </div>
                </div>
            {/if}
            
            <!-- Social Links -->
            <div class="mineless-social-links">
                <p>Sementara menunggu, ikuti kami di:</p>
                <div class="mineless-social-icons">
                    {if isset($DISCORD_LINK)}
                        <a href="{$DISCORD_LINK}" class="mineless-social-btn discord">
                            <i class="fab fa-discord"></i>
                        </a>
                    {/if}
                    {if isset($TWITTER_LINK)}
                        <a href="{$TWITTER_LINK}" class="mineless-social-btn twitter">
                            <i class="fab fa-twitter"></i>
                        </a>
                    {/if}
                    {if isset($YOUTUBE_LINK)}
                        <a href="{$YOUTUBE_LINK}" class="mineless-social-btn youtube">
                            <i class="fab fa-youtube"></i>
                        </a>
                    {/if}
                </div>
            </div>
            
            <!-- Auto Refresh -->
            <div class="mineless-refresh-info">
                <i class="fas fa-sync-alt fa-spin"></i>
                <span>Halaman akan refresh otomatis dalam <span id="refresh-timer">30</span> detik</span>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-maintenance-section {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    position: relative;
    overflow: hidden;
}

.mineless-maintenance-bg {
    position: absolute;
    inset: 0;
}

.mineless-gear {
    position: absolute;
    color: rgba(212, 175, 55, 0.1);
    animation: gearSpin linear infinite;
}

.mineless-gear i {
    display: block;
}

.gear-large {
    font-size: 400px;
    top: -100px;
    right: -100px;
    animation-duration: 20s;
}

.gear-medium {
    font-size: 250px;
    bottom: -50px;
    left: -50px;
    animation-duration: 15s;
    animation-direction: reverse;
}

.gear-small {
    font-size: 150px;
    top: 30%;
    left: 20%;
    animation-duration: 10s;
}

@keyframes gearSpin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.mineless-particles {
    position: absolute;
    inset: 0;
    overflow: hidden;
}

.mineless-particle {
    position: absolute;
    width: 4px;
    height: 4px;
    background: var(--mineless-gold);
    border-radius: 50%;
    opacity: 0.6;
    animation: particleFloat 10s linear infinite;
}

@keyframes particleFloat {
    0% {
        transform: translateY(100vh) translateX(0);
        opacity: 0;
    }
    10% {
        opacity: 0.6;
    }
    90% {
        opacity: 0.6;
    }
    100% {
        transform: translateY(-100px) translateX(100px);
        opacity: 0;
    }
}

.mineless-maintenance-container {
    position: relative;
    z-index: 10;
    text-align: center;
    padding: 2rem;
    max-width: 600px;
}

.mineless-wrench-icon {
    width: 120px;
    height: 120px;
    margin: 0 auto 2rem;
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3.5rem;
    color: var(--bg-primary);
    position: relative;
    animation: wrenchWiggle 2s ease-in-out infinite;
}

@keyframes wrenchWiggle {
    0%, 100% { transform: rotate(-10deg); }
    50% { transform: rotate(10deg); }
}

.mineless-spark {
    position: absolute;
    width: 10px;
    height: 10px;
    background: #fff;
    border-radius: 50%;
    top: 20%;
    right: 20%;
    animation: spark 0.5s ease-out infinite;
}

@keyframes spark {
    0% { transform: scale(0); opacity: 1; }
    100% { transform: scale(2); opacity: 0; }
}

.mineless-maintenance-title {
    font-family: var(--font-display);
    font-size: 2.5rem;
    color: var(--text-primary);
    margin-bottom: 1rem;
}

.mineless-maintenance-message {
    color: var(--text-secondary);
    font-size: 1.1rem;
    line-height: 1.6;
    margin-bottom: 2rem;
}

.mineless-maintenance-notice {
    background: rgba(212, 175, 55, 0.1);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-md);
    padding: 1rem;
    margin-bottom: 2rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    text-align: left;
}

.mineless-maintenance-notice i {
    color: var(--mineless-gold);
    font-size: 1.25rem;
}

.mineless-maintenance-notice p {
    color: var(--text-secondary);
    margin: 0;
}

.mineless-progress-container {
    margin-bottom: 2rem;
}

.mineless-progress-label {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.mineless-progress-track {
    height: 8px;
    background: var(--bg-secondary);
    border-radius: 4px;
    overflow: hidden;
}

.mineless-progress-fill {
    height: 100%;
    width: 65%;
    background: linear-gradient(90deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 4px;
    position: relative;
    overflow: hidden;
    animation: progressPulse 2s ease-in-out infinite;
}

.mineless-progress-shimmer {
    position: absolute;
    inset: 0;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    animation: shimmer 2s infinite;
}

@keyframes shimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}

@keyframes progressPulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.8; }
}

.mineless-countdown-container {
    margin-bottom: 2rem;
}

.mineless-countdown-label {
    color: var(--text-secondary);
    margin-bottom: 1rem;
}

.mineless-countdown {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 0.5rem;
}

.mineless-countdown-item {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-md);
    padding: 1rem;
    min-width: 80px;
}

.mineless-countdown-value {
    display: block;
    font-family: var(--font-display);
    font-size: 2rem;
    font-weight: 700;
    color: var(--mineless-gold);
}

.mineless-countdown-unit {
    font-size: 0.75rem;
    color: var(--text-secondary);
    text-transform: uppercase;
}

.mineless-countdown-sep {
    font-size: 2rem;
    color: var(--mineless-gold);
    font-weight: 700;
}

.mineless-social-links {
    margin-bottom: 2rem;
}

.mineless-social-links p {
    color: var(--text-secondary);
    margin-bottom: 1rem;
}

.mineless-social-icons {
    display: flex;
    justify-content: center;
    gap: 1rem;
}

.mineless-social-btn {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: white;
    text-decoration: none;
    transition: var(--transition-fast);
}

.mineless-social-btn:hover {
    transform: translateY(-3px);
}

.mineless-social-btn.discord { background: #5865F2; }
.mineless-social-btn.twitter { background: #1DA1F2; }
.mineless-social-btn.youtube { background: #FF0000; }

.mineless-refresh-info {
    color: var(--text-secondary);
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.mineless-refresh-info i {
    color: var(--mineless-gold);
}

@media (max-width: 768px) {
    .mineless-maintenance-title {
        font-size: 1.75rem;
    }
    
    .mineless-gear {
        display: none;
    }
    
    .mineless-countdown-item {
        padding: 0.75rem;
        min-width: 60px;
    }
    
    .mineless-countdown-value {
        font-size: 1.5rem;
    }
}
</style>

<script>
// Create particles
const particleContainer = document.getElementById('particles');
for (let i = 0; i < 30; i++) {
    const particle = document.createElement('div');
    particle.className = 'adv-particle';
    particle.style.left = Math.random() * 100 + '%';
    particle.style.animationDelay = Math.random() * 10 + 's';
    particle.style.animationDuration = (10 + Math.random() * 10) + 's';
    particleContainer.appendChild(particle);
}

// Countdown timer
{if isset($MAINTENANCE_TIME)}
const targetTime = new Date('{$MAINTENANCE_TIME}').getTime();

function updateCountdown() {
    const now = new Date().getTime();
    const distance = targetTime - now;
    
    if (distance > 0) {
        const hours = Math.floor(distance / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        document.getElementById('hours').textContent = String(hours).padStart(2, '0');
        document.getElementById('minutes').textContent = String(minutes).padStart(2, '0');
        document.getElementById('seconds').textContent = String(seconds).padStart(2, '0');
    } else {
        location.reload();
    }
}

setInterval(updateCountdown, 1000);
updateCountdown();
{/if}

// Refresh timer
let refreshSeconds = 30;
const refreshTimer = document.getElementById('refresh-timer');

setInterval(() => {
    refreshSeconds--;
    if (refreshTimer) refreshTimer.textContent = refreshSeconds;
    
    if (refreshSeconds <= 0) {
        location.reload();
    }
}, 1000);

// Random progress updates
const progressFill = document.getElementById('maintenance-progress');
const progressText = document.getElementById('progress-text');
let currentProgress = 65;

setInterval(() => {
    if (currentProgress < 95 && Math.random() > 0.7) {
        currentProgress += Math.floor(Math.random() * 3);
        if (progressFill) progressFill.style.width = currentProgress + '%';
        if (progressText) progressText.textContent = currentProgress + '%';
    }
}, 5000);
</script>

{include file='footer.tpl'}