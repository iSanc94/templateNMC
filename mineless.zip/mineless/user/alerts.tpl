{* User Alerts List - Mineless Theme *}
<div class="mineless-user-panel">
    {include file='user/navigation.tpl'}
    
    <main class="mineless-user-main">
        <div class="mineless-alerts-page">
            {* Page Header *}
            <div class="mineless-page-header">
                <div class="mineless-header-content">
                    <h1><i class="fas fa-bell"></i> Notifikasi</h1>
                    <p>Kelola semua notifikasi dan alert akunmu</p>
                </div>
                <div class="mineless-header-actions">
                    <button class="mineless-btn adv-btn-secondary" id="markAllRead">
                        <i class="fas fa-check-double"></i> Tandai Semua Dibaca
                    </button>
                </div>
            </div>
            
            {* Filters *}
            <div class="mineless-filters-bar">
                <div class="mineless-filter-tabs">
                    <button class="mineless-filter-btn active" data-filter="all">
                        <i class="fas fa-list"></i> Semua
                        {if isset($TOTAL_ALERTS) && $TOTAL_ALERTS > 0}
                            <span class="mineless-filter-count">{$TOTAL_ALERTS}</span>
                        {/if}
                    </button>
                    <button class="mineless-filter-btn" data-filter="unread">
                        <i class="fas fa-envelope"></i> Belum Dibaca
                        {if isset($UNREAD_ALERTS) && $UNREAD_ALERTS > 0}
                            <span class="mineless-filter-count adv-badge-new">{$UNREAD_ALERTS}</span>
                        {/if}
                    </button>
                </div>
                
                <div class="mineless-filter-options">
                    <select class="mineless-form-control adv-select-sm" id="sortAlerts">
                        <option value="newest">Terbaru</option>
                        <option value="oldest">Terlama</option>
                    </select>
                </div>
            </div>
            
            {* Alerts List *}
            <div class="mineless-alerts-container">
                {if isset($ALERTS) && is_array($ALERTS) && count($ALERTS) > 0}
                    <div class="mineless-alerts-list" id="alertsList">
                        {foreach from=$ALERTS item=alert}
                            {include file='user/alert.tpl' alert=$alert}
                        {/foreach}
                    </div>
                    
                    {* Pagination *}
                    {if isset($PAGINATION) && $PAGINATION.total_pages > 1}
                        <div class="mineless-pagination">
                            {if $PAGINATION.current_page > 1}
                                <a href="{$PAGINATION.first_link}" class="mineless-page-btn">
                                    <i class="fas fa-angle-double-left"></i>
                                </a>
                                <a href="{$PAGINATION.prev_link}" class="mineless-page-btn">
                                    <i class="fas fa-angle-left"></i>
                                </a>
                            {/if}
                            
                            {foreach from=$PAGINATION.pages item=page}
                                {if $page.number == '...'}
                                    <span class="mineless-page-dots">...</span>
                                {else}
                                    <a href="{$page.link}" 
                                       class="mineless-page-btn {if $page.number == $PAGINATION.current_page}active{/if}">
                                        {$page.number}
                                    </a>
                                {/if}
                            {/foreach}
                            
                            {if $PAGINATION.current_page < $PAGINATION.total_pages}
                                <a href="{$PAGINATION.next_link}" class="mineless-page-btn">
                                    <i class="fas fa-angle-right"></i>
                                </a>
                                <a href="{$PAGINATION.last_link}" class="mineless-page-btn">
                                    <i class="fas fa-angle-double-right"></i>
                                </a>
                            {/if}
                        </div>
                    {/if}
                {else}
                    {* Empty State *}
                    <div class="mineless-empty-state adv-empty-large">
                        <div class="mineless-empty-icon">
                            <i class="fas fa-bell-slash"></i>
                        </div>
                        <h3>Tidak Ada Notifikasi</h3>
                        <p>Belum ada notifikasi untukmu saat ini. Notifikasi akan muncul di sini ketika ada aktivitas terkait akunmu.</p>
                    </div>
                {/if}
            </div>
        </div>
    </main>
</div>

{* Toast Container *}
<div class="mineless-toast-container" id="toastContainer"></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const alertsList = document.getElementById('alertsList');
    
    // Filter tabs
    const filterBtns = document.querySelectorAll('.mineless-filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Filter alerts
            const alerts = alertsList?.querySelectorAll('.mineless-alert-item');
            alerts?.forEach(alert => {
                if (filter === 'unread') {
                    alert.style.display = alert.classList.contains('unread') ? 'flex' : 'none';
                } else {
                    alert.style.display = 'flex';
                }
            });
            
            // Show empty state if no visible alerts
            checkEmptyState();
        });
    });
    
    // Check empty state
    function checkEmptyState() {
        const visibleAlerts = alertsList?.querySelectorAll('.mineless-alert-item:not([style*="none"])');
        const emptyState = alertsList?.parentElement.querySelector('.mineless-empty-state');
        
        if (visibleAlerts?.length === 0 && !emptyState) {
            const emptyDiv = document.createElement('div');
            emptyDiv.className = 'adv-empty-state adv-empty-large';
            emptyDiv.innerHTML = `
                <div class="mineless-empty-icon"><i class="fas fa-bell-slash"></i></div>
                <h3>Tidak Ada Notifikasi</h3>
                <p>Tidak ada notifikasi yang sesuai dengan filter.</p>
            `;
            alertsList.parentElement.appendChild(emptyDiv);
        } else if (visibleAlerts?.length > 0 && emptyState) {
            emptyState.remove();
        }
    }
    
    // Mark all as read
    document.getElementById('markAllRead')?.addEventListener('click', function() {
        const btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
        
        fetch('{$smarty.const.URL}/user/alerts/mark_all_read', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'token={$TOKEN}'
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                // Animate all unread alerts
                const unreadAlerts = document.querySelectorAll('.mineless-alert-item.unread');
                unreadAlerts.forEach((alert, index) => {
                    setTimeout(() => {
                        alert.classList.remove('unread');
                        alert.querySelector('.mineless-alert-unread')?.remove();
                    }, index * 50);
                });
                
                showToast('Semua notifikasi ditandai dibaca', 'success');
                
                // Update badge counts
                document.querySelectorAll('.mineless-filter-count').forEach(badge => badge.remove());
            } else {
                showToast(data.message || 'Gagal menandai notifikasi', 'error');
            }
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-check-double"></i> Tandai Semua Dibaca';
        })
        .catch(() => {
            showToast('Terjadi kesalahan. Coba lagi.', 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-check-double"></i> Tandai Semua Dibaca';
        });
    });
    
    // Toast function
    function showToast(message, type = 'success') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `adv-toast ${type}`;
        toast.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        container.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
});
</script>
