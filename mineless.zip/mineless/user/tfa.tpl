{* 
 * File: user/tfa.tpl
 * Deskripsi: Setup dan management Two-Factor Authentication (TFA)
 * Template: Mineless
 *}

{include file='header.tpl'}

<div class="mineless-user-panel">
  <!-- Particle Background -->
  <div id="particles-tfa" class="mineless-particles"></div>
  
  <div class="mineless-container">
    <div class="mineless-panel-grid">
      
      {include file='user/navigation.tpl'}
      
      <!-- Main Content -->
      <main class="mineless-panel-main">
        <div class="mineless-panel-header">
          <h1 class="mineless-panel-title">
            <span class="mineless-icon adv-icon-shield-lock"></span>
            {$LANGUAGE->get('user', 'two_factor_auth')}
          </h1>
          <p class="mineless-panel-subtitle">{$LANGUAGE->get('user', 'tfa_description')}</p>
        </div>
        
        <!-- Success Message -->
        {if isset($SUCCESS)}
          <div class="mineless-alert adv-alert-success adv-alert-dismissible adv-fade-in">
            <span class="mineless-icon adv-icon-check-circle"></span>
            <span>{$SUCCESS}</span>
            <button type="button" class="mineless-alert-close">
              <span class="mineless-icon adv-icon-close"></span>
            </button>
          </div>
        {/if}
        
        <!-- Error Message -->
        {if isset($ERROR)}
          <div class="mineless-alert adv-alert-error adv-alert-dismissible adv-fade-in">
            <span class="mineless-icon adv-icon-error"></span>
            <span>{$ERROR}</span>
            <button type="button" class="mineless-alert-close">
              <span class="mineless-icon adv-icon-close"></span>
            </button>
          </div>
        {/if}
        
        {if !$TFA_ENABLED}
          
          <!-- Setup TFA Flow -->
          <div class="mineless-tfa-setup">
            
            <!-- Step 1: QR Code -->
            <div class="mineless-card adv-tfa-step {if !$TFA_SECRET}adv-step-active{/if}" id="step1">
              <div class="mineless-step-header">
                <span class="mineless-step-number">1</span>
                <h3 class="mineless-step-title">{$LANGUAGE->get('user', 'tfa_scan_qr')}</h3>
              </div>
              
              <div class="mineless-step-content">
                <p class="mineless-tfa-instruction">
                  {$LANGUAGE->get('user', 'tfa_scan_instruction')}
                </p>
                
                <div class="mineless-tfa-qr-section">
                  <div class="mineless-tfa-qr-wrapper">
                    <img src="{$TFA_QR_URL}" alt="TFA QR Code" class="mineless-tfa-qr">
                    <div class="mineless-tfa-qr-overlay">
                      <span class="mineless-icon adv-icon-shield"></span>
                    </div>
                  </div>
                  
                  <!-- Manual Secret Key -->
                  <div class="mineless-tfa-secret">
                    <label class="mineless-form-label">{$LANGUAGE->get('user', 'cant_scan_qr')}</label>
                    <div class="mineless-secret-input-group">
                      <input type="text" 
                             class="mineless-input adv-input-secret" 
                             value="{$TFA_SECRET_KEY}" 
                             readonly 
                             id="tfaSecretKey">
                      <button type="button" class="mineless-btn adv-btn-secondary" id="copySecretBtn">
                        <span class="mineless-icon adv-icon-copy"></span>
                        {$LANGUAGE->get('general', 'copy')}
                      </button>
                    </div>
                    <span class="mineless-form-hint">{$LANGUAGE->get('user', 'enter_manually')}</span>
                  </div>
                </div>
                
                <div class="mineless-step-actions">
                  <button type="button" class="mineless-btn adv-btn-primary" id="proceedToStep2">
                    {$LANGUAGE->get('general', 'next_step')}
                    <span class="mineless-icon adv-icon-arrow-right"></span>
                  </button>
                </div>
              </div>
            </div>
            
            <!-- Step 2: Verify Code -->
            <div class="mineless-card adv-tfa-step {if $TFA_SECRET}adv-step-active{/if}" id="step2">
              <div class="mineless-step-header">
                <span class="mineless-step-number">2</span>
                <h3 class="mineless-step-title">{$LANGUAGE->get('user', 'tfa_verify_code')}</h3>
              </div>
              
              <div class="mineless-step-content">
                <p class="mineless-tfa-instruction">
                  {$LANGUAGE->get('user', 'tfa_verify_instruction')}
                </p>
                
                <form action="{$TFA_ENABLE_URL}" method="post" class="mineless-tfa-verify-form">
                  <input type="hidden" name="token" value="{$TOKEN}">
                  <input type="hidden" name="secret" value="{$TFA_SECRET_KEY}">
                  
                  <div class="mineless-tfa-code-input">
                    <label class="mineless-form-label">{$LANGUAGE->get('user', 'enter_6_digit_code')}</label>
                    <div class="mineless-code-inputs">
                      <input type="text" 
                             class="mineless-input adv-code-digit" 
                             maxlength="1" 
                             inputmode="numeric"
                             pattern="[0-9]"
                             autocomplete="off">
                      <input type="text" 
                             class="mineless-input adv-code-digit" 
                             maxlength="1" 
                             inputmode="numeric"
                             pattern="[0-9]"
                             autocomplete="off">
                      <input type="text" 
                             class="mineless-input adv-code-digit" 
                             maxlength="1" 
                             inputmode="numeric"
                             pattern="[0-9]"
                             autocomplete="off">
                      <span class="mineless-code-separator">-</span>
                      <input type="text" 
                             class="mineless-input adv-code-digit" 
                             maxlength="1" 
                             inputmode="numeric"
                             pattern="[0-9]"
                             autocomplete="off">
                      <input type="text" 
                             class="mineless-input adv-code-digit" 
                             maxlength="1" 
                             inputmode="numeric"
                             pattern="[0-9]"
                             autocomplete="off">
                      <input type="text" 
                             class="mineless-input adv-code-digit" 
                             maxlength="1" 
                             inputmode="numeric"
                             pattern="[0-9]"
                             autocomplete="off">
                    </div>
                    <input type="hidden" name="code" id="fullTfaCode">
                  </div>
                  
                  <div class="mineless-step-actions">
                    <button type="button" class="mineless-btn adv-btn-outline" id="backToStep1">
                      <span class="mineless-icon adv-icon-arrow-left"></span>
                      {$LANGUAGE->get('general', 'back')}
                    </button>
                    <button type="submit" class="mineless-btn adv-btn-primary adv-btn-lg" id="verifyTfaBtn">
                      <span class="mineless-icon adv-icon-check"></span>
                      {$LANGUAGE->get('user', 'enable_tfa')}
                    </button>
                  </div>
                </form>
              </div>
            </div>
            
          </div>
          
        {else}
          
          <!-- TFA Enabled State -->
          <div class="mineless-tfa-enabled">
            
            <!-- Status Card -->
            <div class="mineless-card adv-tfa-status-card adv-tfa-active">
              <div class="mineless-tfa-status-icon">
                <span class="mineless-icon adv-icon-shield-check"></span>
              </div>
              <div class="mineless-tfa-status-content">
                <h3>{$LANGUAGE->get('user', 'tfa_is_enabled')}</h3>
                <p>{$LANGUAGE->get('user', 'tfa_enabled_desc')}</p>
                <span class="mineless-tfa-enabled-date">
                  {$LANGUAGE->get('user', 'enabled_on')} {$TFA_ENABLED_DATE|date_format:"%d %b %Y"}
                </span>
              </div>
            </div>
            
            <!-- Recovery Codes -->
            <div class="mineless-card adv-recovery-codes">
              <div class="mineless-card-header">
                <h3 class="mineless-card-title">
                  <span class="mineless-icon adv-icon-key"></span>
                  {$LANGUAGE->get('user', 'backup_codes')}
                </h3>
                <span class="mineless-badge adv-badge-warning">
                  {$LANGUAGE->get('user', 'keep_secret')}
                </span>
              </div>
              
              <div class="mineless-card-body">
                <p class="mineless-recovery-info">
                  {$LANGUAGE->get('user', 'backup_codes_desc')}
                </p>
                
                <div class="mineless-codes-grid">
                  {foreach from=$BACKUP_CODES item=code}
                    <div class="mineless-code-item {if $code.used}adv-code-used{/if}">
                      <code class="mineless-backup-code">{$code.code}</code>
                      {if $code.used}
                        <span class="mineless-code-status">{$LANGUAGE->get('user', 'used')}</span>
                      {/if}
                    </div>
                  {/foreach}
                </div>
                
                <div class="mineless-codes-actions">
                  <button type="button" class="mineless-btn adv-btn-secondary" id="copyCodesBtn">
                    <span class="mineless-icon adv-icon-copy"></span>
                    {$LANGUAGE->get('general', 'copy_all')}
                  </button>
                  <a href="{$DOWNLOAD_CODES_URL}" class="mineless-btn adv-btn-primary" download>
                    <span class="mineless-icon adv-icon-download"></span>
                    {$LANGUAGE->get('general', 'download')}
                  </a>
                  <form action="{$REGENERATE_CODES_URL}" method="post" class="mineless-inline-form">
                    <input type="hidden" name="token" value="{$TOKEN}">
                    <button type="submit" class="mineless-btn adv-btn-warning"
                            onclick="return confirm('{$LANGUAGE->get('user', 'confirm_regenerate_codes')}')">
                      <span class="mineless-icon adv-icon-refresh"></span>
                      {$LANGUAGE->get('user', 'regenerate_codes')}
                    </button>
                  </form>
                </div>
              </div>
            </div>
            
            <!-- Disable TFA -->
            <div class="mineless-card adv-disable-tfa">
              <div class="mineless-card-header adv-card-danger">
                <h3 class="mineless-card-title">
                  <span class="mineless-icon adv-icon-shield-off"></span>
                  {$LANGUAGE->get('user', 'disable_tfa')}
                </h3>
              </div>
              
              <div class="mineless-card-body">
                <p class="mineless-disable-warning">
                  <span class="mineless-icon adv-icon-alert-triangle"></span>
                  {$LANGUAGE->get('user', 'disable_tfa_warning')}
                </p>
                
                <form action="{$TFA_DISABLE_URL}" method="post" class="mineless-disable-form">
                  <input type="hidden" name="token" value="{$TOKEN}">
                  
                  <div class="mineless-form-group">
                    <label class="mineless-form-label">{$LANGUAGE->get('user', 'enter_password_confirm')}</label>
                    <div class="mineless-password-wrapper">
                      <input type="password" 
                             name="password" 
                             class="mineless-input" 
                             placeholder="{$LANGUAGE->get('user', 'your_password')}"
                             required>
                      <button type="button" class="mineless-password-toggle">
                        <span class="mineless-icon adv-icon-eye"></span>
                      </button>
                    </div>
                  </div>
                  
                  <div class="mineless-form-group">
                    <label class="mineless-form-label">{$LANGUAGE->get('user', 'enter_tfa_code')}</label>
                    <input type="text" 
                           name="tfa_code" 
                           class="mineless-input adv-input-lg" 
                           placeholder="000000"
                           maxlength="6"
                           inputmode="numeric"
                           pattern="[0-9]{6}"
                           required>
                  </div>
                  
                  <button type="submit" class="mineless-btn adv-btn-danger adv-btn-block"
                          onclick="return confirm('{$LANGUAGE->get('user', 'confirm_disable_tfa')}')">
                    <span class="mineless-icon adv-icon-shield-off"></span>
                    {$LANGUAGE->get('user', 'disable_tfa')}
                  </button>
                </form>
              </div>
            </div>
            
          </div>
          
        {/if}
        
        <!-- Security Info -->
        <div class="mineless-card adv-security-info">
          <div class="mineless-security-icon">
            <span class="mineless-icon adv-icon-info-circle"></span>
          </div>
          <div class="mineless-security-content">
            <h4>{$LANGUAGE->get('user', 'tfa_security_info')}</h4>
            <p>{$LANGUAGE->get('user', 'tfa_security_desc')}</p>
            <ul class="mineless-security-list">
              <li>{$LANGUAGE->get('user', 'tfa_security_1')}</li>
              <li>{$LANGUAGE->get('user', 'tfa_security_2')}</li>
              <li>{$LANGUAGE->get('user', 'tfa_security_3')}</li>
            </ul>
          </div>
        </div>
        
      </main>
      
    </div>
  </div>
</div>

<script>
  // Step navigation
  const step1 = document.getElementById('step1');
  const step2 = document.getElementById('step2');
  const proceedBtn = document.getElementById('proceedToStep2');
  const backBtn = document.getElementById('backToStep1');
  
  if (proceedBtn) {
    proceedBtn.addEventListener('click', () => {
      step1.classList.remove('adv-step-active');
      step2.classList.add('adv-step-active');
      step2.scrollIntoView({ behavior: 'smooth', block: 'center' });
      // Focus first digit input
      document.querySelector('.mineless-code-digit').focus();
    });
  }
  
  if (backBtn) {
    backBtn.addEventListener('click', () => {
      step2.classList.remove('adv-step-active');
      step1.classList.add('adv-step-active');
      step1.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }
  
  // Copy secret key
  const copySecretBtn = document.getElementById('copySecretBtn');
  if (copySecretBtn) {
    copySecretBtn.addEventListener('click', () => {
      const secretInput = document.getElementById('tfaSecretKey');
      secretInput.select();
      document.execCommand('copy');
      
      copySecretBtn.innerHTML = '<span class="mineless-icon adv-icon-check"></span> {$LANGUAGE->get("general", "copied")}';
      setTimeout(() => {
        copySecretBtn.innerHTML = '<span class="mineless-icon adv-icon-copy"></span> {$LANGUAGE->get("general", "copy")}';
      }, 2000);
    });
  }
  
  // Code input handling
  const codeDigits = document.querySelectorAll('.mineless-code-digit');
  const fullCodeInput = document.getElementById('fullTfaCode');
  
  codeDigits.forEach((input, index) => {
    input.addEventListener('input', function() {
      if (this.value.length === 1) {
        // Move to next input
        if (index < codeDigits.length - 1) {
          codeDigits[index + 1].focus();
        }
      }
      updateFullCode();
    });
    
    input.addEventListener('keydown', function(e) {
      if (e.key === 'Backspace' && this.value === '' && index > 0) {
        codeDigits[index - 1].focus();
      }
    });
    
    // Paste handling
    input.addEventListener('paste', function(e) {
      e.preventDefault();
      const pasteData = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
      
      pasteData.split('').forEach((char, i) => {
        if (codeDigits[i]) {
          codeDigits[i].value = char;
        }
      });
      
      updateFullCode();
      
      // Focus last filled input or submit button
      const lastFilled = Math.min(pasteData.length, 5);
      if (lastFilled < 5) {
        codeDigits[lastFilled].focus();
      } else {
        document.getElementById('verifyTfaBtn').focus();
      }
    });
  });
  
  function updateFullCode() {
    const code = Array.from(codeDigits).map(input => input.value).join('');
    fullCodeInput.value = code;
  }
  
  // Copy backup codes
  const copyCodesBtn = document.getElementById('copyCodesBtn');
  if (copyCodesBtn) {
    copyCodesBtn.addEventListener('click', () => {
      const codes = Array.from(document.querySelectorAll('.mineless-backup-code'))
        .map(code => code.textContent)
        .join('\n');
      
      navigator.clipboard.writeText(codes).then(() => {
        copyCodesBtn.innerHTML = '<span class="mineless-icon adv-icon-check"></span> {$LANGUAGE->get("general", "copied")}';
        setTimeout(() => {
          copyCodesBtn.innerHTML = '<span class="mineless-icon adv-icon-copy"></span> {$LANGUAGE->get("general", "copy_all")}';
        }, 2000);
      });
    });
  }
  
  // Password toggle
  document.querySelectorAll('.mineless-password-toggle').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = this.previousElementSibling;
      const icon = this.querySelector('.mineless-icon');
      
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('adv-icon-eye');
        icon.classList.add('adv-icon-eye-off');
      } else {
        input.type = 'password';
        icon.classList.remove('adv-icon-eye-off');
        icon.classList.add('adv-icon-eye');
      }
    });
  });
  
  // Alert dismissal
  document.querySelectorAll('.mineless-alert-close').forEach(btn => {
    btn.addEventListener('click', function() {
      this.closest('.mineless-alert').remove();
    });
  });
</script>

{include file='footer.tpl'}
