{* 
 * File: user/sessions.tpl
 * Deskripsi: Daftar active sessions dengan device info dan revoke
 * Template: Mineless
 *}

{include file='header.tpl'}

<div class="mineless-user-panel">
  <!-- Particle Background -->
  <div id="particles-sessions" class="mineless-particles"></div>
  
  <div class="mineless-container">
    <div class="mineless-panel-grid">
      
      {include file='user/navigation.tpl'}
      
      <!-- Main Content -->
      <main class="mineless-panel-main">
        <div class="mineless-panel-header">
          <h1 class="mineless-panel-title">
            <span class="mineless-icon adv-icon-devices"></span>
            {$LANGUAGE->get('user', 'active_sessions')}
          </h1>
          <p class="mineless-panel-subtitle">{$LANGUAGE->get('user', 'manage_sessions')}</p>
        </div>
        
        <!-- Success Message -->
        {if isset($SUCCESS)}
          <div class="mineless-alert adv-alert-success adv-alert-dismissible adv-fade-in">
            <span class="mineless-icon adv-icon-check-circle"></span>
            <span>{$SUCCESS}</span>
            <button type="button" class="mineless-alert-close">
              <span class="mineless-icon adv-icon-close"></span>
            </button>
          </div>
        {/if}
        
        <!-- Global Actions -->
        <div class="mineless-card adv-sessions-actions">
          <div class="mineless-sessions-info">
            <span class="mineless-sessions-count">
              <span class="mineless-icon adv-icon-info"></span>
              {if isset($SESSIONS) && is_array($SESSIONS)}{$SESSIONS|count}{else}0{/if} {$LANGUAGE->get('user', 'active_sessions_found')}
            </span>
          </div>
          {if isset($SESSIONS) && is_array($SESSIONS) && count($SESSIONS) > 1}
            <form action="{$REVOKE_ALL_OTHERS_URL}" method="post" class="mineless-revoke-all-form">
              <input type="hidden" name="token" value="{$TOKEN}">
              <button type="submit" class="mineless-btn adv-btn-danger" 
                      onclick="return confirm('{$LANGUAGE->get('user', 'confirm_revoke_all')}')">
                <span class="mineless-icon adv-icon-logout"></span>
                {$LANGUAGE->get('user', 'logout_all_other_sessions')}
              </button>
            </form>
          {/if}
        </div>
        
        <!-- Sessions List -->
        <div class="mineless-sessions-list">
          {foreach from=$SESSIONS item=session}
            <div class="mineless-session-card {if $session.current}adv-session-current{/if}">
              
              <!-- Device Icon -->
              <div class="mineless-session-device">
                {if $session.device_type == 'mobile'}
                  <span class="mineless-device-icon adv-icon-mobile" title="Mobile Device"></span>
                {elseif $session.device_type == 'tablet'}
                  <span class="mineless-device-icon adv-icon-tablet" title="Tablet Device"></span>
                {else}
                  <span class="mineless-device-icon adv-icon-desktop" title="Desktop"></span>
                {/if}
              </div>
              
              <!-- Session Details -->
              <div class="mineless-session-details">
                <div class="mineless-session-header">
                  <h4 class="mineless-session-browser">
                    {$session.browser}
                    {if $session.current}
                      <span class="mineless-badge adv-badge-success">
                        <span class="mineless-icon adv-icon-check"></span>
                        {$LANGUAGE->get('user', 'this_session')}
                      </span>
                    {/if}
                  </h4>
                  <span class="mineless-session-os">{$session.os}</span>
                </div>
                
                <div class="mineless-session-meta">
                  <div class="mineless-session-info">
                    <span class="mineless-session-ip">
                      <span class="mineless-icon adv-icon-globe"></span>
                      {$session.ip_address}
                    </span>
                    {if $session.location}
                      <span class="mineless-session-location">
                        <span class="mineless-icon adv-icon-location"></span>
                        {$session.location}
                      </span>
                    {/if}
                  </div>
                  <div class="mineless-session-activity">
                    <span class="mineless-session-last-active">
                      <span class="mineless-icon adv-icon-clock"></span>
                      {if $session.current}
                        {$LANGUAGE->get('user', 'active_now')}
                      {else}
                        {$LANGUAGE->get('user', 'last_active')} {$session.last_active|date_format:"%d %b %Y, %H:%M"}
                      {/if}
                    </span>
                  </div>
                </div>
              </div>
              
              <!-- Actions -->
              <div class="mineless-session-actions">
                {if !$session.current}
                  <button type="button" class="mineless-btn adv-btn-danger adv-btn-sm adv-revoke-btn"
                          data-session-id="{$session.id}"
                          data-session-browser="{$session.browser}"
                          data-session-os="{$session.os}">
                    <span class="mineless-icon adv-icon-trash"></span>
                    {$LANGUAGE->get('user', 'revoke')}
                  </button>
                {else}
                  <span class="mineless-session-current-badge">
                    <span class="mineless-pulse-dot"></span>
                    {$LANGUAGE->get('user', 'current')}
                  </span>
                {/if}
              </div>
              
            </div>
          {foreachelse}
            <div class="mineless-empty-state">
              <div class="mineless-empty-icon">
                <span class="mineless-icon adv-icon-devices-off"></span>
              </div>
              <h3>{$LANGUAGE->get('user', 'no_sessions')}</h3>
              <p>{$LANGUAGE->get('user', 'no_sessions_desc')}</p>
            </div>
          {/foreach}
        </div>
        
        <!-- Security Tips -->
        <div class="mineless-card adv-security-tips">
          <h4 class="mineless-tips-title">
            <span class="mineless-icon adv-icon-shield"></span>
            {$LANGUAGE->get('user', 'security_tips')}
          </h4>
          <ul class="mineless-tips-list">
            <li>{$LANGUAGE->get('user', 'session_tip_1')}</li>
            <li>{$LANGUAGE->get('user', 'session_tip_2')}</li>
            <li>{$LANGUAGE->get('user', 'session_tip_3')}</li>
            <li>{$LANGUAGE->get('user', 'session_tip_4')}</li>
          </ul>
        </div>
        
      </main>
      
    </div>
  </div>
</div>

<!-- Revoke Confirmation Modal -->
<div class="mineless-modal" id="revokeModal">
  <div class="mineless-modal-backdrop"></div>
  <div class="mineless-modal-dialog">
    <div class="mineless-modal-content">
      <div class="mineless-modal-header adv-modal-danger">
        <h3 class="mineless-modal-title">
          <span class="mineless-icon adv-icon-warning"></span>
          {$LANGUAGE->get('user', 'confirm_revoke_session')}
        </h3>
        <button type="button" class="mineless-modal-close" data-dismiss="modal">
          <span class="mineless-icon adv-icon-close"></span>
        </button>
      </div>
      <div class="mineless-modal-body">
        <div class="mineless-revoke-confirm">
          <div class="mineless-revoke-device-icon">
            <span class="mineless-icon adv-icon-device"></span>
          </div>
          <p class="mineless-revoke-text">
            {$LANGUAGE->get('user', 'revoke_session_desc')}<br>
            <strong id="revokeDeviceName">Browser on OS</strong>
          </p>
          <p class="mineless-revoke-warning">
            <span class="mineless-icon adv-icon-alert-triangle"></span>
            {$LANGUAGE->get('user', 'revoke_warning')}
          </p>
        </div>
      </div>
      <div class="mineless-modal-footer">
        <button type="button" class="mineless-btn adv-btn-outline" data-dismiss="modal">
          {$LANGUAGE->get('general', 'cancel')}
        </button>
        <form action="" method="post" id="revokeForm">
          <input type="hidden" name="token" value="{$TOKEN}">
          <input type="hidden" name="session_id" id="revokeSessionId" value="">
          <button type="submit" class="mineless-btn adv-btn-danger">
            <span class="mineless-icon adv-icon-trash"></span>
            {$LANGUAGE->get('user', 'revoke_session')}
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
  // Revoke modal handling
  const revokeModal = document.getElementById('revokeModal');
  const revokeForm = document.getElementById('revokeForm');
  const revokeSessionId = document.getElementById('revokeSessionId');
  const revokeDeviceName = document.getElementById('revokeDeviceName');
  
  document.querySelectorAll('.mineless-revoke-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const sessionId = this.dataset.sessionId;
      const browser = this.dataset.sessionBrowser;
      const os = this.dataset.sessionOs;
      
      revokeSessionId.value = sessionId;
      revokeDeviceName.textContent = `${browser} on ${os}`;
      revokeForm.action = `{$REVOKE_SESSION_URL}?id=${sessionId}`;
      
      revokeModal.classList.add('show');
    });
  });
  
  // Close modal handlers
  revokeModal.querySelectorAll('[data-dismiss="modal"]').forEach(el => {
    el.addEventListener('click', () => revokeModal.classList.remove('show'));
  });
  revokeModal.querySelector('.mineless-modal-backdrop').addEventListener('click', () => {
    revokeModal.classList.remove('show');
  });
  
  // Alert dismissal
  document.querySelectorAll('.mineless-alert-close').forEach(btn => {
    btn.addEventListener('click', function() {
      this.closest('.mineless-alert').classList.add('adv-fade-out');
      setTimeout(() => this.closest('.mineless-alert').remove(), 300);
    });
  });
</script>

{include file='footer.tpl'}
