{* 
 * File: user/notification_settings.tpl
 * Deskripsi: Preferensi notifikasi dengan toggle switches
 * Template: Mineless
 *}

{include file='header.tpl'}

<div class="mineless-user-panel">
  <!-- Particle Background -->
  <div id="particles-notif-settings" class="mineless-particles"></div>
  
  <div class="mineless-container">
    <div class="mineless-panel-grid">
      
      {include file='user/navigation.tpl'}
      
      <!-- Main Content -->
      <main class="mineless-panel-main">
        <div class="mineless-panel-header">
          <h1 class="mineless-panel-title">
            <span class="mineless-icon adv-icon-bell-cog"></span>
            {$LANGUAGE->get('user', 'notification_settings')}
          </h1>
          <p class="mineless-panel-subtitle">{$LANGUAGE->get('user', 'customize_notifications')}</p>
        </div>
        
        <!-- Success Message -->
        <div class="mineless-alert adv-alert-success adv-alert-dismissible" id="saveSuccess" style="display: none;">
          <span class="mineless-icon adv-icon-check-circle"></span>
          <span>{$LANGUAGE->get('user', 'settings_saved')}</span>
          <button type="button" class="mineless-alert-close">
            <span class="mineless-icon adv-icon-close"></span>
          </button>
        </div>
        
        <form action="{$NOTIFICATION_SETTINGS_URL}" method="post" class="mineless-notification-form" id="notificationForm">
          <input type="hidden" name="token" value="{$TOKEN}">
          
          <!-- Forum Notifications -->
          <div class="mineless-card adv-notif-section">
            <div class="mineless-notif-header">
              <div class="mineless-notif-icon adv-notif-forum">
                <span class="mineless-icon adv-icon-forum"></span>
              </div>
              <div class="mineless-notif-title">
                <h3>{$LANGUAGE->get('user', 'forum_notifications')}</h3>
                <p>{$LANGUAGE->get('user', 'forum_notif_desc')}</p>
              </div>
            </div>
            
            <div class="mineless-notif-list">
              
              <!-- Forum Reply -->
              <div class="mineless-notif-item">
                <div class="mineless-notif-info">
                  <span class="mineless-notif-name">{$LANGUAGE->get('user', 'forum_reply')}</span>
                  <span class="mineless-notif-desc">{$LANGUAGE->get('user', 'forum_reply_desc')}</span>
                </div>
                <div class="mineless-notif-toggles">
                  <label class="mineless-toggle">
                    <input type="checkbox" name="forum_reply_email" 
                           {if $SETTINGS.forum_reply_email}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-email"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'email')}</span>
                  </label>
                  <label class="mineless-toggle">
                    <input type="checkbox" name="forum_reply_web" 
                           {if $SETTINGS.forum_reply_web}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-web"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'web')}</span>
                  </label>
                </div>
              </div>
              
              <!-- Mention -->
              <div class="mineless-notif-item">
                <div class="mineless-notif-info">
                  <span class="mineless-notif-name">{$LANGUAGE->get('user', 'mention')}</span>
                  <span class="mineless-notif-desc">{$LANGUAGE->get('user', 'mention_desc')}</span>
                </div>
                <div class="mineless-notif-toggles">
                  <label class="mineless-toggle">
                    <input type="checkbox" name="mention_email" 
                           {if $SETTINGS.mention_email}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-email"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'email')}</span>
                  </label>
                  <label class="mineless-toggle">
                    <input type="checkbox" name="mention_web" 
                           {if $SETTINGS.mention_web}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-web"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'web')}</span>
                  </label>
                </div>
              </div>
              
              <!-- Topic Subscription -->
              <div class="mineless-notif-item">
                <div class="mineless-notif-info">
                  <span class="mineless-notif-name">{$LANGUAGE->get('user', 'topic_subscription')}</span>
                  <span class="mineless-notif-desc">{$LANGUAGE->get('user', 'topic_subscription_desc')}</span>
                </div>
                <div class="mineless-notif-toggles">
                  <label class="mineless-toggle">
                    <input type="checkbox" name="topic_subscription_email" 
                           {if $SETTINGS.topic_subscription_email}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-email"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'email')}</span>
                  </label>
                  <label class="mineless-toggle">
                    <input type="checkbox" name="topic_subscription_web" 
                           {if $SETTINGS.topic_subscription_web}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-web"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'web')}</span>
                  </label>
                </div>
              </div>
              
            </div>
          </div>
          
          <!-- Message Notifications -->
          <div class="mineless-card adv-notif-section">
            <div class="mineless-notif-header">
              <div class="mineless-notif-icon adv-notif-messages">
                <span class="mineless-icon adv-icon-messages"></span>
              </div>
              <div class="mineless-notif-title">
                <h3>{$LANGUAGE->get('user', 'message_notifications')}</h3>
                <p>{$LANGUAGE->get('user', 'message_notif_desc')}</p>
              </div>
            </div>
            
            <div class="mineless-notif-list">
              
              <!-- Private Message -->
              <div class="mineless-notif-item">
                <div class="mineless-notif-info">
                  <span class="mineless-notif-name">{$LANGUAGE->get('user', 'private_message')}</span>
                  <span class="mineless-notif-desc">{$LANGUAGE->get('user', 'private_message_desc')}</span>
                </div>
                <div class="mineless-notif-toggles">
                  <label class="mineless-toggle">
                    <input type="checkbox" name="pm_email" 
                           {if $SETTINGS.pm_email}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-email"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'email')}</span>
                  </label>
                  <label class="mineless-toggle">
                    <input type="checkbox" name="pm_web" 
                           {if $SETTINGS.pm_web}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-web"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'web')}</span>
                  </label>
                </div>
              </div>
              
            </div>
          </div>
          
          <!-- Profile Notifications -->
          <div class="mineless-card adv-notif-section">
            <div class="mineless-notif-header">
              <div class="mineless-notif-icon adv-notif-profile">
                <span class="mineless-icon adv-icon-user-circle"></span>
              </div>
              <div class="mineless-notif-title">
                <h3>{$LANGUAGE->get('user', 'profile_notifications')}</h3>
                <p>{$LANGUAGE->get('user', 'profile_notif_desc')}</p>
              </div>
            </div>
            
            <div class="mineless-notif-list">
              
              <!-- Profile Post -->
              <div class="mineless-notif-item">
                <div class="mineless-notif-info">
                  <span class="mineless-notif-name">{$LANGUAGE->get('user', 'profile_post')}</span>
                  <span class="mineless-notif-desc">{$LANGUAGE->get('user', 'profile_post_desc')}</span>
                </div>
                <div class="mineless-notif-toggles">
                  <label class="mineless-toggle">
                    <input type="checkbox" name="profile_post_email" 
                           {if $SETTINGS.profile_post_email}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-email"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'email')}</span>
                  </label>
                  <label class="mineless-toggle">
                    <input type="checkbox" name="profile_post_web" 
                           {if $SETTINGS.profile_post_web}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-web"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'web')}</span>
                  </label>
                </div>
              </div>
              
              <!-- Profile Like -->
              <div class="mineless-notif-item">
                <div class="mineless-notif-info">
                  <span class="mineless-notif-name">{$LANGUAGE->get('user', 'profile_like')}</span>
                  <span class="mineless-notif-desc">{$LANGUAGE->get('user', 'profile_like_desc')}</span>
                </div>
                <div class="mineless-notif-toggles">
                  <label class="mineless-toggle">
                    <input type="checkbox" name="profile_like_email" 
                           {if $SETTINGS.profile_like_email}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-email"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'email')}</span>
                  </label>
                  <label class="mineless-toggle">
                    <input type="checkbox" name="profile_like_web" 
                           {if $SETTINGS.profile_like_web}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-web"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'web')}</span>
                  </label>
                </div>
              </div>
              
            </div>
          </div>
          
          <!-- System Notifications -->
          <div class="mineless-card adv-notif-section">
            <div class="mineless-notif-header">
              <div class="mineless-notif-icon adv-notif-system">
                <span class="mineless-icon adv-icon-cog"></span>
              </div>
              <div class="mineless-notif-title">
                <h3>{$LANGUAGE->get('user', 'system_notifications')}</h3>
                <p>{$LANGUAGE->get('user', 'system_notif_desc')}</p>
              </div>
            </div>
            
            <div class="mineless-notif-list">
              
              <!-- Staff Application -->
              <div class="mineless-notif-item">
                <div class="mineless-notif-info">
                  <span class="mineless-notif-name">{$LANGUAGE->get('user', 'staff_application')}</span>
                  <span class="mineless-notif-desc">{$LANGUAGE->get('user', 'staff_application_desc')}</span>
                </div>
                <div class="mineless-notif-toggles">
                  <label class="mineless-toggle">
                    <input type="checkbox" name="staff_app_email" 
                           {if $SETTINGS.staff_app_email}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-email"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'email')}</span>
                  </label>
                  <label class="mineless-toggle">
                    <input type="checkbox" name="staff_app_web" 
                           {if $SETTINGS.staff_app_web}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-web"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'web')}</span>
                  </label>
                </div>
              </div>
              
              <!-- Ban Appeal -->
              <div class="mineless-notif-item">
                <div class="mineless-notif-info">
                  <span class="mineless-notif-name">{$LANGUAGE->get('user', 'ban_appeal')}</span>
                  <span class="mineless-notif-desc">{$LANGUAGE->get('user', 'ban_appeal_desc')}</span>
                </div>
                <div class="mineless-notif-toggles">
                  <label class="mineless-toggle">
                    <input type="checkbox" name="ban_appeal_email" 
                           {if $SETTINGS.ban_appeal_email}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-email"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'email')}</span>
                  </label>
                  <label class="mineless-toggle">
                    <input type="checkbox" name="ban_appeal_web" 
                           {if $SETTINGS.ban_appeal_web}checked{/if}>
                    <span class="mineless-toggle-slider">
                      <span class="mineless-toggle-icon adv-icon-web"></span>
                    </span>
                    <span class="mineless-toggle-label">{$LANGUAGE->get('general', 'web')}</span>
                  </label>
                </div>
              </div>
              
            </div>
          </div>
          
          <!-- Master Toggles -->
          <div class="mineless-card adv-master-toggles">
            <h4 class="mineless-master-title">
              <span class="mineless-icon advicon-sliders"></span>
              {$LANGUAGE->get('user', 'quick_settings')}
            </h4>
            <div class="mineless-master-actions">
              <button type="button" class="mineless-btn adv-btn-sm adv-btn-secondary" id="enableAllEmail">
                {$LANGUAGE->get('user', 'enable_all_email')}
              </button>
              <button type="button" class="mineless-btn adv-btn-sm adv-btn-secondary" id="enableAllWeb">
                {$LANGUAGE->get('user', 'enable_all_web')}
              </button>
              <button type="button" class="mineless-btn adv-btn-sm adv-btn-outline" id="disableAll">
                {$LANGUAGE->get('user', 'disable_all')}
              </button>
            </div>
          </div>
          
          <!-- Form Actions -->
          <div class="mineless-form-actions adv-sticky-actions">
            <button type="submit" class="mineless-btn adv-btn-primary adv-btn-lg" id="saveBtn">
              <span class="mineless-btn-content">
                <span class="mineless-icon adv-icon-save"></span>
                {$LANGUAGE->get('general', 'save_changes')}
              </span>
              <span class="mineless-btn-loading">
                <span class="mineless-spinner adv-spinner-sm"></span>
                {$LANGUAGE->get('general', 'saving')}...
              </span>
            </button>
          </div>
          
        </form>
        
      </main>
      
    </div>
  </div>
</div>

<script>
  const form = document.getElementById('notificationForm');
  const saveBtn = document.getElementById('saveBtn');
  const saveSuccess = document.getElementById('saveSuccess');
  
  // AJAX form submission
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    
    saveBtn.classList.add('adv-btn-loading-active');
    saveBtn.disabled = true;
    
    const formData = new FormData(form);
    
    fetch(form.action, {
      method: 'POST',
      body: formData,
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      }
    })
    .then(response => response.json())
    .then(data => {
      saveBtn.classList.remove('adv-btn-loading-active');
      saveBtn.disabled = false;
      
      if (data.success) {
        saveSuccess.style.display = 'flex';
        saveSuccess.classList.add('adv-fade-in');
        
        setTimeout(() => {
          saveSuccess.style.display = 'none';
        }, 5000);
      }
    })
    .catch(error => {
      saveBtn.classList.remove('adv-btn-loading-active');
      saveBtn.disabled = false;
      console.error('Error:', error);
    });
  });
  
  // Master toggle buttons
  document.getElementById('enableAllEmail').addEventListener('click', () => {
    document.querySelectorAll('input[name$="_email"]').forEach(cb => {
      cb.checked = true;
      animateToggle(cb);
    });
  });
  
  document.getElementById('enableAllWeb').addEventListener('click', () => {
    document.querySelectorAll('input[name$="_web"]').forEach(cb => {
      cb.checked = true;
      animateToggle(cb);
    });
  });
  
  document.getElementById('disableAll').addEventListener('click', () => {
    document.querySelectorAll('input[type="checkbox"]').forEach(cb => {
      cb.checked = false;
      animateToggle(cb);
    });
  });
  
  function animateToggle(checkbox) {
    const slider = checkbox.nextElementSibling;
    slider.style.transform = 'scale(0.95)';
    setTimeout(() => {
      slider.style.transform = 'scale(1)';
    }, 150);
  }
  
  // Toggle animation enhancement
  document.querySelectorAll('.mineless-toggle input').forEach(toggle => {
    toggle.addEventListener('change', function() {
      const slider = this.nextElementSibling;
      slider.style.animation = 'none';
      slider.offsetHeight; // Trigger reflow
      slider.style.animation = 'togglePulse 300ms ease';
    });
  });
  
  // Alert dismissal
  document.querySelectorAll('.mineless-alert-close').forEach(btn => {
    btn.addEventListener('click', function() {
      this.closest('.mineless-alert').style.display = 'none';
    });
  });
</script>

{include file='footer.tpl'}
