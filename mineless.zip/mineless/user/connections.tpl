{* 
 * File: user/connections.tpl
 * Deskripsi: Halaman manage connected accounts (Discord, Steam, Minecraft)
 * Template: Mineless
 *}

{include file='header.tpl'}

<div class="mineless-user-panel">
  <!-- Particle Background -->
  <div id="particles-connections" class="mineless-particles"></div>
  
  <div class="mineless-container">
    <div class="mineless-panel-grid">
      
      {include file='user/navigation.tpl'}
      
      <!-- Main Content -->
      <main class="mineless-panel-main">
        <div class="mineless-panel-header">
          <h1 class="mineless-panel-title">
            <span class="mineless-icon adv-icon-link"></span>
            {$LANGUAGE->get('user', 'connected_accounts')}
          </h1>
          <p class="mineless-panel-subtitle">{$LANGUAGE->get('user', 'manage_connections')}</p>
        </div>
        
        <!-- Success Message -->
        {if isset($SUCCESS)}
          <div class="mineless-alert adv-alert-success adv-alert-dismissible adv-fade-in">
            <span class="mineless-icon adv-icon-check-circle"></span>
            <span>{$SUCCESS}</span>
            <button type="button" class="mineless-alert-close">
              <span class="mineless-icon adv-icon-close"></span>
            </button>
          </div>
        {/if}
        
        <!-- Error Message -->
        {if isset($ERROR)}
          <div class="mineless-alert adv-alert-error adv-alert-dismissible adv-fade-in">
            <span class="mineless-icon adv-icon-error"></span>
            <span>{$ERROR}</span>
            <button type="button" class="mineless-alert-close">
              <span class="mineless-icon adv-icon-close"></span>
            </button>
          </div>
        {/if}
        
        <!-- Connections Grid -->
        <div class="mineless-connections-grid">
          
          <!-- Discord Connection -->
          <div class="mineless-connection-card {if $DISCORD_CONNECTED}adv-connected{/if}" id="discordCard">
            <div class="mineless-connection-header">
              <div class="mineless-connection-icon adv-discord-icon">
                <svg viewBox="0 0 24 24" class="mineless-svg-icon">
                  <path fill="currentColor" d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286z"/>
                </svg>
              </div>
              <div class="mineless-connection-info">
                <h3 class="mineless-connection-name">Discord</h3>
                <span class="mineless-connection-status {if $DISCORD_CONNECTED}adv-status-connected{else}adv-status-disconnected{/if}">
                  <span class="mineless-status-dot"></span>
                  {if $DISCORD_CONNECTED}
                    {$LANGUAGE->get('user', 'connected')}
                  {else}
                    {$LANGUAGE->get('user', 'not_connected')}
                  {/if}
                </span>
              </div>
            </div>
            
            {if $DISCORD_CONNECTED}
              <div class="mineless-connection-body">
                <div class="mineless-discord-profile">
                  <div class="mineless-discord-avatar">
                    <img src="https://cdn.discordapp.com/avatars/{$DISCORD_USER_ID}/{$DISCORD_AVATAR_HASH}.png?size=128" 
                         alt="Discord Avatar" 
                         onerror="this.src='{$TEMPLATE_URL}/assets/img/discord-default.png'">
                    <div class="mineless-discord-status adv-status-{$DISCORD_STATUS}"></div>
                  </div>
                  <div class="mineless-discord-details">
                    <span class="mineless-discord-username">{$DISCORD_USERNAME}</span>
                    <span class="mineless-discord-id">ID: {$DISCORD_USER_ID}</span>
                  </div>
                </div>
              </div>
              <div class="mineless-connection-footer">
                <form action="{$DISCORD_UNLINK_URL}" method="post" class="mineless-connection-form">
                  <input type="hidden" name="token" value="{$TOKEN}">
                  <button type="submit" class="mineless-btn adv-btn-danger adv-btn-sm" 
                          onclick="return confirm('{$LANGUAGE->get('user', 'confirm_disconnect_discord')}')">
                    <span class="mineless-icon adv-icon-unlink"></span>
                    {$LANGUAGE->get('user', 'disconnect')}
                  </button>
                </form>
              </div>
            {else}
              <div class="mineless-connection-body">
                <p class="mineless-connection-desc">
                  {$LANGUAGE->get('user', 'discord_connect_desc')}
                </p>
                <ul class="mineless-connection-benefits">
                  <li>{$LANGUAGE->get('user', 'discord_benefit_1')}</li>
                  <li>{$LANGUAGE->get('user', 'discord_benefit_2')}</li>
                  <li>{$LANGUAGE->get('user', 'discord_benefit_3')}</li>
                </ul>
              </div>
              <div class="mineless-connection-footer">
                <a href="{$DISCORD_LINK_URL}" class="mineless-btn adv-btn-discord">
                  <span class="mineless-icon adv-icon-link"></span>
                  {$LANGUAGE->get('user', 'connect_discord')}
                </a>
              </div>
            {/if}
          </div>
          
          <!-- Steam Connection -->
          <div class="mineless-connection-card {if $STEAM_CONNECTED}adv-connected{/if}" id="steamCard">
            <div class="mineless-connection-header">
              <div class="mineless-connection-icon adv-steam-icon">
                <svg viewBox="0 0 24 24" class="mineless-svg-icon">
                  <path fill="currentColor" d="M11.979 0C5.359 0 0 5.36 0 11.979c0 2.66.87 5.12 2.343 7.114l.005.006c-.005.003-.01.01-.015.015l-2.02 7.58c-.074.26.255.397.386.215l3.66-4.97c1.62 1.41 3.738 2.27 6.053 2.27 6.62 0 11.978-5.36 11.978-11.98C23.978 5.38 18.62.02 11.98.02zm0 22.42c-1.95 0-3.75-.61-5.243-1.64l.269-.37 3.31-4.5c.52.25 1.11.39 1.735.39 2.54 0 4.597-2.06 4.597-4.6s-2.057-4.6-4.597-4.6c-2.53 0-4.59 2.06-4.59 4.6 0 .73.17 1.42.48 2.03l-4.34 5.89C1.49 17.39.76 14.77.76 11.98.76 5.78 5.78.76 11.98.76s11.22 5.02 11.22 11.22c0 6.2-5.02 11.22-11.22 11.22z"/>
                </svg>
              </div>
              <div class="mineless-connection-info">
                <h3 class="mineless-connection-name">Steam</h3>
                <span class="mineless-connection-status {if $STEAM_CONNECTED}adv-status-connected{else}adv-status-disconnected{/if}">
                  <span class="mineless-status-dot"></span>
                  {if $STEAM_CONNECTED}
                    {$LANGUAGE->get('user', 'connected')}
                  {else}
                    {$LANGUAGE->get('user', 'not_connected')}
                  {/if}
                </span>
              </div>
            </div>
            
            {if $STEAM_CONNECTED}
              <div class="mineless-connection-body">
                <div class="mineless-steam-profile">
                  <div class="mineless-steam-avatar">
                    <img src="{$STEAM_AVATAR}" alt="Steam Avatar">
                  </div>
                  <div class="mineless-steam-details">
                    <span class="mineless-steam-username">{$STEAM_USERNAME}</span>
                    <span class="mineless-steam-id">{$STEAM_ID_64}</span>
                  </div>
                </div>
              </div>
              <div class="mineless-connection-footer">
                <form action="{$STEAM_UNLINK_URL}" method="post" class="mineless-connection-form">
                  <input type="hidden" name="token" value="{$TOKEN}">
                  <button type="submit" class="mineless-btn adv-btn-danger adv-btn-sm"
                          onclick="return confirm('{$LANGUAGE->get('user', 'confirm_disconnect_steam')}')">
                    <span class="mineless-icon adv-icon-unlink"></span>
                    {$LANGUAGE->get('user', 'disconnect')}
                  </button>
                </form>
              </div>
            {else}
              <div class="mineless-connection-body">
                <p class="mineless-connection-desc">
                  {$LANGUAGE->get('user', 'steam_connect_desc')}
                </p>
                <ul class="mineless-connection-benefits">
                  <li>{$LANGUAGE->get('user', 'steam_benefit_1')}</li>
                  <li>{$LANGUAGE->get('user', 'steam_benefit_2')}</li>
                  <li>{$LANGUAGE->get('user', 'steam_benefit_3')}</li>
                </ul>
              </div>
              <div class="mineless-connection-footer">
                <a href="{$STEAM_LINK_URL}" class="mineless-btn adv-btn-steam">
                  <span class="mineless-icon adv-icon-link"></span>
                  {$LANGUAGE->get('user', 'connect_steam')}
                </a>
              </div>
            {/if}
          </div>
          
          <!-- Minecraft Connection -->
          <div class="mineless-connection-card {if $MINECRAFT_CONNECTED}adv-connected{/if}" id="minecraftCard">
            <div class="mineless-connection-header">
              <div class="mineless-connection-icon adv-minecraft-icon">
                <svg viewBox="0 0 24 24" class="mineless-svg-icon">
                  <path fill="currentColor" d="M4 2h16a2 2 0 012 2v16a2 2 0 01-2 2H4a2 2 0 01-2-2V4a2 2 0 012-2zm2 4v12h12V6H6zm2 2h2v2H8V8zm4 0h2v2h-2V8zm4 0h2v2h-2V8zM8 12h2v2H8v-2zm4 0h2v2h-2v-2zm4 0h2v2h-2v-2zM8 16h2v2H8v-2zm4 0h2v2h-2v-2zm4 0h2v2h-2v-2z"/>
                </svg>
              </div>
              <div class="mineless-connection-info">
                <h3 class="mineless-connection-name">Minecraft</h3>
                <span class="mineless-connection-status {if $MINECRAFT_CONNECTED}adv-status-connected{else}adv-status-disconnected{/if}">
                  <span class="mineless-status-dot"></span>
                  {if $MINECRAFT_CONNECTED}
                    {$LANGUAGE->get('user', 'linked')}
                  {else}
                    {$LANGUAGE->get('user', 'not_linked')}
                  {/if}
                </span>
              </div>
            </div>
            
            {if $MINECRAFT_CONNECTED}
              <div class="mineless-connection-body">
                <div class="mineless-minecraft-profile">
                  <div class="mineless-minecraft-avatar">
                    <img src="https://crafatar.com/avatars/{$MINECRAFT_UUID}?size=128&overlay" 
                         alt="{$MINECRAFT_USERNAME}">
                  </div>
                  <div class="mineless-minecraft-details">
                    <span class="mineless-minecraft-username">{$MINECRAFT_USERNAME}</span>
                    <span class="mineless-minecraft-uuid">{$MINECRAFT_UUID}</span>
                  </div>
                </div>
              </div>
              <div class="mineless-connection-footer">
                <form action="{$MINECRAFT_UNLINK_URL}" method="post" class="mineless-connection-form">
                  <input type="hidden" name="token" value="{$TOKEN}">
                  <button type="submit" class="mineless-btn adv-btn-danger adv-btn-sm"
                          onclick="return confirm('{$LANGUAGE->get('user', 'confirm_unlink_minecraft')}')">
                    <span class="mineless-icon adv-icon-unlink"></span>
                    {$LANGUAGE->get('user', 'unlink')}
                  </button>
                </form>
              </div>
            {else}
              <div class="mineless-connection-body">
                <p class="mineless-connection-desc">
                  {$LANGUAGE->get('user', 'minecraft_link_desc')}
                </p>
                <form action="{$MINECRAFT_LINK_URL}" method="post" class="mineless-minecraft-form">
                  <input type="hidden" name="token" value="{$TOKEN}">
                  <div class="mineless-form-group">
                    <label class="mineless-form-label">{$LANGUAGE->get('user', 'minecraft_username')}</label>
                    <input type="text" name="mc_username" class="mineless-input" 
                           placeholder="{$LANGUAGE->get('user', 'enter_mc_username')}" required>
                  </div>
                  <button type="submit" class="mineless-btn adv-btn-minecraft adv-btn-block">
                    <span class="mineless-icon adv-icon-link"></span>
                    {$LANGUAGE->get('user', 'verify_and_link')}
                  </button>
                </form>
              </div>
            {/if}
          </div>
          
        </div>
        
        <!-- Security Info -->
        <div class="mineless-card adv-security-info">
          <div class="mineless-security-icon">
            <span class="mineless-icon adv-icon-shield-check"></span>
          </div>
          <div class="mineless-security-content">
            <h4>{$LANGUAGE->get('user', 'connection_security')}</h4>
            <p>{$LANGUAGE->get('user', 'connection_security_desc')}</p>
          </div>
        </div>
        
      </main>
      
    </div>
  </div>
</div>

<!-- Success Checkmark Animation -->
<div class="mineless-success-popup" id="successPopup">
  <div class="mineless-checkmark-circle">
    <svg viewBox="0 0 52 52">
      <circle cx="26" cy="26" r="25" fill="none" />
      <path fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8" />
    </svg>
  </div>
  <span class="mineless-success-text">{$LANGUAGE->get('user', 'connected_successfully')}</span>
</div>

<script>
  // Success animation when connection is successful
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has('connected')) {
    const popup = document.getElementById('successPopup');
    const cardId = urlParams.get('connected') + 'Card';
    const card = document.getElementById(cardId);
    
    if (card) {
      // Show popup
      popup.classList.add('show');
      
      // Add pop animation to card
      card.classList.add('adv-pop-animation');
      
      // Remove animation classes after completion
      setTimeout(() => {
        popup.classList.remove('show');
        card.classList.remove('adv-pop-animation');
      }, 3000);
    }
  }
  
  // Alert dismissal
  document.querySelectorAll('.mineless-alert-close').forEach(btn => {
    btn.addEventListener('click', function() {
      this.closest('.mineless-alert').remove();
    });
  });
</script>

{include file='footer.tpl'}
