{* User Navigation Sidebar - Mineless Theme *}
<aside class="mineless-user-sidebar" id="userSidebar">
    <button class="mineless-sidebar-toggle" id="sidebarToggle" aria-label="Toggle Menu">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="mineless-sidebar-overlay" id="sidebarOverlay"></div>
    
    <nav class="mineless-sidebar-nav">
        {* User Profile Header *}
        <div class="mineless-user-header">
            <div class="mineless-user-avatar-wrap">
                <img src="{$AVATAR|default:'https://cravatar.eu/avatar/{$USERNAME}/128.png'}" 
                     alt="{$USERNAME}" 
                     class="mineless-user-avatar-lg"
                     onerror="this.src='https://cravatar.eu/avatar/steve/128.png'">
                <span class="mineless-user-status {if $ONLINE}online{else}offline{/if}"></span>
            </div>
            <div class="mineless-user-info">
                <h3 class="mineless-user-name">{$USERNAME}</h3>
                {if isset($USER_RANK) && $USER_RANK}
                    <span class="mineless-user-rank" style="{if $USER_RANK_COLOR}color: {$USER_RANK_COLOR}; border-color: {$USER_RANK_COLOR};{/if}">
                        {$USER_RANK}
                    </span>
                {/if}
            </div>
        </div>
        
        {* Navigation Menu *}
        <ul class="mineless-nav-menu">
            <li class="mineless-nav-item">
                <a href="{$USER_DASHBOARD_URL|default:'{$smarty.const.URL}/user'}" 
                   class="mineless-nav-link {if $ACTIVE_PAGE == 'dashboard'}active{/if}">
                    <span class="mineless-nav-icon"><i class="fas fa-home"></i></span>
                    <span class="mineless-nav-text">Dashboard</span>
                </a>
            </li>
            
            <li class="mineless-nav-item">
                <a href="{$MESSAGING_URL|default:'{$smarty.const.URL}/user/messaging'}" 
                   class="mineless-nav-link {if $ACTIVE_PAGE == 'messaging'}active{/if}">
                    <span class="mineless-nav-icon"><i class="fas fa-envelope"></i></span>
                    <span class="mineless-nav-text">Messages</span>
                    {if isset($MESSAGES_UNREAD) && $MESSAGES_UNREAD > 0}
                        <span class="mineless-nav-badge">{$MESSAGES_UNREAD}</span>
                    {/if}
                </a>
            </li>
            
            <li class="mineless-nav-item">
                <a href="{$ALERTS_URL|default:'{$smarty.const.URL}/user/alerts'}" 
                   class="mineless-nav-link {if $ACTIVE_PAGE == 'alerts'}active{/if}">
                    <span class="mineless-nav-icon"><i class="fas fa-bell"></i></span>
                    <span class="mineless-nav-text">Alerts</span>
                    {if isset($ALERTS_UNREAD) && $ALERTS_UNREAD > 0}
                        <span class="mineless-nav-badge">{$ALERTS_UNREAD}</span>
                    {/if}
                </a>
            </li>
            
            <li class="mineless-nav-divider"></li>
            
            <li class="mineless-nav-item">
                <a href="{$SETTINGS_URL|default:'{$smarty.const.URL}/user/settings'}" 
                   class="mineless-nav-link {if $ACTIVE_PAGE == 'settings'}active{/if}">
                    <span class="mineless-nav-icon"><i class="fas fa-cog"></i></span>
                    <span class="mineless-nav-text">Settings</span>
                </a>
            </li>
            
            <li class="mineless-nav-item">
                <a href="{$CONNECTIONS_URL|default:'{$smarty.const.URL}/user/connections'}" 
                   class="mineless-nav-link {if $ACTIVE_PAGE == 'connections'}active{/if}">
                    <span class="mineless-nav-icon"><i class="fas fa-link"></i></span>
                    <span class="mineless-nav-text">Connections</span>
                </a>
            </li>
            
            <li class="mineless-nav-item">
                <a href="{$SESSIONS_URL|default:'{$smarty.const.URL}/user/sessions'}" 
                   class="mineless-nav-link {if $ACTIVE_PAGE == 'sessions'}active{/if}">
                    <span class="mineless-nav-icon"><i class="fas fa-shield-alt"></i></span>
                    <span class="mineless-nav-text">Sessions</span>
                </a>
            </li>
            
            <li class="mineless-nav-item">
                <a href="{$TFA_URL|default:'{$smarty.const.URL}/user/tfa'}" 
                   class="mineless-nav-link {if $ACTIVE_PAGE == 'tfa'}active{/if}">
                    <span class="mineless-nav-icon"><i class="fas fa-key"></i></span>
                    <span class="mineless-nav-text">Two-Factor Auth</span>
                </a>
            </li>
            
            <li class="mineless-nav-divider"></li>
            
            <li class="mineless-nav-item">
                <a href="{$PROFILE_URL|default:'{$smarty.const.URL}/profile/{$USERNAME}'}" 
                   class="mineless-nav-link">
                    <span class="mineless-nav-icon"><i class="fas fa-user-circle"></i></span>
                    <span class="mineless-nav-text">Lihat Profil</span>
                    <span class="mineless-nav-arrow"><i class="fas fa-external-link-alt"></i></span>
                </a>
            </li>
        </ul>
    </nav>
</aside>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('userSidebar');
    const toggle = document.getElementById('sidebarToggle');
    const overlay = document.getElementById('sidebarOverlay');
    
    function toggleSidebar() {
        sidebar.classList.toggle('collapsed');
        document.body.classList.toggle('sidebar-open');
    }
    
    if (toggle) {
        toggle.addEventListener('click', toggleSidebar);
    }
    
    if (overlay) {
        overlay.addEventListener('click', toggleSidebar);
    }
    
    // Close sidebar when clicking on a link (mobile)
    const navLinks = sidebar.querySelectorAll('.mineless-nav-link');
    navLinks.forEach(function(link) {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                toggleSidebar();
            }
        });
    });
});
</script>
