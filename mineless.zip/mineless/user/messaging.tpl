{* User Messaging Inbox - Mineless Theme *}
<div class="mineless-user-panel">
    {include file='user/navigation.tpl'}
    
    <main class="mineless-user-main">
        <div class="mineless-messaging">
            {* Page Header *}
            <div class="mineless-page-header">
                <div class="mineless-header-content">
                    <h1><i class="fas fa-envelope"></i> Pesan</h1>
                    <p>Kelola percakapan private message</p>
                </div>
                <div class="mineless-header-actions">
                    <button class="mineless-btn adv-btn-primary" id="newMessageBtn">
                        <i class="fas fa-plus"></i> Pesan Baru
                    </button>
                </div>
            </div>
            
            {* Messaging Container *}
            <div class="mineless-messaging-container">
                {* Conversations List *}
                <div class="mineless-conversations-panel">
                    {* Search *}
                    <div class="mineless-conversations-search">
                        <div class="mineless-search-input-wrap">
                            <i class="fas fa-search"></i>
                            <input type="text" 
                                   class="mineless-form-control" 
                                   id="searchConversations"
                                   placeholder="Cari percakapan...">
                        </div>
                    </div>
                    
                    {* Conversations List *}
                    <div class="mineless-conversations-list" id="conversationsList">
                        {if isset($CONVERSATIONS) && is_array($CONVERSATIONS) && count($CONVERSATIONS) > 0}
                            {foreach from=$CONVERSATIONS item=conversation}
                                <a href="{$conversation.url|default:"{$smarty.const.URL}/user/messaging/?id={$conversation.id}"}" 
                                   class="mineless-conversation-item {if $conversation.unread}unread{/if} {if isset($ACTIVE_CONVERSATION) && $ACTIVE_CONVERSATION == $conversation.id}active{/if}"
                                   data-conversation-id="{$conversation.id}">
                                    
                                    <div class="mineless-conversation-avatar">
                                        <img src="{$conversation.other_user.avatar|default:'https://cravatar.eu/avatar/'|cat:$conversation.other_user.username|cat:'/64.png'}" 
                                             alt="{$conversation.other_user.username}"
                                             onerror="this.src='https://cravatar.eu/avatar/steve/64.png'">
                                        {if $conversation.other_user.online}
                                            <span class="mineless-online-status"></span>
                                        {/if}
                                    </div>
                                    
                                    <div class="mineless-conversation-info">
                                        <div class="mineless-conversation-header">
                                            <h4 class="mineless-conversation-name">{$conversation.other_user.username}</h4>
                                            <span class="mineless-conversation-time" data-timestamp="{$conversation.last_message.time}">
                                                {$conversation.last_message.time_friendly|default:$conversation.last_message.time}
                                            </span>
                                        </div>
                                        <div class="mineless-conversation-preview">
                                            <p class="mineless-conversation-text">
                                                {if $conversation.last_message.from_me}
                                                    <span class="mineless-preview-prefix">Kamu:</span>
                                                {/if}
                                                {$conversation.last_message.preview|truncate:40:"...":true}
                                            </p>
                                            {if $conversation.unread > 0}
                                                <span class="mineless-conversation-badge">{$conversation.unread}</span>
                                            {/if}
                                        </div>
                                    </div>
                                </a>
                            {/foreach}
                        {else}
                            {* Empty State *}
                            <div class="mineless-empty-state">
                                <div class="mineless-empty-icon">
                                    <i class="fas fa-inbox"></i>
                                </div>
                                <p>Belum ada percakapan</p>
                            </div>
                        {/if}
                    </div>
                </div>
                
                {* Conversation Content / Empty State *}
                <div class="mineless-conversation-content">
                    {if isset($ACTIVE_CONVERSATION) && $ACTIVE_CONVERSATION}
                        {* Active conversation will be shown here via view_message.tpl *}
                        <div class="mineless-conversation-placeholder">
                            <i class="fas fa-comments"></i>
                            <h3>Pilih percakapan</h3>
                            <p>Klik salah satu percakapan di sidebar untuk melihat pesan</p>
                        </div>
                    {else}
                        {* Empty State *}
                        <div class="mineless-conversation-empty">
                            <div class="mineless-empty-state adv-empty-large">
                                <div class="mineless-empty-icon adv-animated">
                                    <i class="fas fa-comments"></i>
                                </div>
                                <h3>Belum Ada Percakapan</h3>
                                <p>Mulai percakapan baru dengan mengklik tombol "Pesan Baru" di atas.</p>
                                <button class="mineless-btn adv-btn-primary" onclick="document.getElementById('newMessageBtn').click()">
                                    <i class="fas fa-paper-plane"></i> Mulai Percakapan
                                </button>
                            </div>
                        </div>
                    {/if}
                </div>
            </div>
        </div>
    </main>
</div>

{* New Message Modal *}
<div class="mineless-modal" id="newMessageModal">
    <div class="mineless-modal-overlay"></div>
    <div class="mineless-modal-content adv-modal-lg">
        <div class="mineless-modal-header">
            <h3><i class="fas fa-envelope"></i> Pesan Baru</h3>
            <button type="button" class="mineless-modal-close">&times;</button>
        </div>
        <div class="mineless-modal-body">
            <form id="newMessageForm" action="{$smarty.const.URL}/user/messaging/new" method="post">
                <input type="hidden" name="token" value="{$TOKEN}">
                
                <div class="mineless-form-group">
                    <label for="recipient">Kepada</label>
                    <div class="mineless-user-search">
                        <input type="text" 
                               id="recipient" 
                               name="recipient" 
                               class="mineless-form-control"
                               placeholder="Ketik username..."
                               autocomplete="off"
                               required>
                        <input type="hidden" name="recipient_id" id="recipientId">
                        <div class="mineless-search-results" id="userSearchResults"></div>
                    </div>
                </div>
                
                <div class="mineless-form-group">
                    <label for="messageContent">Pesan</label>
                    <textarea id="messageContent" 
                              name="message" 
                              class="mineless-form-control"
                              rows="5"
                              placeholder="Tulis pesanmu..."
                              required></textarea>
                </div>
            </form>
        </div>
        <div class="mineless-modal-footer">
            <button type="button" class="mineless-btn adv-btn-secondary" id="cancelNewMessage">Batal</button>
            <button type="submit" form="newMessageForm" class="mineless-btn adv-btn-primary adv-btn-loading" id="sendMessageBtn">
                <span class="mineless-btn-text"><i class="fas fa-paper-plane"></i> Kirim Pesan</span>
                <span class="mineless-btn-loader"><i class="fas fa-spinner fa-spin"></i></span>
            </button>
        </div>
    </div>
</div>

{* Toast Container *}
<div class="mineless-toast-container" id="toastContainer"></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // New Message Modal
    const modal = document.getElementById('newMessageModal');
    const newMessageBtn = document.getElementById('newMessageBtn');
    const cancelBtn = document.getElementById('cancelNewMessage');
    const closeBtn = modal?.querySelector('.mineless-modal-close');
    const overlay = modal?.querySelector('.mineless-modal-overlay');
    
    function openModal() {
        modal.classList.add('active');
        document.getElementById('recipient')?.focus();
    }
    
    function closeModal() {
        modal.classList.remove('active');
        document.getElementById('newMessageForm')?.reset();
    }
    
    newMessageBtn?.addEventListener('click', openModal);
    cancelBtn?.addEventListener('click', closeModal);
    closeBtn?.addEventListener('click', closeModal);
    overlay?.addEventListener('click', closeModal);
    
    // User search
    const recipientInput = document.getElementById('recipient');
    const recipientId = document.getElementById('recipientId');
    const searchResults = document.getElementById('userSearchResults');
    let searchTimeout;
    
    recipientInput?.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        const query = this.value.trim();
        
        if (query.length < 2) {
            searchResults.style.display = 'none';
            return;
        }
        
        searchTimeout = setTimeout(() => {
            fetch('{$smarty.const.URL}/user/messaging/search_users?query=' + encodeURIComponent(query))
                .then(res => res.json())
                .then(data => {
                    if (data.users && data.users.length > 0) {
                        searchResults.innerHTML = data.users.map(user => `
                            <div class="mineless-search-result-item" data-id="${user.id}" data-name="${user.username}">
                                <img src="https://cravatar.eu/avatar/${user.username}/32.png" 
                                     alt="${user.username}"
                                     onerror="this.src='https://cravatar.eu/avatar/steve/32.png'">
                                <span>${user.username}</span>
                            </div>
                        `).join('');
                        searchResults.style.display = 'block';
                        
                        // Handle result click
                        searchResults.querySelectorAll('.mineless-search-result-item').forEach(item => {
                            item.addEventListener('click', function() {
                                recipientInput.value = this.getAttribute('data-name');
                                recipientId.value = this.getAttribute('data-id');
                                searchResults.style.display = 'none';
                            });
                        });
                    } else {
                        searchResults.innerHTML = '<div class="mineless-search-no-results">Tidak ditemukan</div>';
                        searchResults.style.display = 'block';
                    }
                });
        }, 300);
    });
    
    // Close search results when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.mineless-user-search')) {
            searchResults && (searchResults.style.display = 'none');
        }
    });
    
    // Search conversations
    const searchInput = document.getElementById('searchConversations');
    searchInput?.addEventListener('input', function() {
        const query = this.value.toLowerCase();
        const conversations = document.querySelectorAll('.mineless-conversation-item');
        
        conversations.forEach(conv => {
            const name = conv.querySelector('.mineless-conversation-name').textContent.toLowerCase();
            const text = conv.querySelector('.mineless-conversation-text').textContent.toLowerCase();
            
            if (name.includes(query) || text.includes(query)) {
                conv.style.display = 'flex';
            } else {
                conv.style.display = 'none';
            }
        });
        
        // Show empty state if no results
        const visible = document.querySelectorAll('.mineless-conversation-item:not([style*="none"])');
        const list = document.getElementById('conversationsList');
        let emptyState = list.querySelector('.mineless-empty-state-search');
        
        if (visible.length === 0) {
            if (!emptyState) {
                emptyState = document.createElement('div');
                emptyState.className = 'adv-empty-state adv-empty-state-search';
                emptyState.innerHTML = `
                    <i class="fas fa-search"></i>
                    <p>Tidak ada hasil untuk "${this.value}"</p>
                `;
                list.appendChild(emptyState);
            }
        } else if (emptyState) {
            emptyState.remove();
        }
    });
    
    // Toast function
    function showToast(message, type = 'success') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `adv-toast ${type}`;
        toast.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        container.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
    
    // Form submission
    document.getElementById('newMessageForm')?.addEventListener('submit', function(e) {
        if (!recipientId.value) {
            e.preventDefault();
            showToast('Pilih penerima pesan', 'error');
            return;
        }
        
        const btn = document.getElementById('sendMessageBtn');
        btn.classList.add('loading');
    });
});
</script>
