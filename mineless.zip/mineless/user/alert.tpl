{* Single Alert Component - Mineless Theme *}
<div class="mineless-alert-item {if !$alert.read}unread{/if}" data-id="{$alert.id}">
    {* Unread Indicator *}
    {if !$alert.read}
        <span class="mineless-alert-unread"></span>
    {/if}
    
    {* Alert Icon based on type *}
    <div class="mineless-alert-icon adv-alert-{$alert.type|default:'info'}">
        {if $alert.type == 'success'}
            <i class="fas fa-check-circle"></i>
        {elseif $alert.type == 'warning'}
            <i class="fas fa-exclamation-triangle"></i>
        {elseif $alert.type == 'danger'}
            <i class="fas fa-times-circle"></i>
        {elseif $alert.type == 'message'}
            <i class="fas fa-envelope"></i>
        {elseif $alert.type == 'like'}
            <i class="fas fa-heart"></i>
        {elseif $alert.type == 'reply'}
            <i class="fas fa-reply"></i>
        {elseif $alert.type == 'mention'}
            <i class="fas fa-at"></i>
        {else}
            <i class="fas fa-info-circle"></i>
        {/if}
    </div>
    
    {* Alert Content *}
    <div class="mineless-alert-content">
        <p class="mineless-alert-text">
            {if $alert.url}
                <a href="{$alert.url}" class="mineless-alert-link">{$alert.content}</a>
            {else}
                {$alert.content}
            {/if}
        </p>
        <span class="mineless-alert-time" data-timestamp="{$alert.time}">
            <i class="fas fa-clock"></i>
            {$alert.time_friendly|default:$alert.time}
        </span>
    </div>
    
    {* Alert Actions *}
    <div class="mineless-alert-actions">
        {if !$alert.read}
            <button class="mineless-alert-btn adv-mark-read" data-id="{$alert.id}" title="Tandai dibaca">
                <i class="fas fa-check"></i>
            </button>
        {/if}
        <button class="mineless-alert-btn adv-delete-alert" data-id="{$alert.id}" title="Hapus">
            <i class="fas fa-trash"></i>
        </button>
    </div>
</div>

<script>
(function() {
    // Mark single alert as read
    document.querySelectorAll('.mineless-mark-read').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const alertId = this.getAttribute('data-id');
            const alertItem = this.closest('.mineless-alert-item');
            
            // Animate out
            alertItem.style.transform = 'translateX(20px)';
            alertItem.style.opacity = '0.5';
            
            fetch('{$smarty.const.URL}/user/alerts/mark_read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id=' + alertId + '&token={$TOKEN}'
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alertItem.classList.remove('unread');
                    alertItem.querySelector('.mineless-alert-unread')?.remove();
                    this.remove();
                    
                    // Update unread count badge
                    const unreadBadge = document.querySelector('.mineless-nav-badge');
                    if (unreadBadge) {
                        const count = parseInt(unreadBadge.textContent) - 1;
                        if (count > 0) {
                            unreadBadge.textContent = count;
                        } else {
                            unreadBadge.remove();
                        }
                    }
                }
                alertItem.style.transform = '';
                alertItem.style.opacity = '';
            })
            .catch(() => {
                alertItem.style.transform = '';
                alertItem.style.opacity = '';
            });
        });
    });
    
    // Delete alert
    document.querySelectorAll('.mineless-delete-alert').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const alertId = this.getAttribute('data-id');
            const alertItem = this.closest('.mineless-alert-item');
            
            if (!confirm('Hapus notifikasi ini?')) return;
            
            // Animate slide out
            alertItem.style.transform = 'translateX(100%)';
            alertItem.style.opacity = '0';
            
            fetch('{$smarty.const.URL}/user/alerts/delete', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id=' + alertId + '&token={$TOKEN}'
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    setTimeout(() => {
                        alertItem.style.height = alertItem.offsetHeight + 'px';
                        alertItem.style.margin = '0';
                        alertItem.style.padding = '0';
                        alertItem.style.overflow = 'hidden';
                        
                        setTimeout(() => {
                            alertItem.style.height = '0';
                            setTimeout(() => alertItem.remove(), 300);
                        }, 50);
                    }, 300);
                } else {
                    alertItem.style.transform = '';
                    alertItem.style.opacity = '';
                }
            })
            .catch(() => {
                alertItem.style.transform = '';
                alertItem.style.opacity = '';
            });
        });
    });
})();
</script>
