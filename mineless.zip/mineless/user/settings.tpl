{* User Settings - Mineless Theme *}
<div class="mineless-user-panel">
    {include file='user/navigation.tpl'}
    
    <main class="mineless-user-main">
        <div class="mineless-settings">
            {* Page Header *}
            <div class="mineless-page-header">
                <h1><i class="fas fa-cog"></i> Account Settings</h1>
                <p>Manage profile information, security, and account preferences</p>
            </div>
            
            {* Settings Tabs *}
            <div class="mineless-settings-tabs">
                <button class="mineless-tab-btn active" data-tab="avatar">
                    <i class="fas fa-user-circle"></i> Avatar
                </button>
                <button class="mineless-tab-btn" data-tab="profile">
                    <i class="fas fa-id-card"></i> Profile
                </button>
                <button class="mineless-tab-btn" data-tab="security">
                    <i class="fas fa-shield-alt"></i> Security
                </button>
                <button class="mineless-tab-btn" data-tab="privacy">
                    <i class="fas fa-lock"></i> Privacy
                </button>
                <button class="mineless-tab-btn" data-tab="preferences">
                    <i class="fas fa-sliders-h"></i> Preferences
                </button>
                <button class="mineless-tab-btn danger" data-tab="danger">
                    <i class="fas fa-exclamation-triangle"></i> Danger Zone
                </button>
            </div>
            
            {* Tab Content *}
            <div class="mineless-settings-content">
                {* AVATAR TAB *}
                <div class="mineless-tab-panel active" id="tab-avatar">
                    <div class="mineless-settings-card">
                        <div class="mineless-settings-card-header">
                            <h3><i class="fas fa-camera"></i> Profile Photo</h3>
                        </div>
                        <div class="mineless-settings-card-body">
                            <div class="mineless-avatar-preview-section">
                                <div class="mineless-avatar-current">
                                    <img src="{$AVATAR|default:'https://cravatar.eu/avatar/{$USERNAME}/256.png'}" 
                                         alt="Current Avatar"
                                         id="avatarPreview"
                                         onerror="this.src='https://cravatar.eu/avatar/steve/256.png'">
                                    <div class="mineless-avatar-overlay">
                                        <i class="fas fa-camera"></i>
                                    </div>
                                </div>
                                <div class="mineless-avatar-actions">
                                    <label class="mineless-btn adv-btn-primary">
                                        <i class="fas fa-upload"></i> Upload Photo
                                        <input type="file" name="avatar" accept="image/*" hidden id="avatarInput">
                                    </label>
                                    <button type="button" class="mineless-btn adv-btn-secondary" id="useMCSkin">
                                        <i class="fas fa-cube"></i> Use MC Skin
                                    </button>
                                </div>
                            </div>
                            
                            <form action="{$smarty.const.URL}/user/settings/avatar" method="post" enctype="multipart/form-data" class="mineless-avatar-form" id="avatarForm">
                                <input type="hidden" name="token" value="{$TOKEN}">
                                <input type="hidden" name="mc_skin" id="mcSkinValue" value="0">
                                
                                <div class="mineless-form-group">
                                    <p class="mineless-help-text">
                                        <i class="fas fa-info-circle"></i>
                                        Supported formats: JPG, PNG, GIF. Max 2MB.
                                    </p>
                                </div>
                                
                                <div class="mineless-form-actions">
                                    <button type="submit" class="mineless-btn adv-btn-success adv-btn-loading" id="saveAvatar">
                                        <span class="mineless-btn-text"><i class="fas fa-save"></i> Save Avatar</span>
                                        <span class="mineless-btn-loader"><i class="fas fa-spinner fa-spin"></i></span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                {* PROFILE TAB *}
                <div class="mineless-tab-panel" id="tab-profile">
                    <div class="mineless-settings-card">
                        <div class="mineless-settings-card-header">
                            <h3><i class="fas fa-id-card"></i> Profile Information</h3>
                        </div>
                        <div class="mineless-settings-card-body">
                            <form action="{$smarty.const.URL}/user/settings/profile" method="post" class="mineless-settings-form" id="profileForm">
                                <input type="hidden" name="token" value="{$TOKEN}">
                                
                                <div class="mineless-form-row">
                                    <div class="mineless-form-group adv-col-6">
                                        <label for="nickname">Display Name</label>
                                        <input type="text" id="nickname" name="nickname" 
                                               value="{$NICKNAME|default:$USERNAME}" 
                                               class="mineless-form-control"
                                               maxlength="20">
                                        <span class="mineless-form-hint">Name displayed on profile</span>
                                    </div>
                                    
                                    <div class="mineless-form-group adv-col-6">
                                        <label for="username">Username</label>
                                        <input type="text" id="username" value="{$USERNAME}" 
                                               class="mineless-form-control" disabled>
                                        <span class="mineless-form-hint">Username cannot be changed</span>
                                    </div>
                                </div>
                                
                                <div class="mineless-form-group">
                                    <label for="email">Email</label>
                                    <input type="email" id="email" name="email" 
                                           value="{$EMAIL}" 
                                           class="mineless-form-control">
                                </div>
                                
                                <div class="mineless-form-group">
                                    <label for="bio">Bio</label>
                                    <textarea id="bio" name="bio" class="mineless-form-control" 
                                              rows="4" maxlength="500"
                                              placeholder="Tell us a little about yourself...">{$BIO|default:''}</textarea>
                                    <span class="mineless-char-count"><span id="bioCount">0</span>/500</span>
                                </div>
                                
                                {* Custom Profile Fields *}
                                {if isset($CUSTOM_FIELDS) && count($CUSTOM_FIELDS) > 0}
                                    <div class="mineless-custom-fields">
                                        <h4>Additional Information</h4>
                                        {foreach from=$CUSTOM_FIELDS item=field}
                                            <div class="mineless-form-group">
                                                <label for="field_{$field.id}">{$field.name}</label>
                                                {if $field.type == 'text'}
                                                    <input type="text" id="field_{$field.id}" 
                                                           name="fields[{$field.id}]" 
                                                           value="{$field.value}"
                                                           class="mineless-form-control">
                                                {elseif $field.type == 'textarea'}
                                                    <textarea id="field_{$field.id}" 
                                                              name="fields[{$field.id}]" 
                                                              class="mineless-form-control" 
                                                              rows="3">{$field.value}</textarea>
                                                {elseif $field.type == 'select'}
                                                    <select id="field_{$field.id}" 
                                                            name="fields[{$field.id}]" 
                                                            class="mineless-form-control">
                                                        {foreach from=$field.options item=option}
                                                            <option value="{$option.value}" {if $option.value == $field.value}selected{/if}>
                                                                {$option.label}
                                                            </option>
                                                        {/foreach}
                                                    </select>
                                                {/if}
                                            </div>
                                        {/foreach}
                                    </div>
                                {/if}
                                
                                <div class="mineless-form-actions">
                                    <button type="submit" class="mineless-btn adv-btn-success adv-btn-loading" id="saveProfile">
                                        <span class="mineless-btn-text"><i class="fas fa-save"></i> Save Changes</span>
                                        <span class="mineless-btn-loader"><i class="fas fa-spinner fa-spin"></i></span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                {* SECURITY TAB *}
                <div class="mineless-tab-panel" id="tab-security">
                    <div class="mineless-settings-card">
                        <div class="mineless-settings-card-header">
                            <h3><i class="fas fa-shield-alt"></i> Account Security</h3>
                        </div>
                        <div class="mineless-settings-card-body">
                            <form action="{$smarty.const.URL}/user/settings/password" method="post" class="mineless-settings-form" id="passwordForm">
                                <input type="hidden" name="token" value="{$TOKEN}">
                                
                                <div class="mineless-form-group">
                                    <label for="current_password">Current Password</label>
                                    <div class="mineless-input-group">
                                        <input type="password" id="current_password" name="current_password" 
                                               class="mineless-form-control" required>
                                        <button type="button" class="mineless-input-addon toggle-password">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                </div>
                                
                                <div class="mineless-form-group">
                                    <label for="new_password">New Password</label>
                                    <div class="mineless-input-group">
                                        <input type="password" id="new_password" name="new_password" 
                                               class="mineless-form-control" required>
                                        <button type="button" class="mineless-input-addon toggle-password">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                    {* Password Strength Meter *}
                                    <div class="mineless-password-strength">
                                        <div class="mineless-strength-bar">
                                            <div class="mineless-strength-fill" id="strengthFill"></div>
                                        </div>
                                        <span class="mineless-strength-text" id="strengthText">Password strength</span>
                                    </div>
                                </div>
                                
                                <div class="mineless-form-group">
                                    <label for="confirm_password">Confirm New Password</label>
                                    <div class="mineless-input-group">
                                        <input type="password" id="confirm_password" name="confirm_password" 
                                               class="mineless-form-control" required>
                                        <button type="button" class="mineless-input-addon toggle-password">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                    <span class="mineless-password-match" id="passwordMatch"></span>
                                </div>
                                
                                <div class="mineless-form-actions">
                                    <button type="submit" class="mineless-btn adv-btn-success adv-btn-loading" id="savePassword">
                                        <span class="mineless-btn-text"><i class="fas fa-key"></i> Update Password</span>
                                        <span class="mineless-btn-loader"><i class="fas fa-spinner fa-spin"></i></span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                {* PRIVACY TAB *}
                <div class="mineless-tab-panel" id="tab-privacy">
                    <div class="mineless-settings-card">
                        <div class="mineless-settings-card-header">
                            <h3><i class="fas fa-lock"></i> Privacy Settings</h3>
                        </div>
                        <div class="mineless-settings-card-body">
                            <form action="{$smarty.const.URL}/user/settings/privacy" method="post" class="mineless-settings-form" id="privacyForm">
                                <input type="hidden" name="token" value="{$TOKEN}">
                                
                                <div class="mineless-privacy-options">
                                    <div class="mineless-privacy-item">
                                        <div class="mineless-privacy-info">
                                            <h4>Public Profile</h4>
                                            <p>Who can view your profile</p>
                                        </div>
                                        <select name="profile_privacy" class="mineless-form-control">
                                            <option value="everyone" {if $PRIVACY_PROFILE == 'everyone'}selected{/if}>Everyone</option>
                                            <option value="members" {if $PRIVACY_PROFILE == 'members'}selected{/if}>Registered Members</option>
                                            <option value="friends" {if $PRIVACY_PROFILE == 'friends'}selected{/if}>Friends Only</option>
                                            <option value="nobody" {if $PRIVACY_PROFILE == 'nobody'}selected{/if}>Nobody</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mineless-privacy-item">
                                        <div class="mineless-privacy-info">
                                            <h4>Posts & Activity</h4>
                                            <p>Who can view your posts and activity</p>
                                        </div>
                                        <select name="posts_privacy" class="mineless-form-control">
                                            <option value="everyone" {if $PRIVACY_POSTS == 'everyone'}selected{/if}>Everyone</option>
                                            <option value="members" {if $PRIVACY_POSTS == 'members'}selected{/if}>Registered Members</option>
                                            <option value="friends" {if $PRIVACY_POSTS == 'friends'}selected{/if}>Friends Only</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mineless-privacy-item">
                                        <div class="mineless-privacy-info">
                                            <h4>Online Status</h4>
                                            <p>Show online status on profile</p>
                                        </div>
                                        <label class="mineless-toggle">
                                            <input type="checkbox" name="show_online" 
                                                   {if $SHOW_ONLINE !== false}checked{/if}>
                                            <span class="mineless-toggle-slider"></span>
                                        </label>
                                    </div>
                                    
                                    <div class="mineless-privacy-item">
                                        <div class="mineless-privacy-info">
                                            <h4>Mention & Tag</h4>
                                            <p>Allow others to mention you</p>
                                        </div>
                                        <label class="mineless-toggle">
                                            <input type="checkbox" name="allow_mentions" 
                                                   {if $ALLOW_MENTIONS !== false}checked{/if}>
                                            <span class="mineless-toggle-slider"></span>
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="mineless-form-actions">
                                    <button type="submit" class="mineless-btn adv-btn-success adv-btn-loading" id="savePrivacy">
                                        <span class="mineless-btn-text"><i class="fas fa-save"></i> Save Privacy</span>
                                        <span class="mineless-btn-loader"><i class="fas fa-spinner fa-spin"></i></span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                {* PREFERENCES TAB *}
                <div class="mineless-tab-panel" id="tab-preferences">
                    <div class="mineless-settings-card">
                        <div class="mineless-settings-card-header">
                            <h3><i class="fas fa-sliders-h"></i> Preferensi</h3>
                        </div>
                        <div class="mineless-settings-card-body">
                            <form action="{$smarty.const.URL}/user/settings/preferences" method="post" class="mineless-settings-form" id="preferencesForm">
                                <input type="hidden" name="token" value="{$TOKEN}">
                                
                                <div class="mineless-form-row">
                                    <div class="mineless-form-group adv-col-6">
                                        <label for="language">Language</label>
                                        <select id="language" name="language" class="mineless-form-control">
                                            {foreach from=$LANGUAGES item=lang}
                                                <option value="{$lang.code}" {if $lang.code == $ACTIVE_LANGUAGE}selected{/if}>
                                                    {$lang.name}
                                                </option>
                                            {/foreach}
                                        </select>
                                    </div>
                                    
                                    <div class="mineless-form-group adv-col-6">
                                        <label for="timezone">Timezone</label>
                                        <select id="timezone" name="timezone" class="mineless-form-control">
                                            {foreach from=$TIMEZONES item=tz}
                                                <option value="{$tz.zone}" {if $tz.zone == $ACTIVE_TIMEZONE}selected{/if}>
                                                    {$tz.name}
                                                </option>
                                            {/foreach}
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mineless-form-group">
                                    <label for="theme">Default Theme</label>
                                    <select id="theme" name="theme" class="mineless-form-control">
                                        <option value="dark" {if $ACTIVE_THEME == 'dark'}selected{/if}>Dark Mode</option>
                                        <option value="light" {if $ACTIVE_THEME == 'light'}selected{/if}>Light Mode</option>
                                        <option value="auto" {if $ACTIVE_THEME == 'auto'}selected{/if}>Auto (System)</option>
                                    </select>
                                </div>
                                
                                <div class="mineless-form-group">
                                    <label>Notifikasi Email</label>
                                    <div class="mineless-checkbox-group">
                                        <label class="mineless-checkbox">
                                            <input type="checkbox" name="email_notifications[]" value="messages"
                                                   {if in_array('messages', $EMAIL_NOTIFICATIONS)}checked{/if}>
                                            <span class="mineless-checkmark"></span>
                                            Pesan Baru
                                        </label>
                                        <label class="mineless-checkbox">
                                            <input type="checkbox" name="email_notifications[]" value="alerts"
                                                   {if in_array('alerts', $EMAIL_NOTIFICATIONS)}checked{/if}>
                                            <span class="mineless-checkmark"></span>
                                            Notifikasi & Alert
                                        </label>
                                        <label class="mineless-checkbox">
                                            <input type="checkbox" name="email_notifications[]" value="newsletter"
                                                   {if in_array('newsletter', $EMAIL_NOTIFICATIONS)}checked{/if}>
                                            <span class="mineless-checkmark"></span>
                                            Newsletter & Update
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="mineless-form-actions">
                                    <button type="submit" class="mineless-btn adv-btn-success adv-btn-loading" id="savePreferences">
                                        <span class="mineless-btn-text"><i class="fas fa-save"></i> Save Preferences</span>
                                        <span class="mineless-btn-loader"><i class="fas fa-spinner fa-spin"></i></span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                {* DANGER ZONE TAB *}
                <div class="mineless-tab-panel" id="tab-danger">
                    <div class="mineless-settings-card adv-danger-card">
                        <div class="mineless-settings-card-header">
                            <h3><i class="fas fa-exclamation-triangle"></i> Danger Zone</h3>
                        </div>
                        <div class="mineless-settings-card-body">
                            <div class="mineless-danger-item">
                                <div class="mineless-danger-info">
                                    <h4>Delete Account</h4>
                                    <p>This action cannot be undone. All your account data will be permanently deleted.</p>
                                </div>
                                <button type="button" class="mineless-btn adv-btn-danger" id="deleteAccountBtn">
                                    <i class="fas fa-trash-alt"></i> Delete Account
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

{* Delete Account Modal *}
<div class="mineless-modal" id="deleteAccountModal">
    <div class="mineless-modal-overlay"></div>
    <div class="mineless-modal-content">
        <div class="mineless-modal-header">
            <h3><i class="fas fa-exclamation-triangle"></i> Confirm Deletion</h3>
            <button type="button" class="mineless-modal-close">&times;</button>
        </div>
        <div class="mineless-modal-body">
            <div class="mineless-danger-alert">
                <i class="fas fa-skull"></i>
                <p>Are you sure you want to delete this account? This action <strong>CANNOT BE UNDONE</strong>.</p>
            </div>
            <form id="deleteAccountForm" action="{$smarty.const.URL}/user/settings/delete" method="post">
                <input type="hidden" name="token" value="{$TOKEN}">
                <div class="mineless-form-group">
                    <label>Type <strong>"{$USERNAME}"</strong> to confirm:</label>
                    <input type="text" name="confirm_username" class="mineless-form-control" 
                           placeholder="{$USERNAME}" required
                           pattern="{$USERNAME}" title="Type your username exactly as displayed">
                </div>
                <div class="mineless-form-group">
                    <label>Enter password:</label>
                    <input type="password" name="confirm_password" class="mineless-form-control" required>
                </div>
            </form>
        </div>
        <div class="mineless-modal-footer">
            <button type="button" class="mineless-btn adv-btn-secondary" id="cancelDelete">Cancel</button>
            <button type="submit" form="deleteAccountForm" class="mineless-btn adv-btn-danger">
                <i class="fas fa-trash-alt"></i> Yes, Delete My Account
            </button>
        </div>
    </div>
</div>

{* Toast Notification *}
<div class="mineless-toast-container" id="toastContainer"></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tab switching
    const tabBtns = document.querySelectorAll('.mineless-tab-btn');
    const tabPanels = document.querySelectorAll('.mineless-tab-panel');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanels.forEach(p => p.classList.remove('active'));
            
            this.classList.add('active');
            document.getElementById('tab-' + tabId).classList.add('active');
        });
    });
    
    // Avatar preview
    const avatarInput = document.getElementById('avatarInput');
    const avatarPreview = document.getElementById('avatarPreview');
    const useMCSkin = document.getElementById('useMCSkin');
    const mcSkinValue = document.getElementById('mcSkinValue');
    
    avatarInput?.addEventListener('change', function() {
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                avatarPreview.src = e.target.result;
                mcSkinValue.value = '0';
            };
            reader.readAsDataURL(this.files[0]);
        }
    });
    
    useMCSkin?.addEventListener('click', function() {
        avatarPreview.src = 'https://cravatar.eu/avatar/{$USERNAME}/256.png';
        mcSkinValue.value = '1';
    });
    
    // Password strength meter
    const newPassword = document.getElementById('new_password');
    const strengthFill = document.getElementById('strengthFill');
    const strengthText = document.getElementById('strengthText');
    const confirmPassword = document.getElementById('confirm_password');
    const passwordMatch = document.getElementById('passwordMatch');
    
    function checkPasswordStrength(password) {
        let strength = 0;
        if (password.length >= 8) strength++;
        if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
        if (password.match(/\d/)) strength++;
        if (password.match(/[^a-zA-Z\d]/)) strength++;
        return strength;
    }
    
    newPassword?.addEventListener('input', function() {
        const strength = checkPasswordStrength(this.value);
        const widths = ['0%', '25%', '50%', '75%', '100%'];
        const colors = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#10b981'];
        const texts = ['Very Weak', 'Weak', 'Fair', 'Strong', 'Very Strong'];
        
        strengthFill.style.width = widths[strength];
        strengthFill.style.background = colors[strength];
        strengthText.textContent = texts[strength];
        strengthText.style.color = colors[strength];
    });
    
    confirmPassword?.addEventListener('input', function() {
        if (this.value === newPassword.value) {
            passwordMatch.textContent = '✓ Password match';
            passwordMatch.className = 'adv-password-match match';
        } else {
            passwordMatch.textContent = '✗ Password do not match';
            passwordMatch.className = 'adv-password-match no-match';
        }
    });
    
    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(btn => {
        btn.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });
    });
    
    // Bio character count
    const bio = document.getElementById('bio');
    const bioCount = document.getElementById('bioCount');
    bio?.addEventListener('input', function() {
        bioCount.textContent = this.value.length;
    });
    bioCount && (bioCount.textContent = bio.value.length);
    
    // Delete account modal
    const deleteModal = document.getElementById('deleteAccountModal');
    document.getElementById('deleteAccountBtn')?.addEventListener('click', function() {
        deleteModal.classList.add('active');
    });
    document.getElementById('cancelDelete')?.addEventListener('click', function() {
        deleteModal.classList.remove('active');
    });
    document.querySelector('.mineless-modal-close')?.addEventListener('click', function() {
        deleteModal.classList.remove('active');
    });
    document.querySelector('.mineless-modal-overlay')?.addEventListener('click', function() {
        deleteModal.classList.remove('active');
    });
    
    // AJAX form submission with toast
    function showToast(message, type = 'success') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `adv-toast ${type}`;
        toast.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        container.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
    
    // Handle all forms with AJAX
    ['avatarForm', 'profileForm', 'passwordForm', 'privacyForm', 'preferencesForm'].forEach(formId => {
        const form = document.getElementById(formId);
        form?.addEventListener('submit', function(e) {
            e.preventDefault();
            const btn = form.querySelector('.mineless-btn-loading');
            btn.classList.add('loading');
            
            const formData = new FormData(form);
            fetch(form.action, {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                btn.classList.remove('loading');
                showToast(data.message || 'Saved successfully!', data.success ? 'success' : 'error');
            })
            .catch(() => {
                btn.classList.remove('loading');
                showToast('An error occurred. Please try again.', 'error');
            });
        });
    });
});
</script>
