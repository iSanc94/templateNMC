{* 
 * File: user/placeholders.tpl
 * Deskripsi: Render custom profile field types (text, select, checkbox, date, url, textarea)
 * Template: Mineless
 *}

{include file='header.tpl'}

<div class="mineless-user-panel">
  <!-- Particle Background -->
  <div id="particles-placeholders" class="mineless-particles"></div>
  
  <div class="mineless-container">
    <div class="mineless-panel-grid">
      
      {include file='user/navigation.tpl'}
      
      <!-- Main Content -->
      <main class="mineless-panel-main">
        <div class="mineless-panel-header">
          <h1 class="mineless-panel-title">
            <span class="mineless-icon adv-icon-id-card"></span>
            {$LANGUAGE->get('user', 'custom_profile_fields')}
          </h1>
          <p class="mineless-panel-subtitle">{$LANGUAGE->get('user', 'customize_profile_info')}</p>
        </div>
        
        <!-- Success Message -->
        {if isset($SUCCESS)}
          <div class="mineless-alert adv-alert-success adv-alert-dismissible adv-fade-in">
            <span class="mineless-icon adv-icon-check-circle"></span>
            <span>{$SUCCESS}</span>
            <button type="button" class="mineless-alert-close">
              <span class="mineless-icon adv-icon-close"></span>
            </button>
          </div>
        {/if}
        
        <!-- Error Message -->
        {if isset($ERROR)}
          <div class="mineless-alert adv-alert-error adv-alert-dismissible adv-fade-in">
            <span class="mineless-icon adv-icon-error"></span>
            <span>{$ERROR}</span>
            <button type="button" class="mineless-alert-close">
              <span class="mineless-icon adv-icon-close"></span>
            </button>
          </div>
        {/if}
        
        <!-- Placeholders Form -->
        <form action="{$PLACEHOLDERS_UPDATE_URL}" method="post" class="mineless-placeholders-form">
          <input type="hidden" name="token" value="{$TOKEN}">
          
          <div class="mineless-card adv-placeholders-card">
            <div class="mineless-card-header">
              <h3 class="mineless-card-title">
                <span class="mineless-icon advicon-edit"></span>
                {$LANGUAGE->get('user', 'profile_information')}
              </h3>
              <span class="mineless-required-hint">
                <span class="mineless-required-mark">*</span> {$LANGUAGE->get('general', 'required')}
              </span>
            </div>
            
            <div class="mineless-card-body">
              <div class="mineless-placeholders-grid">
                
                {foreach from=$PLACEHOLDERS item=field}
                  <div class="mineless-placeholder-item" data-type="{$field.type}">
                    
                    {* TEXT Field *}
                    {if $field.type == 'text'}
                      <div class="mineless-form-group">
                        <label class="mineless-form-label" for="field_{$field.id}">
                          {$field.name}
                          {if $field.required}<span class="mineless-required-mark">*</span>{/if}
                        </label>
                        <input 
                          type="text" 
                          id="field_{$field.id}"
                          name="fields[{$field.id}]" 
                          class="mineless-input" 
                          value="{$field.value|escape}"
                          placeholder="{$field.placeholder|default:''}"
                          {if $field.required}required{/if}
                          {if $field.max_length}maxlength="{$field.max_length}"{/if}
                        >
                        {if $field.description}
                          <span class="mineless-form-hint">{$field.description}</span>
                        {/if}
                      </div>
                    {/if}
                    
                    {* TEXTAREA Field *}
                    {if $field.type == 'textarea'}
                      <div class="mineless-form-group adv-form-group-full">
                        <label class="mineless-form-label" for="field_{$field.id}">
                          {$field.name}
                          {if $field.required}<span class="mineless-required-mark">*</span>{/if}
                        </label>
                        <textarea 
                          id="field_{$field.id}"
                          name="fields[{$field.id}]" 
                          class="mineless-input adv-textarea"
                          rows="4"
                          placeholder="{$field.placeholder|default:''}"
                          {if $field.required}required{/if}
                          {if $field.max_length}maxlength="{$field.max_length}"{/if}
                        >{$field.value|escape}</textarea>
                        {if $field.description}
                          <span class="mineless-form-hint">{$field.description}</span>
                        {/if}
                        {if $field.max_length}
                          <span class="mineless-char-counter">
                            <span class="mineless-char-count">{$field.value|strlen}</span> / {$field.max_length}
                          </span>
                        {/if}
                      </div>
                    {/if}
                    
                    {* SELECT Field *}
                    {if $field.type == 'select'}
                      <div class="mineless-form-group">
                        <label class="mineless-form-label" for="field_{$field.id}">
                          {$field.name}
                          {if $field.required}<span class="mineless-required-mark">*</span>{/if}
                        </label>
                        <div class="mineless-select-wrapper">
                          <select 
                            id="field_{$field.id}"
                            name="fields[{$field.id}]" 
                            class="mineless-input adv-select"
                            {if $field.required}required{/if}
                          >
                            <option value="">{$LANGUAGE->get('general', 'select_option')}</option>
                            {foreach from=$field.options item=option}
                              <option value="{$option.value}" {if $field.value == $option.value}selected{/if}>
                                {$option.label}
                              </option>
                            {/foreach}
                          </select>
                          <span class="mineless-select-arrow">
                            <span class="mineless-icon adv-icon-chevron-down"></span>
                          </span>
                        </div>
                        {if $field.description}
                          <span class="mineless-form-hint">{$field.description}</span>
                        {/if}
                      </div>
                    {/if}
                    
                    {* CHECKBOX Field *}
                    {if $field.type == 'checkbox'}
                      <div class="mineless-form-group adv-form-group-checkbox">
                        <label class="mineless-checkbox-label" for="field_{$field.id}">
                          <input 
                            type="checkbox" 
                            id="field_{$field.id}"
                            name="fields[{$field.id}]" 
                            class="mineless-checkbox-input"
                            value="1"
                            {if $field.value}checked{/if}
                          >
                          <span class="mineless-checkbox-custom">
                            <span class="mineless-checkbox-check">
                              <span class="mineless-icon adv-icon-check"></span>
                            </span>
                          </span>
                          <span class="mineless-checkbox-text">
                            {$field.name}
                            {if $field.required}<span class="mineless-required-mark">*</span>{/if}
                          </span>
                        </label>
                        {if $field.description}
                          <span class="mineless-form-hint adv-checkbox-hint">{$field.description}</span>
                        {/if}
                      </div>
                    {/if}
                    
                    {* DATE Field *}
                    {if $field.type == 'date'}
                      <div class="mineless-form-group">
                        <label class="mineless-form-label" for="field_{$field.id}">
                          {$field.name}
                          {if $field.required}<span class="mineless-required-mark">*</span>{/if}
                        </label>
                        <div class="mineless-date-wrapper">
                          <input 
                            type="date" 
                            id="field_{$field.id}"
                            name="fields[{$field.id}]" 
                            class="mineless-input adv-input-date"
                            value="{$field.value|escape}"
                            {if $field.min}min="{$field.min}"{/if}
                            {if $field.max}max="{$field.max}"{/if}
                            {if $field.required}required{/if}
                          >
                          <span class="mineless-date-icon">
                            <span class="mineless-icon adv-icon-calendar"></span>
                          </span>
                        </div>
                        {if $field.description}
                          <span class="mineless-form-hint">{$field.description}</span>
                        {/if}
                      </div>
                    {/if}
                    
                    {* URL Field *}
                    {if $field.type == 'url'}
                      <div class="mineless-form-group">
                        <label class="mineless-form-label" for="field_{$field.id}">
                          {$field.name}
                          {if $field.required}<span class="mineless-required-mark">*</span>{/if}
                        </label>
                        <div class="mineless-input-wrapper">
                          <span class="mineless-input-prefix">
                            <span class="mineless-icon adv-icon-link"></span>
                          </span>
                          <input 
                            type="url" 
                            id="field_{$field.id}"
                            name="fields[{$field.id}]" 
                            class="mineless-input adv-input-with-prefix"
                            value="{$field.value|escape}"
                            placeholder="https://example.com"
                            {if $field.required}required{/if}
                          >
                        </div>
                        {if $field.description}
                          <span class="mineless-form-hint">{$field.description}</span>
                        {/if}
                        {if $field.value}
                          <a href="{$field.value|escape}" target="_blank" rel="noopener" class="mineless-preview-link">
                            <span class="mineless-icon adv-icon-external-link"></span>
                            {$LANGUAGE->get('general', 'preview')}
                          </a>
                        {/if}
                      </div>
                    {/if}
                    
                    {* NUMBER Field *}
                    {if $field.type == 'number'}
                      <div class="mineless-form-group">
                        <label class="mineless-form-label" for="field_{$field.id}">
                          {$field.name}
                          {if $field.required}<span class="mineless-required-mark">*</span>{/if}
                        </label>
                        <div class="mineless-number-wrapper">
                          <input 
                            type="number" 
                            id="field_{$field.id}"
                            name="fields[{$field.id}]" 
                            class="mineless-input adv-input-number"
                            value="{$field.value|escape}"
                            {if $field.min}min="{$field.min}"{/if}
                            {if $field.max}max="{$field.max}"{/if}
                            {if $field.step}step="{$field.step}"{/if}
                            {if $field.required}required{/if}
                          >
                          <div class="mineless-number-controls">
                            <button type="button" class="mineless-number-btn adv-number-up">
                              <span class="mineless-icon adv-icon-chevron-up"></span>
                            </button>
                            <button type="button" class="mineless-number-btn adv-number-down">
                              <span class="mineless-icon adv-icon-chevron-down"></span>
                            </button>
                          </div>
                        </div>
                        {if $field.description}
                          <span class="mineless-form-hint">{$field.description}</span>
                        {/if}
                      </div>
                    {/if}
                    
                    {* EMAIL Field *}
                    {if $field.type == 'email'}
                      <div class="mineless-form-group">
                        <label class="mineless-form-label" for="field_{$field.id}">
                          {$field.name}
                          {if $field.required}<span class="mineless-required-mark">*</span>{/if}
                        </label>
                        <div class="mineless-input-wrapper">
                          <span class="mineless-input-prefix">
                            <span class="mineless-icon adv-icon-mail"></span>
                          </span>
                          <input 
                            type="email" 
                            id="field_{$field.id}"
                            name="fields[{$field.id}]" 
                            class="mineless-input adv-input-with-prefix"
                            value="{$field.value|escape}"
                            placeholder="email@example.com"
                            {if $field.required}required{/if}
                          >
                        </div>
                        {if $field.description}
                          <span class="mineless-form-hint">{$field.description}</span>
                        {/if}
                      </div>
                    {/if}
                    
                    {* COLOR Field *}
                    {if $field.type == 'color'}
                      <div class="mineless-form-group">
                        <label class="mineless-form-label" for="field_{$field.id}">
                          {$field.name}
                          {if $field.required}<span class="mineless-required-mark">*</span>{/if}
                        </label>
                        <div class="mineless-color-wrapper">
                          <input 
                            type="color" 
                            id="field_{$field.id}"
                            name="fields[{$field.id}]" 
                            class="mineless-input adv-input-color"
                            value="{$field.value|default:'#D4AF37'}"
                            {if $field.required}required{/if}
                          >
                          <input 
                            type="text" 
                            class="mineless-input adv-color-text"
                            value="{$field.value|default:'#D4AF37'}"
                            maxlength="7"
                            placeholder="#D4AF37"
                          >
                        </div>
                        {if $field.description}
                          <span class="mineless-form-hint">{$field.description}</span>
                        {/if}
                      </div>
                    {/if}
                    
                  </div>
                {foreachelse}
                  <div class="mineless-empty-state">
                    <div class="mineless-empty-icon">
                      <span class="mineless-icon adv-icon-file-text"></span>
                    </div>
                    <h3>{$LANGUAGE->get('user', 'no_custom_fields')}</h3>
                    <p>{$LANGUAGE->get('user', 'no_custom_fields_desc')}</p>
                  </div>
                {/foreach}
                
              </div>
            </div>
            
            {if isset($PLACEHOLDERS) && is_array($PLACEHOLDERS) && count($PLACEHOLDERS) > 0}
              <div class="mineless-card-footer">
                <button type="submit" class="mineless-btn adv-btn-primary adv-btn-lg" id="saveBtn">
                  <span class="mineless-btn-content">
                    <span class="mineless-icon adv-icon-save"></span>
                    {$LANGUAGE->get('general', 'save_changes')}
                  </span>
                  <span class="mineless-btn-loading">
                    <span class="mineless-spinner adv-spinner-sm"></span>
                    {$LANGUAGE->get('general', 'saving')}...
                  </span>
                </button>
              </div>
            {/if}
          </div>
          
        </form>
        
        <!-- Field Type Info -->
        {if isset($PLACEHOLDERS) && is_array($PLACEHOLDERS) && count($PLACEHOLDERS) > 0}
          <div class="mineless-card adv-field-info">
            <h4 class="mineless-info-title">
              <span class="mineless-icon adv-icon-info-circle"></span>
              {$LANGUAGE->get('user', 'field_types_info')}
            </h4>
            <div class="mineless-field-types-grid">
              <div class="mineless-field-type">
                <span class="mineless-type-icon adv-icon-type-text"></span>
                <span class="mineless-type-name">{$LANGUAGE->get('user', 'type_text')}</span>
              </div>
              <div class="mineless-field-type">
                <span class="mineless-type-icon adv-icon-type-paragraph"></span>
                <span class="mineless-type-name">{$LANGUAGE->get('user', 'type_textarea')}</span>
              </div>
              <div class="mineless-field-type">
                <span class="mineless-type-icon adv-icon-type-list"></span>
                <span class="mineless-type-name">{$LANGUAGE->get('user', 'type_select')}</span>
              </div>
              <div class="mineless-field-type">
                <span class="mineless-type-icon adv-icon-type-check"></span>
                <span class="mineless-type-name">{$LANGUAGE->get('user', 'type_checkbox')}</span>
              </div>
              <div class="mineless-field-type">
                <span class="mineless-type-icon adv-icon-type-calendar"></span>
                <span class="mineless-type-name">{$LANGUAGE->get('user', 'type_date')}</span>
              </div>
              <div class="mineless-field-type">
                <span class="mineless-type-icon adv-icon-type-link"></span>
                <span class="mineless-type-name">{$LANGUAGE->get('user', 'type_url')}</span>
              </div>
            </div>
          </div>
        {/if}
        
      </main>
      
    </div>
  </div>
</div>

<script>
  // Character counter for textarea
  document.querySelectorAll('.mineless-textarea[maxlength]').forEach(textarea => {
    const maxLength = textarea.getAttribute('maxlength');
    const counter = textarea.parentElement.querySelector('.mineless-char-count');
    
    textarea.addEventListener('input', function() {
      const currentLength = this.value.length;
      counter.textContent = currentLength;
      
      if (currentLength >= maxLength) {
        counter.classList.add('adv-char-limit');
      } else {
        counter.classList.remove('adv-char-limit');
      }
    });
  });
  
  // Number input controls
  document.querySelectorAll('.mineless-number-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = this.closest('.mineless-number-wrapper').querySelector('input');
      const step = parseFloat(input.step) || 1;
      const currentValue = parseFloat(input.value) || 0;
      const min = parseFloat(input.min);
      const max = parseFloat(input.max);
      
      if (this.classList.contains('adv-number-up')) {
        let newValue = currentValue + step;
        if (max !== undefined && !isNaN(max)) {
          newValue = Math.min(newValue, max);
        }
        input.value = newValue;
      } else {
        let newValue = currentValue - step;
        if (min !== undefined && !isNaN(min)) {
          newValue = Math.max(newValue, min);
        }
        input.value = newValue;
      }
      
      input.dispatchEvent(new Event('input'));
    });
  });
  
  // Color input sync
  document.querySelectorAll('.mineless-input-color').forEach(colorInput => {
    const textInput = colorInput.parentElement.querySelector('.mineless-color-text');
    
    colorInput.addEventListener('input', function() {
      textInput.value = this.value;
    });
    
    textInput.addEventListener('input', function() {
      let value = this.value;
      if (!value.startsWith('#')) {
        value = '#' + value;
      }
      if (/^#[0-9A-Fa-f]{6}$/.test(value)) {
        colorInput.value = value;
      }
    });
  });
  
  // Form submission with loading state
  const form = document.querySelector('.mineless-placeholders-form');
  const saveBtn = document.getElementById('saveBtn');
  
  if (form) {
    form.addEventListener('submit', function() {
      saveBtn.classList.add('adv-btn-loading-active');
      saveBtn.disabled = true;
    });
  }
  
  // Alert dismissal
  document.querySelectorAll('.mineless-alert-close').forEach(btn => {
    btn.addEventListener('click', function() {
      this.closest('.mineless-alert').remove();
    });
  });
</script>

{include file='footer.tpl'}
