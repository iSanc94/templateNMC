{* 
 * File: user/new_message.tpl
 * Deskripsi: Form kirim pesan baru dengan autocomplete user dan WYSIWYG editor
 * Template: Mineless
 *}

{include file='header.tpl'}

<div class="mineless-user-panel">
  <!-- Particle Background -->
  <div id="particles-new-message" class="mineless-particles"></div>
  
  <div class="mineless-container">
    <div class="mineless-panel-grid">
      
      {include file='user/navigation.tpl'}
      
      <!-- Main Content -->
      <main class="mineless-panel-main">
        <div class="mineless-panel-header">
          <h1 class="mineless-panel-title">
            <span class="mineless-icon adv-icon-feather"></span>
            {$LANGUAGE->get('user', 'new_message')}
          </h1>
          <p class="mineless-panel-subtitle">{$LANGUAGE->get('user', 'compose_new_message')}</p>
        </div>
        
        <!-- Compose Form -->
        <div class="mineless-card adv-compose-card">
          <form action="" method="post" class="mineless-compose-form" id="newMessageForm">
            <input type="hidden" name="token" value="{$TOKEN}">
            
            <!-- Recipient -->
            <div class="mineless-form-group">
              <label class="mineless-form-label" for="recipient">
                <span class="mineless-icon adv-icon-user"></span>
                {$LANGUAGE->get('user', 'to')}
              </label>
              <div class="mineless-autocomplete-wrapper">
                <input 
                  type="text" 
                  id="recipient" 
                  name="recipient" 
                  class="mineless-input adv-input-lg" 
                  placeholder="{$LANGUAGE->get('user', 'type_username')}..."
                  autocomplete="off"
                  data-autocomplete="users"
                  required
                >
                <span class="mineless-input-icon adv-icon-search"></span>
                <div class="mineless-autocomplete-dropdown" id="userDropdown">
                  <ul class="mineless-autocomplete-list"></ul>
                </div>
              </div>
              <span class="mineless-form-hint">{$LANGUAGE->get('user', 'start_typing_username')}</span>
            </div>
            
            <!-- Subject -->
            <div class="mineless-form-group">
              <label class="mineless-form-label" for="subject">
                <span class="mineless-icon adv-icon-tag"></span>
                {$LANGUAGE->get('user', 'subject')}
              </label>
              <input 
                type="text" 
                id="subject" 
                name="title" 
                class="mineless-input adv-input-lg" 
                placeholder="{$LANGUAGE->get('user', 'message_subject')}..."
                maxlength="64"
                required
              >
            </div>
            
            <!-- Message Editor -->
            <div class="mineless-form-group">
              <label class="mineless-form-label" for="message">
                <span class="mineless-icon adv-icon-message"></span>
                {$LANGUAGE->get('user', 'message')}
              </label>
              
              <!-- WYSIWYG Toolbar -->
              <div class="mineless-editor-toolbar">
                <div class="mineless-toolbar-group">
                  <button type="button" class="mineless-toolbar-btn" data-command="bold" title="Bold">
                    <span class="mineless-icon adv-icon-bold"></span>
                  </button>
                  <button type="button" class="mineless-toolbar-btn" data-command="italic" title="Italic">
                    <span class="mineless-icon adv-icon-italic"></span>
                  </button>
                  <button type="button" class="mineless-toolbar-btn" data-command="underline" title="Underline">
                    <span class="mineless-icon adv-icon-underline"></span>
                  </button>
                  <button type="button" class="mineless-toolbar-btn" data-command="strikeThrough" title="Strikethrough">
                    <span class="mineless-icon adv-icon-strikethrough"></span>
                  </button>
                </div>
                <div class="mineless-toolbar-divider"></div>
                <div class="mineless-toolbar-group">
                  <button type="button" class="mineless-toolbar-btn" data-command="insertUnorderedList" title="Bullet List">
                    <span class="mineless-icon adv-icon-list-ul"></span>
                  </button>
                  <button type="button" class="mineless-toolbar-btn" data-command="insertOrderedList" title="Numbered List">
                    <span class="mineless-icon adv-icon-list-ol"></span>
                  </button>
                </div>
                <div class="mineless-toolbar-divider"></div>
                <div class="mineless-toolbar-group">
                  <button type="button" class="mineless-toolbar-btn" data-command="createLink" title="Insert Link">
                    <span class="mineless-icon adv-icon-link"></span>
                  </button>
                  <button type="button" class="mineless-toolbar-btn" data-command="insertImage" title="Insert Image">
                    <span class="mineless-icon adv-icon-image"></span>
                  </button>
                </div>
                <div class="mineless-toolbar-divider"></div>
                <div class="mineless-toolbar-group">
                  <button type="button" class="mineless-toolbar-btn" data-command="removeFormat" title="Clear Formatting">
                    <span class="mineless-icon adv-icon-eraser"></span>
                  </button>
                </div>
              </div>
              
              <!-- Editor Content -->
              <div class="mineless-editor-wrapper">
                <textarea 
                  name="content" 
                  id="messageEditor" 
                  class="mineless-editor-textarea"
                  placeholder="{$LANGUAGE->get('user', 'write_message_here')}..."
                  rows="12"
                  required
                ></textarea>
                <div class="mineless-editor-content" id="editorContent" contenteditable="true"></div>
              </div>
              
              <div class="mineless-editor-footer">
                <span class="mineless-char-count">
                  <span id="charCount">0</span> / 10,000 {$LANGUAGE->get('general', 'characters')}
                </span>
                <button type="button" class="mineless-btn adv-btn-sm adv-btn-text" id="previewBtn">
                  <span class="mineless-icon adv-icon-eye"></span>
                  {$LANGUAGE->get('general', 'preview')}
                </button>
              </div>
            </div>
            
            <!-- Error Message -->
            {if isset($ERROR)}
              <div class="mineless-alert adv-alert-error adv-alert-dismissible">
                <span class="mineless-icon adv-icon-error"></span>
                <span>{$ERROR}</span>
                <button type="button" class="mineless-alert-close">
                  <span class="mineless-icon adv-icon-close"></span>
                </button>
              </div>
            {/if}
            
            <!-- Form Actions -->
            <div class="mineless-form-actions">
              <a href="{$MESSAGING_LINK}" class="mineless-btn adv-btn-outline">
                <span class="mineless-icon adv-icon-arrow-left"></span>
                {$LANGUAGE->get('general', 'cancel')}
              </a>
              <div class="mineless-action-group">
                <button type="submit" class="mineless-btn adv-btn-primary adv-btn-lg" id="sendBtn">
                  <span class="mineless-btn-content">
                    <span class="mineless-icon adv-icon-send"></span>
                    <span>{$LANGUAGE->get('user', 'send_message')}</span>
                  </span>
                  <span class="mineless-btn-loading">
                    <span class="mineless-spinner adv-spinner-sm"></span>
                    <span>{$LANGUAGE->get('general', 'sending')}...</span>
                  </span>
                </button>
              </div>
            </div>
            
          </form>
        </div>
        
        <!-- Quick Tips -->
        <div class="mineless-card adv-tips-card">
          <h3 class="mineless-tips-title">
            <span class="mineless-icon adv-icon-lightbulb"></span>
            {$LANGUAGE->get('general', 'tips')}
          </h3>
          <ul class="mineless-tips-list">
            <li>{$LANGUAGE->get('user', 'message_tip_1')}</li>
            <li>{$LANGUAGE->get('user', 'message_tip_2')}</li>
            <li>{$LANGUAGE->get('user', 'message_tip_3')}</li>
          </ul>
        </div>
        
      </main>
      
    </div>
  </div>
</div>

<!-- Message Preview Modal -->
<div class="mineless-modal" id="previewModal">
  <div class="mineless-modal-backdrop"></div>
  <div class="mineless-modal-dialog adv-modal-lg">
    <div class="mineless-modal-content">
      <div class="mineless-modal-header">
        <h3 class="mineless-modal-title">
          <span class="mineless-icon adv-icon-eye"></span>
          {$LANGUAGE->get('general', 'preview')}
        </h3>
        <button type="button" class="mineless-modal-close" data-dismiss="modal">
          <span class="mineless-icon adv-icon-close"></span>
        </button>
      </div>
      <div class="mineless-modal-body">
        <div class="mineless-preview-message">
          <div class="mineless-preview-header">
            <div class="mineless-preview-avatar">
              <img src="{$USER_AVATAR}" alt="{$USERNAME}">
            </div>
            <div class="mineless-preview-meta">
              <span class="mineless-preview-author">{$USERNAME}</span>
              <span class="mineless-preview-date">{$LANGUAGE->get('general', 'just_now')}</span>
            </div>
          </div>
          <div class="mineless-preview-subject" id="previewSubject"></div>
          <div class="mineless-preview-content" id="previewContent"></div>
        </div>
      </div>
      <div class="mineless-modal-footer">
        <button type="button" class="mineless-btn adv-btn-primary" data-dismiss="modal">
          {$LANGUAGE->get('general', 'close')}
        </button>
      </div>
    </div>
  </div>
</div>

<script>
  // User Autocomplete
  const recipientInput = document.getElementById('recipient');
  const userDropdown = document.getElementById('userDropdown');
  const userList = userDropdown.querySelector('.mineless-autocomplete-list');
  
  let debounceTimer;
  recipientInput.addEventListener('input', function() {
    clearTimeout(debounceTimer);
    const query = this.value.trim();
    
    if (query.length < 2) {
      userDropdown.classList.remove('show');
      return;
    }
    
    debounceTimer = setTimeout(() => {
      fetch(`{$SITE_URL}/queries/user_search/?query=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => {
          userList.innerHTML = '';
          if (data.users && data.users.length > 0) {
            data.users.forEach(user => {
              const li = document.createElement('li');
              li.className = 'adv-autocomplete-item';
              li.innerHTML = `
                <img src="${user.avatar}" class="mineless-autocomplete-avatar" alt="${user.username}">
                <span class="mineless-autocomplete-name">${user.username}</span>
                <span class="mineless-autocomplete-group">${user.group}</span>
              `;
              li.addEventListener('click', () => {
                recipientInput.value = user.username;
                userDropdown.classList.remove('show');
              });
              userList.appendChild(li);
            });
            userDropdown.classList.add('show');
          } else {
            userDropdown.classList.remove('show');
          }
        });
    }, 300);
  });
  
  // Close dropdown on outside click
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.mineless-autocomplete-wrapper')) {
      userDropdown.classList.remove('show');
    }
  });
  
  // WYSIWYG Editor
  const editorContent = document.getElementById('editorContent');
  const messageTextarea = document.getElementById('messageEditor');
  const charCount = document.getElementById('charCount');
  const toolbarBtns = document.querySelectorAll('.mineless-toolbar-btn');
  
  toolbarBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      const command = this.dataset.command;
      if (command === 'createLink' || command === 'insertImage') {
        const url = prompt(command === 'createLink' ? 'Enter URL:' : 'Enter image URL:');
        if (url) document.execCommand(command, false, url);
      } else {
        document.execCommand(command, false, null);
      }
      editorContent.focus();
    });
  });
  
  // Sync content to textarea and count chars
  editorContent.addEventListener('input', function() {
    messageTextarea.value = this.innerHTML;
    charCount.textContent = this.textContent.length;
  });
  
  // Preview Modal
  const previewBtn = document.getElementById('previewBtn');
  const previewModal = document.getElementById('previewModal');
  const previewSubject = document.getElementById('previewSubject');
  const previewContent = document.getElementById('previewContent');
  
  previewBtn.addEventListener('click', () => {
    previewSubject.textContent = document.getElementById('subject').value || '(No subject)';
    previewContent.innerHTML = editorContent.innerHTML || '<em>{$LANGUAGE->get('user', 'no_content')}</em>';
    previewModal.classList.add('show');
  });
  
  // Modal close handlers
  previewModal.querySelectorAll('[data-dismiss="modal"]').forEach(el => {
    el.addEventListener('click', () => previewModal.classList.remove('show'));
  });
  previewModal.querySelector('.mineless-modal-backdrop').addEventListener('click', () => {
    previewModal.classList.remove('show');
  });
  
  // Form Submit with Loading State
  const form = document.getElementById('newMessageForm');
  const sendBtn = document.getElementById('sendBtn');
  
  form.addEventListener('submit', function(e) {
    sendBtn.classList.add('adv-btn-loading-active');
    sendBtn.disabled = true;
  });
</script>

{include file='footer.tpl'}
