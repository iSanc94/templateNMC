{* 
 * File: user/oauth.tpl
 * Deskripsi: OAuth callback / connect account handler page
 * Template: Mineless
 *}

{include file='header.tpl'}

<div class="mineless-oauth-page">
  <!-- Animated Background -->
  <div class="mineless-oauth-bg">
    <div class="mineless-oauth-particles"></div>
    <div class="mineless-oauth-gradient"></div>
  </div>
  
  <div class="mineless-oauth-container">
    
    {include file='user/navigation.tpl'}
    
    <main class="mineless-oauth-main">
      
      <!-- Loading State -->
      <div class="mineless-oauth-state adv-state-loading" id="loadingState">
        <div class="mineless-oauth-card">
          <div class="mineless-loading-animation">
            <div class="mineless-loading-ring">
              <div class="mineless-loading-ring-inner"></div>
              <div class="mineless-loading-ring-outer"></div>
            </div>
            <div class="mineless-loading-icons">
              <span class="mineless-icon adv-icon-link"></span>
            </div>
          </div>
          <h2 class="mineless-oauth-title">{$LANGUAGE->get('user', 'connecting_account')}</h2>
          <p class="mineless-oauth-message">{$LANGUAGE->get('user', 'please_wait')}</p>
          <div class="mineless-loading-progress">
            <div class="mineless-progress-bar">
              <div class="mineless-progress-fill" id="progressFill"></div>
            </div>
            <span class="mineless-progress-text" id="progressText">0%</span>
          </div>
        </div>
      </div>
      
      <!-- Success State -->
      <div class="mineless-oauth-state adv-state-success" id="successState" style="display: none;">
        <div class="mineless-oauth-card">
          <div class="mineless-success-animation">
            <div class="mineless-checkmark">
              <svg viewBox="0 0 52 52">
                <circle class="mineless-checkmark-circle" cx="26" cy="26" r="25" fill="none"/>
                <path class="mineless-checkmark-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
              </svg>
            </div>
            <div class="mineless-success-particles">
              <span class="mineless-particle"></span>
              <span class="mineless-particle"></span>
              <span class="mineless-particle"></span>
              <span class="mineless-particle"></span>
              <span class="mineless-particle"></span>
            </div>
          </div>
          <h2 class="mineless-oauth-title adv-title-success">
            {$LANGUAGE->get('user', 'connection_successful')}
          </h2>
          <p class="mineless-oauth-message">
            {if $OAUTH_PROVIDER == 'discord'}
              {$LANGUAGE->get('user', 'discord_connected_msg')}
            {elseif $OAUTH_PROVIDER == 'steam'}
              {$LANGUAGE->get('user', 'steam_connected_msg')}
            {elseif $OAUTH_PROVIDER == 'google'}
              {$LANGUAGE->get('user', 'google_connected_msg')}
            {else}
              {$LANGUAGE->get('user', 'account_connected_msg')}
            {/if}
          </p>
          <div class="mineless-connected-account">
            <div class="mineless-account-avatar">
              {if $OAUTH_PROVIDER == 'discord'}
                <img src="https://cdn.discordapp.com/avatars/{$OAUTH_ID}/{$OAUTH_AVATAR}.png?size=64" 
                     alt="Discord Avatar">
              {elseif $OAUTH_PROVIDER == 'steam'}
                <img src="{$OAUTH_AVATAR}" alt="Steam Avatar">
              {else}
                <img src="{$OAUTH_AVATAR}" alt="Account Avatar">
              {/if}
            </div>
            <div class="mineless-account-info">
              <span class="mineless-account-name">{$OAUTH_USERNAME}</span>
              <span class="mineless-account-provider">
                <span class="mineless-icon adv-icon-{$OAUTH_PROVIDER}"></span>
                {$OAUTH_PROVIDER|capitalize}
              </span>
            </div>
          </div>
          <div class="mineless-redirect-info">
            <p>{$LANGUAGE->get('user', 'redirecting_in')} <span id="countdown">5</span> {$LANGUAGE->get('general', 'seconds')}</p>
            <a href="{$REDIRECT_URL}" class="mineless-btn adv-btn-primary">
              <span class="mineless-icon adv-icon-arrow-right"></span>
              {$LANGUAGE->get('general', 'continue')}
            </a>
          </div>
        </div>
      </div>
      
      <!-- Error State -->
      <div class="mineless-oauth-state adv-state-error" id="errorState" style="display: none;">
        <div class="mineless-oauth-card">
          <div class="mineless-error-animation">
            <div class="mineless-error-x">
              <svg viewBox="0 0 52 52">
                <circle class="mineless-error-circle" cx="26" cy="26" r="25" fill="none"/>
                <path class="mineless-error-cross" fill="none" d="M16 16l20 20M36 16L16 36"/>
              </svg>
            </div>
            <div class="mineless-error-shake">
              <span class="mineless-icon adv-icon-error-large"></span>
            </div>
          </div>
          <h2 class="mineless-oauth-title adv-title-error">
            {$LANGUAGE->get('user', 'connection_failed')}
          </h2>
          <p class="mineless-oauth-message adv-message-error">
            {if isset($ERROR_MESSAGE)}
              {$ERROR_MESSAGE}
            {else}
              {$LANGUAGE->get('user', 'connection_error_generic')}
            {/if}
          </p>
          
          {if isset($ERROR_DETAILS)}
            <div class="mineless-error-details">
              <details>
                <summary>{$LANGUAGE->get('general', 'error_details')}</summary>
                <code>{$ERROR_DETAILS}</code>
              </details>
            </div>
          {/if}
          
          <div class="mineless-error-actions">
            <a href="{$RETRY_URL}" class="mineless-btn adv-btn-primary">
              <span class="mineless-icon adv-icon-refresh"></span>
              {$LANGUAGE->get('general', 'try_again')}
            </a>
            <a href="{$BACK_URL}" class="mineless-btn adv-btn-outline">
              <span class="mineless-icon adv-icon-arrow-left"></span>
              {$LANGUAGE->get('general', 'go_back')}
            </a>
          </div>
          
          <div class="mineless-troubleshooting">
            <h4>{$LANGUAGE->get('user', 'troubleshooting')}</h4>
            <ul class="mineless-troubleshoot-list">
              <li>{$LANGUAGE->get('user', 'troubleshoot_1')}</li>
              <li>{$LANGUAGE->get('user', 'troubleshoot_2')}</li>
              <li>{$LANGUAGE->get('user', 'troubleshoot_3')}</li>
              <li>{$LANGUAGE->get('user', 'troubleshoot_4')}</li>
            </ul>
          </div>
        </div>
      </div>
      
    </main>
    
  </div>
</div>

<script>
  // OAuth Status Handler
  const loadingState = document.getElementById('loadingState');
  const successState = document.getElementById('successState');
  const errorState = document.getElementById('errorState');
  const progressFill = document.getElementById('progressFill');
  const progressText = document.getElementById('progressText');
  
  // Simulate progress animation
  let progress = 0;
  const progressInterval = setInterval(() => {
    progress += Math.random() * 15;
    if (progress >= 100) progress = 100;
    
    progressFill.style.width = progress + '%';
    progressText.textContent = Math.floor(progress) + '%';
    
    if (progress === 100) {
      clearInterval(progressInterval);
    }
  }, 200);
  
  // Handle OAuth result
  {if isset($OAUTH_SUCCESS)}
    // Success case
    setTimeout(() => {
      clearInterval(progressInterval);
      progressFill.style.width = '100%';
      progressText.textContent = '100%';
      
      setTimeout(() => {
        loadingState.style.display = 'none';
        successState.style.display = 'block';
        successState.classList.add('adv-fade-in');
        
        // Start countdown
        let seconds = 5;
        const countdownEl = document.getElementById('countdown');
        const countdownInterval = setInterval(() => {
          seconds--;
          countdownEl.textContent = seconds;
          
          if (seconds <= 0) {
            clearInterval(countdownInterval);
            window.location.href = '{$REDIRECT_URL}';
          }
        }, 1000);
      }, 500);
    }, 1500);
  {elseif isset($OAUTH_ERROR)}
    // Error case
    setTimeout(() => {
      clearInterval(progressInterval);
      
      setTimeout(() => {
        loadingState.style.display = 'none';
        errorState.style.display = 'block';
        errorState.classList.add('adv-fade-in');
      }, 500);
    }, 1500);
  {else}
    // Default: check server status
    fetch('{$OAUTH_STATUS_URL}')
      .then(response => response.json())
      .then(data => {
        clearInterval(progressInterval);
        
        if (data.success) {
          loadingState.style.display = 'none';
          successState.style.display = 'block';
          successState.classList.add('adv-fade-in');
          
          // Start countdown
          let seconds = 5;
          const countdownEl = document.getElementById('countdown');
          const countdownInterval = setInterval(() => {
            seconds--;
            countdownEl.textContent = seconds;
            
            if (seconds <= 0) {
              clearInterval(countdownInterval);
              window.location.href = data.redirect_url || '{$REDIRECT_URL}';
            }
          }, 1000);
        } else {
          loadingState.style.display = 'none';
          errorState.style.display = 'block';
          errorState.classList.add('adv-fade-in');
        }
      })
      .catch(() => {
        clearInterval(progressInterval);
        loadingState.style.display = 'none';
        errorState.style.display = 'block';
        errorState.classList.add('adv-fade-in');
      });
  {/if}
</script>

{include file='footer.tpl'}
