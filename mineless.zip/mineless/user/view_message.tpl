{* View Single Conversation - Mineless Theme *}
<div class="mineless-user-panel">
    {include file='user/navigation.tpl'}
    
    <main class="mineless-user-main">
        <div class="mineless-messaging">
            {* Page Header *}
            <div class="mineless-page-header">
                <div class="mineless-header-content">
                    <h1><i class="fas fa-envelope"></i> Pesan</h1>
                </div>
                <div class="mineless-header-actions">
                    <button class="mineless-btn adv-btn-primary" id="newMessageBtn">
                        <i class="fas fa-plus"></i> Pesan Baru
                    </button>
                </div>
            </div>
            
            {* Messaging Container *}
            <div class="mineless-messaging-container adv-conversation-open">
                {* Conversations List *}
                <div class="mineless-conversations-panel">
                    <div class="mineless-conversations-search">
                        <div class="mineless-search-input-wrap">
                            <i class="fas fa-search"></i>
                            <input type="text" 
                                   class="mineless-form-control" 
                                   id="searchConversations"
                                   placeholder="Cari percakapan...">
                        </div>
                    </div>
                    
                    <div class="mineless-conversations-list" id="conversationsList">
                        {if isset($CONVERSATIONS) && is_array($CONVERSATIONS) && count($CONVERSATIONS) > 0}
                            {foreach from=$CONVERSATIONS item=conversation}
                                <a href="{$conversation.url|default:"{$smarty.const.URL}/user/messaging/?id={$conversation.id}"}" 
                                   class="mineless-conversation-item {if $conversation.unread}unread{/if} {if isset($ACTIVE_CONVERSATION) && $ACTIVE_CONVERSATION == $conversation.id}active{/if}"
                                   data-conversation-id="{$conversation.id}">
                                    
                                    <div class="mineless-conversation-avatar">
                                        <img src="{$conversation.other_user.avatar|default:'https://cravatar.eu/avatar/'|cat:$conversation.other_user.username|cat:'/64.png'}" 
                                             alt="{$conversation.other_user.username}"
                                             onerror="this.src='https://cravatar.eu/avatar/steve/64.png'">
                                        {if $conversation.other_user.online}
                                            <span class="mineless-online-status"></span>
                                        {/if}
                                    </div>
                                    
                                    <div class="mineless-conversation-info">
                                        <div class="mineless-conversation-header">
                                            <h4 class="mineless-conversation-name">{$conversation.other_user.username}</h4>
                                            <span class="mineless-conversation-time" data-timestamp="{$conversation.last_message.time}">
                                                {$conversation.last_message.time_friendly|default:$conversation.last_message.time}
                                            </span>
                                        </div>
                                        <div class="mineless-conversation-preview">
                                            <p class="mineless-conversation-text">
                                                {if $conversation.last_message.from_me}
                                                    <span class="mineless-preview-prefix">Kamu:</span>
                                                {/if}
                                                {$conversation.last_message.preview|truncate:40:"...":true}
                                            </p>
                                            {if $conversation.unread > 0}
                                                <span class="mineless-conversation-badge">{$conversation.unread}</span>
                                            {/if}
                                        </div>
                                    </div>
                                </a>
                            {/foreach}
                        {/if}
                    </div>
                </div>
                
                {* Active Conversation *}
                <div class="mineless-conversation-view">
                    {if isset($CONVERSATION) && $CONVERSATION}
                        {* Conversation Header *}
                        <div class="mineless-conversation-view-header">
                            <a href="{$smarty.const.URL}/user/messaging" class="mineless-back-btn">
                                <i class="fas fa-arrow-left"></i>
                            </a>
                            
                            <div class="mineless-conversation-partner">
                                <div class="mineless-partner-avatar">
                                    <img src="{$CONVERSATION.other_user.avatar|default:'https://cravatar.eu/avatar/'|cat:$CONVERSATION.other_user.username|cat:'/64.png'}" 
                                         alt="{$CONVERSATION.other_user.username}"
                                         onerror="this.src='https://cravatar.eu/avatar/steve/64.png'">
                                    <span class="mineless-online-indicator {if $CONVERSATION.other_user.online}online{else}offline{/if}"></span>
                                </div>
                                <div class="mineless-partner-info">
                                    <h3>{$CONVERSATION.other_user.username}</h3>
                                    <span class="mineless-partner-status">
                                        {if $CONVERSATION.other_user.online}
                                            <i class="fas fa-circle"></i> Online
                                        {else}
                                            Terakhir dilihat {$CONVERSATION.other_user.last_seen|default:'baru saja'}
                                        {/if}
                                    </span>
                                </div>
                            </div>
                            
                            <div class="mineless-conversation-actions">
                                <a href="{$CONVERSATION.other_user.profile_url|default:"{$smarty.const.URL}/profile/{$CONVERSATION.other_user.username}"}" 
                                   class="mineless-btn adv-btn-icon" title="Lihat Profil">
                                    <i class="fas fa-user"></i>
                                </a>
                                <button class="mineless-btn adv-btn-icon adv-btn-danger" id="deleteConversation" title="Hapus Percakapan">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                        
                        {* Messages Container *}
                        <div class="mineless-messages-container" id="messagesContainer">
                            {if isset($MESSAGES) && is_array($MESSAGES) && count($MESSAGES) > 0}
                                {foreach from=$MESSAGES item=message}
                                    <div class="mineless-message {if $message.from_me}adv-message-sent{else}adv-message-received{/if}" 
                                         data-message-id="{$message.id}">
                                        
                                        {if !$message.from_me}
                                            <div class="mineless-message-avatar">
                                                <img src="{$CONVERSATION.other_user.avatar|default:'https://cravatar.eu/avatar/'|cat:$CONVERSATION.other_user.username|cat:'/32.png'}" 
                                                     alt="{$CONVERSATION.other_user.username}"
                                                     onerror="this.src='https://cravatar.eu/avatar/steve/32.png'">
                                            </div>
                                        {/if}
                                        
                                        <div class="mineless-message-content">
                                            <div class="mineless-message-bubble">
                                                <p class="mineless-message-text">{$message.content|nl2br}</p>
                                                {if $message.attachments}
                                                    <div class="mineless-message-attachments">
                                                        {foreach from=$message.attachments item=attachment}
                                                            <a href="{$attachment.url}" class="mineless-attachment" target="_blank">
                                                                <i class="fas fa-paperclip"></i>
                                                                {$attachment.name}
                                                            </a>
                                                        {/foreach}
                                                    </div>
                                                {/if}
                                            </div>
                                            <div class="mineless-message-meta">
                                                <span class="mineless-message-time" data-timestamp="{$message.time}">
                                                    {$message.time_friendly|default:$message.time}
                                                </span>
                                                {if $message.from_me && $message.read}
                                                    <span class="mineless-message-read" title="Dibaca">
                                                        <i class="fas fa-check-double"></i>
                                                    </span>
                                                {/if}
                                            </div>
                                        </div>
                                        
                                        {if $message.from_me}
                                            <div class="mineless-message-avatar">
                                                <img src="{$AVATAR|default:'https://cravatar.eu/avatar/'|cat:$USERNAME|cat:'/32.png'}" 
                                                     alt="{$USERNAME}"
                                                     onerror="this.src='https://cravatar.eu/avatar/steve/32.png'">
                                            </div>
                                        {/if}
                                    </div>
                                {/foreach}
                            {else}
                                <div class="mineless-messages-empty">
                                    <i class="fas fa-comments"></i>
                                    <p>Mulai percakapan dengan {$CONVERSATION.other_user.username}</p>
                                </div>
                            {/if}
                        </div>
                        
                        {* Reply Form *}
                        <div class="mineless-message-reply">
                            <form action="{$smarty.const.URL}/user/messaging/reply" method="post" id="replyForm">
                                <input type="hidden" name="token" value="{$TOKEN}">
                                <input type="hidden" name="conversation_id" value="{$CONVERSATION.id}">
                                
                                <div class="mineless-reply-input-wrap">
                                    <button type="button" class="mineless-reply-btn adv-emoji-btn" title="Emoji">
                                        <i class="fas fa-smile"></i>
                                    </button>
                                    
                                    <textarea name="message" 
                                              class="mineless-reply-input" 
                                              id="replyInput"
                                              placeholder="Tulis pesan..."
                                              rows="1"
                                              required></textarea>
                                    
                                    <button type="submit" class="mineless-reply-btn adv-send-btn" title="Kirim">
                                        <i class="fas fa-paper-plane"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    {/if}
                </div>
            </div>
        </div>
    </main>
</div>

{* Delete Conversation Modal *}
<div class="mineless-modal" id="deleteConversationModal">
    <div class="mineless-modal-overlay"></div>
    <div class="mineless-modal-content">
        <div class="mineless-modal-header">
            <h3><i class="fas fa-trash-alt"></i> Hapus Percakapan</h3>
            <button type="button" class="mineless-modal-close">&times;</button>
        </div>
        <div class="mineless-modal-body">
            <div class="mineless-danger-alert">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Apakah kamu yakin ingin menghapus percakapan ini? Semua pesan akan dihapus secara permanen.</p>
            </div>
        </div>
        <div class="mineless-modal-footer">
            <button type="button" class="mineless-btn adv-btn-secondary" id="cancelDelete">Batal</button>
            <form action="{$smarty.const.URL}/user/messaging/delete" method="post" id="deleteForm" style="display: inline;">
                <input type="hidden" name="token" value="{$TOKEN}">
                <input type="hidden" name="conversation_id" value="{$CONVERSATION.id}">
                <button type="submit" class="mineless-btn adv-btn-danger">
                    <i class="fas fa-trash"></i> Ya, Hapus
                </button>
            </form>
        </div>
    </div>
</div>

{* Toast Container *}
<div class="mineless-toast-container" id="toastContainer"></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const messagesContainer = document.getElementById('messagesContainer');
    const replyInput = document.getElementById('replyInput');
    
    // Scroll to bottom
    if (messagesContainer) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    // Auto-resize textarea
    replyInput?.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
    
    // Send message on Enter (Shift+Enter for new line)
    replyInput?.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            document.getElementById('replyForm')?.dispatchEvent(new Event('submit'));
        }
    });
    
    // Reply form AJAX
    document.getElementById('replyForm')?.addEventListener('submit', function(e) {
        e.preventDefault();
        const form = this;
        const message = replyInput.value.trim();
        
        if (!message) return;
        
        // Add message to UI immediately (optimistic)
        const tempId = 'temp-' + Date.now();
        addMessageToUI(message, tempId, true);
        replyInput.value = '';
        replyInput.style.height = 'auto';
        
        // Send via AJAX
        const formData = new FormData(form);
        fetch(form.action, {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                // Update temp message with real ID
                const tempMsg = document.querySelector(`[data-message-id="${tempId}"]`);
                if (tempMsg) {
                    tempMsg.setAttribute('data-message-id', data.message_id);
                }
            } else {
                showToast(data.message || 'Gagal mengirim pesan', 'error');
                // Remove temp message
                document.querySelector(`[data-message-id="${tempId}"]`)?.remove();
            }
        })
        .catch(() => {
            showToast('Terjadi kesalahan. Coba lagi.', 'error');
            document.querySelector(`[data-message-id="${tempId}"]`)?.remove();
        });
    });
    
    // Add message to UI
    function addMessageToUI(content, id, isSent) {
        const messageHtml = `
            <div class="mineless-message ${isSent ? 'adv-message-sent' : 'adv-message-received'}" data-message-id="${id}">
                ${!isSent ? `
                    <div class="mineless-message-avatar">
                        <img src="{$CONVERSATION.other_user.avatar|default:'https://cravatar.eu/avatar/'|cat:$CONVERSATION.other_user.username|cat:'/32.png'}" 
                             alt="{$CONVERSATION.other_user.username}"
                             onerror="this.src='https://cravatar.eu/avatar/steve/32.png'">
                    </div>
                ` : ''}
                <div class="mineless-message-content">
                    <div class="mineless-message-bubble">
                        <p class="mineless-message-text">${escapeHtml(content).replace(/\n/g, '<br>')}</p>
                    </div>
                    <div class="mineless-message-meta">
                        <span class="mineless-message-time">Baru saja</span>
                    </div>
                </div>
                ${isSent ? `
                    <div class="mineless-message-avatar">
                        <img src="{$AVATAR|default:'https://cravatar.eu/avatar/'|cat:$USERNAME|cat:'/32.png'}" 
                             alt="{$USERNAME}"
                             onerror="this.src='https://cravatar.eu/avatar/steve/32.png'">
                    </div>
                ` : ''}
            </div>
        `;
        
        const emptyState = messagesContainer.querySelector('.mineless-messages-empty');
        if (emptyState) {
            emptyState.remove();
        }
        
        messagesContainer.insertAdjacentHTML('beforeend', messageHtml);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // Delete conversation modal
    const deleteModal = document.getElementById('deleteConversationModal');
    document.getElementById('deleteConversation')?.addEventListener('click', function() {
        deleteModal.classList.add('active');
    });
    document.getElementById('cancelDelete')?.addEventListener('click', function() {
        deleteModal.classList.remove('active');
    });
    deleteModal?.querySelector('.mineless-modal-close')?.addEventListener('click', function() {
        deleteModal.classList.remove('active');
    });
    deleteModal?.querySelector('.mineless-modal-overlay')?.addEventListener('click', function() {
        deleteModal.classList.remove('active');
    });
    
    // Toast function
    function showToast(message, type = 'success') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `adv-toast ${type}`;
        toast.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        container.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
    
    // Search conversations
    const searchInput = document.getElementById('searchConversations');
    searchInput?.addEventListener('input', function() {
        const query = this.value.toLowerCase();
        const conversations = document.querySelectorAll('.mineless-conversation-item');
        
        conversations.forEach(conv => {
            const name = conv.querySelector('.mineless-conversation-name').textContent.toLowerCase();
            const text = conv.querySelector('.mineless-conversation-text').textContent.toLowerCase();
            
            conv.style.display = (name.includes(query) || text.includes(query)) ? 'flex' : 'none';
        });
    });
});
</script>
