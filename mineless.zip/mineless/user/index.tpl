{* User Dashboard - Mineless Theme *}
<div class="mineless-user-panel">
    {include file='user/navigation.tpl'}
    
    <main class="mineless-user-main">
        <div class="mineless-dashboard">
            {* Welcome Greeting Card *}
            <section class="mineless-welcome-card">
                <div class="mineless-welcome-bg"></div>
                <div class="mineless-welcome-content">
                    <div class="mineless-welcome-avatar">
                        <img src="{$AVATAR|default:'https://cravatar.eu/avatar/{$USERNAME}/128.png'}" 
                             alt="{$USERNAME}"
                             onerror="this.src='https://cravatar.eu/avatar/steve/128.png'">
                        <div class="mineless-avatar-glow"></div>
                    </div>
                    <div class="mineless-welcome-text">
                        <h1 class="mineless-welcome-title">
                            <span class="mineless-typing-text">Selamat datang kembali,</span>
                            <strong>{$USERNAME}</strong>
                        </h1>
                        {if isset($USER_RANK) && $USER_RANK}
                            <span class="mineless-rank-badge" style="{if $USER_RANK_COLOR}background: {$USER_RANK_COLOR};{/if}">
                                {$USER_RANK}
                            </span>
                        {/if}
                        <p class="mineless-welcome-subtitle">{$WELCOME_MESSAGE|default:'Semoga harimu menyenangkan petualang!'}</p>
                    </div>
                </div>
            </section>
            
            {* Quick Stats *}
            <section class="mineless-stats-grid">
                <div class="mineless-stat-card" data-count="{$POSTS_COUNT|default:0}">
                    <div class="mineless-stat-icon">
                        <i class="fas fa-comment-alt"></i>
                    </div>
                    <div class="mineless-stat-info">
                        <span class="mineless-stat-value counter" data-target="{$POSTS_COUNT|default:0}">0</span>
                        <span class="mineless-stat-label">Posts</span>
                    </div>
                    <div class="mineless-stat-shine"></div>
                </div>
                
                <div class="mineless-stat-card" data-count="{$REACTIONS_RECEIVED|default:0}">
                    <div class="mineless-stat-icon adv-icon-gold">
                        <i class="fas fa-heart"></i>
                    </div>
                    <div class="mineless-stat-info">
                        <span class="mineless-stat-value counter" data-target="{$REACTIONS_RECEIVED|default:0}">0</span>
                        <span class="mineless-stat-label">Reactions</span>
                    </div>
                    <div class="mineless-stat-shine"></div>
                </div>
                
                <div class="mineless-stat-card" data-count="{$TROPHIES_COUNT|default:0}">
                    <div class="mineless-stat-icon adv-icon-purple">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <div class="mineless-stat-info">
                        <span class="mineless-stat-value counter" data-target="{$TROPHIES_COUNT|default:0}">0</span>
                        <span class="mineless-stat-label">Trophies</span>
                    </div>
                    <div class="mineless-stat-shine"></div>
                </div>
            </section>
            
            <div class="mineless-dashboard-grid">
                {* Recent Notifications *}
                <section class="mineless-section adv-notifications-section">
                    <div class="mineless-section-header">
                        <h2><i class="fas fa-bell"></i> Notifikasi Terbaru</h2>
                        <a href="{$ALERTS_URL|default:'{$smarty.const.URL}/user/alerts'}" class="mineless-link-all">
                            Lihat Semua <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                    
                    <div class="mineless-notifications-list">
                        {if isset($RECENT_ALERTS) && is_array($RECENT_ALERTS) && count($RECENT_ALERTS) > 0}
                            {foreach from=$RECENT_ALERTS item=alert name=recent_alerts}
                                {if $smarty.foreach.recent_alerts.iteration <= 5}
                                    <div class="mineless-notification-item {if !$alert.read}unread{/if}">
                                        <div class="mineless-notif-icon adv-notif-{$alert.type|default:'info'}">
                                            <i class="fas fa-{if $alert.type == 'success'}check-circle{elseif $alert.type == 'warning'}exclamation-triangle{elseif $alert.type == 'danger'}times-circle{else}info-circle{/if}"></i>
                                        </div>
                                        <div class="mineless-notif-content">
                                            <p class="mineless-notif-text">{$alert.content}</p>
                                            <span class="mineless-notif-time" data-timestamp="{$alert.time}">
                                                {$alert.time_friendly|default:$alert.time}
                                            </span>
                                        </div>
                                        {if !$alert.read}
                                            <button class="mineless-mark-read-btn" data-id="{$alert.id}" title="Tandai dibaca">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        {/if}
                                    </div>
                                {/if}
                            {/foreach}
                        {else}
                            <div class="mineless-empty-state">
                                <i class="fas fa-bell-slash"></i>
                                <p>Tidak ada notifikasi baru</p>
                            </div>
                        {/if}
                    </div>
                </section>
                
                {* Shortcut Cards *}
                <section class="mineless-section adv-shortcuts-section">
                    <div class="mineless-section-header">
                        <h2><i class="fas fa-bolt"></i> Shortcut</h2>
                    </div>
                    
                    <div class="mineless-shortcuts-grid">
                        <a href="{$SETTINGS_URL|default:'{$smarty.const.URL}/user/settings'}" class="mineless-shortcut-card">
                            <div class="mineless-shortcut-icon">
                                <i class="fas fa-cog"></i>
                            </div>
                            <span class="mineless-shortcut-label">Settings</span>
                            <div class="mineless-shortcut-hover">
                                <i class="fas fa-arrow-right"></i>
                            </div>
                        </a>
                        
                        <a href="{$MESSAGING_URL|default:'{$smarty.const.URL}/user/messaging'}" class="mineless-shortcut-card">
                            <div class="mineless-shortcut-icon adv-icon-blue">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <span class="mineless-shortcut-label">Messages</span>
                            {if isset($MESSAGES_UNREAD) && $MESSAGES_UNREAD > 0}
                                <span class="mineless-shortcut-badge">{$MESSAGES_UNREAD}</span>
                            {/if}
                            <div class="mineless-shortcut-hover">
                                <i class="fas fa-arrow-right"></i>
                            </div>
                        </a>
                        
                        <a href="{$CONNECTIONS_URL|default:'{$smarty.const.URL}/user/connections'}" class="mineless-shortcut-card">
                            <div class="mineless-shortcut-icon adv-icon-green">
                                <i class="fas fa-link"></i>
                            </div>
                            <span class="mineless-shortcut-label">Connections</span>
                            <div class="mineless-shortcut-hover">
                                <i class="fas fa-arrow-right"></i>
                            </div>
                        </a>
                        
                        <a href="{$PROFILE_URL|default:'{$smarty.const.URL}/profile/{$USERNAME}'}" class="mineless-shortcut-card">
                            <div class="mineless-shortcut-icon adv-icon-purple">
                                <i class="fas fa-user-circle"></i>
                            </div>
                            <span class="mineless-shortcut-label">Profile</span>
                            <div class="mineless-shortcut-hover">
                                <i class="fas fa-external-link-alt"></i>
                            </div>
                        </a>
                    </div>
                </section>
            </div>
            
            {* Recent Activity Timeline *}
            <section class="mineless-section adv-activity-section">
                <div class="mineless-section-header">
                    <h2><i class="fas fa-history"></i> Aktivitas Terbaru</h2>
                </div>
                
                <div class="mineless-activity-timeline">
                    {if isset($RECENT_ACTIVITY) && is_array($RECENT_ACTIVITY) && count($RECENT_ACTIVITY) > 0}
                        {foreach from=$RECENT_ACTIVITY item=activity}
                            <div class="mineless-timeline-item">
                                <div class="mineless-timeline-marker">
                                    <i class="fas fa-{if $activity.type == 'post'}comment{elseif $activity.type == 'reaction'}heart{elseif $activity.type == 'trophy'}trophy{else}circle{/if}"></i>
                                </div>
                                <div class="mineless-timeline-content">
                                    <p class="mineless-timeline-text">{$activity.description}</p>
                                    <span class="mineless-timeline-time" data-timestamp="{$activity.time}">
                                        {$activity.time_friendly|default:$activity.time}
                                    </span>
                                </div>
                            </div>
                        {/foreach}
                    {else}
                        <div class="mineless-empty-state">
                            <i class="fas fa-history"></i>
                            <p>Belum ada aktivitas terbaru</p>
                        </div>
                    {/if}
                </div>
            </section>
        </div>
    </main>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Counter Animation
    const counters = document.querySelectorAll('.counter');
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 1500;
        const increment = target / (duration / 16);
        let current = 0;
        
        const updateCounter = () => {
            current += increment;
            if (current < target) {
                counter.textContent = Math.floor(current).toLocaleString();
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target.toLocaleString();
            }
        };
        
        // Start animation when element is in view
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    updateCounter();
                    observer.unobserve(entry.target);
                }
            });
        });
        
        observer.observe(counter);
    });
    
    // Mark as Read functionality
    document.querySelectorAll('.mineless-mark-read-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const item = this.closest('.mineless-notification-item');
            const alertId = this.getAttribute('data-id');
            
            // Animate out
            item.style.transform = 'translateX(100%)';
            item.style.opacity = '0';
            
            setTimeout(() => {
                item.classList.remove('unread');
                this.remove();
                item.style.transform = '';
                item.style.opacity = '';
            }, 300);
            
            // AJAX request to mark as read
            fetch('{$smarty.const.URL}/user/alerts/mark_read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'id=' + alertId + '&token={$TOKEN}'
            });
        });
    });
});
</script>
