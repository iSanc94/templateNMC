{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-status-section">
    <div class="mineless-container">
        <h1 class="mineless-page-title"><i class="fas fa-heartbeat"></i> {$SERVER_STATUS}</h1>
        
        <div class="mineless-status-grid">
            <!-- Main Status Card -->
            <div class="mineless-status-card main">
                <div class="mineless-status-indicator-large {if $SERVER_ONLINE}online{else}offline{/if}">
                    <div class="mineless-pulse-ring"></div>
                    <i class="fas fa-{if $SERVER_ONLINE}check{else}times{/if}"></i>
                </div>
                <h2>{if $SERVER_ONLINE}{$SERVER_ONLINE_TEXT}{else}{$SERVER_OFFLINE_TEXT}{/if}</h2>
                <p>{$SERVER_IP}{if $SERVER_PORT}:{$SERVER_PORT}{/if}</p>
            </div>
            
            <!-- Stats -->
            <div class="mineless-status-card">
                <h3><i class="fas fa-users"></i> Pemain Online</h3>
                <div class="mineless-stat-display">
                    <span class="mineless-stat-value">{$ONLINE_PLAYERS}</span>
                    <span class="mineless-stat-separator">/</span>
                    <span class="mineless-stat-max">{$MAX_PLAYERS}</span>
                </div>
                <div class="mineless-progress-bar">
                    <div class="mineless-progress-fill" style="width: {$ONLINE_PLAYERS/$MAX_PLAYERS*100}%"></div>
                </div>
            </div>
            
            <div class="mineless-status-card">
                <h3><i class="fas fa-clock"></i> Uptime</h3>
                <div class="mineless-uptime-display">
                    <span class="mineless-uptime-value" id="uptime">{$UPTIME}</span>
                </div>
                <div class="mineless-uptime-chart">
                    <div class="mineless-uptime-bar" style="height: {$UPTIME_PERCENT}%"></div>
                </div>
                <span class="mineless-uptime-percent">{$UPTIME_PERCENT}%</span>
            </div>
            
            <!-- Player List -->
            <div class="mineless-status-card wide">
                <h3><i class="fas fa-list"></i> {$ONLINE_PLAYERS_LIST}</h3>
                {if isset($PLAYER_LIST) && is_array($PLAYER_LIST) && count($PLAYER_LIST) > 0}
                    <div class="mineless-player-grid">
                        {foreach from=$PLAYER_LIST item=player}
                            <div class="mineless-player-item">
                                <img src="https://crafatar.com/avatars/{$player.uuid}?size=32&overlay" alt="{$player.name}">
                                <span>{$player.name}</span>
                            </div>
                        {/foreach}
                    </div>
                {else}
                    <p class="mineless-empty">{$NO_PLAYERS}</p>
                {/if}
            </div>
        </div>
        
        <div class="mineless-auto-refresh">
            <i class="fas fa-sync-alt fa-spin"></i>
            <span>Refresh otomatis dalam <span id="refresh-timer">30</span>s</span>
        </div>
    </div>
</section>

<style>
.mineless-status-section {
    min-height: 100vh;
    padding: 4rem 0;
    background: var(--bg-primary);
}

.mineless-container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 0 1.5rem;
}

.mineless-page-title {
    font-family: var(--font-display);
    font-size: 2.5rem;
    color: var(--text-primary);
    text-align: center;
    margin-bottom: 2rem;
}

.mineless-page-title i {
    color: var(--mineless-gold);
}

.mineless-status-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
}

.mineless-status-card {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    padding: 2rem;
    text-align: center;
}

.mineless-status-card.main {
    grid-column: 1 / -1;
}

.mineless-status-card.wide {
    grid-column: 1 / -1;
}

.mineless-status-card h3 {
    font-family: var(--font-display);
    font-size: 1rem;
    color: var(--text-secondary);
    margin: 0 0 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.mineless-status-card h3 i {
    color: var(--mineless-gold);
}

.mineless-status-indicator-large {
    width: 100px;
    height: 100px;
    margin: 0 auto 1.5rem;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    position: relative;
}

.mineless-status-indicator-large.online {
    background: rgba(40, 167, 69, 0.1);
    color: #28a745;
}

.mineless-status-indicator-large.offline {
    background: rgba(220, 53, 69, 0.1);
    color: #dc3545;
}

.mineless-pulse-ring {
    position: absolute;
    inset: 0;
    border-radius: 50%;
    animation: pulse 2s infinite;
}

.mineless-status-indicator-large.online .mineless-pulse-ring {
    border: 2px solid #28a745;
}

.mineless-status-indicator-large.offline .mineless-pulse-ring {
    border: 2px solid #dc3545;
}

@keyframes pulse {
    0% { transform: scale(1); opacity: 1; }
    100% { transform: scale(1.3); opacity: 0; }
}

.mineless-stat-display {
    font-family: var(--font-display);
    font-size: 3rem;
    margin-bottom: 1rem;
}

.mineless-stat-value {
    color: var(--mineless-gold);
}

.mineless-stat-separator {
    color: var(--text-secondary);
    margin: 0 0.5rem;
}

.mineless-stat-max {
    color: var(--text-secondary);
}

.mineless-progress-bar {
    height: 8px;
    background: var(--bg-secondary);
    border-radius: 4px;
    overflow: hidden;
}

.mineless-progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 4px;
}

.mineless-uptime-display {
    font-family: var(--font-display);
    font-size: 2rem;
    color: var(--mineless-gold);
    margin-bottom: 1rem;
}

.mineless-uptime-chart {
    width: 60px;
    height: 100px;
    margin: 0 auto;
    background: var(--bg-secondary);
    border-radius: 4px;
    position: relative;
    overflow: hidden;
}

.mineless-uptime-bar {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(180deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 0 0 4px 4px;
}

.mineless-uptime-percent {
    display: block;
    margin-top: 0.5rem;
    font-size: 1.5rem;
    color: var(--mineless-gold);
    font-weight: 600;
}

.mineless-player-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 1rem;
    margin-top: 1rem;
}

.mineless-player-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem;
    background: var(--bg-secondary);
    border-radius: var(--radius-md);
}

.mineless-player-item img {
    width: 32px;
    height: 32px;
    border-radius: 4px;
}

.mineless-player-item span {
    color: var(--text-primary);
    font-weight: 500;
}

.mineless-empty {
    color: var(--text-secondary);
    padding: 2rem;
}

.mineless-auto-refresh {
    text-align: center;
    margin-top: 2rem;
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.mineless-auto-refresh i {
    color: var(--mineless-gold);
    margin-right: 0.5rem;
}

@media (max-width: 768px) {
    .mineless-status-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
// Auto refresh countdown
let seconds = 30;
const timer = document.getElementById('refresh-timer');

setInterval(() => {
    seconds--;
    if (timer) timer.textContent = seconds;
    if (seconds <= 0) {
        location.reload();
    }
}, 1000);

// Server status polling
setInterval(() => {
    fetch('{$SITE_URL}/queries/server/?ip={$SERVER_IP}')
        .then(r => r.json())
        .then(data => {
            // Update status display
        });
}, 30000);
</script>

{include file='footer.tpl'}