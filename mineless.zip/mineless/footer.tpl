{* NamelessMC Mineless Template - footer.tpl *}
{* Dark Fantasy Mineless Theme *}

    </div>{* /.mineless-content *}
</main>{* /.mineless-main *}

{* Medieval Rune Ornament Divider *}
<div class="mineless-rune-ornament">
    <svg viewBox="0 0 1200 60" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">
        <defs>
            <linearGradient id="runeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" style="stop-color:var(--mineless-rune-fade);stop-opacity:0" />
                <stop offset="50%" style="stop-color:var(--mineless-rune-color);stop-opacity:1" />
                <stop offset="100%" style="stop-color:var(--mineless-rune-fade);stop-opacity:0" />
            </linearGradient>
        </defs>
        {* Center Rune Circle *}
        <circle cx="600" cy="30" r="20" fill="none" stroke="url(#runeGradient)" stroke-width="2"/>
        <circle cx="600" cy="30" r="12" fill="none" stroke="url(#runeGradient)" stroke-width="1"/>
        <text x="600" y="36" text-anchor="middle" fill="url(#runeGradient)" font-size="16" font-family="serif">ᚦ</text>
        {* Left Runes *}
        <text x="520" y="36" text-anchor="middle" fill="url(#runeGradient)" font-size="14" font-family="serif">ᚩ</text>
        <text x="480" y="36" text-anchor="middle" fill="url(#runeGradient)" font-size="12" font-family="serif">ᚱ</text>
        <text x="440" y="36" text-anchor="middle" fill="url(#runeGradient)" font-size="10" font-family="serif">ᚢ</text>
        <text x="400" y="36" text-anchor="middle" fill="url(#runeGradient)" font-size="8" font-family="serif">ᚾ</text>
        {* Right Runes *}
        <text x="680" y="36" text-anchor="middle" fill="url(#runeGradient)" font-size="14" font-family="serif">ᚩ</text>
        <text x="720" y="36" text-anchor="middle" fill="url(#runeGradient)" font-size="12" font-family="serif">ᚱ</text>
        <text x="760" y="36" text-anchor="middle" fill="url(#runeGradient)" font-size="10" font-family="serif">ᚢ</text>
        <text x="800" y="36" text-anchor="middle" fill="url(#runeGradient)" font-size="8" font-family="serif">ᚾ</text>
        {* Decorative Lines *}
        <line x1="100" y1="30" x2="380" y2="30" stroke="url(#runeGradient)" stroke-width="1"/>
        <line x1="820" y1="30" x2="1100" y2="30" stroke="url(#runeGradient)" stroke-width="1"/>
        {* Corner Decorations *}
        <path d="M 50 30 L 80 20 L 80 40 Z" fill="url(#runeGradient)" opacity="0.5"/>
        <path d="M 1150 30 L 1120 20 L 1120 40 Z" fill="url(#runeGradient)" opacity="0.5"/>
    </svg>
</div>

{* Footer Section *}
<footer class="mineless-footer">
    {* Floating Particles Background *}
    <div class="mineless-footer-particles" aria-hidden="true">
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
        <div class="mineless-particle"></div>
    </div>

    <div class="mineless-footer-container">
        {* 4 Column Layout *}
        <div class="mineless-footer-grid">
            {* Column 1: Logo & Tagline *}
            <div class="mineless-footer-col adv-footer-brand">
                <div class="mineless-footer-logo">
                    <div class="mineless-footer-logo-fallback">
                        <span class="mineless-logo-icon">⚔</span>
                        <span class="mineless-logo-text">{$SITE_NAME}</span>
                    </div>
                </div>
                <p class="mineless-footer-tagline">Forge Your Legend</p>
                <p class="mineless-footer-desc">
                    Embark on an epic journey through mystical realms. Build, explore, and conquer in our immersive Minecraft Mineless world.
                </p>
                <div class="mineless-footer-mood">
                    <span class="mineless-moon-phase">🌙</span>
                    <span class="mineless-mood-text">The adventure awaits...</span>
                </div>
            </div>

            {* Column 2: Quick Links *}
            <div class="mineless-footer-col adv-footer-links">
                <h4 class="mineless-footer-heading">
                    <span class="mineless-heading-icon">⛓</span>
                    Quick Links
                </h4>
                {if isset($FOOTER_NAVIGATION) && is_array($FOOTER_NAVIGATION) && count($FOOTER_NAVIGATION) > 0}
                    <ul class="mineless-footer-nav">
                        {foreach from=$FOOTER_NAVIGATION item=item}
                            <li>
                                <a href="{$item.link}" class="mineless-footer-link" {if $item.external}target="_blank" rel="noopener"{/if}>
                                    <span class="mineless-link-rune">›</span>
                                    {$item.title}
                                </a>
                            </li>
                        {/foreach}
                    </ul>
                {else}
                    <ul class="mineless-footer-nav">
                        <li><a href="{$SITE_URL}/play" class="mineless-footer-link"><span class="mineless-link-rune">›</span> Play Now</a></li>
                        <li><a href="{$SITE_URL}/forum" class="mineless-footer-link"><span class="mineless-link-rune">›</span> Community</a></li>
                        <li><a href="{$SITE_URL}/rules" class="mineless-footer-link"><span class="mineless-link-rune">›</span> Server Rules</a></li>
                        <li><a href="{$SITE_URL}/vote" class="mineless-footer-link"><span class="mineless-link-rune">›</span> Vote for Us</a></li>
                        <li><a href="{$SITE_URL}/store" class="mineless-footer-link"><span class="mineless-link-rune">›</span> Store</a></li>
                        <li><a href="{$SITE_URL}/staff" class="mineless-footer-link"><span class="mineless-link-rune">›</span> Our Team</a></li>
                    </ul>
                {/if}
            </div>

            {* Column 3: Social Media *}
            <div class="mineless-footer-col adv-footer-social">
                <h4 class="mineless-footer-heading">
                    <span class="mineless-heading-icon">📜</span>
                    Join the Guild
                </h4>
                {if isset($SOCIAL_MEDIA_ICONS) && is_array($SOCIAL_MEDIA_ICONS) && count($SOCIAL_MEDIA_ICONS) > 0}
                    <div class="mineless-social-grid">
                        {foreach from=$SOCIAL_MEDIA_ICONS item=social}
                            <a href="{$social.link}" class="mineless-social-link adv-social-{$social.name|lower}" target="_blank" rel="noopener" title="{$social.name}">
                                        <span class="mineless-social-icon">
                                            {if $social.name|lower eq 'discord'}🎮
                                            {elseif $social.name|lower eq 'twitter' || $social.name|lower eq 'x'}🐦
                                            {elseif $social.name|lower eq 'youtube'}📺
                                            {elseif $social.name|lower eq 'tiktok'}🎵
                                            {elseif $social.name|lower eq 'instagram'}📷
                                            {elseif $social.name|lower eq 'facebook'}📘
                                            {elseif $social.name|lower eq 'twitch'}📡
                                            {elseif $social.name|lower eq 'reddit'}🔴
                                            {elseif $social.name|lower eq 'github'}🐙
                                            {else}🔗{/if}
                                        </span>
                                <span class="mineless-social-name">{$social.name}</span>
                            </a>
                        {/foreach}
                    </div>
                {else}
                    <div class="mineless-social-grid">
                        <a href="#" class="mineless-social-link adv-social-discord" target="_blank" rel="noopener">
                            <span class="mineless-social-icon">🎮</span>
                            <span class="mineless-social-name">Discord</span>
                        </a>
                        <a href="#" class="mineless-social-link adv-social-twitter" target="_blank" rel="noopener">
                            <span class="mineless-social-icon">🐦</span>
                            <span class="mineless-social-name">Twitter/X</span>
                        </a>
                        <a href="#" class="mineless-social-link adv-social-youtube" target="_blank" rel="noopener">
                            <span class="mineless-social-icon">📺</span>
                            <span class="mineless-social-name">YouTube</span>
                        </a>
                        <a href="#" class="mineless-social-link adv-social-tiktok" target="_blank" rel="noopener">
                            <span class="mineless-social-icon">🎵</span>
                            <span class="mineless-social-name">TikTok</span>
                        </a>
                        <a href="#" class="mineless-social-link adv-social-instagram" target="_blank" rel="noopener">
                            <span class="mineless-social-icon">📷</span>
                            <span class="mineless-social-name">Instagram</span>
                        </a>
                    </div>
                {/if}
                <p class="mineless-social-cta">Connect with fellow Minelessrs!</p>
            </div>

            {* Column 4: Server Status *}
            <div class="mineless-footer-col adv-footer-status">
                <h4 class="mineless-footer-heading">
                    <span class="mineless-heading-icon">🏰</span>
                    Realm Status
                </h4>
                <div class="mineless-status-card">
                    <div class="mineless-status-header">
                        <div class="mineless-status-indicator">
                            <span class="mineless-status-dot" id="serverStatusDot"></span>
                            <span class="mineless-status-pulse"></span>
                        </div>
                        <span class="mineless-status-text" id="serverStatusText">Checking...</span>
                    </div>
                    <div class="mineless-server-ip-box">
                        <code class="mineless-server-ip" id="serverIP">play.{$SITE_NAME|lower|replace:' ':''}.net</code>
                        <button class="mineless-copy-btn" onclick="copyServerIP()" title="Copy IP">
                            <span class="mineless-copy-icon">📋</span>
                        </button>
                    </div>
                    <div class="mineless-player-count" id="playerCount">
                        <span class="mineless-players-icon">👥</span>
                        <span class="mineless-players-online">-</span>
                        <span class="mineless-players-separator">/</span>
                        <span class="mineless-players-max">-</span>
                        <span class="mineless-players-label">explorers</span>
                    </div>
                    <div class="mineless-server-version">
                        <span class="mineless-version-label">Version:</span>
                        <span class="mineless-version-value">1.20.x</span>
                    </div>
                </div>
                <div class="mineless-status-refresh">
                    <span class="mineless-refresh-icon">🔄</span>
                    <span class="mineless-refresh-text">Auto-refreshing</span>
                </div>
            </div>
        </div>

        {* Discord CTA Banner *}
        <div class="mineless-discord-cta">
            <div class="mineless-discord-bg" aria-hidden="true">
                <div class="mineless-discord-pattern"></div>
            </div>
            <div class="mineless-discord-content">
                <div class="mineless-discord-icon">
                    <span>🎮</span>
                </div>
                <div class="mineless-discord-text">
                    <h5>Join Our Discord Guild</h5>
                    <p>Connect with {$SITE_NAME} community, get updates, and find party members!</p>
                </div>
                <a href="{$SITE_URL}/discord" class="mineless-discord-btn" target="_blank" rel="noopener">
                    <span class="mineless-btn-icon">⚔</span>
                    <span class="mineless-btn-text">Join the Adventure</span>
                </a>
            </div>
        </div>

        {* Footer Bottom *}
        <div class="mineless-footer-bottom">
            <div class="mineless-footer-divider">
                <span class="mineless-divider-rune">❦</span>
            </div>

            <div class="mineless-footer-bottom-content">
                <div class="mineless-footer-legal">
                    <p class="mineless-copyright">
                        &copy; {$smarty.now|date_format:"%Y"} {$SITE_NAME}. All rights reserved.
                    </p>
                    <div class="mineless-footer-links-legal">
                        {if isset($TERMS_LINK)}
                            <a href="{$TERMS_LINK}" class="mineless-legal-link">Terms of Service</a>
                        {/if}
                        {if isset($PRIVACY_LINK)}
                            <a href="{$PRIVACY_LINK}" class="mineless-legal-link">Privacy Policy</a>
                        {/if}
                        <a href="{$SITE_URL}/cookies" class="mineless-legal-link">Cookie Policy</a>
                    </div>
                </div>

                <div class="mineless-footer-credits">
                    <p class="mineless-powered-by">
                        Powered by <a href="https://namelessmc.com" target="_blank" rel="noopener">NamelessMC</a>
                    </p>
                    {if isset($PAGE_LOAD_TIME)}
                        <p class="mineless-page-stats">
                            <span class="mineless-stats-item">
                                <span class="mineless-stats-icon">⚡</span>
                                {$PAGE_LOAD_TIME}s
                            </span>
                        </p>
                    {/if}
                </div>
            </div>

            {* Dark/Light Mode Toggle *}
            <div class="mineless-theme-toggle-wrapper">
                <form action="{$DARK_LIGHT_MODE_ACTION}" method="post" class="mineless-theme-form">
                    <input type="hidden" name="token" value="{$DARK_LIGHT_MODE_TOKEN}">
                    <button type="submit" class="mineless-theme-toggle" title="Toggle Dark/Light Mode">
                        <span class="mineless-theme-icon adv-theme-sun">☀️</span>
                        <span class="mineless-theme-icon adv-theme-moon">🌙</span>
                        <span class="mineless-theme-slider"></span>
                    </button>
                </form>
            </div>
        </div>
    </div>
</footer>

{* Back to Top Button *}
<button class="mineless-back-to-top" id="backToTop" onclick="scrollToTop()" aria-label="Back to top">
    <span class="mineless-backtop-icon">▲</span>
    <span class="mineless-backtop-rings" aria-hidden="true"></span>
</button>

{* Global Warning Modal *}
{if isset($GLOBAL_WARNING_TITLE)}
    <div class="mineless-modal-overlay" id="globalWarningModal">
        <div class="mineless-modal adv-modal-warning">
            <div class="mineless-modal-header">
                <span class="mineless-modal-icon">⚠️</span>
                <h3 class="mineless-modal-title">{$GLOBAL_WARNING_TITLE}</h3>
            </div>
            <div class="mineless-modal-body">
                {if isset($GLOBAL_WARNING_REASON)}
                    <p class="mineless-modal-text">{$GLOBAL_WARNING_REASON}</p>
                {/if}
                {if isset($GLOBAL_WARNING_EXPIRES) && $GLOBAL_WARNING_EXPIRES neq 'Never'}
                    <p class="mineless-modal-expires">
                        <span class="mineless-expires-label">Expires:</span>
                        <span class="mineless-expires-value">{$GLOBAL_WARNING_EXPIRES}</span>
                    </p>
                {/if}
            </div>
            <div class="mineless-modal-footer">
                <button class="mineless-modal-btn adv-modal-btn-primary" onclick="dismissWarningModal()">
                    I Understand
                </button>
            </div>
        </div>
    </div>
{/if}

{* Scripts *}
<script>
    {* Server Status Update *}
    function updateServerStatus() {
        const dot = document.getElementById('serverStatusDot');
        const text = document.getElementById('serverStatusText');
        const online = document.querySelector('.mineless-players-online');
        const max = document.querySelector('.mineless-players-max');

        fetch('{$SITE_URL}/queries/server/')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'online') {
                    dot.classList.add('online');
                    dot.classList.remove('offline');
                    text.textContent = 'Online';
                    online.textContent = data.players.online || 0;
                    max.textContent = data.players.max || 0;
                } else {
                    dot.classList.add('offline');
                    dot.classList.remove('online');
                    text.textContent = 'Offline';
                    online.textContent = '0';
                    max.textContent = '0';
                }
            })
            .catch(() => {
                dot.classList.add('offline');
                dot.classList.remove('online');
                text.textContent = 'Unknown';
            });
    }

    {* Copy Server IP *}
    function copyServerIP() {
        const ip = document.getElementById('serverIP').textContent;
        navigator.clipboard.writeText(ip).then(() => {
            const btn = document.querySelector('.mineless-copy-btn');
            const original = btn.innerHTML;
            btn.innerHTML = '<span class="mineless-copy-icon">✓</span>';
            setTimeout(() => btn.innerHTML = original, 2000);
        });
    }

    {* Back to Top Smooth Scroll *}
    function scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }

    {* Back to Top Visibility *}
    function handleScroll() {
        const btn = document.getElementById('backToTop');
        if (window.scrollY > 300) {
            btn.classList.add('visible');
        } else {
            btn.classList.remove('visible');
        }
    }

    {* Warning Modal Dismiss *}
    function dismissWarningModal() {
        const modal = document.getElementById('globalWarningModal');
        modal.style.opacity = '0';
        setTimeout(() => modal.remove(), 300);
    }

    {* Initialize *}
    document.addEventListener('DOMContentLoaded', function() {
        {* Server Status *}
        if (document.getElementById('serverStatusDot')) {
            updateServerStatus();
            setInterval(updateServerStatus, 30000);
        }

        {* Scroll Handler *}
        window.addEventListener('scroll', handleScroll, { passive: true });

        {* Warning Modal *}
        {if isset($GLOBAL_WARNING_TITLE)}
            document.getElementById('globalWarningModal').style.display = 'flex';
        {/if}
        
        {* Typed.js Animation *}
        const typedElement = document.getElementById('typed-text');
        if (typedElement && typeof Typed !== 'undefined') {
            new Typed('#typed-text', {
                strings: ['Creative', 'Survival', 'Adventure', 'PvP', 'Minigames'],
                typeSpeed: 80,
                backSpeed: 50,
                backDelay: 2000,
                startDelay: 500,
                loop: true,
                showCursor: true,
                cursorChar: '|',
                smartBackspace: true
            });
        }
        
        {* Particles.js *}
        const particlesContainer = document.getElementById('particles-js');
        if (particlesContainer && typeof particlesJS !== 'undefined') {
            particlesJS('particles-js', {
                particles: {
                    number: { value: 60, density: { enable: true, value_area: 800 } },
                    color: { value: '#D4AF37' },
                    shape: { type: 'circle' },
                    opacity: { value: 0.3, random: true, anim: { enable: true, speed: 1, opacity_min: 0.1, sync: false } },
                    size: { value: 2, random: true, anim: { enable: true, speed: 2, size_min: 0.1, sync: false } },
                    line_linked: { enable: true, distance: 150, color: '#D4AF37', opacity: 0.1, width: 1 },
                    move: { enable: true, speed: 0.5, direction: 'none', random: true, straight: false, out_mode: 'out', bounce: false }
                },
                interactivity: {
                    detect_on: 'canvas',
                    events: { onhover: { enable: true, mode: 'grab' }, onclick: { enable: true, mode: 'push' }, resize: true },
                    modes: { grab: { distance: 140, line_linked: { opacity: 0.3 } }, push: { particles_nb: 4 } }
                },
                retina_detect: true
            });
        }
        
        {* Parallax Effect *}
        const parallaxLayers = document.querySelectorAll('.mineless-hero-layer');
        if (parallaxLayers.length > 0 && !window.matchMedia('(pointer: coarse)').matches) {
            window.addEventListener('scroll', function() {
                const scrolled = window.pageYOffset;
                parallaxLayers.forEach(layer => {
                    const speed = layer.dataset.speed || 0.5;
                    const yPos = -(scrolled * speed);
                    layer.style.transform = 'translateY(' + yPos + 'px)';
                });
            }, { passive: true });
        }
    });
</script>

{* Template JS Files *}
{if isset($TEMPLATE_JS) && is_array($TEMPLATE_JS) && count($TEMPLATE_JS) > 0}
    {foreach from=$TEMPLATE_JS item=script}
        {if is_array($script)}
            <script src="{$script.src}"{if isset($script.async)} async{/if}{if isset($script.defer)} defer{/if}></script>
        {else}
            <script src="{$script}"></script>
        {/if}
    {/foreach}
{/if}

{* Debug Bar *}
{if isset($DEBUGBAR_JS)}
    {$DEBUGBAR_JS}
{/if}

</body>
</html>
