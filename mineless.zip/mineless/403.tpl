{include file='header.tpl'}

<section class="mineless-error-section">
    <div class="mineless-error-bg">
        <div class="mineless-dungeon-overlay"></div>
        <div class="mineless-chains">
            <div class="mineless-chain left"></div>
            <div class="mineless-chain right"></div>
        </div>
        <div class="mineless-torch left">
            <div class="mineless-flame"></div>
        </div>
        <div class="mineless-torch right">
            <div class="mineless-flame"></div>
        </div>
    </div>
    
    <div class="mineless-error-container">
        <div class="mineless-error-content">
            <!-- Dungeon Guard -->
            <div class="mineless-guard-svg">
                <svg viewBox="0 0 200 250">
                    <defs>
                        <linearGradient id="armor" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" style="stop-color:#5a5a5a"/>
                            <stop offset="100%" style="stop-color:#2a2a2a"/>
                        </linearGradient>
                    </defs>
                    <!-- Guard Body -->
                    <ellipse cx="100" cy="200" rx="60" ry="40" fill="url(#armor)"/>
                    <!-- Guard Head -->
                    <circle cx="100" cy="120" r="50" fill="url(#armor)"/>
                    <!-- Helmet -->
                    <path d="M50,100 Q100,50 150,100 L150,130 Q100,150 50,130 Z" fill="#3a3a3a"/>
                    <!-- Eyes (glowing red) -->
                    <circle cx="80" cy="115" r="8" fill="#ff0000">
                        <animate attributeName="opacity" values="0.5;1;0.5" dur="2s" repeatCount="indefinite"/>
                    </circle>
                    <circle cx="120" cy="115" r="8" fill="#ff0000">
                        <animate attributeName="opacity" values="0.5;1;0.5" dur="2s" repeatCount="indefinite"/>
                    </circle>
                    <!-- Spear -->
                    <rect x="95" y="40" width="10" height="180" fill="#8B6914"/>
                    <path d="M90,40 L100,10 L110,40 Z" fill="#C0C0C0"/>
                </svg>
            </div>
            
            <!-- Lock Icon -->
            <div class="mineless-error-icon">
                <i class="fas fa-lock"></i>
                <div class="mineless-lock-shake">
                    <i class="fas fa-key"></i>
                </div>
            </div>
            
            <h1 class="mineless-error-code">403</h1>
            <h2 class="mineless-error-title">Akses Ditolak</h2>
            <p class="mineless-error-message">
                Seperti petualang yang mencoba memasuki dungeon tanpa izin, kamu tidak memiliki akses ke area ini.
            </p>
            
            <div class="mineless-error-actions">
                <a href="{$SITE_HOME}" class="mineless-btn adv-btn-primary">
                    <i class="fas fa-home"></i>
                    <span>Kembali ke Permukaan</span>
                </a>
                <a href="javascript:history.back()" class="mineless-btn adv-btn-outline">
                    <i class="fas fa-arrow-left"></i>
                    <span>Mundur Perlahan</span>
                </a>
            </div>
            
            <div class="mineless-error-runes">
                <span>ᚦ</span>
                <span>ᚩ</span>
                <span>ᚱ</span>
                <span>ᚢ</span>
                <span>ᚾ</span>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-error-section {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #0a0a0f;
    position: relative;
    overflow: hidden;
}

.mineless-error-bg {
    position: absolute;
    inset: 0;
    background: 
        radial-gradient(ellipse at center, rgba(139,0,0,0.1) 0%, transparent 70%),
        linear-gradient(180deg, #0a0a0f 0%, #1a0505 100%);
}

.mineless-dungeon-overlay {
    position: absolute;
    inset: 0;
    background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
    opacity: 0.5;
}

.mineless-chains {
    position: absolute;
    inset: 0;
    pointer-events: none;
}

.mineless-chain {
    position: absolute;
    top: -50px;
    width: 30px;
    height: 200px;
    background: repeating-linear-gradient(
        0deg,
        #4a4a4a 0px,
        #2a2a2a 10px,
        #4a4a4a 20px
    );
    animation: chainSway 4s ease-in-out infinite;
}

.mineless-chain.left {
    left: 15%;
}

.mineless-chain.right {
    right: 15%;
    animation-delay: -2s;
}

@keyframes chainSway {
    0%, 100% { transform: rotate(-5deg); }
    50% { transform: rotate(5deg); }
}

.mineless-torch {
    position: absolute;
    bottom: 20%;
    width: 20px;
    height: 100px;
    background: linear-gradient(90deg, #4a3728, #2a1f18);
}

.mineless-torch.left { left: 10%; }
.mineless-torch.right { right: 10%; }

.mineless-flame {
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
    width: 30px;
    height: 40px;
    background: linear-gradient(180deg, #ffdd00, #ff6600, transparent);
    border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%;
    animation: flameFlicker 0.5s ease-in-out infinite alternate;
    filter: blur(2px);
}

@keyframes flameFlicker {
    0% { transform: translateX(-50%) scaleY(1) scaleX(1); }
    100% { transform: translateX(-50%) scaleY(1.1) scaleX(0.9); }
}

.mineless-error-container {
    position: relative;
    z-index: 10;
    text-align: center;
    padding: 2rem;
}

.mineless-guard-svg {
    width: 150px;
    height: 180px;
    margin: 0 auto 1rem;
    opacity: 0.3;
}

.mineless-error-icon {
    width: 120px;
    height: 120px;
    margin: 0 auto 2rem;
    background: linear-gradient(135deg, #8B0000, #4a0000);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    color: #ff6b6b;
    position: relative;
    box-shadow: 0 0 50px rgba(139,0,0,0.4);
}

.mineless-lock-shake {
    position: absolute;
    font-size: 1.5rem;
    color: var(--mineless-gold);
    animation: keyShake 0.5s ease-in-out infinite;
}

@keyframes keyShake {
    0%, 100% { transform: translate(15px, -15px) rotate(-20deg); }
    25% { transform: translate(20px, -10px) rotate(0deg); }
    50% { transform: translate(15px, -15px) rotate(20deg); }
    75% { transform: translate(10px, -10px) rotate(0deg); }
}

.mineless-error-code {
    font-family: var(--font-display);
    font-size: 8rem;
    font-weight: 700;
    background: linear-gradient(180deg, #ff6b6b, #8B0000);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1;
    text-shadow: 0 0 50px rgba(139,0,0,0.5);
    margin-bottom: 1rem;
}

.mineless-error-title {
    font-family: var(--font-display);
    font-size: 2rem;
    color: var(--text-primary);
    margin-bottom: 1rem;
}

.mineless-error-message {
    color: var(--text-secondary);
    font-size: 1.1rem;
    max-width: 500px;
    margin: 0 auto 2rem;
    line-height: 1.6;
}

.mineless-error-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
}

.mineless-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.875rem 1.5rem;
    border-radius: var(--radius-md);
    font-weight: 600;
    text-decoration: none;
    transition: var(--transition-fast);
    border: none;
    cursor: pointer;
    font-size: 1rem;
}

.mineless-btn-primary {
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    color: var(--bg-primary);
}

.mineless-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(212, 175, 55, 0.3);
}

.mineless-btn-outline {
    background: transparent;
    border: 2px solid rgba(212, 175, 55, 0.3);
    color: var(--mineless-gold);
}

.mineless-btn-outline:hover {
    border-color: var(--mineless-gold);
    background: rgba(212, 175, 55, 0.1);
}

.mineless-error-runes {
    margin-top: 3rem;
    display: flex;
    justify-content: center;
    gap: 1rem;
    opacity: 0.2;
}

.mineless-error-runes span {
    font-size: 1.5rem;
    color: var(--mineless-gold);
    animation: runePulse 2s ease-in-out infinite;
}

.mineless-error-runes span:nth-child(2) { animation-delay: -0.4s; }
.mineless-error-runes span:nth-child(3) { animation-delay: -0.8s; }
.mineless-error-runes span:nth-child(4) { animation-delay: -1.2s; }
.mineless-error-runes span:nth-child(5) { animation-delay: -1.6s; }

@keyframes runePulse {
    0%, 100% { opacity: 0.2; }
    50% { opacity: 0.5; }
}

@media (max-width: 768px) {
    .mineless-error-code {
        font-size: 5rem;
    }
    
    .mineless-error-title {
        font-size: 1.5rem;
    }
    
    .mineless-chain, .mineless-torch {
        display: none;
    }
}
</style>

{include file='footer.tpl'}