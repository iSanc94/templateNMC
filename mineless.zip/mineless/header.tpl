{* Mineless Theme - Header Template *}
{* NamelessMC v2 Compatible *}

{* Conditional HTML attributes *}
{if isset($HTML_CLASS)}
    {assign var="HTML_CLASS_ATTR" value=" class=`$HTML_CLASS`"}
{else}
    {assign var="HTML_CLASS_ATTR" value=""}
{/if}

{if isset($HTML_LANG)}
    {assign var="HTML_LANG_ATTR" value=" lang=`$HTML_LANG`"}
{else}
    {assign var="HTML_LANG_ATTR" value=" lang=\"en\""}
{/if}

{if isset($HTMLRTL) && $HTMLRTL}
    {assign var="HTML_DIR_ATTR" value=" dir=\"rtl\""}
{else}
    {assign var="HTML_DIR_ATTR" value=""}
{/if}

{if isset($METACHARSET)}
    {assign var="META_CHARSET_VALUE" value=$METACHARSET}
{else}
    {assign var="META_CHARSET_VALUE" value="UTF-8"}
{/if}

{if isset($PAGEDESCRIPTION)}
    {assign var="PAGE_DESC_VALUE" value=$PAGEDESCRIPTION}
{else}
    {assign var="PAGE_DESC_VALUE" value=$smarty.const.SITE_NAME}
{/if}

{if isset($PAGEKEYWORDS)}
    {assign var="PAGE_KEYWORDS_VALUE" value=$PAGEKEYWORDS}
{else}
    {assign var="PAGE_KEYWORDS_VALUE" value="minecraft, server, gaming, community"}
{/if}

<!DOCTYPE html>
<html{$HTML_CLASS_ATTR}{$HTML_LANG_ATTR}{$HTML_DIR_ATTR}>
<head>
    {* Meta Tags *}
    <meta charset="{$META_CHARSET_VALUE}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    {* Page Title *}
    <title>{$TITLE} • {$smarty.const.SITE_NAME}</title>
    
    {* Favicon *}
    {if isset($FAVICON)}
        <link rel="shortcut icon" href="{$FAVICON}" type="image/x-icon">
        <link rel="icon" href="{$FAVICON}" type="image/x-icon">
    {/if}
    
    {* Meta Information *}
    <meta name="author" content="{$smarty.const.SITE_NAME}">
    <meta name="description" content="{$PAGE_DESC_VALUE}">
    <meta name="keywords" content="{$PAGE_KEYWORDS_VALUE}">
    <meta name="theme-color" content="#1a1a2e">
    <meta name="msapplication-TileColor" content="#1a1a2e">
    
    {* Open Graph Meta Tags *}
    <meta property="og:title" content="{$TITLE} • {$smarty.const.SITE_NAME}">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{$smarty.server.REQUEST_SCHEME}://{$smarty.server.HTTP_HOST}{$smarty.server.REQUEST_URI}">
    {if isset($OG_IMAGE)}
        <meta property="og:image" content="{$OG_IMAGE}">
    {else}
        <meta property="og:image" content="{$smarty.const.SITE_URL}/uploads/logo.png">
    {/if}
    <meta property="og:description" content="{$PAGE_DESC_VALUE}">
    <meta property="og:site_name" content="{$smarty.const.SITE_NAME}">
    
    {* Twitter Card Meta Tags *}
    <meta name="twitter:title" content="{$TITLE} • {$smarty.const.SITE_NAME}">
    <meta name="twitter:card" content="summary_large_image">
    {if isset($OG_IMAGE)}
        <meta name="twitter:image" content="{$OG_IMAGE}">
    {else}
        <meta name="twitter:image" content="{$smarty.const.SITE_URL}/uploads/logo.png">
    {/if}
    <meta name="twitter:description" content="{$PAGE_DESC_VALUE}">
    
    {* NamelessMC Head Tags Hook *}
    {$HEAD_TAGS}
    
    {* Preconnect for Performance *}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
    <link rel="preconnect" href="https://kit.fontawesome.com" crossorigin>
    <link rel="dns-prefetch" href="https://fonts.googleapis.com">
    <link rel="dns-prefetch" href="https://cdnjs.cloudflare.com">
    
    {* Critical CSS - Above The Fold (Inlining for Performance) *}
    {literal}<style>
    :root{--primary:#c9a227;--primary-dark:#a88420;--secondary:#1a1a2e;--accent:#16213e;--bg-dark:#0f0f1a;--text-light:#f5f5f5;--text-muted:#a0a0a0;--success:#4ade80;--error:#f87171;--warning:#fbbf24}
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    html{scroll-behavior:smooth}
    body{font-family:Inter,-apple-system,BlinkMacSystemFont,sans-serif;background:var(--bg-dark);color:var(--text-light);line-height:1.6;overflow-x:hidden;min-height:100vh}
    #loading-bar{position:fixed;top:0;left:0;width:0;height:3px;background:linear-gradient(90deg,var(--primary),var(--primary-dark));z-index:99999;transition:width .3s ease}
    #loading-bar.active{width:100%}
    .loading-spinner{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:50px;height:50px;border:3px solid rgba(201,162,39,.2);border-top-color:var(--primary);border-radius:50%;animation:spin 1s linear infinite;z-index:99998;opacity:0;pointer-events:none;transition:opacity .3s}
    .loading-spinner.active{opacity:1}
    @keyframes spin{to{transform:translate(-50%,-50%) rotate(360deg)}}
    #toast-container{position:fixed;top:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:10px;pointer-events:none}
    .toast{pointer-events:auto;background:var(--secondary);border-left:4px solid var(--primary);padding:15px 20px;border-radius:4px;box-shadow:0 4px 20px rgba(0,0,0,.4);transform:translateX(120%);animation:slideIn .3s ease forwards;min-width:300px;max-width:400px}
    .toast.success{border-left-color:var(--success)}
    .toast.error{border-left-color:var(--error)}
    .toast.warning{border-left-color:var(--warning)}
    @keyframes slideIn{to{transform:translateX(0)}}
    @keyframes slideOut{to{transform:translateX(120%);opacity:0}}
    .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
    </style>{/literal}
    
    {* Custom Theme CSS *}
    <link rel="stylesheet" href="{$TEMPLATE.path}/css/mineless.css?v=3">
    <link rel="stylesheet" href="{$TEMPLATE.path}/css/emergency-fix.css?v=1">
    
    {literal}<style>
    /* Critical CSS Fallback */
    .mineless-navbar{position:fixed;top:0;left:0;right:0;z-index:300;background:rgba(10,10,15,0.85);backdrop-filter:blur(12px);border-bottom:1px solid #2A2A3A}
    .mineless-navbar-inner{display:flex;align-items:center;justify-content:space-between;height:70px;max-width:1400px;margin:0 auto;padding:0 1.5rem}
    .mineless-logo{display:flex;align-items:center;gap:0.5rem;text-decoration:none}
    .mineless-logo-text{font-family:'Cinzel',serif;font-size:1.25rem;font-weight:700;color:#D4AF37;text-shadow:0 0 20px rgba(212,175,55,0.4)}
    .mineless-hero{position:relative;min-height:100vh;display:flex;align-items:center;justify-content:center;padding-top:70px;background:linear-gradient(135deg,#0A0A0F 0%,#0f1419 50%,#111118 100%);overflow:hidden}
    .mineless-hero-content{position:relative;z-index:2;width:100%;max-width:1200px;margin:0 auto;padding:0 1.5rem;text-align:center}
    .mineless-hero-title{font-family:'Cinzel',serif;font-size:3rem;font-weight:700;color:#F0E6D3;margin-bottom:1rem;line-height:1.2}
    .mineless-title-main{display:block;font-size:1.5rem;color:#A09080;margin-bottom:0.5rem;font-weight:400}
    .mineless-title-highlight{display:block;background:linear-gradient(90deg,#D4AF37,#F4D03F,#D4AF37);background-size:200% auto;-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:textShimmer 3s linear infinite}
    @keyframes textShimmer{0%{background-position:-200% center}100%{background-position:200% center}}
    .mineless-hero-subtitle{font-size:1.25rem;color:#A09080;margin-bottom:1.5rem}
    .mineless-hero-description{font-size:1.125rem;color:#6B5D4F;margin-bottom:2rem;max-width:600px;margin-left:auto;margin-right:auto}
    .mineless-hero-buttons{display:flex;align-items:center;justify-content:center;gap:1rem;margin-bottom:3rem;flex-wrap:wrap}
    .mineless-btn{display:inline-flex;align-items:center;justify-content:center;gap:0.5rem;padding:0.75rem 1.5rem;font-weight:600;border-radius:8px;transition:all 0.25s;text-decoration:none}
    .adv-btn-primary{background:linear-gradient(135deg,#B8960C 0%,#D4AF37 100%);color:#0A0A0F;border:2px solid #D4AF37}
    .adv-btn-outline{background:transparent;color:#D4AF37;border:2px solid #D4AF37}
    #particles-js{position:absolute;inset:0;z-index:1;pointer-events:none}
    .mineless-nav-user{display:flex;align-items:center;gap:0.5rem;padding:0.25rem 0.75rem 0.25rem 0.25rem;background:#222230;border:1px solid #2A2A3A;border-radius:9999px}
    .user-avatar{width:32px;height:32px;border-radius:50%}
    </style>{/literal}
    
    {* Template CSS Files *}
    {if isset($TEMPLATE_CSS)}
        {foreach from=$TEMPLATE_CSS item=css}
            <link rel="stylesheet" href="{$css}">
        {/foreach}
    {/if}
    
    {* Google Fonts *}
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    {* External Libraries CDN *}
    {* Particles.js for background effects *}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js" defer></script>
    
    {* GSAP + ScrollTrigger for animations *}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js" defer></script>
    
    {* Typed.js for text animations *}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.12/typed.min.js" defer></script>
    
    {* FontAwesome *}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    {* Analytics *}
    {if isset($ANALYTICS_ID) && $ANALYTICS_ID|strlen > 0}
        <script async src="https://www.googletagmanager.com/gtag/js?id={$ANALYTICS_ID}"></script>
        {literal}<script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '{/literal}{$ANALYTICS_ID}{literal}');
        </script>{/literal}
    {/if}
    
    {* Debugbar *}
    {if isset($DEBUGBAR_JS)}
        {$DEBUGBAR_JS}
    {/if}
</head>
<body id="page-{$PAGE}">
    {* Loading Bar *}
    <div id="loading-bar"></div>
    <div class="loading-spinner" id="page-loader"></div>
    
    {* Navigation Bar *}
    {include file='navbar.tpl'}
    
    {* Toast/Notification Container *}
    <div id="toast-container" aria-live="polite" aria-atomic="true"></div>
    
    {* Main Content Wrapper Start *}
    <main id="main-content" role="main">
