{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-profile-section">
    <!-- Profile Banner -->
    <div class="mineless-profile-banner" {if isset($BANNER)}style="background-image: url('{$BANNER}')"{/if}>
        <div class="mineless-banner-overlay"></div>
        <div class="mineless-banner-runes">
            <span>ᚦ</span><span>ᚩ</span><span>ᚱ</span><span>ᚢ</span><span>ᚾ</span>
        </div>
    </div>
    
    <div class="mineless-container">
        <!-- Profile Header -->
        <div class="mineless-profile-header">
            <div class="mineless-profile-avatar-wrap">
                <div class="mineless-profile-avatar-float">
                    {if isset($MINECRAFT_UUID)}
                        <img src="https://crafatar.com/renders/body/{$MINECRAFT_UUID}?scale=4&overlay" 
                             alt="{$USERNAME}" class="mineless-profile-body-render">
                    {else}
                        <img src="{$AVATAR}" alt="{$USERNAME}" class="mineless-profile-avatar-lg">
                    {/if}
                    <div class="mineless-avatar-frame"></div>
                    <div class="mineless-avatar-glow"></div>
                </div>
                <div class="mineless-profile-avatar-badge">
                    <img src="{$AVATAR}" alt="" class="mineless-profile-avatar-sm">
                </div>
            </div>
            
            <div class="mineless-profile-info">
                <div class="mineless-profile-name-wrap">
                    <h1 class="mineless-profile-name" style="{if isset($USER_STYLE)}{$USER_STYLE}{/if}">{$NICKNAME}</h1>
                    {if isset($USER_GROUPS)}
                        {foreach from=$USER_GROUPS item=group}
                            <span class="mineless-badge" style="background: {$group.color}">{$group.name}</span>
                        {/foreach}
                    {/if}
                </div>
                
                <div class="mineless-profile-stats-row">
                    <div class="mineless-profile-stat">
                        <i class="fas fa-comment"></i>
                        <span class="mineless-stat-value">{$POSTS_COUNT}</span>
                        <span class="mineless-stat-label">Posts</span>
                    </div>
                    <div class="mineless-profile-stat">
                        <i class="fas fa-heart"></i>
                        <span class="mineless-stat-value">{$REACTIONS_COUNT}</span>
                        <span class="mineless-stat-label">Reactions</span>
                    </div>
                    <div class="mineless-profile-stat">
                        <i class="fas fa-calendar"></i>
                        <span class="mineless-stat-value">{$REGISTERED_DATE}</span>
                        <span class="mineless-stat-label">Joined</span>
                    </div>
                    <div class="mineless-profile-stat">
                        <i class="fas fa-clock"></i>
                        <span class="mineless-stat-value">{$LAST_ACTIVE}</span>
                        <span class="mineless-stat-label">Last Active</span>
                    </div>
                </div>
            </div>
            
            <div class="mineless-profile-actions">
                {if isset($SELF)}
                    <a href="{$SETTINGS_URL}" class="mineless-btn adv-btn-outline">
                        <i class="fas fa-cog"></i> Edit Profile
                    </a>
                {else}
                    <button class="mineless-btn adv-btn-primary" onclick="sendMessage({$USER_ID})">
                        <i class="fas fa-envelope"></i> Message
                    </button>
                    <button class="mineless-btn adv-btn-outline" onclick="addFriend({$USER_ID})">
                        <i class="fas fa-user-plus"></i> Add Friend
                    </button>
                {/if}
            </div>
        </div>
        
        <!-- Profile Tabs -->
        <div class="mineless-profile-tabs-wrap">
            <div class="mineless-tabs">
                <button class="mineless-tab active" data-tab="about">
                    <i class="fas fa-user"></i> About
                </button>
                <button class="mineless-tab" data-tab="posts">
                    <i class="fas fa-comments"></i> Posts
                </button>
                <button class="mineless-tab" data-tab="trophies">
                    <i class="fas fa-trophy"></i> Trophies
                </button>
                <button class="mineless-tab" data-tab="friends">
                    <i class="fas fa-users"></i> Friends
                </button>
                <div class="mineless-tab-indicator"></div>
            </div>
        </div>
        
        <!-- Tab Content -->
        <div class="mineless-profile-content">
            <!-- About Tab -->
            <div class="mineless-tab-panel active" id="tab-about">
                <div class="mineless-profile-grid">
                    <div class="mineless-profile-main">
                        {if isset($ABOUT)}
                            <div class="mineless-card">
                                <h3 class="mineless-card-title"><i class="fas fa-quote-left"></i> Bio</h3>
                                <p class="mineless-profile-bio">{$ABOUT}</p>
                            </div>
                        {/if}
                        
                        {if isset($PROFILE_FIELDS)}
                            <div class="mineless-card">
                                <h3 class="mineless-card-title"><i class="fas fa-info-circle"></i> Information</h3>
                                <div class="mineless-profile-fields">
                                    {foreach from=$PROFILE_FIELDS item=field}
                                        <div class="mineless-field-item">
                                            <span class="mineless-field-label">{$field.name}</span>
                                            <span class="mineless-field-value">{$field.value}</span>
                                        </div>
                                    {/foreach}
                                </div>
                            </div>
                        {/if}
                    </div>
                    
                    <div class="mineless-profile-sidebar">
                        <div class="mineless-card">
                            <h3 class="mineless-card-title"><i class="fas fa-chart-bar"></i> Statistik</h3>
                            <div class="mineless-stats-list">
                                <div class="mineless-stat-bar">
                                    <span class="mineless-stat-name">Posts</span>
                                    <div class="mineless-stat-progress">
                                        <div class="mineless-progress-fill" style="width: {math equation="min(x, 100)" x=$POSTS_COUNT}%"></div>
                                    </div>
                                    <span class="mineless-stat-number">{$POSTS_COUNT}</span>
                                </div>
                                <div class="mineless-stat-bar">
                                    <span class="mineless-stat-name">Topics</span>
                                    <div class="mineless-stat-progress">
                                        <div class="mineless-progress-fill" style="width: {math equation="min(x, 100)" x=$TOPICS_COUNT}%"></div>
                                    </div>
                                    <span class="mineless-stat-number">{$TOPICS_COUNT|default:0}</span>
                                </div>
                                <div class="mineless-stat-bar">
                                    <span class="mineless-stat-name">Reactions</span>
                                    <div class="mineless-stat-progress">
                                        <div class="mineless-progress-fill" style="width: {math equation="min(x, 100)" x=$REACTIONS_COUNT}%"></div>
                                    </div>
                                    <span class="mineless-stat-number">{$REACTIONS_COUNT}</span>
                                </div>
                            </div>
                        </div>
                        
                        {if isset($MINECRAFT_UUID)}
                            <div class="mineless-card">
                                <h3 class="mineless-card-title"><i class="fab fa-minecraft"></i> Minecraft</h3>
                                <div class="mineless-minecraft-info">
                                    <img src="https://crafatar.com/avatars/{$MINECRAFT_UUID}?size=64&overlay" 
                                         alt="" class="mineless-minecraft-avatar">
                                    <div class="mineless-minecraft-details">
                                        <span class="mineless-mc-name">{$MINECRAFT_USERNAME|default:$NICKNAME}</span>
                                        <span class="mineless-mc-uuid">{$MINECRAFT_UUID}</span>
                                    </div>
                                </div>
                            </div>
                        {/if}
                    </div>
                </div>
            </div>
            
            <!-- Posts Tab -->
            <div class="mineless-tab-panel" id="tab-posts">
                <div class="mineless-card">
                    <h3 class="mineless-card-title">Recent Posts</h3>
                    {if isset($POSTS) && is_array($POSTS) && count($POSTS) > 0}
                        <div class="mineless-posts-list">
                            {foreach from=$POSTS item=post}
                                <div class="mineless-post-item">
                                    <div class="mineless-post-icon">
                                        <i class="fas fa-comment-alt"></i>
                                    </div>
                                    <div class="mineless-post-content">
                                        <a href="{$post.link}" class="mineless-post-title">{$post.title}</a>
                                        <span class="mineless-post-forum">in {$post.forum}</span>
                                        <p class="mineless-post-excerpt">{$post.content|truncate:100}</p>
                                    </div>
                                    <div class="mineless-post-meta">
                                        <span class="mineless-post-date">{$post.date}</span>
                                        <span class="mineless-post-likes"><i class="fas fa-heart"></i> {$post.likes}</span>
                                    </div>
                                </div>
                            {/foreach}
                        </div>
                        {if isset($PAGINATION)}
                            <div class="mineless-pagination">{$PAGINATION}</div>
                        {/if}
                    {else}
                        <div class="mineless-empty-state">
                            <i class="fas fa-comments"></i>
                            <p>No posts yet</p>
                        </div>
                    {/if}
                </div>
            </div>
            
            <!-- Trophies Tab -->
            <div class="mineless-tab-panel" id="tab-trophies">
                <div class="mineless-trophies-grid">
                    {if isset($TROPHIES) && is_array($TROPHIES) && count($TROPHIES) > 0}
                        {foreach from=$TROPHIES item=trophy}
                            <div class="mineless-trophy-card" data-rarity="{$trophy.rarity}">
                                <div class="mineless-trophy-icon">
                                    <i class="fas fa-{if $trophy.icon}{$trophy.icon}{else}trophy{/if}"></i>
                                    <div class="mineless-trophy-sparkle"></div>
                                </div>
                                <h4 class="mineless-trophy-name">{$trophy.name}</h4>
                                <p class="mineless-trophy-desc">{$trophy.description}</p>
                                <span class="mineless-trophy-date">{$trophy.date}</span>
                            </div>
                        {/foreach}
                    {else}
                        <div class="mineless-empty-state wide">
                            <i class="fas fa-trophy"></i>
                            <p>No trophies earned yet</p>
                        </div>
                    {/if}
                </div>
            </div>
            
            <!-- Friends Tab -->
            <div class="mineless-tab-panel" id="tab-friends">
                <div class="mineless-friends-grid">
                    {if isset($FRIENDS) && is_array($FRIENDS) && count($FRIENDS) > 0}
                        {foreach from=$FRIENDS item=friend}
                            <a href="{$friend.profile}" class="mineless-friend-card">
                                <img src="{$friend.avatar}" alt="{$friend.name}" class="mineless-friend-avatar">
                                <span class="mineless-friend-name" style="{$friend.style}">{$friend.name}</span>
                                {if $friend.online}
                                    <span class="mineless-friend-status online"></span>
                                {/if}
                            </a>
                        {/foreach}
                    {else}
                        <div class="mineless-empty-state wide">
                            <i class="fas fa-users"></i>
                            <p>No friends yet</p>
                        </div>
                    {/if}
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-profile-section {
    min-height: 100vh;
    background: var(--bg-primary);
}

.mineless-profile-banner {
    height: 300px;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    background-size: cover;
    background-position: center;
    position: relative;
    overflow: hidden;
}

.mineless-banner-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(to bottom, rgba(10,10,15,0.3) 0%, var(--bg-primary) 100%);
}

.mineless-banner-runes {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 2rem;
    opacity: 0.2;
}

.mineless-banner-runes span {
    font-size: 2rem;
    color: var(--mineless-gold);
    animation: runeFloat 3s ease-in-out infinite;
}

.mineless-banner-runes span:nth-child(2) { animation-delay: -0.5s; }
.mineless-banner-runes span:nth-child(3) { animation-delay: -1s; }
.mineless-banner-runes span:nth-child(4) { animation-delay: -1.5s; }
.mineless-banner-runes span:nth-child(5) { animation-delay: -2s; }

@keyframes runeFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

.mineless-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1.5rem;
}

.mineless-profile-header {
    display: flex;
    align-items: flex-end;
    gap: 2rem;
    margin-top: -80px;
    position: relative;
    z-index: 10;
    padding-bottom: 2rem;
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-profile-avatar-wrap {
    position: relative;
    flex-shrink: 0;
}

.mineless-profile-avatar-float {
    position: relative;
    animation: avatarFloat 4s ease-in-out infinite;
}

@keyframes avatarFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

.mineless-profile-body-render {
    width: 180px;
    height: auto;
    filter: drop-shadow(0 10px 30px rgba(0,0,0,0.5));
}

.mineless-avatar-frame {
    position: absolute;
    inset: -10px;
    border: 3px solid var(--mineless-gold);
    border-radius: 50% 50% 10px 10px;
    opacity: 0.5;
}

.mineless-avatar-glow {
    position: absolute;
    inset: -20px;
    background: radial-gradient(circle, rgba(212,175,55,0.3) 0%, transparent 70%);
    animation: glowPulse 3s ease-in-out infinite;
}

@keyframes glowPulse {
    0%, 100% { opacity: 0.5; transform: scale(1); }
    50% { opacity: 0.8; transform: scale(1.05); }
}

.mineless-profile-avatar-badge {
    position: absolute;
    bottom: 10px;
    right: -10px;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    border: 3px solid var(--mineless-gold);
    overflow: hidden;
    background: var(--bg-card);
}

.mineless-profile-avatar-sm {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.mineless-profile-info {
    flex: 1;
    padding-bottom: 1rem;
}

.mineless-profile-name-wrap {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-bottom: 1rem;
    flex-wrap: wrap;
}

.mineless-profile-name {
    font-family: var(--font-display);
    font-size: 2.5rem;
    color: var(--text-primary);
    text-shadow: 0 2px 10px rgba(0,0,0,0.5);
}

.mineless-profile-stats-row {
    display: flex;
    gap: 2rem;
    flex-wrap: wrap;
}

.mineless-profile-stat {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--text-secondary);
}

.mineless-profile-stat i {
    color: var(--mineless-gold);
}

.mineless-stat-value {
    font-weight: 600;
    color: var(--text-primary);
}

.mineless-stat-label {
    font-size: 0.85rem;
}

.mineless-profile-actions {
    display: flex;
    gap: 0.75rem;
    padding-bottom: 1rem;
}

.mineless-profile-tabs-wrap {
    margin-top: 2rem;
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-tabs {
    display: flex;
    gap: 0.5rem;
    position: relative;
}

.mineless-tab {
    padding: 1rem 1.5rem;
    background: none;
    border: none;
    color: var(--text-secondary);
    font-size: 0.95rem;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    transition: var(--transition-fast);
    position: relative;
}

.mineless-tab:hover {
    color: var(--mineless-gold);
}

.mineless-tab.active {
    color: var(--mineless-gold);
}

.mineless-tab-indicator {
    position: absolute;
    bottom: 0;
    height: 2px;
    background: var(--mineless-gold);
    transition: all 0.3s ease;
    box-shadow: 0 0 10px var(--mineless-gold);
}

.mineless-profile-content {
    padding: 2rem 0;
}

.mineless-tab-panel {
    display: none;
    animation: fadeIn 0.3s ease;
}

.mineless-tab-panel.active {
    display: block;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

.mineless-profile-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1.5rem;
}

.mineless-card {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    padding: 1.5rem;
    margin-bottom: 1.5rem;
}

.mineless-card-title {
    font-family: var(--font-display);
    font-size: 1.1rem;
    color: var(--text-primary);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.mineless-card-title i {
    color: var(--mineless-gold);
}

.mineless-profile-bio {
    color: var(--text-secondary);
    line-height: 1.7;
}

.mineless-profile-fields {
    display: grid;
    gap: 1rem;
}

.mineless-field-item {
    display: flex;
    justify-content: space-between;
    padding: 0.75rem 0;
    border-bottom: 1px solid rgba(212, 175, 55, 0.05);
}

.mineless-field-item:last-child {
    border-bottom: none;
}

.mineless-field-label {
    color: var(--text-secondary);
}

.mineless-field-value {
    color: var(--text-primary);
    font-weight: 500;
}

.mineless-stats-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.mineless-stat-bar {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.mineless-stat-name {
    width: 80px;
    font-size: 0.9rem;
    color: var(--text-secondary);
}

.mineless-stat-progress {
    flex: 1;
    height: 8px;
    background: var(--bg-secondary);
    border-radius: 4px;
    overflow: hidden;
}

.mineless-progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 4px;
    transition: width 1s ease;
}

.mineless-stat-number {
    width: 50px;
    text-align: right;
    font-weight: 600;
    color: var(--text-primary);
}

.mineless-minecraft-info {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.mineless-minecraft-avatar {
    width: 64px;
    height: 64px;
    border-radius: var(--radius-sm);
}

.mineless-minecraft-details {
    display: flex;
    flex-direction: column;
}

.mineless-mc-name {
    font-weight: 600;
    color: var(--text-primary);
}

.mineless-mc-uuid {
    font-size: 0.8rem;
    color: var(--text-secondary);
    font-family: monospace;
}

.mineless-posts-list {
    display: flex;
    flex-direction: column;
}

.mineless-post-item {
    display: flex;
    gap: 1rem;
    padding: 1.25rem 0;
    border-bottom: 1px solid rgba(212, 175, 55, 0.05);
}

.mineless-post-item:last-child {
    border-bottom: none;
}

.mineless-post-icon {
    width: 40px;
    height: 40px;
    background: rgba(212, 175, 55, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--mineless-gold);
    flex-shrink: 0;
}

.mineless-post-content {
    flex: 1;
}

.mineless-post-title {
    color: var(--text-primary);
    font-weight: 600;
    text-decoration: none;
    display: block;
    margin-bottom: 0.25rem;
}

.mineless-post-title:hover {
    color: var(--mineless-gold);
}

.mineless-post-forum {
    font-size: 0.85rem;
    color: var(--text-secondary);
}

.mineless-post-excerpt {
    margin-top: 0.5rem;
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.mineless-post-meta {
    text-align: right;
    font-size: 0.85rem;
    color: var(--text-secondary);
}

.mineless-post-likes {
    display: block;
    margin-top: 0.25rem;
    color: #e74c3c;
}

.mineless-trophies-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 1rem;
}

.mineless-trophy-card {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    padding: 1.5rem;
    text-align: center;
    transition: var(--transition-fast);
    position: relative;
    overflow: hidden;
}

.mineless-trophy-card:hover {
    transform: translateY(-5px);
    border-color: var(--mineless-gold);
    box-shadow: 0 10px 30px rgba(212, 175, 55, 0.1);
}

.mineless-trophy-card[data-rarity="legendary"] {
    border-color: #ff6b00;
    background: linear-gradient(135deg, var(--bg-card) 0%, rgba(255,107,0,0.1) 100%);
}

.mineless-trophy-card[data-rarity="epic"] {
    border-color: #a855f7;
}

.mineless-trophy-card[data-rarity="rare"] {
    border-color: #3b82f6;
}

.mineless-trophy-icon {
    width: 60px;
    height: 60px;
    margin: 0 auto 1rem;
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: var(--bg-primary);
    position: relative;
}

.mineless-trophy-sparkle {
    position: absolute;
    inset: 0;
    background: radial-gradient(circle, rgba(255,255,255,0.5) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.3s;
}

.mineless-trophy-card:hover .mineless-trophy-sparkle {
    opacity: 1;
    animation: sparkle 1s ease infinite;
}

@keyframes sparkle {
    0%, 100% { transform: scale(1); opacity: 0; }
    50% { transform: scale(1.2); opacity: 1; }
}

.mineless-trophy-name {
    color: var(--text-primary);
    margin-bottom: 0.5rem;
}

.mineless-trophy-desc {
    font-size: 0.85rem;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
}

.mineless-trophy-date {
    font-size: 0.75rem;
    color: var(--text-secondary);
}

.mineless-friends-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 1rem;
}

.mineless-friend-card {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    padding: 1rem;
    text-align: center;
    text-decoration: none;
    transition: var(--transition-fast);
    position: relative;
}

.mineless-friend-card:hover {
    transform: translateY(-3px);
    border-color: var(--mineless-gold);
}

.mineless-friend-avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    margin-bottom: 0.75rem;
    border: 2px solid transparent;
    transition: var(--transition-fast);
}

.mineless-friend-card:hover .mineless-friend-avatar {
    border-color: var(--mineless-gold);
}

.mineless-friend-name {
    display: block;
    font-weight: 500;
    color: var(--text-primary);
}

.mineless-friend-status {
    position: absolute;
    bottom: 1rem;
    right: 1rem;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    border: 2px solid var(--bg-card);
}

.mineless-friend-status.online {
    background: #28a745;
    box-shadow: 0 0 10px #28a745;
}

.mineless-empty-state {
    text-align: center;
    padding: 3rem;
    color: var(--text-secondary);
}

.mineless-empty-state.wide {
    grid-column: 1 / -1;
}

.mineless-empty-state i {
    font-size: 3rem;
    margin-bottom: 1rem;
    opacity: 0.5;
}

@media (max-width: 768px) {
    .mineless-profile-header {
        flex-direction: column;
        align-items: center;
        text-align: center;
    }
    
    .mineless-profile-stats-row {
        justify-content: center;
    }
    
    .mineless-profile-grid {
        grid-template-columns: 1fr;
    }
    
    .mineless-profile-name {
        font-size: 1.75rem;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
    initTabs();
});

function initTabs() {
    const tabs = document.querySelectorAll('.mineless-tab');
    const panels = document.querySelectorAll('.mineless-tab-panel');
    const indicator = document.querySelector('.mineless-tab-indicator');
    
    function updateIndicator(tab) {
        indicator.style.width = tab.offsetWidth + 'px';
        indicator.style.left = tab.offsetLeft + 'px';
    }
    
    // Initial indicator position
    const activeTab = document.querySelector('.mineless-tab.active');
    if (activeTab && indicator) {
        updateIndicator(activeTab);
    }
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetId = 'tab-' + tab.dataset.tab;
            
            // Update tabs
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Update indicator
            updateIndicator(tab);
            
            // Update panels
            panels.forEach(p => p.classList.remove('active'));
            document.getElementById(targetId).classList.add('active');
        });
    });
}

function sendMessage(userId) {
    window.location.href = '{$SITE_URL}/user/messaging/?action=new&to=' + userId;
}

function addFriend(userId) {
    fetch('{$SITE_URL}/queries/friends/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'token={$TOKEN}&user=' + userId
    }).then(() => {
        showToast('Friend request sent!', 'success');
    });
}

function showToast(message, type) {
    // Implementation
}
</script>

{include file='footer.tpl'}