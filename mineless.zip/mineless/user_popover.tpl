<div class="mineless-user-popover" id="user-popover-{$USER_ID}">
    <div class="mineless-popover-arrow"></div>
    <div class="mineless-popover-header">
        <div class="mineless-popover-bg"></div>
        <img src="{$AVATAR}" alt="{$USERNAME}" class="mineless-popover-avatar">
    </div>
    <div class="mineless-popover-body">
        <div class="mineless-popover-name-wrap">
            <span class="mineless-popover-name" style="{$USER_STYLE}">{$NICKNAME}</span>
            {if isset($USER_GROUPS)}
                {foreach from=$USER_GROUPS item=group}
                    <span class="mineless-popover-badge" style="background: {$group.color}">{$group.name}</span>
                {/foreach}
            {/if}
        </div>
        
        <div class="mineless-popover-stats">
            <div class="mineless-popover-stat">
                <span class="mineless-stat-value">{$POSTS|default:0}</span>
                <span class="mineless-stat-label">Posts</span>
            </div>
            <div class="mineless-popover-stat">
                <span class="mineless-stat-value">{$JOINED_DATE|default:'New'}</span>
                <span class="mineless-stat-label">Joined</span>
            </div>
        </div>
        
        <div class="mineless-popover-actions">
            <a href="{$PROFILE_URL}" class="mineless-btn adv-btn-primary adv-btn-sm">
                <i class="fas fa-user"></i> Profil
            </a>
            {if !$SELF}
                <a href="{$MESSAGE_URL}" class="mineless-btn adv-btn-outline adv-btn-sm">
                    <i class="fas fa-envelope"></i> Pesan
                </a>
            {/if}
        </div>
    </div>
</div>

<style>
.mineless-user-popover {
    position: absolute;
    width: 280px;
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-lg);
    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    z-index: 1000;
    animation: popoverIn 0.2s ease;
    overflow: hidden;
}

@keyframes popoverIn {
    from {
        opacity: 0;
        transform: scale(0.8) translateY(-10px);
    }
    to {
        opacity: 1;
        transform: scale(1) translateY(0);
    }
}

.mineless-popover-arrow {
    position: absolute;
    top: -8px;
    left: 50%;
    transform: translateX(-50%);
    width: 0;
    height: 0;
    border-left: 8px solid transparent;
    border-right: 8px solid transparent;
    border-bottom: 8px solid var(--mineless-gold);
}

.mineless-popover-header {
    position: relative;
    height: 80px;
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    display: flex;
    align-items: flex-end;
    justify-content: center;
    padding-bottom: 0;
}

.mineless-popover-avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    border: 4px solid var(--bg-card);
    margin-bottom: -40px;
    background: var(--bg-card);
}

.mineless-popover-body {
    padding: 3rem 1.5rem 1.5rem;
    text-align: center;
}

.mineless-popover-name-wrap {
    margin-bottom: 1rem;
}

.mineless-popover-name {
    display: block;
    font-family: var(--font-display);
    font-size: 1.25rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.mineless-popover-badge {
    display: inline-block;
    padding: 0.25rem 0.5rem;
    border-radius: var(--radius-sm);
    font-size: 0.7rem;
    font-weight: 600;
    color: white;
}

.mineless-popover-stats {
    display: flex;
    justify-content: center;
    gap: 2rem;
    margin-bottom: 1.5rem;
    padding: 1rem 0;
    border-top: 1px solid rgba(212, 175, 55, 0.1);
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-popover-stat {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.25rem;
}

.mineless-popover-stat .mineless-stat-value {
    font-weight: 600;
    color: var(--text-primary);
}

.mineless-popover-stat .mineless-stat-label {
    font-size: 0.75rem;
    color: var(--text-secondary);
}

.mineless-popover-actions {
    display: flex;
    gap: 0.5rem;
    justify-content: center;
}

.mineless-btn-sm {
    padding: 0.5rem 1rem;
    font-size: 0.85rem;
}
</style>