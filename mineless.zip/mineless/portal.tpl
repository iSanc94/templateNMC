{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-portal-section">
    <div class="mineless-container">
        <!-- Welcome Banner -->
        <div class="mineless-welcome-banner">
            <div class="mineless-welcome-content">
                <h1 class="mineless-welcome-title">
                    <span class="mineless-greeting">Welcome back,</span>
                    <span class="mineless-username" style="{$USER_STYLE}">{$USERNAME}!</span>
                </h1>
                <p class="mineless-welcome-subtitle">A new adventure awaits you today.</p>
            </div>
            <div class="mineless-welcome-avatar">
                <img src="{$AVATAR}" alt="{$USERNAME}">
                <div class="mineless-avatar-ring"></div>
            </div>
        </div>
        
        <!-- Quick Stats -->
        <div class="mineless-quick-stats">
            <div class="mineless-stat-card">
                <div class="mineless-stat-icon posts">
                    <i class="fas fa-comment"></i>
                </div>
                <div class="mineless-stat-info">
                    <span class="mineless-stat-number">{$POSTS_COUNT|default:0}</span>
                    <span class="mineless-stat-label">Posts</span>
                </div>
            </div>
            <div class="mineless-stat-card">
                <div class="mineless-stat-icon reactions">
                    <i class="fas fa-heart"></i>
                </div>
                <div class="mineless-stat-info">
                    <span class="mineless-stat-number">{$REACTIONS_COUNT|default:0}</span>
                    <span class="mineless-stat-label">Reactions</span>
                </div>
            </div>
            <div class="mineless-stat-card">
                <div class="mineless-stat-icon trophies">
                    <i class="fas fa-trophy"></i>
                </div>
                <div class="mineless-stat-info">
                    <span class="mineless-stat-number">{$TROPHIES_COUNT|default:0}</span>
                    <span class="mineless-stat-label">Trophies</span>
                </div>
            </div>
            <div class="mineless-stat-card">
                <div class="mineless-stat-icon messages">
                    <i class="fas fa-envelope"></i>
                </div>
                <div class="mineless-stat-info">
                    <span class="mineless-stat-number">{$MESSAGES_COUNT|default:0}</span>
                    <span class="mineless-stat-label">Messages</span>
                </div>
            </div>
        </div>
        
        <div class="mineless-portal-grid">
            <!-- Recent Alerts -->
            <div class="mineless-portal-card">
                <div class="mineless-card-header">
                    <h3><i class="fas fa-bell"></i> Recent Notifications</h3>
                    <a href="{$ALERTS_URL}" class="mineless-link">View All</a>
                </div>
                <div class="mineless-card-body">
                    {if isset($ALERTS) && is_array($ALERTS) && count($ALERTS) > 0}
                        <div class="mineless-alerts-list">
                            {foreach from=$ALERTS item=alert}
                                <div class="mineless-alert-item {if !$alert.read}unread{/if}">
                                    <div class="mineless-alert-icon {$alert.type}">
                                        <i class="fas fa-{$alert.icon|default:'info'}"></i>
                                    </div>
                                    <div class="mineless-alert-content">
                                        <p>{$alert.message}</p>
                                        <span class="mineless-alert-time">{$alert.time}</span>
                                    </div>
                                </div>
                            {/foreach}
                        </div>
                    {else}
                        <div class="mineless-empty-state">
                            <i class="fas fa-bell-slash"></i>
                            <p>No new notifications</p>
                        </div>
                    {/if}
                </div>
            </div>
            
            <!-- Quick Links -->
            <div class="mineless-portal-card">
                <div class="mineless-card-header">
                    <h3><i class="fas fa-bolt"></i> Quick Access</h3>
                </div>
                <div class="mineless-card-body">
                    <div class="mineless-quick-links">
                        <a href="{$USER_SETTINGS_URL}" class="mineless-quick-link">
                            <div class="mineless-link-icon">
                                <i class="fas fa-cog"></i>
                            </div>
                            <span>Settings</span>
                        </a>
                        <a href="{$MESSAGING_URL}" class="mineless-quick-link">
                            <div class="mineless-link-icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <span>Messages</span>
                        </a>
                        <a href="{$CONNECTIONS_URL}" class="mineless-quick-link">
                            <div class="mineless-link-icon">
                                <i class="fas fa-link"></i>
                            </div>
                            <span>Connections</span>
                        </a>
                        <a href="{$PROFILE_URL}" class="mineless-quick-link">
                            <div class="mineless-link-icon">
                                <i class="fas fa-user"></i>
                            </div>
                            <span>Profile</span>
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="mineless-portal-card wide">
                <div class="mineless-card-header">
                    <h3><i class="fas fa-history"></i> Recent Activity</h3>
                </div>
                <div class="mineless-card-body">
                    {if isset($ACTIVITY) && is_array($ACTIVITY) && count($ACTIVITY) > 0}
                        <div class="mineless-activity-timeline">
                            {foreach from=$ACTIVITY item=activity}
                                <div class="mineless-activity-item">
                                    <div class="mineless-activity-icon {$activity.type}">
                                        <i class="fas fa-{$activity.icon}"></i>
                                    </div>
                                    <div class="mineless-activity-content">
                                        <p>{$activity.description}</p>
                                        <span class="mineless-activity-time">{$activity.time}</span>
                                    </div>
                                </div>
                            {/foreach}
                        </div>
                    {else}
                        <div class="mineless-empty-state">
                            <i class="fas fa-history"></i>
                            <p>No activity yet</p>
                        </div>
                    {/if}
                </div>
            </div>
            
            <!-- Server Status -->
            <div class="mineless-portal-card">
                <div class="mineless-card-header">
                    <h3><i class="fas fa-server"></i> Server Status</h3>
                </div>
                <div class="mineless-card-body">
                    <div class="mineless-server-status">
                        {if isset($SERVER_ONLINE) && $SERVER_ONLINE}
                            <div class="mineless-status-indicator online">
                                <span class="mineless-status-dot"></span>
                                <span class="mineless-status-text">Online</span>
                            </div>
                            <div class="mineless-server-info">
                                <span class="mineless-player-count">{$ONLINE_PLAYERS}/{$MAX_PLAYERS} Players</span>
                                <div class="mineless-progress-track">
                                    <div class="mineless-progress-fill" style="width: {$ONLINE_PLAYERS/$MAX_PLAYERS*100}%"></div>
                                </div>
                            </div>
                        {else}
                            <div class="mineless-status-indicator offline">
                                <span class="mineless-status-dot"></span>
                                <span class="mineless-status-text">Offline</span>
                            </div>
                        {/if}
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-portal-section {
    min-height: 100vh;
    padding: 2rem 0;
    background: var(--bg-primary);
}

.mineless-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1.5rem;
}

/* Welcome Banner */
.mineless-welcome-banner {
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: var(--radius-xl);
    padding: 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    position: relative;
    overflow: hidden;
}

.mineless-welcome-banner::before {
    content: '';
    position: absolute;
    inset: 0;
    background: url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E");
}

.mineless-welcome-title {
    font-family: var(--font-display);
    font-size: 2rem;
    color: var(--bg-primary);
    margin: 0;
}

.mineless-greeting {
    display: block;
    font-size: 1rem;
    opacity: 0.8;
}

.mineless-username {
    display: block;
    font-size: 1.75rem;
}

.mineless-welcome-subtitle {
    color: var(--bg-primary);
    opacity: 0.9;
    margin-top: 0.5rem;
}

.mineless-welcome-avatar {
    position: relative;
    width: 100px;
    height: 100px;
}

.mineless-welcome-avatar img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    border: 4px solid rgba(255,255,255,0.3);
}

.mineless-avatar-ring {
    position: absolute;
    inset: -10px;
    border: 2px solid rgba(255,255,255,0.2);
    border-radius: 50%;
    animation: ringPulse 2s ease-in-out infinite;
}

@keyframes ringPulse {
    0%, 100% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.1); opacity: 0.5; }
}

/* Quick Stats */
.mineless-quick-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
    margin-bottom: 2rem;
}

.mineless-stat-card {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    transition: var(--transition-fast);
}

.mineless-stat-card:hover {
    transform: translateY(-3px);
    border-color: rgba(212, 175, 55, 0.3);
}

.mineless-stat-icon {
    width: 50px;
    height: 50px;
    border-radius: var(--radius-md);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
}

.mineless-stat-icon.posts { background: rgba(59, 130, 246, 0.1); color: #3b82f6; }
.mineless-stat-icon.reactions { background: rgba(239, 68, 68, 0.1); color: #ef4444; }
.mineless-stat-icon.trophies { background: rgba(212, 175, 55, 0.1); color: var(--mineless-gold); }
.mineless-stat-icon.messages { background: rgba(16, 185, 129, 0.1); color: #10b981; }

.mineless-stat-info {
    display: flex;
    flex-direction: column;
}

.mineless-stat-number {
    font-family: var(--font-display);
    font-size: 1.5rem;
    font-weight: 600;
    color: var(--text-primary);
}

.mineless-stat-label {
    font-size: 0.85rem;
    color: var(--text-secondary);
}

/* Portal Grid */
.mineless-portal-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
}

.mineless-portal-card {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.mineless-portal-card.wide {
    grid-column: 1 / -1;
}

.mineless-card-header {
    padding: 1.25rem;
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.mineless-card-header h3 {
    font-family: var(--font-display);
    font-size: 1.1rem;
    color: var(--text-primary);
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin: 0;
}

.mineless-card-header h3 i {
    color: var(--mineless-gold);
}

.mineless-link {
    color: var(--mineless-gold);
    text-decoration: none;
    font-size: 0.9rem;
}

.mineless-link:hover {
    text-decoration: underline;
}

.mineless-card-body {
    padding: 1.25rem;
}

/* Alerts */
.mineless-alerts-list {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.mineless-alert-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem;
    border-radius: var(--radius-md);
    background: var(--bg-secondary);
    transition: var(--transition-fast);
}

.mineless-alert-item.unread {
    border-left: 3px solid var(--mineless-gold);
}

.mineless-alert-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.mineless-alert-icon.info { background: rgba(59, 130, 246, 0.1); color: #3b82f6; }
.mineless-alert-icon.success { background: rgba(16, 185, 129, 0.1); color: #10b981; }
.mineless-alert-icon.warning { background: rgba(245, 158, 11, 0.1); color: #f59e0b; }
.mineless-alert-icon.danger { background: rgba(239, 68, 68, 0.1); color: #ef4444; }

.mineless-alert-content {
    flex: 1;
}

.mineless-alert-content p {
    margin: 0;
    color: var(--text-primary);
    font-size: 0.9rem;
}

.mineless-alert-time {
    font-size: 0.75rem;
    color: var(--text-secondary);
}

/* Quick Links */
.mineless-quick-links {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
}

.mineless-quick-link {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem;
    background: var(--bg-secondary);
    border-radius: var(--radius-md);
    text-decoration: none;
    color: var(--text-primary);
    transition: var(--transition-fast);
}

.mineless-quick-link:hover {
    background: rgba(212, 175, 55, 0.1);
    transform: translateX(5px);
}

.mineless-link-icon {
    width: 40px;
    height: 40px;
    background: rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-md);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--mineless-gold);
}

/* Activity Timeline */
.mineless-activity-timeline {
    position: relative;
    padding-left: 2rem;
}

.mineless-activity-timeline::before {
    content: '';
    position: absolute;
    left: 0.75rem;
    top: 0;
    bottom: 0;
    width: 2px;
    background: rgba(212, 175, 55, 0.2);
}

.mineless-activity-item {
    position: relative;
    padding-bottom: 1.5rem;
}

.mineless-activity-icon {
    position: absolute;
    left: -2rem;
    width: 1.5rem;
    height: 1.5rem;
    background: var(--bg-card);
    border: 2px solid rgba(212, 175, 55, 0.3);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.7rem;
    color: var(--mineless-gold);
}

.mineless-activity-content p {
    margin: 0 0 0.25rem;
    color: var(--text-primary);
}

.mineless-activity-time {
    font-size: 0.8rem;
    color: var(--text-secondary);
}

/* Server Status */
.mineless-server-status {
    text-align: center;
}

.mineless-status-indicator {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    margin-bottom: 1rem;
}

.mineless-status-dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    animation: statusPulse 2s ease-in-out infinite;
}

.mineless-status-indicator.online .mineless-status-dot {
    background: #10b981;
    box-shadow: 0 0 10px #10b981;
}

.mineless-status-indicator.offline .mineless-status-dot {
    background: #ef4444;
    box-shadow: 0 0 10px #ef4444;
}

@keyframes statusPulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.mineless-status-text {
    font-weight: 600;
    color: var(--text-primary);
}

.mineless-player-count {
    display: block;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
}

.mineless-progress-track {
    height: 8px;
    background: var(--bg-secondary);
    border-radius: 4px;
    overflow: hidden;
}

.mineless-progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 4px;
    transition: width 0.5s ease;
}

/* Empty State */
.mineless-empty-state {
    text-align: center;
    padding: 2rem;
    color: var(--text-secondary);
}

.mineless-empty-state i {
    font-size: 2rem;
    margin-bottom: 0.5rem;
    opacity: 0.5;
}

@media (max-width: 768px) {
    .mineless-quick-stats {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .mineless-portal-grid {
        grid-template-columns: 1fr;
    }
    
    .mineless-welcome-banner {
        flex-direction: column;
        text-align: center;
    }
}
</style>

{include file='footer.tpl'}