<div class="mineless-widget adv-staff-widget">
    <div class="mineless-widget-header">
        <h3><i class="fas fa-shield-alt"></i> {$STAFF_ONLINE}</h3>
        <i class="fas fa-check-circle" style="color: var(--mineless-gold);"></i>
    </div>
    <div class="mineless-widget-body">
        {if isset($STAFF) && is_array($STAFF) && count($STAFF) > 0}
            <div class="mineless-staff-grid">
                {foreach from=$STAFF item=member}
                    <a href="{$member.profile}" class="mineless-staff-item">
                        <div class="mineless-staff-avatar">
                            <img src="{$member.avatar}" alt="{$member.username}">
                            <span class="mineless-status {if $member.afk}afk{else}online{/if}"></span>
                        </div>
                        <div class="mineless-staff-info">
                            <span class="mineless-staff-name" style="{$member.style}">{$member.username}</span>
                            <span class="mineless-staff-role" style="color: {$member.group_color}">{$member.group_name}</span>
                        </div>
                    </a>
                {/foreach}
            </div>
            <a href="{$STAFF_PAGE}" class="mineless-view-all">{$VIEW_ALL_STAFF}</a>
        {else}
            <div class="mineless-empty">
                <i class="fas fa-moon"></i>
                <p>Tidak ada staff online saat ini</p>
            </div>
        {/if}
    </div>
</div>

<style>
.mineless-widget {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.mineless-widget-header {
    padding: 1rem 1.25rem;
    background: rgba(212, 175, 55, 0.05);
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.mineless-widget-header h3 {
    margin: 0;
    font-family: var(--font-display);
    font-size: 1rem;
    color: var(--text-primary);
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.mineless-widget-header h3 i {
    color: var(--mineless-gold);
}

.mineless-widget-body {
    padding: 1.25rem;
}

.mineless-staff-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
}

.mineless-staff-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem;
    background: var(--bg-secondary);
    border-radius: var(--radius-md);
    text-decoration: none;
    transition: var(--transition-fast);
}

.mineless-staff-item:hover {
    background: rgba(212, 175, 55, 0.1);
    transform: translateX(3px);
}

.mineless-staff-avatar {
    position: relative;
    width: 40px;
    height: 40px;
}

.mineless-staff-avatar img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
}

.mineless-status {
    position: absolute;
    bottom: 2px;
    right: 2px;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 2px solid var(--bg-card);
}

.mineless-status.online {
    background: #28a745;
}

.mineless-status.afk {
    background: #ffc107;
}

.mineless-staff-info {
    display: flex;
    flex-direction: column;
}

.mineless-staff-name {
    font-weight: 600;
    font-size: 0.9rem;
}

.mineless-staff-role {
    font-size: 0.75rem;
}

.mineless-view-all {
    display: block;
    text-align: center;
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 1px solid rgba(212, 175, 55, 0.1);
    color: var(--mineless-gold);
    text-decoration: none;
    font-size: 0.9rem;
}

.mineless-view-all:hover {
    text-decoration: underline;
}

.mineless-empty {
    text-align: center;
    padding: 2rem;
    color: var(--text-secondary);
}

.mineless-empty i {
    font-size: 2rem;
    margin-bottom: 0.5rem;
    opacity: 0.5;
}

.mineless-empty p {
    margin: 0;
    font-size: 0.9rem;
}
</style>