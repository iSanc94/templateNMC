<div class="mineless-widget adv-server-widget">
    <div class="mineless-widget-header">
        <h3><i class="fas fa-server"></i> Server Status</h3>
        <span class="mineless-status-indicator {if $SERVER_ONLINE}online{else}offline{/if}" id="server-status-dot">
            <span class="mineless-pulse"></span>
        </span>
    </div>
    <div class="mineless-widget-body">
        {if $SERVER_ONLINE}
            <div class="mineless-server-ip" onclick="copyServerIP()">
                <span class="mineless-ip-text" id="server-ip">{$SERVER_IP}{if $SERVER_PORT}:{$SERVER_PORT}{/if}</span>
                <i class="fas fa-copy"></i>
                <span class="mineless-copy-tooltip">Copy!</span>
            </div>
            
            <div class="mineless-player-count">
                <div class="mineless-count-header">
                    <span><i class="fas fa-users"></i> {$ONLINE_PLAYERS}/{$MAX_PLAYERS} Players</span>
                    <span class="mineless-percentage">{$ONLINE_PLAYERS/$MAX_PLAYERS*100|round}%</span>
                </div>
                <div class="mineless-progress-bar">
                    <div class="mineless-progress-fill" style="width: {$ONLINE_PLAYERS/$MAX_PLAYERS*100}%"></div>
                </div>
            </div>
            
            {if isset($SERVER_MOTD)}
                <div class="mineless-server-motd">
                    <p>{$SERVER_MOTD}</p>
                </div>
            {/if}
            
            <div class="mineless-server-meta">
                <span><i class="fas fa-gamepad"></i> {$SERVER_VERSION|default:'1.20.x'}</span>
                <span><i class="fas fa-globe"></i> {$SERVER_TYPE|default:'Survival'}</span>
            </div>
        {else}
            <div class="mineless-server-offline">
                <i class="fas fa-plug"></i>
                <p>Server is currently offline</p>
                <span>Please try again later</span>
            </div>
        {/if}
    </div>
</div>

<style>
.mineless-widget {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.mineless-widget-header {
    padding: 1rem 1.25rem;
    background: rgba(212, 175, 55, 0.05);
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.mineless-widget-header h3 {
    margin: 0;
    font-family: var(--font-display);
    font-size: 1rem;
    color: var(--text-primary);
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.mineless-widget-header h3 i {
    color: var(--mineless-gold);
}

.mineless-status-indicator {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    position: relative;
}

.mineless-status-indicator.online {
    background: #28a745;
}

.mineless-status-indicator.offline {
    background: #dc3545;
}

.mineless-pulse {
    position: absolute;
    inset: 0;
    border-radius: 50%;
    animation: pulse 2s ease-in-out infinite;
}

.mineless-status-indicator.online .mineless-pulse {
    background: #28a745;
}

@keyframes pulse {
    0% { transform: scale(1); opacity: 0.5; }
    100% { transform: scale(2); opacity: 0; }
}

.mineless-widget-body {
    padding: 1.25rem;
}

.mineless-server-ip {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1rem;
    background: var(--bg-secondary);
    border-radius: var(--radius-md);
    margin-bottom: 1rem;
    cursor: pointer;
    position: relative;
    transition: var(--transition-fast);
}

.mineless-server-ip:hover {
    border-color: var(--mineless-gold);
}

.mineless-ip-text {
    flex: 1;
    font-family: monospace;
    font-size: 1rem;
    color: var(--mineless-gold);
}

.mineless-copy-tooltip {
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
    background: var(--mineless-gold);
    color: var(--bg-primary);
    padding: 0.25rem 0.5rem;
    border-radius: var(--radius-sm);
    font-size: 0.75rem;
    opacity: 0;
    transition: var(--transition-fast);
}

.mineless-copy-tooltip.show {
    opacity: 1;
    top: -35px;
}

.mineless-count-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
    font-size: 0.9rem;
    color: var(--text-secondary);
}

.mineless-percentage {
    color: var(--mineless-gold);
    font-weight: 600;
}

.mineless-progress-bar {
    height: 6px;
    background: var(--bg-secondary);
    border-radius: 3px;
    overflow: hidden;
}

.mineless-progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 3px;
    transition: width 0.5s ease;
}

.mineless-server-motd {
    margin-top: 1rem;
    padding: 0.75rem;
    background: rgba(212, 175, 55, 0.05);
    border-radius: var(--radius-md);
}

.mineless-server-motd p {
    margin: 0;
    font-size: 0.9rem;
    color: var(--text-secondary);
}

.mineless-server-meta {
    display: flex;
    gap: 1rem;
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-server-meta span {
    font-size: 0.85rem;
    color: var(--text-secondary);
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

.mineless-server-offline {
    text-align: center;
    padding: 2rem;
    color: var(--text-secondary);
}

.mineless-server-offline i {
    font-size: 3rem;
    margin-bottom: 1rem;
    opacity: 0.5;
}

.mineless-server-offline p {
    margin: 0 0 0.5rem;
    font-size: 1.1rem;
}

.mineless-server-offline span {
    font-size: 0.85rem;
    opacity: 0.7;
}
</style>

<script>
function copyServerIP() {
    const ip = document.getElementById('server-ip').textContent;
    navigator.clipboard.writeText(ip).then(() => {
        const tooltip = document.querySelector('.mineless-copy-tooltip');
        tooltip.classList.add('show');
        setTimeout(() => tooltip.classList.remove('show'), 2000);
    });
}

// Auto-refresh every 60 seconds
setInterval(() => {
    fetch('{$SITE_URL}/queries/server/?ip={$SERVER_IP}')
        .then(r => r.json())
        .then(data => {
            const dot = document.getElementById('server-status-dot');
            if (data.online) {
                dot.classList.add('online');
                dot.classList.remove('offline');
            } else {
                dot.classList.add('offline');
                dot.classList.remove('online');
            }
        });
}, 60000);
</script>