<div class="mineless-cookie-notice" id="cookie-notice">
    <div class="mineless-cookie-content">
        <div class="mineless-cookie-icon">
            <i class="fas fa-cookie-bite"></i>
        </div>
        <div class="mineless-cookie-text">
            <p>{$COOKIE_NOTICE_TEXT}</p>
        </div>
    </div>
    <div class="mineless-cookie-actions">
        <button class="mineless-btn adv-btn-primary" onclick="acceptCookies()">
            {$ACCEPT_COOKIES}
        </button>
        <button class="mineless-btn adv-btn-text" onclick="declineCookies()">
            {$DECLINE_COOKIES}
        </button>
        <a href="{$COOKIE_SETTINGS_URL}" class="mineless-link">{$MORE_INFO}</a>
    </div>
</div>

<style>
.mineless-cookie-notice {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: var(--bg-card);
    border-top: 2px solid var(--mineless-gold);
    padding: 1.5rem;
    z-index: 9999;
    transform: translateY(0);
    transition: transform 0.5s ease;
}

.mineless-cookie-notice.hidden {
    transform: translateY(100%);
}

.mineless-cookie-content {
    display: flex;
    align-items: center;
    gap: 1rem;
    max-width: 1200px;
    margin: 0 auto 1rem;
}

.mineless-cookie-icon {
    width: 50px;
    height: 50px;
    background: rgba(212, 175, 55, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: var(--mineless-gold);
    flex-shrink: 0;
}

.mineless-cookie-text p {
    margin: 0;
    color: var(--text-secondary);
    line-height: 1.6;
}

.mineless-cookie-actions {
    display: flex;
    align-items: center;
    gap: 1rem;
    max-width: 1200px;
    margin: 0 auto;
    flex-wrap: wrap;
}

.mineless-btn {
    padding: 0.75rem 1.5rem;
    border-radius: var(--radius-md);
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: var(--transition-fast);
}

.mineless-btn-primary {
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    color: var(--bg-primary);
}

.mineless-btn-text {
    background: none;
    color: var(--text-secondary);
}

.mineless-btn-text:hover {
    color: var(--mineless-gold);
}

.mineless-link {
    color: var(--mineless-gold);
    text-decoration: none;
    margin-left: auto;
}

.mineless-link:hover {
    text-decoration: underline;
}

@media (max-width: 768px) {
    .mineless-cookie-content {
        flex-direction: column;
        text-align: center;
    }
    
    .mineless-cookie-actions {
        justify-content: center;
    }
    
    .mineless-link {
        margin-left: 0;
        width: 100%;
        text-align: center;
    }
}
</style>

<script>
function acceptCookies() {
    document.cookie = "cookies_accepted=1; path=/; max-age=" + (365 * 24 * 60 * 60);
    document.getElementById('cookie-notice').classList.add('hidden');
}

function declineCookies() {
    document.cookie = "cookies_accepted=0; path=/; max-age=" + (365 * 24 * 60 * 60);
    document.getElementById('cookie-notice').classList.add('hidden');
}

// Check if already accepted
if (document.cookie.indexOf('cookies_accepted=') !== -1) {
    document.getElementById('cookie-notice').classList.add('hidden');
}
</script>