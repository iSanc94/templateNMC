<div class="mineless-widget adv-posts-widget">
    <div class="mineless-widget-header">
        <h3><i class="fas fa-comment-dots"></i> {$LATEST_POSTS}</h3>
    </div>
    <div class="mineless-widget-body">
        {if isset($POSTS) && is_array($POSTS) && count($POSTS) > 0}
            <div class="mineless-posts-list">
                {foreach from=$POSTS item=post}
                    <a href="{$post.link}" class="mineless-post-item">
                        <img src="{$post.author_avatar}" alt="" class="mineless-post-avatar">
                        <div class="mineless-post-content">
                            <span class="mineless-post-title">{$post.topic_title|truncate:30}</span>
                            <div class="mineless-post-meta">
                                <span class="mineless-post-author" style="{$post.author_style}">{$post.author_name}</span>
                                <span class="mineless-post-forum">{$post.forum_name}</span>
                                <span class="mineless-post-time">{$post.time}</span>
                            </div>
                        </div>
                    </a>
                {/foreach}
            </div>
        {else}
            <div class="mineless-empty">
                <p>{$NO_POSTS}</p>
            </div>
        {/if}
    </div>
</div>

<style>
.mineless-widget {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.mineless-widget-header {
    padding: 1rem 1.25rem;
    background: rgba(212, 175, 55, 0.05);
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-widget-header h3 {
    margin: 0;
    font-family: var(--font-display);
    font-size: 1rem;
    color: var(--text-primary);
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.mineless-widget-header h3 i {
    color: var(--mineless-gold);
}

.mineless-widget-body {
    padding: 0.75rem;
}

.mineless-posts-list {
    display: flex;
    flex-direction: column;
}

.mineless-post-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem;
    border-radius: var(--radius-md);
    text-decoration: none;
    transition: var(--transition-fast);
}

.mineless-post-item:hover {
    background: rgba(212, 175, 55, 0.05);
}

.mineless-post-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    flex-shrink: 0;
}

.mineless-post-content {
    flex: 1;
    min-width: 0;
}

.mineless-post-title {
    display: block;
    font-weight: 600;
    color: var(--text-primary);
    font-size: 0.9rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.mineless-post-meta {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.8rem;
    color: var(--text-secondary);
    margin-top: 0.25rem;
}

.mineless-post-author {
    font-weight: 500;
}

.mineless-post-forum::before {
    content: 'in ';
}

.mineless-post-time::before {
    content: '• ';
}

.mineless-empty {
    text-align: center;
    padding: 2rem;
    color: var(--text-secondary);
}

.mineless-empty p {
    margin: 0;
}
</style>