<div class="mineless-widget mineless-stats-widget">
    <div class="mineless-widget-header">
        <h3><i class="fas fa-chart-pie"></i> {$STATISTICS_TITLE|default:'Statistik'}</h3>
    </div>
    <div class="mineless-widget-body">
        {if isset($STATISTICS) && is_array($STATISTICS)}
            <div class="mineless-stat-grid">
                <div class="mineless-stat-box">
                    <div class="mineless-stat-icon users">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="mineless-stat-info">
                        <span class="mineless-stat-number" data-count="{if isset($STATISTICS.member_count)}{$STATISTICS.member_count}{else}0{/if}">0</span>
                        <span class="mineless-stat-label">Total Members</span>
                    </div>
                </div>
                
                <div class="mineless-stat-box">
                    <div class="mineless-stat-icon posts">
                        <i class="fas fa-comment"></i>
                    </div>
                    <div class="mineless-stat-info">
                        <span class="mineless-stat-number" data-count="{if isset($STATISTICS.post_count)}{$STATISTICS.post_count}{else}0{/if}">0</span>
                        <span class="mineless-stat-label">Total Posts</span>
                    </div>
                </div>
                
                <div class="mineless-stat-box">
                    <div class="mineless-stat-icon topics">
                        <i class="fas fa-comments"></i>
                    </div>
                    <div class="mineless-stat-info">
                        <span class="mineless-stat-number" data-count="{if isset($STATISTICS.topic_count)}{$STATISTICS.topic_count}{else}0{/if}">0</span>
                        <span class="mineless-stat-label">Total Topics</span>
                    </div>
                </div>
            </div>
            
            {if isset($STATISTICS.newest_member) && is_array($STATISTICS.newest_member)}
                <div class="mineless-newest-member">
                    <span class="mineless-label">Member Terbaru:</span>
                    <a href="{$STATISTICS.newest_member.profile}" class="mineless-member-link">
                        <img src="{$STATISTICS.newest_member.avatar}" alt="">
                        <span style="{$STATISTICS.newest_member.style}">{$STATISTICS.newest_member.username}</span>
                    </a>
                </div>
            {/if}
        {else}
            <p class="mineless-empty">Statistik tidak tersedia</p>
        {/if}
    </div>
</div>

<style>
.mineless-widget {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.mineless-widget-header {
    padding: 1rem 1.25rem;
    background: rgba(212, 175, 55, 0.05);
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-widget-header h3 {
    margin: 0;
    font-family: var(--font-display);
    font-size: 1rem;
    color: var(--text-primary);
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.mineless-widget-header h3 i {
    color: var(--mineless-gold);
}

.mineless-widget-body {
    padding: 1.25rem;
}

.mineless-stat-grid {
    display: grid;
    gap: 1rem;
    margin-bottom: 1.25rem;
}

.mineless-stat-box {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    background: var(--bg-secondary);
    border-radius: var(--radius-md);
    transition: var(--transition-fast);
}

.mineless-stat-box:hover {
    transform: translateX(5px);
}

.mineless-stat-icon {
    width: 45px;
    height: 45px;
    border-radius: var(--radius-md);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
}

.mineless-stat-icon.users { background: rgba(59, 130, 246, 0.1); color: #3b82f6; }
.mineless-stat-icon.posts { background: rgba(16, 185, 129, 0.1); color: #10b981; }
.mineless-stat-icon.topics { background: rgba(245, 158, 11, 0.1); color: #f59e0b; }

.mineless-stat-info {
    display: flex;
    flex-direction: column;
}

.mineless-stat-number {
    font-family: var(--font-display);
    font-size: 1.5rem;
    font-weight: 600;
    color: var(--text-primary);
}

.mineless-stat-label {
    font-size: 0.85rem;
    color: var(--text-secondary);
}

.mineless-newest-member {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding-top: 1.25rem;
    border-top: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-label {
    font-size: 0.9rem;
    color: var(--text-secondary);
}

.mineless-member-link {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    text-decoration: none;
    font-weight: 500;
}

.mineless-member-link img {
    width: 24px;
    height: 24px;
    border-radius: 50%;
}

.mineless-empty {
    text-align: center;
    padding: 2rem;
    color: var(--text-secondary);
}
</style>

<script>
document.querySelectorAll('.mineless-stat-number[data-count]').forEach(counter => {
    const target = parseInt(counter.dataset.count) || 0;
    if (target === 0) {
        counter.textContent = '0';
        return;
    }
    
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;
    
    const update = () => {
        current += step;
        if (current < target) {
            counter.textContent = Math.floor(current).toLocaleString();
            requestAnimationFrame(update);
        } else {
            counter.textContent = target.toLocaleString();
        }
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                update();
                observer.unobserve(entry.target);
            }
        });
    });
    
    observer.observe(counter);
});
</script>