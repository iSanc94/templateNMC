<div class="mineless-widget adv-online-widget">
    <div class="mineless-widget-header">
        <h3><i class="fas fa-signal"></i> {$ONLINE_USERS}</h3>
        <span class="mineless-online-count">{$TOTAL_ONLINE}</span>
    </div>
    <div class="mineless-widget-body">
        <div class="mineless-online-avatars">
            {if isset($ONLINE_LIST) && count($ONLINE_LIST) > 0}
                {foreach from=$ONLINE_LIST item=user name=online}
                    {if $smarty.foreach.online.index < 10}
                        <a href="{$user.profile}" class="mineless-online-avatar" title="{$user.username}">
                            <img src="{$user.avatar}" alt="{$user.username}">
                            <span class="mineless-status-dot"></span>
                        </a>
                    {/if}
                {/foreach}
                {if isset($ONLINE_LIST) && is_array($ONLINE_LIST) && $ONLINE_LIST|count > 10}
                    <span class="mineless-more-users">+{$ONLINE_LIST|count - 10}</span>
                {/if}
            {else}
                <p class="mineless-empty">Tidak ada user online</p>
            {/if}
        </div>
        <div class="mineless-online-breakdown">
            <span><i class="fas fa-user"></i> {$MEMBERS_ONLINE} members</span>
            <span><i class="fas fa-user-secret"></i> {$GUESTS_ONLINE} guests</span>
        </div>
    </div>
</div>

<style>
.mineless-widget {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.mineless-widget-header {
    padding: 1rem 1.25rem;
    background: rgba(212, 175, 55, 0.05);
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.mineless-widget-header h3 {
    margin: 0;
    font-family: var(--font-display);
    font-size: 1rem;
    color: var(--text-primary);
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.mineless-widget-header h3 i {
    color: var(--mineless-gold);
}

.mineless-online-count {
    background: rgba(40, 167, 69, 0.1);
    color: #28a745;
    padding: 0.25rem 0.75rem;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
}

.mineless-widget-body {
    padding: 1.25rem;
}

.mineless-online-avatars {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-bottom: 1rem;
}

.mineless-online-avatar {
    position: relative;
    width: 40px;
    height: 40px;
}

.mineless-online-avatar img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    border: 2px solid transparent;
    transition: var(--transition-fast);
}

.mineless-online-avatar:hover img {
    border-color: var(--mineless-gold);
    transform: scale(1.1);
}

.mineless-status-dot {
    position: absolute;
    bottom: 2px;
    right: 2px;
    width: 10px;
    height: 10px;
    background: #28a745;
    border: 2px solid var(--bg-card);
    border-radius: 50%;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.mineless-more-users {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--bg-secondary);
    border-radius: 50%;
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--mineless-gold);
}

.mineless-empty {
    color: var(--text-secondary);
    font-size: 0.9rem;
    text-align: center;
    padding: 1rem;
}

.mineless-online-breakdown {
    display: flex;
    gap: 1rem;
    padding-top: 1rem;
    border-top: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-online-breakdown span {
    font-size: 0.85rem;
    color: var(--text-secondary);
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

.mineless-online-breakdown i {
    color: var(--mineless-gold);
}
</style>