# Mineless Template - Quick Reference

## Installation

### 1. Copy Files
```bash
# Copy template to NamelessMC
copy D:\kimi_ai\mineless\ → D:\xampp\htdocs\namemc\custom\templates\Mineless\
```

### 2. Clear Cache
```powershell
# Windows PowerShell
Remove-Item -Path "D:\xampp\htdocs\namemc\cache\templates_c\*" -Force -Recurse
```

### 3. Activate Template
- Go to Admin Panel → Layout → Templates
- Activate "Mineless" template

---

## Color Scheme

### Primary Colors
```css
--mineless-gold: #D4AF37;
--mineless-gold-light: #F4D03F;
--mineless-gold-dark: #B8960C;
--mineless-ember: #C84B11;
--mineless-forest: #2D5A27;
```

### Background Colors
```css
--bg-primary: #0A0A0F;
--bg-secondary: #111118;
--bg-card: #16161F;
--bg-elevated: #222230;
```

### Text Colors
```css
--text-primary: #F0E6D3;
--text-secondary: #A09080;
--text-muted: #6B5D4F;
```

---

## Common Snippets

### Logo (No Image)
```smarty
<span class="mineless-logo-text">
    <i class="fas fa-dragon"></i> {$SITE_NAME}
</span>
```

### Avatar (With Fallback)
```smarty
<img src="https://cravatar.eu/avatar/{$username}/32.png" 
     alt="{$username}"
     onerror="this.src='https://cravatar.eu/avatar/Steve/32.png'">
```

### Button Primary
```html
<a href="#" class="mineless-btn adv-btn-primary">
    <i class="fas fa-gamepad"></i> Start Playing
</a>
```

### Button Outline
```html
<a href="#" class="mineless-btn adv-btn-outline">
    <i class="fas fa-info-circle"></i> Learn More
</a>
```

### Section Header
```html
<div class="mineless-section-header">
    <span class="mineless-section-tag">Information</span>
    <h2 class="mineless-section-title">Latest News</h2>
    <p class="mineless-section-desc">Description here</p>
</div>
```

### Card
```html
<div class="mineless-card">
    <div class="mineless-card__header">
        <h3 class="mineless-card__title">Title</h3>
    </div>
    <div class="mineless-card__content">
        Content here
    </div>
</div>
```

---

## Template Variables

### Global
| Variable | Description |
|----------|-------------|
| `{$SITE_NAME}` | Website name |
| `{$SITE_URL}` | Website URL |
| `{$TEMPLATE.path}` | Template path |
| `{$LOGGED_IN_USER}` | Boolean |
| `{$USER_SECTION.username}` | Current user name |
| `{$USER_SECTION.avatar}` | Current user avatar |

### Forum
| Variable | Description |
|----------|-------------|
| `{$FORUMS}` | Forum categories |
| `{$TOPICS}` | Topics array |
| `{$POSTS}` | Posts array |
| `{$FORUM_URL}` | Forum page URL |

### Statistics
| Variable | Description |
|----------|-------------|
| `{$STATISTICS.member_count}` | Total members |
| `{$STATISTICS.post_count}` | Total posts |
| `{$SERVER_ONLINE}` | Server status boolean |
| `{$ONLINE_PLAYERS}` | Online player count |

---

## CSS Classes Reference

### Layout
| Class | Description |
|-------|-------------|
| `.mineless-container` | Max-width container |
| `.mineless-section` | Section wrapper |
| `.mineless-grid` | Grid layout |
| `.mineless-flex` | Flex layout |

### Components
| Class | Description |
|-------|-------------|
| `.mineless-btn` | Base button |
| `.mineless-btn--primary` | Gold button |
| `.mineless-btn--outline` | Outline button |
| `.mineless-card` | Card component |
| `.mineless-avatar` | Avatar component |
| `.mineless-badge` | Badge/pill |
| `.mineless-input` | Form input |

### Text
| Class | Description |
|-------|-------------|
| `.mineless-text-gold` | Gold colored text |
| `.mineless-text-muted` | Muted text |
| `.mineless-text-center` | Center aligned |

---

## File Locations

### Important Files
| File | Path |
|------|------|
| Main CSS | `css/mineless.css` |
| Emergency CSS | `css/emergency-fix.css` |
| Header | `header.tpl` |
| Footer | `footer.tpl` |
| Navbar | `navbar.tpl` |
| Home | `index.tpl` |
| Forum Index | `forum/forum_index.tpl` |
| User Settings | `user/settings.tpl` |

### Cache Location
```
D:\xampp\htdocs\namemc\cache\templates_c\
```

---

## Debugging

### Enable Debug Mode
```php
// In config.php
define('DEBUG_MODE', true);
```

### Check Template Variables
```smarty
{* Debug all variables *}
<pre>{$smarty|print_r}</pre>

{* Check specific variable *}
<pre>{$VARIABLE|print_r}</pre>
```

### Force CSS Reload
```html
<link rel="stylesheet" href="{$TEMPLATE.path}/css/mineless.css?v=NEW_VERSION">
```

---

## Common Issues

### Issue: CSS Not Loading
**Solution:**
1. Check file permissions
2. Clear browser cache (Ctrl+F5)
3. Clear template cache
4. Verify file path

### Issue: Images Broken
**Solution:**
1. Use Cravatar for avatars
2. Use FontAwesome for icons
3. Check file exists in `/uploads/`

### Issue: Smarty Errors
**Solution:**
1. Wrap CSS/JS in `{literal}` tags
2. Use `|default` modifier
3. Check for undefined variables

### Issue: Indonesian Text Showing
**Solution:**
1. Search for Indonesian text in templates
2. Replace with English
3. Clear cache

---

## External Services

### Avatar Services
- **Cravatar**: `https://cravatar.eu/avatar/{username}/{size}.png`
- **Crafatar**: `https://crafatar.com/avatars/{uuid}?size={size}&overlay`

### CDN Libraries
- **FontAwesome**: `https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/`
- **Particles.js**: `https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/`
- **Typed.js**: `https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.12/`

---

## Support

### Resources
- NamelessMC Docs: https://docs.namelessmc.com/
- Smarty Docs: https://www.smarty.net/docs/
- FontAwesome: https://fontawesome.com/

### Template Info
- **Name**: Mineless
- **Version**: 1.0.0
- **Author**: Mineless Theme Team
- **Compatible**: NamelessMC v2.2.0+

---

*Quick Reference v1.0 - 2026-03-26*
