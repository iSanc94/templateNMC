{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-auth-section">
    <div class="mineless-auth-bg">
        <div class="mineless-auth-particles" id="auth-particles"></div>
        
        <!-- Flying Envelope Animation -->
        <div class="mineless-envelope-container">
            <svg class="mineless-flying-envelope" viewBox="0 0 120 80" id="flying-envelope">
                <defs>
                    <linearGradient id="envGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:#D4AF37"/>
                        <stop offset="100%" style="stop-color:#8B6914"/>
                    </linearGradient>
                </defs>
                <!-- Envelope Body -->
                <rect x="5" y="20" width="110" height="55" rx="3" fill="url(#envGrad)"/>
                <!-- Envelope Flap -->
                <path d="M5,20 L60,50 L115,20" fill="#C9AA5E" stroke="#8B6914" stroke-width="1"/>
                <!-- Envelope Seal -->
                <circle cx="60" cy="45" r="12" fill="#C84B11"/>
                <text x="60" y="49" text-anchor="middle" fill="#F0E6D3" font-size="10" font-weight="bold">ADV</text>
                <!-- Wings -->
                <path class="mineless-wing-left" d="M5,35 Q-15,30 -10,45 Q-5,40 5,42" fill="#D4AF37" opacity="0.8"/>
                <path class="mineless-wing-right" d="M115,35 Q135,30 130,45 Q125,40 115,42" fill="#D4AF37" opacity="0.8"/>
            </svg>
            
            <!-- Trail particles -->
            <div class="mineless-envelope-trail" id="envelope-trail"></div>
        </div>
    </div>
    
    <div class="mineless-auth-container">
        <div class="mineless-auth-card" data-animate="fade-in-up">
            <div class="mineless-auth-border"></div>
            
            <div class="mineless-auth-header">
                <div class="mineless-auth-icon">
                    <i class="fas fa-envelope-open"></i>
                </div>
                <h1 class="mineless-auth-title">{$FORGOT_PASSWORD}</h1>
                <p class="mineless-auth-subtitle">Masukkan email untuk reset password</p>
            </div>
            
            {if isset($ERROR)}
                <div class="mineless-alert adv-alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>{$ERROR}</span>
                </div>
            {/if}
            
            {if isset($SUCCESS)}
                <div class="mineless-success-sent" id="success-panel">
                    <div class="mineless-sent-icon">
                        <i class="fas fa-paper-plane"></i>
                    </div>
                    <h3>Email Terkirim!</h3>
                    <p>{$SUCCESS}</p>
                    <div class="mineless-resend-section">
                        <span id="resend-countdown">Kirim ulang dalam 60 detik</span>
                        <button type="button" class="mineless-btn adv-btn-outline adv-btn-sm" id="resend-btn" onclick="resendEmail()" disabled>
                            <i class="fas fa-redo"></i> Kirim Ulang
                        </button>
                    </div>
                </div>
            {else}
                <form action="" method="post" class="mineless-form" id="forgot-form">
                    <input type="hidden" name="token" value="{$TOKEN}">
                    
                    <div class="mineless-form-group">
                        <label for="email" class="mineless-form-label">{$EMAIL_ADDRESS}</label>
                        <div class="mineless-input-wrapper">
                            <i class="fas fa-envelope adv-input-icon"></i>
                            <input type="email" id="email" name="email" class="mineless-input" placeholder="email@example.com" required>
                        </div>
                        <span class="mineless-input-help">Kami akan mengirim link reset password ke email ini</span>
                    </div>
                    
                    <button type="submit" class="mineless-btn adv-btn-primary adv-btn-block adv-btn-lg" id="submit-btn">
                        <span class="mineless-btn-text">Kirim Link Reset</span>
                        <i class="fas fa-paper-plane adv-btn-icon"></i>
                    </button>
                </form>
            {/if}
            
            <div class="mineless-auth-footer">
                <p>Ingat password? <a href="{$LOGIN_URL}" class="mineless-link adv-link-bold">{$SIGN_IN}</a></p>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-envelope-container {
    position: absolute;
    left: 10%;
    top: 50%;
    transform: translateY(-50%);
    width: 300px;
    height: 300px;
}

.mineless-flying-envelope {
    width: 150px;
    height: 100px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    filter: drop-shadow(0 10px 20px rgba(212, 175, 55, 0.3));
}

.mineless-flying-envelope.flying {
    animation: envelopeFly 2s ease-in-out forwards;
}

@keyframes envelopeFly {
    0% {
        transform: translate(-50%, -50%) rotate(0deg) scale(1);
        left: 50%;
        top: 50%;
        opacity: 1;
    }
    30% {
        transform: translate(-50%, -50%) rotate(-15deg) scale(0.9);
        left: 60%;
        top: 40%;
    }
    60% {
        transform: translate(-50%, -50%) rotate(10deg) scale(0.7);
        left: 120%;
        top: 30%;
        opacity: 0.8;
    }
    100% {
        transform: translate(-50%, -50%) rotate(0deg) scale(0.5);
        left: 150%;
        top: 20%;
        opacity: 0;
    }
}

.mineless-wing-left, .mineless-wing-right {
    animation: wingFlap 0.2s ease-in-out infinite;
}

.mineless-wing-left {
    transform-origin: right center;
}

.mineless-wing-right {
    transform-origin: left center;
}

@keyframes wingFlap {
    0%, 100% { transform: scaleX(1); }
    50% { transform: scaleX(0.6); }
}

.mineless-envelope-trail {
    position: absolute;
    inset: 0;
    pointer-events: none;
}

.mineless-trail-particle {
    position: absolute;
    width: 8px;
    height: 8px;
    background: var(--mineless-gold);
    border-radius: 50%;
    opacity: 0.6;
    animation: trailFade 1s ease-out forwards;
}

@keyframes trailFade {
    0% { transform: scale(1); opacity: 0.6; }
    100% { transform: scale(0); opacity: 0; }
}

.mineless-success-sent {
    text-align: center;
    padding: 1.5rem;
    background: rgba(40, 167, 69, 0.1);
    border: 1px solid rgba(40, 167, 69, 0.3);
    border-radius: var(--radius-md);
    animation: fadeInUp 0.5s ease;
}

.mineless-sent-icon {
    width: 70px;
    height: 70px;
    margin: 0 auto 1rem;
    background: linear-gradient(135deg, #28a745, #20c997);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    color: white;
    animation: iconPop 0.5s ease;
}

@keyframes iconPop {
    0% { transform: scale(0); }
    50% { transform: scale(1.2); }
    100% { transform: scale(1); }
}

.mineless-success-sent h3 {
    color: var(--text-primary);
    margin-bottom: 0.5rem;
}

.mineless-success-sent p {
    color: var(--text-secondary);
    font-size: 0.9rem;
    margin-bottom: 1rem;
}

.mineless-resend-section {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.75rem;
}

.mineless-resend-section span {
    color: var(--text-secondary);
    font-size: 0.85rem;
}

.mineless-btn-sm {
    padding: 0.5rem 1rem;
    font-size: 0.85rem;
}

.mineless-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

@media (max-width: 1024px) {
    .mineless-envelope-container {
        display: none;
    }
}
</style>

<script>
let resendTimeout;
let countdownInterval;

document.addEventListener('DOMContentLoaded', () => {
    {if isset($SUCCESS)}
        startResendCountdown();
    {else}
        initForm();
    {/if}
});

function initForm() {
    const form = document.getElementById('forgot-form');
    const envelope = document.getElementById('flying-envelope');
    
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Animate envelope flying
        envelope.classList.add('flying');
        createTrail();
        
        // Submit form after animation
        setTimeout(() => {
            form.submit();
        }, 1500);
    });
}

function createTrail() {
    const trail = document.getElementById('envelope-trail');
    const envelope = document.getElementById('flying-envelope');
    const rect = envelope.getBoundingClientRect();
    
    for (let i = 0; i < 20; i++) {
        setTimeout(() => {
            const particle = document.createElement('div');
            particle.className = 'adv-trail-particle';
            particle.style.left = rect.left + rect.width / 2 + 'px';
            particle.style.top = rect.top + rect.height / 2 + 'px';
            particle.style.transform = `translate(${(Math.random() - 0.5) * 50}px, ${(Math.random() - 0.5) * 50}px)`;
            trail.appendChild(particle);
            
            setTimeout(() => particle.remove(), 1000);
        }, i * 50);
    }
}

function startResendCountdown() {
    let seconds = 60;
    const countdown = document.getElementById('resend-countdown');
    const btn = document.getElementById('resend-btn');
    
    btn.disabled = true;
    
    countdownInterval = setInterval(() => {
        countdown.textContent = `Kirim ulang dalam ${seconds} detik`;
        seconds--;
        
        if (seconds < 0) {
            clearInterval(countdownInterval);
            countdown.textContent = 'Belum menerima email?';
            btn.disabled = false;
        }
    }, 1000);
}

function resendEmail() {
    // Reset countdown
    clearInterval(countdownInterval);
    startResendCountdown();
    
    // AJAX call to resend email
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'token={$TOKEN}&email=' + encodeURIComponent(document.getElementById('email')?.value || '')
    }).then(() => {
        // Show toast notification
        showToast('Email reset password telah dikirim ulang!', 'success');
    });
}

function showToast(message, type) {
    // Simple toast implementation
    const toast = document.createElement('div');
    toast.className = `adv-toast adv-toast-${type}`;
    toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : 'info'}-circle"></i> ${message}`;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}
</script>

{include file='footer.tpl'}