{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-auth-section">
    <div class="mineless-auth-bg">
        <div class="mineless-auth-particles"></div>
    </div>
    
    <div class="mineless-auth-container">
        <div class="mineless-auth-card" data-animate="fade-in-up">
            <div class="mineless-auth-border"></div>
            
            <div class="mineless-auth-header">
                <div class="mineless-auth-icon">
                    <i class="fas fa-lock-open"></i>
                </div>
                <h1 class="mineless-auth-title">{$CHANGE_PASSWORD}</h1>
                <p class="mineless-auth-subtitle">Buat password baru yang kuat</p>
            </div>
            
            {if isset($ERROR)}
                <div class="mineless-alert adv-alert-error adv-shake">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>{$ERROR}</span>
                </div>
            {/if}
            
            {if isset($SUCCESS)}
                <div class="mineless-alert adv-alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span>{$SUCCESS}</span>
                </div>
            {/if}
            
            <form action="" method="post" class="mineless-form" id="change-password-form">
                <input type="hidden" name="token" value="{$TOKEN}">
                
                {if isset($OLD_PASSWORD_REQUIRED)}
                <div class="mineless-form-group">
                    <label for="old_password" class="mineless-form-label">{$OLD_PASSWORD}</label>
                    <div class="mineless-input-wrapper">
                        <i class="fas fa-lock adv-input-icon"></i>
                        <input type="password" id="old_password" name="old_password" class="mineless-input" placeholder="Password saat ini" required>
                        <button type="button" class="mineless-password-toggle" onclick="togglePassword('old_password', this)">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                {/if}
                
                <div class="mineless-form-group">
                    <label for="new_password" class="mineless-form-label">{$NEW_PASSWORD}</label>
                    <div class="mineless-input-wrapper">
                        <i class="fas fa-key adv-input-icon"></i>
                        <input type="password" id="new_password" name="new_password" class="mineless-input" placeholder="Password baru" required>
                        <button type="button" class="mineless-password-toggle" onclick="togglePassword('new_password', this)">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    
                    <!-- Strength Meter -->
                    <div class="mineless-strength-meter" id="strength-meter">
                        <div class="mineless-strength-segment" data-level="1"></div>
                        <div class="mineless-strength-segment" data-level="2"></div>
                        <div class="mineless-strength-segment" data-level="3"></div>
                        <div class="mineless-strength-segment" data-level="4"></div>
                    </div>
                    <span class="mineless-strength-label" id="strength-label">Kekuatan password</span>
                </div>
                
                <div class="mineless-form-group">
                    <label for="new_password_again" class="mineless-form-label">{$CONFIRM_NEW_PASSWORD}</label>
                    <div class="mineless-input-wrapper">
                        <i class="fas fa-check-double adv-input-icon"></i>
                        <input type="password" id="new_password_again" name="new_password_again" class="mineless-input" placeholder="Ulangi password baru" required>
                        <button type="button" class="mineless-password-toggle" onclick="togglePassword('new_password_again', this)">
                            <i class="fas fa-eye"></i>
                        </button>
                        <i class="fas fa-check adv-match-icon" id="match-icon"></i>
                    </div>
                    <span class="mineless-match-text" id="match-text"></span>
                </div>
                
                <!-- Password Requirements -->
                <div class="mineless-password-reqs">
                    <h4 class="mineless-reqs-title">Persyaratan Password:</h4>
                    <ul class="mineless-reqs-list">
                        <li id="req-length">
                            <i class="fas fa-circle"></i>
                            <span>Minimal 8 karakter</span>
                        </li>
                        <li id="req-upper">
                            <i class="fas fa-circle"></i>
                            <span>Satu huruf besar (A-Z)</span>
                        </li>
                        <li id="req-lower">
                            <i class="fas fa-circle"></i>
                            <span>Satu huruf kecil (a-z)</span>
                        </li>
                        <li id="req-number">
                            <i class="fas fa-circle"></i>
                            <span>Satu angka (0-9)</span>
                        </li>
                        <li id="req-special">
                            <i class="fas fa-circle"></i>
                            <span>Satu karakter khusus (!@#$%)</span>
                        </li>
                    </ul>
                </div>
                
                <button type="submit" class="mineless-btn adv-btn-primary adv-btn-block adv-btn-lg" id="submit-btn">
                    <span class="mineless-btn-text">{$SUBMIT}</span>
                    <i class="fas fa-save adv-btn-icon"></i>
                </button>
            </form>
            
            <div class="mineless-auth-footer">
                <a href="{$PROFILE_URL}" class="mineless-link">
                    <i class="fas fa-arrow-left"></i> Kembali ke Profil
                </a>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-auth-section {
    min-height: 100vh;
    display: flex;
    position: relative;
    padding: 2rem 0;
}

.mineless-auth-bg {
    position: fixed;
    inset: 0;
    background: linear-gradient(135deg, #0A0A0F 0%, #16161F 50%, #111118 100%);
    z-index: -1;
}

.mineless-auth-particles {
    position: absolute;
    inset: 0;
    background-image: 
        radial-gradient(circle at 20% 80%, rgba(212, 175, 55, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 80% 20%, rgba(200, 75, 17, 0.1) 0%, transparent 50%);
}

.mineless-auth-container {
    width: 100%;
    max-width: 500px;
    margin: 0 auto;
    padding: 0 1rem;
}

.mineless-auth-card {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-xl);
    padding: 2.5rem;
    position: relative;
    overflow: hidden;
}

.mineless-auth-border {
    position: absolute;
    inset: 0;
    border-radius: var(--radius-xl);
    padding: 2px;
    background: linear-gradient(135deg, var(--mineless-gold), transparent, var(--mineless-gold));
    -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    animation: borderRotate 4s linear infinite;
}

.mineless-auth-header {
    text-align: center;
    margin-bottom: 2rem;
}

.mineless-auth-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 1.5rem;
    background: linear-gradient(135deg, var(--mineless-gold), #8B6914);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    color: var(--bg-primary);
    box-shadow: 0 0 30px rgba(212, 175, 55, 0.3);
    animation: magicPulse 2s ease-in-out infinite;
}

.mineless-auth-title {
    font-family: var(--font-display);
    font-size: 1.75rem;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
}

.mineless-auth-subtitle {
    color: var(--text-secondary);
    font-size: 0.95rem;
}

.mineless-alert {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem;
    border-radius: var(--radius-md);
    margin-bottom: 1.5rem;
    font-size: 0.9rem;
}

.mineless-alert-error {
    background: rgba(220, 53, 69, 0.1);
    border: 1px solid rgba(220, 53, 69, 0.3);
    color: #ff6b6b;
}

.mineless-alert-success {
    background: rgba(40, 167, 69, 0.1);
    border: 1px solid rgba(40, 167, 69, 0.3);
    color: #51cf66;
}

.mineless-shake {
    animation: shakeError 0.5s ease-in-out;
}

.mineless-form-group {
    margin-bottom: 1.25rem;
}

.mineless-form-label {
    display: block;
    margin-bottom: 0.5rem;
    color: var(--text-primary);
    font-weight: 500;
    font-size: 0.9rem;
}

.mineless-input-wrapper {
    position: relative;
}

.mineless-input-icon {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-secondary);
}

.mineless-input {
    width: 100%;
    padding: 0.875rem 1rem 0.875rem 2.75rem;
    background: var(--bg-secondary);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-md);
    color: var(--text-primary);
    font-size: 1rem;
    transition: var(--transition-fast);
}

.mineless-input:focus {
    outline: none;
    border-color: var(--mineless-gold);
    box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
}

.mineless-password-toggle {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    padding: 0.25rem;
    transition: var(--transition-fast);
}

.mineless-password-toggle:hover {
    color: var(--mineless-gold);
}

.mineless-match-icon {
    position: absolute;
    right: 3rem;
    top: 50%;
    transform: translateY(-50%);
    color: #28a745;
    opacity: 0;
    transition: var(--transition-fast);
}

.mineless-match-icon.show {
    opacity: 1;
}

.mineless-match-text {
    display: block;
    margin-top: 0.5rem;
    font-size: 0.85rem;
    min-height: 1.2em;
}

.mineless-match-text.match {
    color: #28a745;
}

.mineless-match-text.no-match {
    color: #dc3545;
}

.mineless-strength-meter {
    display: flex;
    gap: 4px;
    margin-top: 0.75rem;
}

.mineless-strength-segment {
    flex: 1;
    height: 4px;
    background: var(--bg-secondary);
    border-radius: 2px;
    transition: var(--transition-fast);
}

.mineless-strength-segment.weak { background: #dc3545; }
.mineless-strength-segment.fair { background: #ffc107; }
.mineless-strength-segment.good { background: #17a2b8; }
.mineless-strength-segment.strong { background: #28a745; }

.mineless-strength-label {
    display: block;
    margin-top: 0.5rem;
    font-size: 0.85rem;
    color: var(--text-secondary);
}

.mineless-password-reqs {
    background: var(--bg-secondary);
    border-radius: var(--radius-md);
    padding: 1rem;
    margin-bottom: 1.5rem;
}

.mineless-reqs-title {
    font-size: 0.9rem;
    color: var(--text-primary);
    margin-bottom: 0.75rem;
}

.mineless-reqs-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.mineless-reqs-list li {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.85rem;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
    transition: var(--transition-fast);
}

.mineless-reqs-list li:last-child {
    margin-bottom: 0;
}

.mineless-reqs-list li i {
    font-size: 0.5rem;
    transition: var(--transition-fast);
}

.mineless-reqs-list li.met {
    color: #28a745;
}

.mineless-reqs-list li.met i {
    transform: scale(1.5);
}

.mineless-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    border-radius: var(--radius-md);
    font-weight: 600;
    font-size: 0.95rem;
    cursor: pointer;
    transition: var(--transition-fast);
    border: none;
    position: relative;
    overflow: hidden;
}

.mineless-btn-primary {
    background: linear-gradient(135deg, var(--mineless-gold), #8B6914);
    color: var(--bg-primary);
}

.mineless-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(212, 175, 55, 0.3);
}

.mineless-btn-block {
    width: 100%;
}

.mineless-btn-lg {
    padding: 1rem 2rem;
    font-size: 1rem;
}

.mineless-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

.mineless-auth-footer {
    text-align: center;
    margin-top: 1.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-link {
    color: var(--mineless-gold);
    text-decoration: none;
    transition: var(--transition-fast);
}

.mineless-link:hover {
    text-decoration: underline;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const newPassword = document.getElementById('new_password');
    const confirmPassword = document.getElementById('new_password_again');
    const segments = document.querySelectorAll('.mineless-strength-segment');
    const label = document.getElementById('strength-label');
    const matchIcon = document.getElementById('match-icon');
    const matchText = document.getElementById('match-text');
    const submitBtn = document.getElementById('submit-btn');
    
    const requirements = {
        length: document.getElementById('req-length'),
        upper: document.getElementById('req-upper'),
        lower: document.getElementById('req-lower'),
        number: document.getElementById('req-number'),
        special: document.getElementById('req-special')
    };
    
    newPassword.addEventListener('input', updateStrength);
    confirmPassword.addEventListener('input', checkMatch);
    
    function updateStrength() {
        const value = newPassword.value;
        let score = 0;
        
        // Check requirements
        const checks = {
            length: value.length >= 8,
            upper: /[A-Z]/.test(value),
            lower: /[a-z]/.test(value),
            number: /[0-9]/.test(value),
            special: /[^A-Za-z0-9]/.test(value)
        };
        
        // Update requirement indicators
        Object.keys(checks).forEach(key => {
            requirements[key].classList.toggle('met', checks[key]);
            if (checks[key]) score++;
        });
        
        // Update strength meter
        segments.forEach((seg, i) => {
            seg.className = 'adv-strength-segment';
            if (i < Math.ceil(score / 1.25)) {
                if (score <= 2) seg.classList.add('weak');
                else if (score === 3) seg.classList.add('fair');
                else if (score === 4) seg.classList.add('good');
                else seg.classList.add('strong');
            }
        });
        
        // Update label
        const labels = ['', 'Lemah', 'Cukup', 'Bagus', 'Kuat', 'Sangat Kuat!'];
        label.textContent = labels[score] || 'Kekuatan password';
        label.style.color = score <= 2 ? '#dc3545' : score === 3 ? '#ffc107' : '#28a745';
        
        checkMatch();
    }
    
    function checkMatch() {
        const value = newPassword.value;
        const confirm = confirmPassword.value;
        
        if (confirm === '') {
            matchIcon.classList.remove('show');
            matchText.textContent = '';
            return;
        }
        
        if (value === confirm) {
            matchIcon.classList.add('show');
            matchText.textContent = 'Password cocok';
            matchText.className = 'adv-match-text match';
        } else {
            matchIcon.classList.remove('show');
            matchText.textContent = 'Password tidak cocok';
            matchText.className = 'adv-match-text no-match';
        }
        
        validateForm();
    }
    
    function validateForm() {
        const value = newPassword.value;
        const confirm = confirmPassword.value;
        
        const isValid = value.length >= 8 && 
                       /[A-Z]/.test(value) && 
                       /[a-z]/.test(value) && 
                       /[0-9]/.test(value) && 
                       /[^A-Za-z0-9]/.test(value) &&
                       value === confirm;
        
        submitBtn.disabled = !isValid;
    }
});

function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>

{include file='footer.tpl'}