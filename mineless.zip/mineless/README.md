# Mineless Template for NamelessMC

Template NamelessMC v2 dengan tema Minecraft Dark Fantasy.

## Fitur

- ✅ Tema Dark Fantasy dengan accent Gold
- ✅ Animasi smooth dengan GSAP
- ✅ Particles.js di homepage
- ✅ Fully Responsive
- ✅ Customizable via Admin Panel

## Instalasi

### Langkah 1: Copy Folder Template
1. Copy folder `Mineless` ke `/custom/templates/` di instalasi NamelessMC Anda
2. Struktur folder harus seperti ini:
   ```
   /custom/templates/Mineless/
   ├── template.php
   ├── css/
   │   ├── custom.css
   │   └── toastr.min.css
   ├── js/
   │   └── core/
   │       ├── core.js
   │       ├── pages.js
   │       ├── user.js
   │       └── update.js
   ├── template_settings/
   │   ├── settings.php
   │   └── settings.tpl
   └── ... (file .tpl lainnya)
   ```

### Langkah 2: Aktifkan Template
1. Login ke Admin Panel (`/panel`)
2. Pergi ke **Configuration** → **Templates**
3. Klik **Install** pada template "Mineless"
4. Klik **Activate** untuk mengaktifkan template

### Langkah 3: Konfigurasi Template (Opsional)
1. Di halaman Templates, klik **Settings** pada template Mineless
2. Atur:
   - Accent Color (default: #D4AF37 - Gold)
   - Server IP dan Port
   - Hero Title dan Subtitle
   - Enable/Disable Particles dan Parallax
   - Discord Invite URL
   - Custom CSS

## Troubleshooting

### Template tidak muncul di daftar
- Pastikan folder template bernama `Mineless` (case-sensitive)
- Pastikan `template.php` ada di root folder template
- Pastikan permission folder bisa dibaca oleh web server

### Error setelah instalasi
- Clear cache NamelessMC: Hapus folder `/cache/` (kecuali `.htaccess`)
- Pastikan semua file ada dan tidak corrupt
- Cek error log di `/cache/logs/`

### CSS/JS tidak load
- Pastikan file `css/custom.css` dan file JS di `js/core/` ada
- Cek browser console untuk error 404
- Pastikan path di `template.php` benar

## Struktur File Penting

| File | Fungsi |
|------|--------|
| `template.php` | Bootstrap template, load CSS/JS |
| `header.tpl` | Head HTML, meta tags, CDN |
| `navbar.tpl` | Navigation bar |
| `footer.tpl` | Footer section |
| `css/custom.css` | Styling utama |
| `js/core/core.js` | JavaScript utama |

## Requirements

- NamelessMC v2.0.0 atau lebih baru
- PHP 7.4 atau lebih baru
- Web server dengan rewrite support (Apache/Nginx)

## License

MIT License
