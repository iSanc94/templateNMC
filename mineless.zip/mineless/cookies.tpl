{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-cookies-section">
    <div class="mineless-container">
        <h1 class="mineless-page-title">{$COOKIE_POLICY}</h1>
        
        <div class="mineless-cookies-intro">
            <p>{$COOKIE_POLICY_INTRO}</p>
        </div>
        
        <div class="mineless-cookies-table">
            <div class="mineless-cookie-category">
                <div class="mineless-cookie-header">
                    <div>
                        <h3>Necessary Cookies</h3>
                        <p>Required for the website to function properly</p>
                    </div>
                    <span class="mineless-badge required">Required</span>
                </div>
                <div class="mineless-cookie-list">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Purpose</th>
                                <th>Duration</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><code>PHPSESSID</code></td>
                                <td>Session management</td>
                                <td>Session</td>
                            </tr>
                            <tr>
                                <td><code>nl2_token</code></td>
                                <td>Security token</td>
                                <td>Session</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="mineless-cookie-category">
                <div class="mineless-cookie-header">
                    <div>
                        <h3>Preference Cookies</h3>
                        <p>Remember your settings and preferences</p>
                    </div>
                    <label class="mineless-toggle">
                        <input type="checkbox" checked>
                        <span class="mineless-toggle-slider"></span>
                    </label>
                </div>
            </div>
            
            <div class="mineless-cookie-category">
                <div class="mineless-cookie-header">
                    <div>
                        <h3>Analytics Cookies</h3>
                        <p>Help us improve our website</p>
                    </div>
                    <label class="mineless-toggle">
                        <input type="checkbox">
                        <span class="mineless-toggle-slider"></span>
                    </label>
                </div>
            </div>
        </div>
        
        <div class="mineless-cookies-actions">
            <button class="mineless-btn adv-btn-primary" onclick="savePreferences()">
                {$SAVE_PREFERENCES}
            </button>
            <button class="mineless-btn adv-btn-outline" onclick="acceptAll()">
                {$ACCEPT_ALL_COOKIES}
            </button>
        </div>
    </div>
</section>

<style>
.mineless-cookies-section {
    min-height: 100vh;
    padding: 4rem 0;
    background: var(--bg-primary);
}

.mineless-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 0 1.5rem;
}

.mineless-page-title {
    font-family: var(--font-display);
    font-size: 2.5rem;
    color: var(--text-primary);
    text-align: center;
    margin-bottom: 1rem;
}

.mineless-cookies-intro {
    text-align: center;
    color: var(--text-secondary);
    margin-bottom: 3rem;
}

.mineless-cookie-category {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    margin-bottom: 1.5rem;
    overflow: hidden;
}

.mineless-cookie-header {
    padding: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-cookie-header h3 {
    margin: 0 0 0.5rem;
    color: var(--text-primary);
}

.mineless-cookie-header p {
    margin: 0;
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.mineless-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
}

.mineless-badge.required {
    background: rgba(212, 175, 55, 0.1);
    color: var(--mineless-gold);
}

.mineless-cookie-list {
    padding: 1.5rem;
}

.mineless-cookie-list table {
    width: 100%;
    border-collapse: collapse;
}

.mineless-cookie-list th,
.mineless-cookie-list td {
    padding: 0.75rem;
    text-align: left;
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-cookie-list th {
    color: var(--text-secondary);
    font-weight: 500;
    font-size: 0.9rem;
}

.mineless-cookie-list td {
    color: var(--text-primary);
}

.mineless-cookie-list code {
    background: var(--bg-secondary);
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    font-family: monospace;
    font-size: 0.9rem;
    color: var(--mineless-gold);
}

.mineless-toggle {
    position: relative;
    width: 50px;
    height: 26px;
}

.mineless-toggle input {
    opacity: 0;
    width: 0;
    height: 0;
}

.mineless-toggle-slider {
    position: absolute;
    cursor: pointer;
    inset: 0;
    background: var(--bg-secondary);
    border-radius: 26px;
    transition: 0.3s;
}

.mineless-toggle-slider::before {
    content: '';
    position: absolute;
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background: white;
    border-radius: 50%;
    transition: 0.3s;
}

.mineless-toggle input:checked + .mineless-toggle-slider {
    background: var(--mineless-gold);
}

.mineless-toggle input:checked + .mineless-toggle-slider::before {
    transform: translateX(24px);
}

.mineless-cookies-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    margin-top: 2rem;
}

.mineless-btn {
    padding: 0.875rem 2rem;
    border-radius: var(--radius-md);
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: var(--transition-fast);
}

.mineless-btn-primary {
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    color: var(--bg-primary);
}

.mineless-btn-outline {
    background: transparent;
    border: 2px solid rgba(212, 175, 55, 0.3);
    color: var(--mineless-gold);
}

.mineless-btn-outline:hover {
    border-color: var(--mineless-gold);
    background: rgba(212, 175, 55, 0.1);
}
</style>

<script>
function savePreferences() {
    // Save cookie preferences
    document.cookie = "cookie_prefs=1; path=/; max-age=" + (365 * 24 * 60 * 60);
    showToast('Preferences saved!', 'success');
}

function acceptAll() {
    document.cookie = "cookies_accepted=1; path=/; max-age=" + (365 * 24 * 60 * 60);
    showToast('All cookies accepted!', 'success');
}

function showToast(message, type) {
    // Simple toast implementation
}
</script>

{include file='footer.tpl'}