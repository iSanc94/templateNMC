{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-error-section">
    <div class="mineless-error-bg">
        <div class="mineless-graveyard-overlay"></div>
        <div class="mineless-mist"></div>
    </div>
    
    <div class="mineless-error-container">
        <div class="mineless-error-content">
            <!-- Gravestone -->
            <div class="mineless-gravestone">
                <div class="mineless-gravestone-top">RIP</div>
                <div class="mineless-gravestone-body">
                    <span class="mineless-grave-name">{$USERNAME|default:'Unknown'}</span>
                    <span class="mineless-grave-date">??? - 404</span>
                    <span class="mineless-grave-epitaph">"Tidak pernah ada di sini"</span>
                </div>
                <div class="mineless-gravestone-base"></div>
            </div>
            
            <h1 class="mineless-error-title">Player Tidak Ditemukan</h1>
            <p class="mineless-error-message">
                Seperti mencari diamond di layer grass, pengguna ini tidak dapat ditemukan.
                <br><br>
                <em>"Mungkin mereka jatuh ke void?"</em>
            </p>
            
            <div class="mineless-search-box">
                <form action="{$MEMBERS_URL}" method="get">
                    <div class="mineless-input-group">
                        <i class="fas fa-search"></i>
                        <input type="text" name="search" placeholder="Cari player lain..." class="mineless-input">
                        <button type="submit" class="mineless-btn adv-btn-primary">Cari</button>
                    </div>
                </form>
            </div>
            
            <div class="mineless-error-actions">
                <a href="{$MEMBERS_URL}" class="mineless-btn adv-btn-primary">
                    <i class="fas fa-users"></i>
                    <span>Lihat Semua Member</span>
                </a>
                <a href="{$SITE_HOME}" class="mineless-btn adv-btn-outline">
                    <i class="fas fa-home"></i>
                    <span>Kembali ke Home</span>
                </a>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-error-section {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(180deg, #1a1a2e 0%, #0f0f1a 50%, #0a0a0f 100%);
    position: relative;
    overflow: hidden;
}

.mineless-error-bg {
    position: absolute;
    inset: 0;
}

.mineless-graveyard-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 30%;
    background: linear-gradient(to top, #0d1f0d, transparent);
}

.mineless-mist {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 200px;
    background: linear-gradient(to top, rgba(200,200,200,0.1), transparent);
    animation: mistFloat 10s ease-in-out infinite;
}

@keyframes mistFloat {
    0%, 100% { transform: translateX(0); opacity: 0.3; }
    50% { transform: translateX(50px); opacity: 0.5; }
}

.mineless-error-container {
    position: relative;
    z-index: 10;
    text-align: center;
    padding: 2rem;
}

.mineless-gravestone {
    display: inline-block;
    margin-bottom: 2rem;
    position: relative;
}

.mineless-gravestone-top {
    width: 100px;
    height: 50px;
    background: linear-gradient(180deg, #4a4a4a, #3a3a3a);
    border-radius: 50px 50px 0 0;
    margin: 0 auto -5px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: var(--font-display);
    font-size: 1.5rem;
    color: #666;
    border: 3px solid #2a2a2a;
}

.mineless-gravestone-body {
    width: 140px;
    background: linear-gradient(90deg, #4a4a4a, #5a5a5a, #4a4a4a);
    padding: 1.5rem 1rem;
    border: 3px solid #2a2a2a;
    border-top: none;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.mineless-grave-name {
    font-family: var(--font-display);
    font-size: 1.25rem;
    color: #333;
    text-shadow: 1px 1px 0 rgba(255,255,255,0.1);
}

.mineless-grave-date {
    font-size: 0.8rem;
    color: #555;
}

.mineless-grave-epitaph {
    font-size: 0.7rem;
    color: #666;
    font-style: italic;
}

.mineless-gravestone-base {
    width: 160px;
    height: 15px;
    background: #3a3a3a;
    margin: 0 auto;
    border-radius: 3px;
    border: 2px solid #2a2a2a;
}

.mineless-error-title {
    font-family: var(--font-display);
    font-size: 2rem;
    color: var(--text-primary);
    margin-bottom: 1rem;
}

.mineless-error-message {
    color: var(--text-secondary);
    font-size: 1.1rem;
    max-width: 500px;
    margin: 0 auto 2rem;
    line-height: 1.6;
}

.mineless-error-message em {
    color: var(--mineless-gold);
    font-style: italic;
}

.mineless-search-box {
    max-width: 400px;
    margin: 0 auto 2rem;
}

.mineless-input-group {
    display: flex;
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-md);
    overflow: hidden;
}

.mineless-input-group i {
    padding: 0 1rem;
    display: flex;
    align-items: center;
    color: var(--text-secondary);
}

.mineless-input-group .mineless-input {
    flex: 1;
    background: none;
    border: none;
    padding: 0.875rem 0;
    color: var(--text-primary);
    font-size: 1rem;
}

.mineless-input-group .mineless-input:focus {
    outline: none;
}

.mineless-input-group .mineless-btn {
    border-radius: 0;
    padding: 0.875rem 1.5rem;
}

.mineless-error-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
}

.mineless-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.875rem 1.5rem;
    border-radius: var(--radius-md);
    font-weight: 600;
    text-decoration: none;
    transition: var(--transition-fast);
    border: none;
    cursor: pointer;
    font-size: 1rem;
}

.mineless-btn-primary {
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    color: var(--bg-primary);
}

.mineless-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(212, 175, 55, 0.3);
}

.mineless-btn-outline {
    background: transparent;
    border: 2px solid rgba(212, 175, 55, 0.3);
    color: var(--mineless-gold);
}

.mineless-btn-outline:hover {
    border-color: var(--mineless-gold);
    background: rgba(212, 175, 55, 0.1);
}

@media (max-width: 768px) {
    .mineless-error-title {
        font-size: 1.5rem;
    }
}
</style>

<script>
// Add ghost floating effect
document.addEventListener('DOMContentLoaded', () => {
    const gravestone = document.querySelector('.mineless-gravestone');
    
    setInterval(() => {
        const ghost = document.createElement('div');
        ghost.innerHTML = '👻';
        ghost.style.cssText = `
            position: absolute;
            font-size: 2rem;
            left: ${Math.random() * 100}%;
            bottom: 0;
            opacity: 0;
            pointer-events: none;
            animation: ghostFloat 5s ease-out forwards;
        `;
        gravestone.appendChild(ghost);
        
        setTimeout(() => ghost.remove(), 5000);
    }, 3000);
});
</script>

<style>
@keyframes ghostFloat {
    0% { transform: translateY(0); opacity: 0; }
    20% { opacity: 0.6; }
    100% { transform: translateY(-200px); opacity: 0; }
}
</style>

{include file='footer.tpl'}