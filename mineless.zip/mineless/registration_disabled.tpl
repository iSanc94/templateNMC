{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-error-section">
    <div class="mineless-error-bg">
        <div class="mineless-gate-overlay"></div>
        <div class="mineless-chain-barrier"></div>
    </div>
    
    <div class="mineless-error-container">
        <div class="mineless-error-content">
            <!-- Closed Gate -->
            <div class="mineless-closed-gate">
                <div class="mineless-gate-frame">
                    <div class="mineless-gate-doors">
                        <div class="mineless-gate-door left">
                            <div class="mineless-gate-bars">
                                <span></span><span></span><span></span><span></span><span></span>
                            </div>
                        </div>
                        <div class="mineless-gate-door right">
                            <div class="mineless-gate-bars">
                                <span></span><span></span><span></span><span></span><span></span>
                            </div>
                        </div>
                    </div>
                    <div class="mineless-gate-lock">
                        <i class="fas fa-lock"></i>
                    </div>
                </div>
            </div>
            
            <h1 class="mineless-error-title">Pendaftaran Ditutup</h1>
            <p class="mineless-error-message">
                Gerbang masuk ke dunia petualangan saat ini ditutup.
                <br>
                {if isset($REGISTRATION_DISABLED_REASON)}
                    <strong>{$REGISTRATION_DISABLED_REASON}</strong>
                {else}
                    Silakan kembali lagi nanti atau hubungi admin untuk informasi lebih lanjut.
                {/if}
            </p>
            
            <div class="mineless-error-actions">
                <a href="{$SITE_HOME}" class="mineless-btn adv-btn-primary">
                    <i class="fas fa-home"></i>
                    <span>Kembali ke Beranda</span>
                </a>
                {if isset($DISCORD_INVITE)}
                    <a href="{$DISCORD_INVITE}" class="mineless-btn adv-btn-outline">
                        <i class="fab fa-discord"></i>
                        <span>Join Discord</span>
                    </a>
                {/if}
            </div>
            
            <div class="mineless-contact-info">
                <p>Jika merasa ini adalah kesalahan, silakan hubungi kami:</p>
                <a href="mailto:{$CONTACT_EMAIL|default:'admin@example.com'}" class="mineless-link">
                    <i class="fas fa-envelope"></i> {$CONTACT_EMAIL|default:'admin@example.com'}
                </a>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-error-section {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(180deg, #0a0a0f 0%, #1a1a2e 100%);
    position: relative;
    overflow: hidden;
}

.mineless-error-bg {
    position: absolute;
    inset: 0;
}

.mineless-gate-overlay {
    position: absolute;
    inset: 0;
    background: radial-gradient(ellipse at center, rgba(139,0,0,0.1) 0%, transparent 70%);
}

.mineless-chain-barrier {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 100px;
    background: repeating-linear-gradient(
        90deg,
        transparent,
        transparent 20px,
        rgba(212, 175, 55, 0.1) 20px,
        rgba(212, 175, 55, 0.1) 22px
    );
}

.mineless-error-container {
    position: relative;
    z-index: 10;
    text-align: center;
    padding: 2rem;
}

.mineless-closed-gate {
    width: 200px;
    height: 250px;
    margin: 0 auto 2rem;
    position: relative;
}

.mineless-gate-frame {
    position: absolute;
    inset: 0;
    border: 8px solid #4a4a4a;
    border-radius: 10px 10px 0 0;
    background: linear-gradient(180deg, #3a3a3a 0%, #2a2a2a 100%);
    overflow: hidden;
}

.mineless-gate-doors {
    display: flex;
    height: 100%;
    gap: 2px;
    padding: 4px;
}

.mineless-gate-door {
    flex: 1;
    background: linear-gradient(180deg, #5a5a5a 0%, #4a4a4a 100%);
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.mineless-gate-bars {
    display: flex;
    gap: 8px;
    height: 80%;
}

.mineless-gate-bars span {
    width: 6px;
    background: linear-gradient(180deg, #6a6a6a, #3a3a3a);
    border-radius: 3px;
}

.mineless-gate-lock {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: var(--bg-primary);
    box-shadow: 0 0 20px rgba(212, 175, 55, 0.5);
    animation: lockGlow 2s ease-in-out infinite;
}

@keyframes lockGlow {
    0%, 100% { box-shadow: 0 0 20px rgba(212, 175, 55, 0.5); }
    50% { box-shadow: 0 0 30px rgba(212, 175, 55, 0.8); }
}

.mineless-error-title {
    font-family: var(--font-display);
    font-size: 2rem;
    color: var(--text-primary);
    margin-bottom: 1rem;
}

.mineless-error-message {
    color: var(--text-secondary);
    font-size: 1.1rem;
    max-width: 500px;
    margin: 0 auto 2rem;
    line-height: 1.6;
}

.mineless-error-message strong {
    color: var(--mineless-gold);
    display: block;
    margin-top: 1rem;
    padding: 1rem;
    background: rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-md);
}

.mineless-error-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
    margin-bottom: 2rem;
}

.mineless-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.875rem 1.5rem;
    border-radius: var(--radius-md);
    font-weight: 600;
    text-decoration: none;
    transition: var(--transition-fast);
    border: none;
    cursor: pointer;
    font-size: 1rem;
}

.mineless-btn-primary {
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    color: var(--bg-primary);
}

.mineless-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(212, 175, 55, 0.3);
}

.mineless-btn-outline {
    background: transparent;
    border: 2px solid rgba(212, 175, 55, 0.3);
    color: var(--mineless-gold);
}

.mineless-btn-outline:hover {
    border-color: var(--mineless-gold);
    background: rgba(212, 175, 55, 0.1);
}

.mineless-contact-info {
    padding-top: 2rem;
    border-top: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-contact-info p {
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
}

.mineless-link {
    color: var(--mineless-gold);
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.mineless-link:hover {
    text-decoration: underline;
}

@media (max-width: 768px) {
    .mineless-error-title {
        font-size: 1.5rem;
    }
}
</style>

{include file='footer.tpl'}