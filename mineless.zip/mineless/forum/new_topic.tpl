{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- New Topic - Mineless Template -->
<div class="mineless-new-topic py-4">
    <div class="container">
        
        <!-- Header -->
        <div class="mineless-new-topic-header mb-4">
            <h1 class="mineless-title">
                <i class="fas fa-plus-circle mr-2"></i>Create New Topic
            </h1>
            <p class="mineless-subtitle">Start a new discussion in forum {$FORUM->title}</p>
        </div>

        <!-- Form -->
        <form action="{$FORM_ACTION}" method="post" enctype="multipart/form-data" id="adv-new-topic-form">
            <div class="row">
                <!-- Main Form -->
                <div class="col-lg-8">
                    <div class="mineless-form-card">
                        <!-- Forum Selection -->
                        <div class="form-group">
                            <label class="mineless-label">
                                <i class="fas fa-folder mr-1"></i>Forum / Category
                            </label>
                            <select name="forum" class="form-control adv-select" required>
                                {foreach from=$FORUM_CATEGORIES item=category}
                                    <optgroup label="{$category->title}">
                                        {foreach from=$category->forums item=forum}
                                            <option value="{$forum->id}" {($forum->id == $FORUM->id) ? 'selected' : ''}>
                                                {$forum->title}
                                            </option>
                                        {/foreach}
                                    </optgroup>
                                {/foreach}
                            </select>
                        </div>

                        <!-- Title -->
                        <div class="form-group">
                            <label class="mineless-label">
                                <i class="fas fa-heading mr-1"></i>Topic Title
                            </label>
                            <input type="text" name="title" class="form-control adv-input" 
                                   placeholder="Enter a clear and interesting title..." 
                                   maxlength="100" required>
                            <small class="mineless-input-hint">Maximum 100 characters</small>
                        </div>

                        <!-- Tags -->
                        <div class="form-group">
                            <label class="mineless-label">
                                <i class="fas fa-tags mr-1"></i>Tags
                            </label>
                            <div class="mineless-tag-input-wrapper">
                                <div class="mineless-tag-container" id="tag-container">
                                    <!-- Tags will be added here -->
                                </div>
                                <input type="text" class="mineless-tag-input" id="tag-input" 
                                       placeholder="Add tag... (Press Enter to add)" maxlength="20">
                            </div>
                            <input type="hidden" name="tags" id="tags-hidden">
                            <small class="mineless-input-hint">Maximum 5 tags</small>
                        </div>

                        <!-- Content Editor -->
                        <div class="form-group">
                            <label class="mineless-label">
                                <i class="fas fa-edit mr-1"></i>Content
                            </label>
                            
                            <!-- WYSIWYG Toolbar -->
                            <div class="mineless-editor-toolbar">
                                <div class="mineless-toolbar-group">
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="b" title="Bold">
                                        <i class="fas fa-bold"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="i" title="Italic">
                                        <i class="fas fa-italic"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="u" title="Underline">
                                        <i class="fas fa-underline"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="s" title="Strikethrough">
                                        <i class="fas fa-strikethrough"></i>
                                    </button>
                                </div>
                                <div class="mineless-toolbar-sep"></div>
                                <div class="mineless-toolbar-group">
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="h2" title="Heading">
                                        <i class="fas fa-heading"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="color" title="Color">
                                        <i class="fas fa-palette"></i>
                                    </button>
                                </div>
                                <div class="mineless-toolbar-sep"></div>
                                <div class="mineless-toolbar-group">
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="url" title="Link">
                                        <i class="fas fa-link"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="img" title="Image">
                                        <i class="fas fa-image"></i>
                                    </button>
                                </div>
                                <div class="mineless-toolbar-sep"></div>
                                <div class="mineless-toolbar-group">
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="quote" title="Quote">
                                        <i class="fas fa-quote-left"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="code" title="Code">
                                        <i class="fas fa-code"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="spoiler" title="Spoiler">
                                        <i class="fas fa-eye-slash"></i>
                                    </button>
                                </div>
                                <div class="mineless-toolbar-sep"></div>
                                <div class="mineless-toolbar-group">
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="list" title="List">
                                        <i class="fas fa-list"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn" data-bbcode="center" title="Center">
                                        <i class="fas fa-align-center"></i>
                                    </button>
                                </div>
                                <div class="mineless-toolbar-sep"></div>
                                <div class="mineless-toolbar-group">
                                    <button type="button" class="mineless-toolbar-btn" id="emoji-btn" title="Emoji">
                                        <i class="fas fa-smile"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn" id="mention-btn" title="Mention">
                                        <i class="fas fa-at"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- Editor -->
                            <textarea name="content" class="form-control adv-editor-textarea" 
                                      rows="12" placeholder="Write your topic content here..." required></textarea>
                            
                            <!-- Character Count -->
                            <div class="mineless-char-count">
                                <span id="char-count">0</span> characters
                            </div>
                        </div>

                        <!-- Attachments -->
                        <div class="form-group">
                            <label class="mineless-label">
                                <i class="fas fa-paperclip mr-1"></i>Attachments
                            </label>
                            <div class="mineless-dropzone" id="dropzone">
                                <input type="file" name="attachments[]" id="file-input" multiple 
                                       accept="image/*,.pdf,.doc,.docx,.txt,.zip">
                                <div class="mineless-dropzone-content">
                                    <i class="fas fa-cloud-upload-alt fa-3x mb-3"></i>
                                    <p>Drag & drop files here or <span class="mineless-browse">click to browse</span></p>
                                    <small class="text-muted">Maximum 5 files, 10MB each</small>
                                </div>
                            </div>
                            <div class="mineless-attachments-list" id="attachments-list"></div>
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="col-lg-4">
                    <!-- Preview Card -->
                    <div class="mineless-sidebar-card mb-4">
                        <div class="mineless-sidebar-header">
                            <i class="fas fa-eye mr-2"></i>Preview
                        </div>
                        <div class="mineless-sidebar-content">
                            <button type="button" class="btn adv-btn-preview w-100" id="preview-toggle">
                                <i class="fas fa-eye mr-2"></i>View Preview
                            </button>
                            <div class="mineless-preview-content d-none" id="preview-content">
                                <div class="mineless-preview-header">
                                    <span id="preview-title">Preview Title</span>
                                </div>
                                <div class="mineless-preview-body" id="preview-body">
                                    Preview content will appear here...
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Poll Creator -->
                    <div class="mineless-sidebar-card mb-4">
                        <div class="mineless-sidebar-header d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-poll mr-2"></i>Poll</span>
                            <label class="mineless-toggle">
                                <input type="checkbox" name="enable_poll" id="enable-poll">
                                <span class="mineless-toggle-slider"></span>
                            </label>
                        </div>
                        <div class="mineless-sidebar-content d-none" id="poll-section">
                            <div class="form-group">
                                <input type="text" name="poll_question" class="form-control adv-input-sm" 
                                       placeholder="Poll question...">
                            </div>
                            <div class="mineless-poll-options" id="poll-options">
                                <div class="form-group adv-poll-option">
                                    <input type="text" name="poll_options[]" class="form-control adv-input-sm" 
                                           placeholder="Option 1" required>
                                </div>
                                <div class="form-group adv-poll-option">
                                    <input type="text" name="poll_options[]" class="form-control adv-input-sm" 
                                           placeholder="Option 2" required>
                                </div>
                            </div>
                            <button type="button" class="btn adv-btn-add-option" id="add-poll-option">
                                <i class="fas fa-plus mr-1"></i>Add Option
                            </button>
                        </div>
                    </div>

                    <!-- Guidelines -->
                    <div class="mineless-sidebar-card">
                        <div class="mineless-sidebar-header">
                            <i class="fas fa-info-circle mr-2"></i>Guidelines
                        </div>
                        <div class="mineless-sidebar-content">
                            <ul class="mineless-guidelines">
                                <li>Use a clear and descriptive title</li>
                                <li>Make sure content is appropriate for the forum</li>
                                <li>Avoid spam and excessive promotion</li>
                                <li>Use relevant tags</li>
                                <li>Respect other members</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Form Actions -->
            <div class="mineless-form-actions">
                <button type="submit" class="btn adv-btn-submit">
                    <i class="fas fa-paper-plane mr-2"></i>Post Topic
                </button>
                <button type="button" class="btn adv-btn-draft" id="save-draft">
                    <i class="fas fa-save mr-2"></i>Save Draft
                </button>
                <a href="{$FORUM->link}" class="btn adv-btn-cancel">
                    <i class="fas fa-times mr-2"></i>Cancel
                </a>
            </div>

            <input type="hidden" name="token" value="{$TOKEN}">
        </form>

    </div>
</div>

<style>
/* New Topic Styles */
.mineless-new-topic {
    background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
    min-height: 100vh;
}

.mineless-new-topic-header {
    text-align: center;
    padding: 30px 0;
}

.mineless-new-topic-header .mineless-title {
    color: #ffd700;
    font-weight: 700;
    font-size: 2rem;
    margin-bottom: 10px;
}

.mineless-new-topic-header .mineless-subtitle {
    color: #888;
    margin: 0;
}

.mineless-form-card {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    padding: 30px;
    border: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-label {
    color: #ccc;
    font-weight: 500;
    margin-bottom: 10px;
    display: block;
}

.mineless-label i {
    color: #ffd700;
}

.mineless-input, .mineless-select, .mineless-textarea {
    background: rgba(0, 0, 0, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #fff;
    border-radius: 8px;
    padding: 12px 15px;
}

.mineless-input:focus, .mineless-select:focus, .mineless-textarea:focus {
    background: rgba(0, 0, 0, 0.3);
    border-color: rgba(255, 215, 0, 0.5);
    color: #fff;
    box-shadow: 0 0 10px rgba(255, 215, 0, 0.1);
}

.mineless-input-hint {
    color: #666;
    font-size: 0.8rem;
    margin-top: 5px;
}

/* Tag Input */
.mineless-tag-input-wrapper {
    background: rgba(0, 0, 0, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    padding: 8px 12px;
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    min-height: 50px;
}

.mineless-tag-container {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.mineless-tag-chip {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    color: #1a1a2e;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 6px;
}

.mineless-tag-chip .mineless-tag-remove {
    cursor: pointer;
    opacity: 0.7;
    transition: opacity 0.3s;
}

.mineless-tag-chip .mineless-tag-remove:hover {
    opacity: 1;
}

.mineless-tag-input {
    background: transparent;
    border: none;
    color: #fff;
    flex: 1;
    min-width: 100px;
    outline: none;
}

.mineless-tag-input::placeholder {
    color: #666;
}

/* Editor Toolbar */
.mineless-editor-toolbar {
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-bottom: none;
    border-radius: 8px 8px 0 0;
    padding: 10px;
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
}

.mineless-toolbar-group {
    display: flex;
    gap: 2px;
}

.mineless-toolbar-btn {
    background: transparent;
    border: none;
    color: #888;
    padding: 8px 12px;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.3s;
}

.mineless-toolbar-btn:hover {
    background: rgba(255, 215, 0, 0.1);
    color: #ffd700;
}

.mineless-toolbar-sep {
    width: 1px;
    background: rgba(255, 255, 255, 0.1);
    margin: 0 5px;
}

.mineless-editor-textarea {
    background: rgba(0, 0, 0, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-top: none;
    border-radius: 0 0 8px 8px;
    color: #ccc;
    resize: vertical;
    min-height: 250px;
}

.mineless-char-count {
    text-align: right;
    color: #666;
    font-size: 0.85rem;
    margin-top: 5px;
}

/* Dropzone */
.mineless-dropzone {
    position: relative;
    background: rgba(0, 0, 0, 0.2);
    border: 2px dashed rgba(255, 255, 255, 0.2);
    border-radius: 8px;
    padding: 40px;
    text-align: center;
    transition: all 0.3s;
}

.mineless-dropzone:hover, .mineless-dropzone.dragover {
    border-color: #ffd700;
    background: rgba(255, 215, 0, 0.05);
}

.mineless-dropzone input[type="file"] {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    cursor: pointer;
}

.mineless-dropzone-content i {
    color: #ffd700;
}

.mineless-dropzone-content p {
    color: #888;
    margin: 0;
}

.mineless-browse {
    color: #ffd700;
    cursor: pointer;
}

.mineless-attachments-list {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 15px;
}

.mineless-attachment-item {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 8px;
    padding: 10px 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.mineless-attachment-item i {
    color: #ffd700;
}

/* Sidebar Cards */
.mineless-sidebar-card {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-sidebar-header {
    background: rgba(0, 0, 0, 0.3);
    padding: 15px 20px;
    color: #ffd700;
    font-weight: 600;
}

.mineless-sidebar-content {
    padding: 20px;
}

.mineless-btn-preview {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: #ccc;
}

.mineless-btn-preview:hover {
    background: rgba(255, 215, 0, 0.1);
    border-color: rgba(255, 215, 0, 0.3);
    color: #ffd700;
}

.mineless-preview-content {
    margin-top: 15px;
    background: rgba(0, 0, 0, 0.2);
    border-radius: 8px;
    overflow: hidden;
}

.mineless-preview-header {
    background: rgba(255, 215, 0, 0.1);
    padding: 10px 15px;
    color: #ffd700;
    font-weight: 600;
}

.mineless-preview-body {
    padding: 15px;
    color: #aaa;
    font-size: 0.9rem;
    max-height: 200px;
    overflow-y: auto;
}

/* Toggle Switch */
.mineless-toggle {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 26px;
    margin: 0;
}

.mineless-toggle input {
    opacity: 0;
    width: 0;
    height: 0;
}

.mineless-toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 26px;
    transition: all 0.3s;
}

.mineless-toggle-slider::before {
    content: '';
    position: absolute;
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background: #fff;
    border-radius: 50%;
    transition: all 0.3s;
}

.mineless-toggle input:checked + .mineless-toggle-slider {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
}

.mineless-toggle input:checked + .mineless-toggle-slider::before {
    transform: translateX(24px);
}

/* Poll */
.mineless-poll-option {
    position: relative;
}

.mineless-input-sm {
    background: rgba(0, 0, 0, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #fff;
    border-radius: 6px;
    padding: 8px 12px;
}

.mineless-input-sm:focus {
    background: rgba(0, 0, 0, 0.3);
    border-color: rgba(255, 215, 0, 0.5);
    color: #fff;
    box-shadow: none;
}

.mineless-btn-add-option {
    background: rgba(255, 215, 0, 0.1);
    border: 1px dashed rgba(255, 215, 0, 0.3);
    color: #ffd700;
    font-size: 0.85rem;
    width: 100%;
}

.mineless-btn-add-option:hover {
    background: rgba(255, 215, 0, 0.2);
    color: #ffd700;
}

/* Guidelines */
.mineless-guidelines {
    list-style: none;
    padding: 0;
    margin: 0;
}

.mineless-guidelines li {
    color: #888;
    font-size: 0.9rem;
    padding: 8px 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    padding-left: 20px;
    position: relative;
}

.mineless-guidelines li::before {
    content: '•';
    color: #ffd700;
    position: absolute;
    left: 5px;
}

.mineless-guidelines li:last-child {
    border-bottom: none;
}

/* Form Actions */
.mineless-form-actions {
    display: flex;
    gap: 15px;
    margin-top: 30px;
    padding-top: 30px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.mineless-btn-submit {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    border: none;
    color: #1a1a2e;
    font-weight: 600;
    padding: 14px 35px;
    border-radius: 8px;
    transition: all 0.3s;
}

.mineless-btn-submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(255, 215, 0, 0.3);
}

.mineless-btn-draft {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: #ccc;
    padding: 14px 30px;
    border-radius: 8px;
    transition: all 0.3s;
}

.mineless-btn-draft:hover {
    background: rgba(255, 255, 255, 0.15);
    color: #fff;
}

.mineless-btn-cancel {
    background: transparent;
    border: 1px solid rgba(231, 76, 60, 0.3);
    color: #e74c3c;
    padding: 14px 30px;
    border-radius: 8px;
    transition: all 0.3s;
}

.mineless-btn-cancel:hover {
    background: rgba(231, 76, 60, 0.1);
    color: #e74c3c;
}

@media (max-width: 768px) {
    .mineless-form-actions {
        flex-direction: column;
    }
    
    .mineless-form-actions .btn {
        width: 100%;
    }
}
</style>

<script>
// Tag Input
const tagContainer = document.getElementById('tag-container');
const tagInput = document.getElementById('tag-input');
const tagsHidden = document.getElementById('tags-hidden');
let tags = [];

tagInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && tagInput.value.trim() && tags.length < 5) {
        e.preventDefault();
        addTag(tagInput.value.trim());
        tagInput.value = '';
    }
});

function addTag(tag) {
    if (tags.includes(tag)) return;
    tags.push(tag);
    updateTags();
}

function removeTag(tag) {
    tags = tags.filter(t => t !== tag);
    updateTags();
}

function updateTags() {
    tagContainer.innerHTML = tags.map(tag => `
        <span class="mineless-tag-chip">
            ${tag}
            <i class="fas fa-times adv-tag-remove" onclick="removeTag('${tag}')"></i>
        </span>
    `).join('');
    tagsHidden.value = JSON.stringify(tags);
}

// Character Count
const textarea = document.querySelector('.mineless-editor-textarea');
const charCount = document.getElementById('char-count');
textarea.addEventListener('input', () => {
    charCount.textContent = textarea.value.length;
});

// BBCode Toolbar
document.querySelectorAll('.mineless-toolbar-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const bbcode = btn.dataset.bbcode;
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selected = textarea.value.substring(start, end);
        
        let replacement = '';
        switch(bbcode) {
            case 'b': replacement = `[b]${selected || 'bold'}[/b]`; break;
            case 'i': replacement = `[i]${selected || 'italic'}[/i]`; break;
            case 'u': replacement = `[u]${selected || 'underline'}[/u]`; break;
            case 's': replacement = `[s]${selected || 'strikethrough'}[/s]`; break;
            case 'h2': replacement = `[h2]${selected || 'heading'}[/h2]`; break;
            case 'color': replacement = `[color=#ffd700]${selected || 'colored text'}[/color]`; break;
            case 'url': replacement = `[url=${selected || 'https://'}]${selected || 'link'}[/url]`; break;
            case 'img': replacement = `[img]${selected || 'image url'}[/img]`; break;
            case 'quote': replacement = `[quote=User]${selected || 'quoted text'}[/quote]`; break;
            case 'code': replacement = `[code]${selected || 'code'}[/code]`; break;
            case 'spoiler': replacement = `[spoiler]${selected || 'spoiler'}[/spoiler]`; break;
            case 'list': replacement = `[list][*]${selected || 'item 1'}\n[*]item 2[/list]`; break;
            case 'center': replacement = `[center]${selected || 'centered text'}[/center]`; break;
        }
        
        textarea.value = textarea.value.substring(0, start) + replacement + textarea.value.substring(end);
        textarea.focus();
    });
});

// Dropzone
const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('file-input');
const attachmentsList = document.getElementById('attachments-list');

dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('dragover');
});

dropzone.addEventListener('dragleave', () => {
    dropzone.classList.remove('dragover');
});

dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    handleFiles(e.dataTransfer.files);
});

fileInput.addEventListener('change', (e) => {
    handleFiles(e.target.files);
});

function handleFiles(files) {
    Array.from(files).forEach(file => {
        if (file.size > 10 * 1024 * 1024) {
            alert(`File ${file.name} is too large (max 10MB)`);
            return;
        }
        const div = document.createElement('div');
        div.className = 'adv-attachment-item';
        div.innerHTML = `
            <i class="fas fa-file"></i>
            <span>${file.name}</span>
            <small class="text-muted">(${(file.size / 1024).toFixed(1)} KB)</small>
        `;
        attachmentsList.appendChild(div);
    });
}

// Poll Toggle
const enablePoll = document.getElementById('enable-poll');
const pollSection = document.getElementById('poll-section');
enablePoll.addEventListener('change', () => {
    pollSection.classList.toggle('d-none', !enablePoll.checked);
});

// Add Poll Option
const pollOptions = document.getElementById('poll-options');
document.getElementById('add-poll-option').addEventListener('click', () => {
    const count = pollOptions.children.length + 1;
    const div = document.createElement('div');
    div.className = 'form-group adv-poll-option';
    div.innerHTML = `
        <div class="input-group">
            <input type="text" name="poll_options[]" class="form-control adv-input-sm" 
                   placeholder="Option ${count}" required>
            <div class="input-group-append">
                <button type="button" class="btn btn-outline-danger adv-remove-option">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    `;
    pollOptions.appendChild(div);
    div.querySelector('.mineless-remove-option').addEventListener('click', () => div.remove());
});

// Preview Toggle
document.getElementById('preview-toggle').addEventListener('click', () => {
    document.getElementById('preview-content').classList.toggle('d-none');
    document.getElementById('preview-title').textContent = 
        document.querySelector('input[name="title"]').value || 'Preview Title';
    document.getElementById('preview-body').innerHTML = 
        textarea.value.replace(/\n/g, '<br>') || 'Preview content...';
});

// Save Draft
document.getElementById('save-draft').addEventListener('click', () => {
    localStorage.setItem('topic_draft', JSON.stringify({
        title: document.querySelector('input[name="title"]').value,
        content: textarea.value,
        tags: tags
    }));
    alert('Draft saved!');
});

// Load Draft
window.addEventListener('load', () => {
    const draft = localStorage.getItem('topic_draft');
    if (draft) {
        const data = JSON.parse(draft);
        if (data.title || data.content) {
            if (confirm('There is a saved draft. Load draft?')) {
                document.querySelector('input[name="title"]').value = data.title || '';
                textarea.value = data.content || '';
                tags = data.tags || [];
                updateTags();
            }
        }
    }
});
</script>

{include file='footer.tpl'}
