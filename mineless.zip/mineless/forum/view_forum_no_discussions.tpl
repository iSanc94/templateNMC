{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- Empty Forum State - Mineless Template -->
<div class="mineless-empty-forum py-5">
    <div class="container">
        
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mineless-breadcrumb mb-4">
            <ol class="breadcrumb bg-transparent p-0">
                <li class="breadcrumb-item"><a href="{$HOME_URL}"><i class="fas fa-home"></i></a></li>
                <li class="breadcrumb-item"><a href="{$FORUM_INDEX_URL}">Forum</a></li>
                {if isset($CATEGORY)}
                    <li class="breadcrumb-item"><a href="{$CATEGORY->link}">{$CATEGORY->title}</a></li>
                {/if}
                <li class="breadcrumb-item active" aria-current="page">{$FORUM->title}</li>
            </ol>
        </nav>

        <!-- Forum Header -->
        <div class="mineless-forum-header-empty mb-5">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="d-flex align-items-center">
                        <div class="mineless-forum-icon-empty">
                            <i class="fas {($FORUM->icon) ? $FORUM->icon : 'fa-comments'}"></i>
                        </div>
                        <div class="ml-3">
                            <h1 class="mineless-forum-title-empty">{$FORUM->title}</h1>
                            <p class="mineless-forum-description-empty mb-0">{$FORUM->description}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-md-right">
                    <span class="mineless-empty-stats">
                        <i class="fas fa-list mr-2"></i>0 topic
                    </span>
                </div>
            </div>
        </div>

        <!-- Empty State Content -->
        <div class="mineless-empty-state-container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    
                    <!-- Animated Scroll Illustration -->
                    <div class="mineless-scroll-illustration mb-5">
                        <div class="mineless-scroll-wrapper">
                            <svg class="mineless-scroll-svg" viewBox="0 0 200 240" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <!-- Scroll Background -->
                                <rect x="30" y="20" width="140" height="200" rx="5" fill="#2a2a4a" stroke="#ffd700" stroke-width="2"/>
                                
                                <!-- Scroll Lines (Content) -->
                                <line x1="50" y1="50" x2="150" y2="50" stroke="#444" stroke-width="3" stroke-linecap="round"/>
                                <line x1="50" y1="70" x2="140" y2="70" stroke="#444" stroke-width="3" stroke-linecap="round"/>
                                <line x1="50" y1="90" x2="130" y2="90" stroke="#444" stroke-width="3" stroke-linecap="round"/>
                                <line x1="50" y1="110" x2="150" y2="110" stroke="#444" stroke-width="3" stroke-linecap="round"/>
                                <line x1="50" y1="130" x2="120" y2="130" stroke="#444" stroke-width="3" stroke-linecap="round"/>
                                <line x1="50" y1="150" x2="140" y2="150" stroke="#444" stroke-width="3" stroke-linecap="round"/>
                                <line x1="50" y1="170" x2="150" y2="170" stroke="#444" stroke-width="3" stroke-linecap="round"/>
                                
                                <!-- Question Mark -->
                                <text x="100" y="195" text-anchor="middle" fill="#ffd700" font-size="20" font-weight="bold" opacity="0.5">?</text>
                                
                                <!-- Scroll Top/Bottom Rolls -->
                                <rect x="25" y="15" width="150" height="15" rx="7" fill="#3a3a5a" stroke="#ffd700" stroke-width="2"/>
                                <rect x="25" y="210" width="150" height="15" rx="7" fill="#3a3a5a" stroke="#ffd700" stroke-width="2"/>
                                
                                <!-- Decorative Sparkles -->
                                <circle cx="25" cy="120" r="3" fill="#ffd700" class="mineless-sparkle"/>
                                <circle cx="175" cy="80" r="2" fill="#ffd700" class="mineless-sparkle"/>
                                <circle cx="40" cy="200" r="2" fill="#ffd700" class="mineless-sparkle"/>
                            </svg>
                        </div>
                        
                        <!-- Floating Particles -->
                        <div class="mineless-particles">
                            <span class="mineless-particle"></span>
                            <span class="mineless-particle"></span>
                            <span class="mineless-particle"></span>
                            <span class="mineless-particle"></span>
                            <span class="mineless-particle"></span>
                        </div>
                    </div>

                    <!-- Empty State Text -->
                    <h2 class="mineless-empty-title">
                        <i class="fas fa-scroll mr-2"></i>
                        Empty Scroll
                    </h2>
                    <p class="mineless-empty-description">
                        This forum doesn't have any topics yet. 
                        Be the first adventurer to write a story here!
                    </p>

                    <!-- CTA Button -->
                    <div class="mineless-empty-cta">
                        {if $CAN_CREATE_TOPIC}
                            <a href="{$NEW_TOPIC_URL}" class="btn adv-btn-first-post">
                                <span class="btn-content">
                                    <i class="fas fa-feather-alt mr-2"></i>
                                    Be the first to post!
                                </span>
                                <span class="btn-shine"></span>
                            </a>
                        {else}
                            <div class="mineless-login-prompt">
                                <i class="fas fa-lock mr-2"></i>
                                <a href="{$LOGIN_URL}">Login</a> or 
                                <a href="{$REGISTER_URL}">Register</a> 
                                to create a topic
                            </div>
                        {/if}
                    </div>

                    <!-- Alternative Actions -->
                    <div class="mineless-alt-actions mt-5">
                        <p class="mineless-alt-text">Or explore:</p>
                        <div class="mineless-alt-buttons">
                            <a href="{$FORUM_INDEX_URL}" class="btn adv-alt-btn">
                                <i class="fas fa-arrow-left mr-2"></i>All Forums
                            </a>
                            {if $LATEST_TOPICS_URL}
                                <a href="{$LATEST_TOPICS_URL}" class="btn adv-alt-btn">
                                    <i class="fas fa-clock mr-2"></i>Latest Topics
                                </a>
                            {/if}
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- Forum Stats Mini -->
        <div class="mineless-forum-stats-mini mt-5">
            <div class="row justify-content-center">
                <div class="col-auto">
                    <div class="mineless-stat-mini">
                        <i class="fas fa-folder"></i>
                        <span>{$TOTAL_FORUMS} forum</span>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="mineless-stat-mini">
                        <i class="fas fa-comments"></i>
                        <span>{$TOTAL_TOPICS} topics</span>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="mineless-stat-mini">
                        <i class="fas fa-comment-alt"></i>
                        <span>{$TOTAL_POSTS} posts</span>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<style>
/* Empty Forum Styles */
.mineless-empty-forum {
    background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
    min-height: 100vh;
}

.mineless-breadcrumb .breadcrumb-item a {
    color: #ffd700;
}

.mineless-breadcrumb .breadcrumb-item.active {
    color: #888;
}

.mineless-forum-header-empty {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    padding: 24px;
    border: 1px solid rgba(255, 215, 0, 0.2);
}

.mineless-forum-icon-empty {
    width: 60px;
    height: 60px;
    background: rgba(255, 215, 0, 0.1);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: #ffd700;
    border: 2px solid rgba(255, 215, 0, 0.3);
}

.mineless-forum-title-empty {
    color: #fff;
    font-weight: 700;
    margin-bottom: 4px;
}

.mineless-forum-description-empty {
    color: #888;
}

.mineless-empty-stats {
    color: #666;
    font-size: 0.9rem;
}

.mineless-empty-state-container {
    padding: 40px 0;
}

/* Scroll Illustration */
.mineless-scroll-illustration {
    position: relative;
    display: inline-block;
}

.mineless-scroll-wrapper {
    position: relative;
    z-index: 2;
}

.mineless-scroll-svg {
    width: 200px;
    height: 240px;
    filter: drop-shadow(0 10px 30px rgba(255, 215, 0, 0.2));
}

.mineless-sparkle {
    animation: adv-sparkle 2s ease-in-out infinite;
}

.mineless-sparkle:nth-child(2) { animation-delay: 0.5s; }
.mineless-sparkle:nth-child(3) { animation-delay: 1s; }

@keyframes adv-sparkle {
    0%, 100% { opacity: 0.3; transform: scale(1); }
    50% { opacity: 1; transform: scale(1.2); }
}

/* Floating Particles */
.mineless-particles {
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 300px;
    height: 100%;
    pointer-events: none;
}

.mineless-particle {
    position: absolute;
    width: 6px;
    height: 6px;
    background: #ffd700;
    border-radius: 50%;
    opacity: 0;
    animation: adv-float-up 3s ease-in-out infinite;
}

.mineless-particle:nth-child(1) { left: 20%; animation-delay: 0s; }
.mineless-particle:nth-child(2) { left: 40%; animation-delay: 0.5s; }
.mineless-particle:nth-child(3) { left: 60%; animation-delay: 1s; }
.mineless-particle:nth-child(4) { left: 80%; animation-delay: 1.5s; }
.mineless-particle:nth-child(5) { left: 30%; animation-delay: 2s; }

@keyframes adv-float-up {
    0% {
        bottom: 0;
        opacity: 0;
        transform: translateX(0) scale(0);
    }
    20% {
        opacity: 0.8;
    }
    80% {
        opacity: 0.5;
    }
    100% {
        bottom: 100%;
        opacity: 0;
        transform: translateX(20px) scale(1);
    }
}

/* Empty State Text */
.mineless-empty-title {
    color: #ffd700;
    font-weight: 700;
    font-size: 2rem;
    margin-bottom: 15px;
}

.mineless-empty-description {
    color: #888;
    font-size: 1.1rem;
    max-width: 500px;
    margin: 0 auto 30px;
}

/* CTA Button */
.mineless-empty-cta {
    margin: 30px 0;
}

.mineless-btn-first-post {
    position: relative;
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    border: none;
    color: #1a1a2e;
    font-weight: 700;
    font-size: 1.1rem;
    padding: 18px 40px;
    border-radius: 50px;
    overflow: hidden;
    transition: all 0.3s;
    box-shadow: 0 5px 20px rgba(255, 215, 0, 0.3);
}

.mineless-btn-first-post:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 40px rgba(255, 215, 0, 0.5);
    color: #1a1a2e;
    text-decoration: none;
}

.btn-content {
    position: relative;
    z-index: 2;
}

.btn-shine {
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.4),
        transparent
    );
    animation: adv-shine 3s infinite;
}

@keyframes adv-shine {
    0% { left: -100%; }
    50%, 100% { left: 100%; }
}

/* Login Prompt */
.mineless-login-prompt {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #888;
    padding: 18px 30px;
    border-radius: 50px;
    display: inline-block;
}

.mineless-login-prompt a {
    color: #ffd700;
    font-weight: 500;
}

.mineless-login-prompt a:hover {
    color: #ffaa00;
}

/* Alternative Actions */
.mineless-alt-text {
    color: #666;
    margin-bottom: 15px;
}

.mineless-alt-buttons {
    display: flex;
    justify-content: center;
    gap: 15px;
    flex-wrap: wrap;
}

.mineless-alt-btn {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #888;
    padding: 10px 25px;
    border-radius: 25px;
    transition: all 0.3s;
}

.mineless-alt-btn:hover {
    background: rgba(255, 215, 0, 0.1);
    border-color: rgba(255, 215, 0, 0.3);
    color: #ffd700;
    text-decoration: none;
}

/* Forum Stats Mini */
.mineless-forum-stats-mini {
    padding-top: 30px;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-stat-mini {
    background: rgba(255, 255, 255, 0.03);
    padding: 12px 25px;
    border-radius: 25px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: #666;
    font-size: 0.9rem;
}

.mineless-stat-mini i {
    color: #ffd700;
}

@media (max-width: 768px) {
    .mineless-scroll-svg {
        width: 150px;
        height: 180px;
    }
    
    .mineless-empty-title {
        font-size: 1.5rem;
    }
    
    .mineless-btn-first-post {
        padding: 15px 30px;
        font-size: 1rem;
    }
}
</style>

{include file='footer.tpl'}
