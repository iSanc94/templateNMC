{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- View Topic - Mineless Template -->
<div class="mineless-view-topic py-4">
    <div class="container">
        
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mineless-breadcrumb mb-3">
            <ol class="breadcrumb bg-transparent p-0">
                <li class="breadcrumb-item"><a href="{$HOME_URL}"><i class="fas fa-home"></i></a></li>
                <li class="breadcrumb-item"><a href="{$FORUM_INDEX_URL}">Forum</a></li>
                {if isset($CATEGORY)}
                    <li class="breadcrumb-item"><a href="{$CATEGORY->link}">{$CATEGORY->title}</a></li>
                {/if}
                <li class="breadcrumb-item"><a href="{$FORUM->link}">{$FORUM->title}</a></li>
                <li class="breadcrumb-item active" aria-current="page">{$TOPIC->title|truncate:40}</li>
            </ol>
        </nav>

        <!-- Topic Header -->
        <div class="mineless-topic-header mb-4">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="d-flex align-items-center flex-wrap">
                        {if $TOPIC->pinned}
                            <span class="mineless-status-badge adv-badge-pinned mr-2">
                                <i class="fas fa-thumbtack mr-1"></i>Pinned
                            </span>
                        {/if}
                        {if $TOPIC->locked}
                            <span class="mineless-status-badge adv-badge-locked mr-2">
                                <i class="fas fa-lock mr-1"></i>Locked
                            </span>
                        {/if}
                        <h1 class="mineless-topic-title-main">{$TOPIC->title}</h1>
                    </div>
                    {if $TOPIC->labels}
                        <div class="mineless-topic-tags mt-2">
                            {foreach from=$TOPIC->labels item=label}
                                <span class="mineless-tag" style="background: {$label->color}">{$label->name}</span>
                            {/foreach}
                        </div>
                    {/if}
                </div>
                <div class="col-md-4 text-md-right mt-3 mt-md-0">
                    <div class="mineless-topic-actions">
                        {if $CAN_SUBSCRIBE}
                            <button class="btn adv-btn-subscribe {($SUBSCRIBED) ? 'active' : ''}" 
                                    data-topic="{$TOPIC->id}" data-action="{($SUBSCRIBED) ? 'unsubscribe' : 'subscribe'}">
                                <i class="fas {($SUBSCRIBED) ? 'fa-bell-slash' : 'fa-bell'} mr-1"></i>
                                {($SUBSCRIBED) ? 'Unfollow' : 'Follow'}
                            </button>
                        {/if}
                        {if $CAN_MODERATE}
                            <div class="btn-group ml-2">
                                <button type="button" class="btn adv-btn-mod dropdown-toggle" data-toggle="dropdown">
                                    <i class="fas fa-cog mr-1"></i>Mod
                                </button>
                                <div class="dropdown-menu dropdown-menu-right adv-dropdown">
                                    {if $CAN_PIN}
                                        <a class="dropdown-item" href="{$PIN_URL}">
                                            <i class="fas fa-thumbtack mr-2"></i>{($TOPIC->pinned) ? 'Unpin' : 'Pin'}
                                        </a>
                                    {/if}
                                    {if $CAN_LOCK}
                                        <a class="dropdown-item" href="{$LOCK_URL}">
                                            <i class="fas fa-lock mr-2"></i>{($TOPIC->locked) ? 'Unlock' : 'Lock'}
                                        </a>
                                    {/if}
                                    {if $CAN_MOVE}
                                        <a class="dropdown-item" href="{$MOVE_URL}">
                                            <i class="fas fa-arrows-alt mr-2"></i>Move
                                        </a>
                                    {/if}
                                    {if $CAN_DELETE}
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item text-danger" href="{$DELETE_URL}" onclick="return confirm('Delete this topic?')">
                                            <i class="fas fa-trash mr-2"></i>Delete
                                        </a>
                                    {/if}
                                </div>
                            </div>
                        {/if}
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Pagination -->
        {if $PAGINATION}
            <div class="mineless-pagination-top mb-3">
                {$PAGINATION}
            </div>
        {/if}

        <!-- Posts List -->
        <div class="mineless-posts-list">
            {foreach from=$POSTS item=post name=posts}
                <div class="mineless-post-card {($smarty.foreach.posts.first) ? 'adv-post-op' : ''}" id="post-{$post->id}">
                    <div class="row">
                        <!-- Author Sidebar -->
                        <div class="col-md-3 col-lg-2 adv-post-author-col">
                            <div class="mineless-author-card">
                                <div class="mineless-author-avatars">
                                    <img src="https://crafatar.com/avatars/{$post->author->id}?size=100&overlay" 
                                         alt="{$post->author->username}"
                                         class="mineless-avatar-mc"
                                         onerror="this.src='{$DEFAULT_AVATAR}'">
                                    {if $post->author->avatar}
                                        <img src="{$post->author->avatar}" 
                                             alt="{$post->author->username}"
                                             class="mineless-avatar-site"
                                             onerror="this.style.display='none'">
                                    {/if}
                                </div>
                                <a href="{$post->author->profile}" class="mineless-author-name" style="color: {$post->author->group_colour}">
                                    {$post->author->username}
                                </a>
                                {if $post->author->group_name}
                                    <span class="mineless-author-rank" style="background: {$post->author->group_colour}">
                                        {$post->author->group_name}
                                    </span>
                                {/if}
                                <div class="mineless-author-stats">
                                    <div class="mineless-stat-item">
                                        <i class="fas fa-calendar-alt"></i>
                                        <span>Joined {$post->author->joined}</span>
                                    </div>
                                    <div class="mineless-stat-item">
                                        <i class="fas fa-comment"></i>
                                        <span>{$post->author->posts} posts</span>
                                    </div>
                                    {if $post->author->reputation}
                                        <div class="mineless-stat-item">
                                            <i class="fas fa-star"></i>
                                            <span>{$post->author->reputation} rep</span>
                                        </div>
                                    {/if}
                                </div>
                            </div>
                        </div>

                        <!-- Post Content -->
                        <div class="col-md-9 col-lg-10 adv-post-content-col">
                            <div class="mineless-post-header-bar">
                                <div class="mineless-post-meta">
                                    <span class="mineless-post-number">#{$post->number}</span>
                                    <span class="mineless-post-date" data-toggle="tooltip" title="{$post->date}">
                                        {$post->date_friendly}
                                    </span>
                                    {if $post->edited}
                                        <span class="mineless-edited-badge" data-toggle="tooltip" title="Edited: {$post->edited_date}">
                                            <i class="fas fa-pencil-alt"></i> edited
                                        </span>
                                    {/if}
                                </div>
                                <div class="mineless-post-actions-bar">
                                    <a href="#post-{$post->id}" class="mineless-action-link" title="Permalink">
                                        <i class="fas fa-link"></i>
                                    </a>
                                    {if $post->can_report}
                                        <a href="{$post->report_url}" class="mineless-action-link" title="Report">
                                            <i class="fas fa-flag"></i>
                                        </a>
                                    {/if}
                                </div>
                            </div>

                            <div class="mineless-post-body">
                                {$post->content}
                            </div>

                            <!-- Reactions -->
                            {if isset($post->reactions) && count($post->reactions) > 0 || $USER_LOGGED_IN}
                                <div class="mineless-reactions-bar">
                                    <div class="mineless-reaction-list">
                                        {foreach from=$post->reactions item=reaction}
                                            <button class="mineless-reaction {($reaction->by_self) ? 'active' : ''}" 
                                                    data-post="{$post->id}" data-reaction="{$reaction->id}">
                                                <span class="mineless-reaction-emoji">{$reaction->emoji}</span>
                                                <span class="mineless-reaction-count">{$reaction->count}</span>
                                            </button>
                                        {/foreach}
                                    </div>
                                    {if $USER_LOGGED_IN}
                                        <div class="mineless-reaction-picker dropdown">
                                            <button class="btn adv-btn-react dropdown-toggle" data-toggle="dropdown">
                                                <i class="fas fa-smile mr-1"></i>React
                                            </button>
                                            <div class="dropdown-menu adv-reaction-menu">
                                                <div class="mineless-reaction-grid">
                                                    <button class="mineless-reaction-item" data-post="{$post->id}" data-reaction="1">👍</button>
                                                    <button class="mineless-reaction-item" data-post="{$post->id}" data-reaction="2">❤️</button>
                                                    <button class="mineless-reaction-item" data-post="{$post->id}" data-reaction="3">😂</button>
                                                    <button class="mineless-reaction-item" data-post="{$post->id}" data-reaction="4">😮</button>
                                                    <button class="mineless-reaction-item" data-post="{$post->id}" data-reaction="5">😢</button>
                                                    <button class="mineless-reaction-item" data-post="{$post->id}" data-reaction="6">🎉</button>
                                                </div>
                                            </div>
                                        </div>
                                    {/if}
                                </div>
                            {/if}

                            <!-- Post Actions -->
                            <div class="mineless-post-footer">
                                <div class="mineless-post-buttons">
                                    {if $post->can_quote}
                                        <button class="btn adv-btn-action adv-btn-quote" data-post="{$post->id}">
                                            <i class="fas fa-quote-left mr-1"></i>Quote
                                        </button>
                                    {/if}
                                    {if $post->can_edit}
                                        <a href="{$post->edit_url}" class="btn adv-btn-action">
                                            <i class="fas fa-edit mr-1"></i>Edit
                                        </a>
                                    {/if}
                                    {if $post->can_delete}
                                        <a href="{$post->delete_url}" class="btn adv-btn-action adv-btn-delete" onclick="return confirm('Delete this post?')">
                                            <i class="fas fa-trash mr-1"></i>Delete
                                        </a>
                                    {/if}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {/foreach}
        </div>

        <!-- Bottom Pagination -->
        {if $PAGINATION}
            <div class="mineless-pagination-bottom mt-3 mb-4">
                {$PAGINATION}
            </div>
        {/if}

        <!-- Reply Form -->
        {if $CAN_REPLY}
            <div class="mineless-reply-section" id="reply">
                <div class="mineless-reply-header">
                    <h4><i class="fas fa-reply mr-2"></i>Post Reply</h4>
                </div>
                <form action="{$REPLY_URL}" method="post" id="adv-reply-form">
                    <div class="mineless-editor-toolbar">
                        <button type="button" class="mineless-toolbar-btn" data-bbcode="b" title="Bold"><i class="fas fa-bold"></i></button>
                        <button type="button" class="mineless-toolbar-btn" data-bbcode="i" title="Italic"><i class="fas fa-italic"></i></button>
                        <button type="button" class="mineless-toolbar-btn" data-bbcode="u" title="Underline"><i class="fas fa-underline"></i></button>
                        <span class="mineless-toolbar-sep"></span>
                        <button type="button" class="mineless-toolbar-btn" data-bbcode="url" title="Link"><i class="fas fa-link"></i></button>
                        <button type="button" class="mineless-toolbar-btn" data-bbcode="img" title="Image"><i class="fas fa-image"></i></button>
                        <span class="mineless-toolbar-sep"></span>
                        <button type="button" class="mineless-toolbar-btn" data-bbcode="spoiler" title="Spoiler"><i class="fas fa-eye-slash"></i></button>
                        <button type="button" class="mineless-toolbar-btn" data-bbcode="quote" title="Quote"><i class="fas fa-quote-left"></i></button>
                        <button type="button" class="mineless-toolbar-btn" data-bbcode="code" title="Code"><i class="fas fa-code"></i></button>
                    </div>
                    <textarea name="content" class="form-control adv-reply-textarea" rows="8" placeholder="Write your reply..."></textarea>
                    <div class="mineless-reply-actions">
                        <button type="submit" class="btn adv-btn-submit">
                            <i class="fas fa-paper-plane mr-2"></i>Post Reply
                        </button>
                        <button type="button" class="btn adv-btn-preview" id="preview-btn">
                            <i class="fas fa-eye mr-2"></i>Preview
                        </button>
                    </div>
                    <input type="hidden" name="token" value="{$TOKEN}">
                </form>
            </div>
        {elseif $TOPIC->locked}
            <div class="mineless-topic-locked-notice">
                <i class="fas fa-lock mr-2"></i>This topic has been locked.
            </div>
        {else}
            <div class="mineless-login-to-reply">
                <a href="{$LOGIN_URL}">Login</a> or <a href="{$REGISTER_URL}">Register</a> to reply.
            </div>
        {/if}

    </div>
</div>

<!-- Lightbox Modal -->
<div class="modal fade" id="adv-lightbox" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content adv-lightbox-content">
            <button type="button" class="mineless-lightbox-close" data-dismiss="modal">
                <i class="fas fa-times"></i>
            </button>
            <img src="" alt="Lightbox" class="mineless-lightbox-img">
        </div>
    </div>
</div>

<style>
/* View Topic Styles */
.mineless-view-topic {
    background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
    min-height: 100vh;
}

.mineless-breadcrumb .breadcrumb-item a {
    color: #ffd700;
}

.mineless-breadcrumb .breadcrumb-item.active {
    color: #888;
}

.mineless-topic-header {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    padding: 24px;
    border: 1px solid rgba(255, 215, 0, 0.2);
}

.mineless-status-badge {
    display: inline-flex;
    align-items: center;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
}

.mineless-badge-pinned {
    background: rgba(255, 215, 0, 0.2);
    color: #ffd700;
}

.mineless-badge-locked {
    background: rgba(231, 76, 60, 0.2);
    color: #e74c3c;
}

.mineless-topic-title-main {
    color: #fff;
    font-weight: 700;
    font-size: 1.5rem;
    margin: 0;
}

.mineless-topic-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.mineless-tag {
    padding: 4px 10px;
    border-radius: 4px;
    font-size: 0.75rem;
    color: #fff;
}

.mineless-topic-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.mineless-btn-subscribe {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: #888;
    border-radius: 8px;
    transition: all 0.3s;
}

.mineless-btn-subscribe:hover, .mineless-btn-subscribe.active {
    background: rgba(46, 204, 113, 0.2);
    border-color: #2ecc71;
    color: #2ecc71;
}

.mineless-btn-mod {
    background: rgba(255, 215, 0, 0.2);
    border: 1px solid rgba(255, 215, 0, 0.3);
    color: #ffd700;
    border-radius: 8px;
}

.mineless-dropdown {
    background: #1a1a2e;
    border: 1px solid rgba(255, 215, 0, 0.2);
}

.mineless-dropdown .dropdown-item {
    color: #ccc;
}

.mineless-dropdown .dropdown-item:hover {
    background: rgba(255, 215, 0, 0.1);
    color: #ffd700;
}

.mineless-post-card {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    margin-bottom: 20px;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-post-op {
    border: 2px solid rgba(255, 215, 0, 0.3);
    box-shadow: 0 0 20px rgba(255, 215, 0, 0.1);
}

.mineless-post-author-col {
    background: rgba(0, 0, 0, 0.2);
    padding: 20px;
}

.mineless-author-card {
    text-align: center;
}

.mineless-author-avatars {
    position: relative;
    display: inline-block;
    margin-bottom: 15px;
}

.mineless-avatar-mc {
    width: 100px;
    height: 100px;
    border-radius: 12px;
    border: 3px solid rgba(255, 215, 0, 0.3);
}

.mineless-avatar-site {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: 2px solid #ffd700;
    position: absolute;
    bottom: -5px;
    right: -5px;
    background: #1a1a2e;
}

.mineless-author-name {
    display: block;
    font-weight: 700;
    font-size: 1.1rem;
    margin-bottom: 8px;
    text-decoration: none;
}

.mineless-author-rank {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    color: #fff;
    margin-bottom: 15px;
}

.mineless-author-stats {
    text-align: left;
}

.mineless-stat-item {
    color: #888;
    font-size: 0.85rem;
    margin-bottom: 5px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.mineless-stat-item i {
    color: #ffd700;
    width: 16px;
}

.mineless-post-content-col {
    padding: 20px;
}

.mineless-post-header-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 15px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    margin-bottom: 15px;
}

.mineless-post-meta {
    display: flex;
    align-items: center;
    gap: 15px;
}

.mineless-post-number {
    background: rgba(255, 215, 0, 0.2);
    color: #ffd700;
    padding: 4px 10px;
    border-radius: 4px;
    font-size: 0.85rem;
    font-weight: 600;
}

.mineless-post-date {
    color: #888;
    font-size: 0.9rem;
}

.mineless-edited-badge {
    color: #888;
    font-size: 0.8rem;
    font-style: italic;
}

.mineless-post-actions-bar {
    display: flex;
    gap: 10px;
}

.mineless-action-link {
    color: #666;
    text-decoration: none;
    transition: color 0.3s;
}

.mineless-action-link:hover {
    color: #ffd700;
}

.mineless-post-body {
    color: #ccc;
    line-height: 1.8;
    font-size: 1rem;
}

.mineless-post-body img {
    max-width: 100%;
    border-radius: 8px;
    cursor: zoom-in;
}

/* BBCode Spoiler */
.mineless-spoiler {
    background: rgba(0, 0, 0, 0.3);
    border-radius: 8px;
    overflow: hidden;
    margin: 15px 0;
}

.mineless-spoiler-header {
    background: rgba(255, 215, 0, 0.1);
    padding: 12px 15px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 10px;
    color: #ffd700;
    transition: all 0.3s;
}

.mineless-spoiler-header:hover {
    background: rgba(255, 215, 0, 0.2);
}

.mineless-spoiler-content {
    padding: 15px;
    display: none;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-spoiler.open .mineless-spoiler-content {
    display: block;
    animation: adv-spoiler-reveal 0.3s ease;
}

@keyframes adv-spoiler-reveal {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* BBCode Code Block */
.mineless-code-block {
    background: #0d1117;
    border-radius: 8px;
    overflow: hidden;
    margin: 15px 0;
}

.mineless-code-header {
    background: rgba(255, 255, 255, 0.05);
    padding: 10px 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.mineless-code-lang {
    color: #888;
    font-size: 0.85rem;
}

.mineless-code-copy {
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: #888;
    padding: 4px 12px;
    border-radius: 4px;
    font-size: 0.8rem;
    cursor: pointer;
    transition: all 0.3s;
}

.mineless-code-copy:hover {
    border-color: #ffd700;
    color: #ffd700;
}

.mineless-code-copy.copied {
    border-color: #2ecc71;
    color: #2ecc71;
}

.mineless-code-content {
    padding: 15px;
    overflow-x: auto;
}

.mineless-code-content pre {
    margin: 0;
    color: #c9d1d9;
}

/* BBCode Quote */
.mineless-quote {
    background: rgba(255, 255, 255, 0.03);
    border-left: 3px solid #ffd700;
    border-radius: 0 8px 8px 0;
    padding: 15px;
    margin: 15px 0;
}

.mineless-quote-header {
    color: #ffd700;
    font-weight: 600;
    margin-bottom: 10px;
    font-size: 0.9rem;
}

.mineless-quote-content {
    color: #aaa;
}

/* Reactions */
.mineless-reactions-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px 0;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    margin: 15px 0;
}

.mineless-reaction-list {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.mineless-reaction {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 20px;
    padding: 6px 12px;
    display: flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
    transition: all 0.3s;
}

.mineless-reaction:hover {
    background: rgba(255, 255, 255, 0.1);
}

.mineless-reaction.active {
    background: rgba(255, 215, 0, 0.2);
    border-color: rgba(255, 215, 0, 0.5);
}

.mineless-reaction-emoji {
    font-size: 1.1rem;
}

.mineless-reaction-count {
    color: #888;
    font-size: 0.85rem;
    font-weight: 500;
}

.mineless-reaction.active .mineless-reaction-count {
    color: #ffd700;
}

.mineless-btn-react {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #888;
    border-radius: 20px;
    padding: 6px 16px;
    font-size: 0.85rem;
}

.mineless-btn-react:hover {
    background: rgba(255, 255, 255, 0.1);
    color: #ccc;
}

.mineless-reaction-menu {
    background: #1a1a2e;
    border: 1px solid rgba(255, 215, 0, 0.3);
    padding: 10px;
    min-width: auto;
}

.mineless-reaction-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 5px;
}

.mineless-reaction-item {
    background: transparent;
    border: none;
    font-size: 1.5rem;
    padding: 8px;
    cursor: pointer;
    border-radius: 8px;
    transition: all 0.2s;
}

.mineless-reaction-item:hover {
    background: rgba(255, 215, 0, 0.1);
    transform: scale(1.1);
}

/* Post Footer */
.mineless-post-footer {
    padding-top: 15px;
}

.mineless-post-buttons {
    display: flex;
    gap: 10px;
}

.mineless-btn-action {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #888;
    font-size: 0.85rem;
    padding: 6px 14px;
    border-radius: 6px;
    transition: all 0.3s;
}

.mineless-btn-action:hover {
    background: rgba(255, 215, 0, 0.1);
    border-color: rgba(255, 215, 0, 0.3);
    color: #ffd700;
}

.mineless-btn-delete:hover {
    background: rgba(231, 76, 60, 0.1);
    border-color: rgba(231, 76, 60, 0.3);
    color: #e74c3c;
}

/* Like Heart Animation */
@keyframes adv-heart-beat {
    0% { transform: scale(1); }
    25% { transform: scale(1.3); }
    50% { transform: scale(1); }
    75% { transform: scale(1.2); }
    100% { transform: scale(1); }
}

.mineless-heart-anim {
    animation: adv-heart-beat 0.4s ease-in-out;
}

/* Reply Section */
.mineless-reply-section {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    padding: 24px;
    border: 1px solid rgba(255, 215, 0, 0.2);
}

.mineless-reply-header {
    color: #ffd700;
    margin-bottom: 20px;
}

.mineless-reply-header h4 {
    font-weight: 600;
}

.mineless-editor-toolbar {
    background: rgba(0, 0, 0, 0.3);
    padding: 10px 15px;
    border-radius: 8px 8px 0 0;
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
}

.mineless-toolbar-btn {
    background: transparent;
    border: none;
    color: #888;
    padding: 8px 12px;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.3s;
}

.mineless-toolbar-btn:hover {
    background: rgba(255, 215, 0, 0.1);
    color: #ffd700;
}

.mineless-toolbar-sep {
    width: 1px;
    background: rgba(255, 255, 255, 0.1);
    margin: 0 5px;
}

.mineless-reply-textarea {
    background: rgba(0, 0, 0, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-top: none;
    border-radius: 0 0 8px 8px;
    color: #ccc;
    resize: vertical;
    min-height: 150px;
}

.mineless-reply-textarea:focus {
    background: rgba(0, 0, 0, 0.3);
    border-color: rgba(255, 215, 0, 0.3);
    color: #fff;
    box-shadow: none;
}

.mineless-reply-actions {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}

.mineless-btn-submit {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    border: none;
    color: #1a1a2e;
    font-weight: 600;
    padding: 12px 30px;
    border-radius: 8px;
    transition: all 0.3s;
}

.mineless-btn-submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(255, 215, 0, 0.3);
}

.mineless-btn-preview {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: #ccc;
    padding: 12px 30px;
    border-radius: 8px;
}

.mineless-btn-preview:hover {
    background: rgba(255, 255, 255, 0.15);
    color: #fff;
}

.mineless-topic-locked-notice {
    background: rgba(231, 76, 60, 0.1);
    border: 1px solid rgba(231, 76, 60, 0.3);
    color: #e74c3c;
    text-align: center;
    padding: 20px;
    border-radius: 12px;
}

.mineless-login-to-reply {
    background: rgba(255, 255, 255, 0.03);
    text-align: center;
    padding: 20px;
    border-radius: 12px;
    color: #888;
}

.mineless-login-to-reply a {
    color: #ffd700;
}

/* Lightbox */
.mineless-lightbox-content {
    background: transparent;
    border: none;
    text-align: center;
}

.mineless-lightbox-close {
    position: absolute;
    top: -40px;
    right: 0;
    background: rgba(255, 255, 255, 0.1);
    border: none;
    color: #fff;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    cursor: pointer;
    transition: all 0.3s;
}

.mineless-lightbox-close:hover {
    background: rgba(231, 76, 60, 0.8);
}

.mineless-lightbox-img {
    max-width: 100%;
    max-height: 80vh;
    border-radius: 12px;
}

@media (max-width: 768px) {
    .mineless-post-author-col {
        padding: 15px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .mineless-author-card {
        display: flex;
        align-items: center;
        text-align: left;
        gap: 15px;
    }
    
    .mineless-author-avatars {
        margin-bottom: 0;
    }
    
    .mineless-author-name {
        margin-bottom: 4px;
    }
}
</style>

<script>
// Spoiler Toggle
document.querySelectorAll('.mineless-spoiler-header').forEach(header => {
    header.addEventListener('click', () => {
        header.parentElement.classList.toggle('open');
    });
});

// Code Copy
document.querySelectorAll('.mineless-code-copy').forEach(btn => {
    btn.addEventListener('click', () => {
        const code = btn.closest('.mineless-code-block').querySelector('code').textContent;
        navigator.clipboard.writeText(code).then(() => {
            btn.textContent = 'Copied!';
            btn.classList.add('copied');
            setTimeout(() => {
                btn.textContent = 'Copy';
                btn.classList.remove('copied');
            }, 2000);
        });
    });
});

// Image Lightbox
document.querySelectorAll('.mineless-post-body img').forEach(img => {
    img.addEventListener('click', () => {
        const lightbox = document.getElementById('adv-lightbox');
        lightbox.querySelector('img').src = img.src;
        $(lightbox).modal('show');
    });
});

// Reaction Click Animation
document.querySelectorAll('.mineless-reaction').forEach(reaction => {
    reaction.addEventListener('click', function() {
        this.classList.add('adv-heart-anim');
        setTimeout(() => this.classList.remove('adv-heart-anim'), 400);
    });
});

// BBCode Toolbar
document.querySelectorAll('.mineless-toolbar-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const bbcode = btn.dataset.bbcode;
        const textarea = document.querySelector('.mineless-reply-textarea');
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selected = textarea.value.substring(start, end);
        
        let replacement = '';
        switch(bbcode) {
            case 'b': replacement = `[b]${selected || 'bold text'}[/b]`; break;
            case 'i': replacement = `[i]${selected || 'italic text'}[/i]`; break;
            case 'u': replacement = `[u]${selected || 'underlined text'}[/u]`; break;
            case 'url': replacement = `[url=${selected || 'https://'}]${selected || 'link text'}[/url]`; break;
            case 'img': replacement = `[img]${selected || 'image url'}[/img]`; break;
            case 'spoiler': replacement = `[spoiler]${selected || 'spoiler content'}[/spoiler]`; break;
            case 'quote': replacement = `[quote=User]${selected || 'quoted text'}[/quote]`; break;
            case 'code': replacement = `[code]${selected || 'code here'}[/code]`; break;
        }
        
        textarea.value = textarea.value.substring(0, start) + replacement + textarea.value.substring(end);
        textarea.focus();
    });
});

// Quote Button
document.querySelectorAll('.mineless-btn-quote').forEach(btn => {
    btn.addEventListener('click', () => {
        const postId = btn.dataset.post;
        const textarea = document.querySelector('.mineless-reply-textarea');
        // In real implementation, fetch post content and add to textarea
        textarea.value += `[quote]Quoted post #${postId}[/quote]\n`;
        textarea.focus();
        document.getElementById('reply').scrollIntoView({ behavior: 'smooth' });
    });
});
</script>

{include file='footer.tpl'}
