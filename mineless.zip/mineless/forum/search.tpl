{include file='header.tpl'}

<div class="mineless-container py-5">
    <!-- Header -->
    <div class="mineless-page-header text-center mb-5">
        <h1 class="mineless-title">{$SEARCH_TITLE|default:"Search Forum"}</h1>
        <p class="mineless-subtitle">{$SEARCH_SUBTITLE|default:"Find topics and discussions you're looking for"}</p>
    </div>

    <!-- Search Form -->
    <div class="mineless-card mb-4">
        <div class="mineless-card-body p-4">
            <form action="{if isset($SEARCH_ACTION)}{$SEARCH_ACTION}{else}/forum/search{/if}" method="GET" class="search-form">
                <input type="hidden" name="token" value="{$TOKEN}">
                
                <!-- Keyword Input -->
                <div class="search-main mb-4">
                    <label for="search-keyword" class="mineless-form-label">{$KEYWORD_LABEL|default:"Keywords"}</label>
                    <div class="search-input-group">
                        <input type="text" 
                               name="keyword" 
                               id="search-keyword" 
                               class="mineless-form-control" 
                               placeholder="{$KEYWORD_PLACEHOLDER|default:"Search topics, posts, or users..."}"
                               value="{if isset($KEYWORD)}{$KEYWORD}{/if}"
                               required>
                        <button type="submit" class="mineless-btn adv-btn-primary">
                            <i class="icon search-icon"></i>
                            {$SEARCH_BUTTON|default:"Search"}
                        </button>
                    </div>
                </div>

                <!-- Advanced Filters Toggle -->
                <div class="advanced-toggle mb-3">
                    <button type="button" class="mineless-btn adv-btn-text" onclick="toggleAdvancedFilters()">
                        <i class="icon filter-icon"></i>
                        <span id="toggle-text">{$SHOW_ADVANCED|default:"Show Advanced Filters"}</span>
                        <i class="icon chevron-down" id="toggle-icon"></i>
                    </button>
                </div>

                <!-- Advanced Filters -->
                <div id="advanced-filters" class="advanced-filters" style="display: none;">
                    <div class="mineless-row">
                        <!-- Forum Filter -->
                        <div class="mineless-col-md-4 mb-3">
                            <label for="search-forum" class="mineless-form-label">{$FORUM_LABEL|default:"Forum"}</label>
                            <select name="forum" id="search-forum" class="mineless-form-select">
                                <option value="">{$ALL_FORUMS|default:"All Forums"}</option>
                                {if isset($FORUMS) && is_array($FORUMS) && count($FORUMS) > 0}
                                    {foreach from=$FORUMS item=forum}
                                        <option value="{$forum.id}" {if isset($SELECTED_FORUM) && $SELECTED_FORUM == $forum.id}selected{/if}>
                                            {$forum.name}
                                        </option>
                                    {/foreach}
                                {/if}
                            </select>
                        </div>

                        <!-- Date Range Filter -->
                        <div class="mineless-col-md-4 mb-3">
                            <label for="search-date-from" class="mineless-form-label">{$DATE_FROM_LABEL|default:"From Date"}</label>
                            <input type="date" 
                                   name="date_from" 
                                   id="search-date-from" 
                                   class="mineless-form-control"
                                   value="{if isset($DATE_FROM)}{$DATE_FROM}{/if}">
                        </div>

                        <div class="mineless-col-md-4 mb-3">
                            <label for="search-date-to" class="mineless-form-label">{$DATE_TO_LABEL|default:"To Date"}</label>
                            <input type="date" 
                                   name="date_to" 
                                   id="search-date-to" 
                                   class="mineless-form-control"
                                   value="{if isset($DATE_TO)}{$DATE_TO}{/if}">
                        </div>
                    </div>

                    <!-- Author Filter -->
                    <div class="mineless-row">
                        <div class="mineless-col-md-6 mb-3">
                            <label for="search-author" class="mineless-form-label">{$AUTHOR_LABEL|default:"Author"}</label>
                            <input type="text" 
                                   name="author" 
                                   id="search-author" 
                                   class="mineless-form-control"
                                   placeholder="{$AUTHOR_PLACEHOLDER|default:"Author name..."}"
                                   value="{if isset($AUTHOR)}{$AUTHOR}{/if}">
                        </div>

                        <!-- Sort By -->
                        <div class="mineless-col-md-6 mb-3">
                            <label for="search-sort" class="mineless-form-label">{$SORT_LABEL|default:"Sort By"}</label>
                            <select name="sort" id="search-sort" class="mineless-form-select">
                                <option value="relevance" {if isset($SORT) && $SORT == 'relevance'}selected{/if}>{$SORT_RELEVANCE|default:"Relevance"}</option>
                                <option value="newest" {if isset($SORT) && $SORT == 'newest'}selected{/if}>{$SORT_NEWEST|default:"Newest"}</option>
                                <option value="oldest" {if isset($SORT) && $SORT == 'oldest'}selected{/if}>{$SORT_OLDEST|default:"Oldest"}</option>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Quick Search Suggestions -->
    {if isset($SUGGESTIONS) && is_array($SUGGESTIONS) && count($SUGGESTIONS) > 0}
        <div class="mineless-card mb-4">
            <div class="mineless-card-header">
                <h5 class="mb-0">{$SUGGESTIONS_TITLE|default:"Popular Searches"}</h5>
            </div>
            <div class="mineless-card-body">
                <div class="search-suggestions">
                    {foreach from=$SUGGESTIONS item=suggestion}
                        <a href="{$suggestion.url}" class="mineless-badge adv-badge-outline">{$suggestion.term}</a>
                    {/foreach}
                </div>
            </div>
        </div>
    {/if}
</div>

<script>
function toggleAdvancedFilters() {
    const filters = document.getElementById('advanced-filters');
    const toggleText = document.getElementById('toggle-text');
    const toggleIcon = document.getElementById('toggle-icon');
    
    if (filters.style.display === 'none') {
        filters.style.display = 'block';
        filters.classList.add('fade-in');
        toggleText.textContent = '{hide_advanced_filters}';
        toggleIcon.classList.remove('chevron-down');
        toggleIcon.classList.add('chevron-up');
    } else {
        filters.style.display = 'none';
        toggleText.textContent = '{show_advanced_filters}';
        toggleIcon.classList.remove('chevron-up');
        toggleIcon.classList.add('chevron-down');
    }
}

// Initialize labels
const showAdvancedText = '{$SHOW_ADVANCED|default:"Tampilkan Filter Lanjutan"}';
const hideAdvancedText = '{$HIDE_ADVANCED|default:"Hide Filters"}';
document.getElementById('toggle-text').textContent = showAdvancedText;
</script>

<style>
.search-input-group {
    display: flex;
    gap: 0.75rem;
}
.search-input-group .mineless-form-control {
    flex: 1;
}
.advanced-filters {
    padding-top: 1rem;
    border-top: 1px solid var(--mineless-border-color);
    animation: fadeIn 0.3s ease;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}
.search-suggestions {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
}
.search-suggestions .mineless-badge {
    cursor: pointer;
    transition: all 0.2s ease;
}
.search-suggestions .mineless-badge:hover {
    background: var(--mineless-primary);
    color: white;
}
</style>

{include file='footer.tpl'}
