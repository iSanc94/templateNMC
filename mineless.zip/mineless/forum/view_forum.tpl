{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- View Forum - Mineless Template -->
<div class="mineless-view-forum py-4">
    <div class="container">
        
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mineless-breadcrumb mb-3">
            <ol class="breadcrumb bg-transparent p-0">
                <li class="breadcrumb-item"><a href="{$HOME_URL}"><i class="fas fa-home"></i></a></li>
                <li class="breadcrumb-item"><a href="{$FORUM_INDEX_URL}">Forum</a></li>
                {if isset($CATEGORY)}
                    <li class="breadcrumb-item"><a href="{$CATEGORY->link}">{$CATEGORY->title}</a></li>
                {/if}
                <li class="breadcrumb-item active" aria-current="page">{$FORUM->title}</li>
            </ol>
        </nav>

        <!-- Forum Header -->
        <div class="mineless-forum-header-card mb-4">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="d-flex align-items-center">
                        <div class="mineless-forum-icon-header">
                            <i class="fas {($FORUM->icon) ? $FORUM->icon : 'fa-comments'}"></i>
                        </div>
                        <div class="ml-3">
                            <h1 class="mineless-forum-title">{$FORUM->title}</h1>
                            <p class="mineless-forum-description mb-0">{$FORUM->description}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-md-right mt-3 mt-md-0">
                    {if $CAN_CREATE_TOPIC}
                        <a href="{$NEW_TOPIC_URL}" class="btn adv-btn-new-topic">
                            <i class="fas fa-plus-circle mr-2"></i>New Topic
                        </a>
                    {else}
                        <button class="btn adv-btn-new-topic" disabled title="Login to create topic">
                            <i class="fas fa-lock mr-2"></i>Login to Post
                        </button>
                    {/if}
                </div>
            </div>
        </div>

        <!-- Sub-forums -->
        {if isset($SUBFORUMS) && is_array($SUBFORUMS) && count($SUBFORUMS) > 0}
            <div class="mineless-subforums-section mb-4">
                <h4 class="mineless-section-title">
                    <i class="fas fa-sitemap mr-2"></i>Sub-forums
                </h4>
                <div class="row">
                    {foreach from=$SUBFORUMS item=subforum}
                        <div class="col-md-6 col-lg-4 mb-3">
                            <a href="{$subforum->link}" class="mineless-subforum-card">
                                <div class="mineless-subforum-icon {($subforum->last_post && $subforum->last_post->read) ? 'adv-read' : 'adv-unread'}">
                                    <i class="fas {($subforum->icon) ? $subforum->icon : 'fa-folder'}"></i>
                                </div>
                                <div class="mineless-subforum-info">
                                    <h5>{$subforum->title}</h5>
                                    <span class="mineless-subforum-stats">{$subforum->topics} topics · {$subforum->posts} posts</span>
                                </div>
                            </a>
                        </div>
                    {/foreach}
                </div>
            </div>
        {/if}

        <!-- Filters & Sort -->
        <div class="mineless-filters-bar mb-3">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="mineless-filter-tabs">
                        <a href="{$FORUM->link}?sort=latest" class="mineless-filter-tab {($SORT == 'latest' || !$SORT) ? 'active' : ''}">
                            <i class="fas fa-clock mr-1"></i>Latest
                        </a>
                        <a href="{$FORUM->link}?sort=popular" class="mineless-filter-tab {($SORT == 'popular') ? 'active' : ''}">
                            <i class="fas fa-fire mr-1"></i>Popular
                        </a>
                        <a href="{$FORUM->link}?sort=unanswered" class="mineless-filter-tab {($SORT == 'unanswered') ? 'active' : ''}">
                            <i class="fas fa-question-circle mr-1"></i>Unanswered
                        </a>
                    </div>
                </div>
                <div class="col-md-6 text-md-right">
                    <span class="mineless-topics-count">
                        <i class="fas fa-list mr-2"></i>{$TOTAL_TOPICS} topic{if $TOTAL_TOPICS != 1}s{/if}
                    </span>
                </div>
            </div>
        </div>

        <!-- Top Pagination -->
        {if $PAGINATION}
            <div class="mineless-pagination-top mb-3">
                {$PAGINATION}
            </div>
        {/if}

        <!-- Topics List -->
        <div class="mineless-topics-list">
            {if isset($TOPICS) && is_array($TOPICS) && count($TOPICS) > 0}
                <!-- Header Row -->
                <div class="mineless-topics-header d-none d-md-flex">
                    <div class="col-topic">Topic</div>
                    <div class="col-author">Author</div>
                    <div class="col-stats text-center">Replies</div>
                    <div class="col-stats text-center">Views</div>
                    <div class="col-last">Last Post</div>
                </div>

                <!-- Pinned Topics -->
                {foreach from=$TOPICS item=topic}
                    {if $topic->pinned}
                        <div class="mineless-topic-row adv-topic-pinned">
                            <div class="row align-items-center">
                                <div class="col-12 col-md-5">
                                    <div class="d-flex align-items-center">
                                        <div class="mineless-topic-icon pinned">
                                            <i class="fas fa-thumbtack adv-pin-icon"></i>
                                        </div>
                                        <div class="mineless-topic-main">
                                            <h5 class="mineless-topic-title">
                                                {if $topic->locked}
                                                    <i class="fas fa-lock text-danger mr-1"></i>
                                                {/if}
                                                <a href="{$topic->link}">{$topic->title}</a>
                                                {if $topic->labels}
                                                    {foreach from=$topic->labels item=label}
                                                        <span class="mineless-topic-badge" style="background: {$label->color}">{$label->name}</span>
                                                    {/foreach}
                                                {/if}
                                            </h5>
                                            <div class="mineless-topic-meta d-md-none">
                                                <span>by <a href="{$topic->author->profile}">{$topic->author->username}</a></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 d-none d-md-block">
                                    <div class="mineless-topic-author">
                                        <img src="https://crafatar.com/avatars/{$topic->author->id}?size=24&overlay" 
                                             alt="{$topic->author->username}"
                                             class="mineless-avatar-xs"
                                             onerror="this.src='{$DEFAULT_AVATAR}'">
                                        <a href="{$topic->author->profile}" style="color: {$topic->author->group_colour}">
                                            {$topic->author->username}
                                        </a>
                                    </div>
                                </div>
                                <div class="col-4 col-md-1 text-center adv-topic-count">
                                    <span class="d-md-none">Replies:</span>
                                    <strong>{$topic->replies}</strong>
                                </div>
                                <div class="col-4 col-md-1 text-center adv-topic-count">
                                    <span class="d-md-none">Views:</span>
                                    <strong>{$topic->views}</strong>
                                </div>
                                <div class="col-4 col-md-3">
                                    <div class="mineless-topic-last">
                                        <img src="https://crafatar.com/avatars/{$topic->last_post->author->id}?size=32&overlay" 
                                             alt="{$topic->last_post->author->username}"
                                             class="mineless-avatar-sm"
                                             onerror="this.src='{$DEFAULT_AVATAR}'">
                                        <div class="mineless-last-info">
                                            <a href="{$topic->last_post->profile}" style="color: {$topic->last_post->author->group_colour}">
                                                {$topic->last_post->author->username}
                                            </a>
                                            <span class="mineless-time-ago">{$topic->last_post->date_friendly}</span>
                                        </div>
                                        <a href="{$topic->last_post->link}" class="mineless-last-jump">
                                            <i class="fas fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    {/if}
                {/foreach}

                <!-- Normal Topics -->
                {foreach from=$TOPICS item=topic}
                    {if !$topic->pinned}
                        <div class="mineless-topic-row {($topic->read) ? 'adv-topic-read' : 'adv-topic-unread'}">
                            <div class="row align-items-center">
                                <div class="col-12 col-md-5">
                                    <div class="d-flex align-items-center">
                                        <div class="mineless-topic-icon {($topic->read) ? 'read' : 'unread'}">
                                            {if $topic->read}
                                                <i class="fas fa-comment"></i>
                                            {else}
                                                <i class="fas fa-comment-dots"></i>
                                            {/if}
                                        </div>
                                        <div class="mineless-topic-main">
                                            <h5 class="mineless-topic-title">
                                                {if $topic->locked}
                                                    <i class="fas fa-lock text-danger mr-1"></i>
                                                {/if}
                                                <a href="{$topic->link}">{$topic->title}</a>
                                                {if $topic->labels}
                                                    {foreach from=$topic->labels item=label}
                                                        <span class="mineless-topic-badge" style="background: {$label->color}">{$label->name}</span>
                                                    {/foreach}
                                                {/if}
                                            </h5>
                                            <div class="mineless-topic-meta d-md-none">
                                                <span>by <a href="{$topic->author->profile}">{$topic->author->username}</a></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 d-none d-md-block">
                                    <div class="mineless-topic-author">
                                        <img src="https://crafatar.com/avatars/{$topic->author->id}?size=24&overlay" 
                                             alt="{$topic->author->username}"
                                             class="mineless-avatar-xs"
                                             onerror="this.src='{$DEFAULT_AVATAR}'">
                                        <a href="{$topic->author->profile}" style="color: {$topic->author->group_colour}">
                                            {$topic->author->username}
                                        </a>
                                    </div>
                                </div>
                                <div class="col-4 col-md-1 text-center adv-topic-count">
                                    <span class="d-md-none">Replies:</span>
                                    <strong>{$topic->replies}</strong>
                                </div>
                                <div class="col-4 col-md-1 text-center adv-topic-count">
                                    <span class="d-md-none">Views:</span>
                                    <strong>{$topic->views}</strong>
                                </div>
                                <div class="col-4 col-md-3">
                                    <div class="mineless-topic-last">
                                        <img src="https://crafatar.com/avatars/{$topic->last_post->author->id}?size=32&overlay" 
                                             alt="{$topic->last_post->author->username}"
                                             class="mineless-avatar-sm"
                                             onerror="this.src='{$DEFAULT_AVATAR}'">
                                        <div class="mineless-last-info">
                                            <a href="{$topic->last_post->profile}" style="color: {$topic->last_post->author->group_colour}">
                                                {$topic->last_post->author->username}
                                            </a>
                                            <span class="mineless-time-ago">{$topic->last_post->date_friendly}</span>
                                        </div>
                                        <a href="{$topic->last_post->link}" class="mineless-last-jump">
                                            <i class="fas fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    {/if}
                {/foreach}

            {else}
                <div class="mineless-no-topics text-center py-5">
                    <i class="fas fa-inbox fa-4x mb-3"></i>
                    <h4>No topics yet</h4>
                    <p>Be the first to create a topic in this forum!</p>
                </div>
            {/if}
        </div>

        <!-- Bottom Pagination -->
        {if $PAGINATION}
            <div class="mineless-pagination-bottom mt-3">
                {$PAGINATION}
            </div>
        {/if}

    </div>
</div>

<style>
/* View Forum Styles */
.mineless-view-forum {
    background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
    min-height: 100vh;
}

.mineless-breadcrumb {
    background: transparent;
}

.mineless-breadcrumb .breadcrumb-item a {
    color: #ffd700;
    text-decoration: none;
}

.mineless-breadcrumb .breadcrumb-item.active {
    color: #888;
}

.mineless-forum-header-card {
    background: linear-gradient(135deg, rgba(255, 215, 0, 0.15) 0%, rgba(0, 0, 0, 0.3) 100%);
    border-radius: 12px;
    padding: 24px;
    border: 1px solid rgba(255, 215, 0, 0.3);
}

.mineless-forum-icon-header {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: #1a1a2e;
}

.mineless-forum-title {
    color: #fff;
    font-weight: 700;
    margin-bottom: 4px;
}

.mineless-forum-description {
    color: #888;
}

.mineless-btn-new-topic {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    border: none;
    color: #1a1a2e;
    font-weight: 600;
    padding: 12px 24px;
    border-radius: 8px;
    position: relative;
    overflow: hidden;
    transition: all 0.3s;
}

.mineless-btn-new-topic:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
    color: #1a1a2e;
}

.mineless-btn-new-topic:disabled {
    background: rgba(255, 255, 255, 0.1);
    color: #666;
}

/* Glow Animation */
.mineless-btn-new-topic::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    transition: left 0.5s;
}

.mineless-btn-new-topic:hover::before {
    left: 100%;
}

.mineless-subforums-section {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    padding: 20px;
}

.mineless-section-title {
    color: #ffd700;
    font-weight: 600;
    margin-bottom: 15px;
    font-size: 1.1rem;
}

.mineless-subforum-card {
    display: flex;
    align-items: center;
    background: rgba(0, 0, 0, 0.2);
    padding: 15px;
    border-radius: 10px;
    text-decoration: none;
    transition: all 0.3s;
    border: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-subforum-card:hover {
    background: rgba(255, 215, 0, 0.1);
    transform: translateX(5px);
    text-decoration: none;
}

.mineless-subforum-icon {
    width: 45px;
    height: 45px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 12px;
    font-size: 1.1rem;
}

.mineless-subforum-icon.mineless-unread {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    color: #1a1a2e;
}

.mineless-subforum-icon.mineless-read {
    background: rgba(255, 255, 255, 0.1);
    color: #888;
}

.mineless-subforum-info h5 {
    color: #fff;
    font-size: 0.95rem;
    margin-bottom: 2px;
}

.mineless-subforum-stats {
    color: #666;
    font-size: 0.8rem;
}

.mineless-filters-bar {
    background: rgba(255, 255, 255, 0.03);
    padding: 15px 20px;
    border-radius: 10px;
}

.mineless-filter-tabs {
    display: flex;
    gap: 5px;
}

.mineless-filter-tab {
    color: #888;
    padding: 8px 16px;
    border-radius: 20px;
    text-decoration: none;
    font-size: 0.9rem;
    transition: all 0.3s;
}

.mineless-filter-tab:hover {
    color: #ffd700;
    background: rgba(255, 215, 0, 0.1);
    text-decoration: none;
}

.mineless-filter-tab.active {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    color: #1a1a2e;
    font-weight: 500;
}

.mineless-topics-count {
    color: #888;
    font-size: 0.9rem;
}

.mineless-topics-list {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    overflow: hidden;
}

.mineless-topics-header {
    display: flex;
    background: rgba(0, 0, 0, 0.3);
    padding: 12px 20px;
    color: #888;
    font-size: 0.85rem;
    font-weight: 500;
    text-transform: uppercase;
}

.col-topic { flex: 5; }
.col-author { flex: 2; }
.col-stats { flex: 1; }
.col-last { flex: 3; }

.mineless-topic-row {
    padding: 16px 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    transition: all 0.3s;
}

.mineless-topic-row:hover {
    background: rgba(255, 215, 0, 0.05);
}

.mineless-topic-row:last-child {
    border-bottom: none;
}

.mineless-topic-pinned {
    background: rgba(255, 215, 0, 0.08);
}

.mineless-topic-icon {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 12px;
    flex-shrink: 0;
}

.mineless-topic-icon.pinned {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    color: #1a1a2e;
}

.mineless-topic-icon.unread {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    color: #1a1a2e;
    box-shadow: 0 0 10px rgba(255, 215, 0, 0.3);
}

.mineless-topic-icon.read {
    background: rgba(255, 255, 255, 0.1);
    color: #666;
}

.mineless-pin-icon {
    animation: adv-pin-wiggle 2s ease-in-out infinite;
}

@keyframes adv-pin-wiggle {
    0%, 100% { transform: rotate(0deg); }
    25% { transform: rotate(-10deg); }
    75% { transform: rotate(10deg); }
}

.mineless-topic-title {
    font-size: 1rem;
    margin-bottom: 0;
}

.mineless-topic-title a {
    color: #fff;
    text-decoration: none;
    transition: color 0.3s;
}

.mineless-topic-title a:hover {
    color: #ffd700;
}

.mineless-topic-badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.7rem;
    margin-left: 5px;
    color: #fff;
}

.mineless-topic-meta {
    color: #666;
    font-size: 0.8rem;
}

.mineless-topic-meta a {
    color: #ffd700;
}

.mineless-topic-author {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.9rem;
}

.mineless-avatar-xs {
    width: 24px;
    height: 24px;
    border-radius: 4px;
}

.mineless-topic-count {
    color: #888;
}

.mineless-topic-count strong {
    color: #fff;
}

.mineless-topic-last {
    display: flex;
    align-items: center;
    gap: 10px;
}

.mineless-avatar-sm {
    width: 32px;
    height: 32px;
    border-radius: 6px;
}

.mineless-last-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    font-size: 0.85rem;
}

.mineless-last-info a {
    color: #ffd700;
}

.mineless-time-ago {
    color: #666;
    font-size: 0.75rem;
}

.mineless-last-jump {
    width: 32px;
    height: 32px;
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #888;
    transition: all 0.3s;
}

.mineless-last-jump:hover {
    background: rgba(255, 215, 0, 0.2);
    color: #ffd700;
    text-decoration: none;
}

.mineless-no-topics {
    color: #666;
    padding: 40px 20px;
}

.mineless-no-topics i {
    color: rgba(255, 215, 0, 0.3);
}

@media (max-width: 768px) {
    .mineless-topic-row {
        padding: 15px;
    }
    
    .mineless-topic-last {
        margin-top: 10px;
        justify-content: flex-end;
    }
}
</style>

{include file='footer.tpl'}
