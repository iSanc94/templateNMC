{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- Forum Index - Mineless Template -->
<div class="mineless-forum-index py-4">
    <div class="container">
        
        <!-- Forum Header with Search -->
        <div class="mineless-forum-header mb-4">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="mineless-title">
                        <i class="fas fa-comments mr-2"></i>
                        {$FORUM_TITLE}
                    </h1>
                    <p class="mineless-subtitle">{$FORUM_DESCRIPTION}</p>
                </div>
                <div class="col-md-6">
                    <form action="{$SEARCH_URL}" method="post" class="mineless-search-form">
                        <div class="input-group">
                            <input type="text" name="query" class="form-control adv-search-input" 
                                   placeholder="{($SEARCH_PLACEHOLDER) ? $SEARCH_PLACEHOLDER : 'Search forum...'}" 
                                   autocomplete="off">
                            <div class="input-group-append">
                                <button type="submit" class="btn adv-search-btn">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <input type="hidden" name="token" value="{$TOKEN}">
                    </form>
                </div>
            </div>
        </div>

        <!-- Forum Categories -->
        {if isset($FORUMS) && is_array($FORUMS) && count($FORUMS) > 0}
            {foreach from=$FORUMS item=category}
                <div class="mineless-forum-category mb-4">
                    <!-- Category Header -->
                    <div class="mineless-category-header">
                        <div class="mineless-category-icon">
                            <i class="fas {($category.icon) ? $category.icon : 'fa-folder-open'}"></i>
                        </div>
                        <h3 class="mineless-category-title">{$category.title}</h3>
                        <div class="mineless-category-decoration"></div>
                    </div>

                    <!-- Forums in Category -->
                    <div class="mineless-forum-list">
                        {foreach from=$category.forums item=forum}
                            <div class="mineless-forum-item {($forum->redirect) ? 'adv-forum-redirect' : ''}">
                                <div class="row align-items-center">
                                    <!-- Forum Icon -->
                                    <div class="col-auto">
                                        <div class="mineless-forum-icon {($forum->last_post && $forum->last_post->read) ? 'adv-read' : 'adv-unread'}">
                                            {if $forum->redirect}
                                                <i class="fas fa-external-link-alt"></i>
                                            {elseif $forum->icon}
                                                <i class="fas {$forum->icon}"></i>
                                            {else}
                                                <i class="fas fa-comment-dots"></i>
                                            {/if}
                                        </div>
                                    </div>

                                    <!-- Forum Info -->
                                    <div class="col-md-5">
                                        <h4 class="mineless-forum-name">
                                            <a href="{$forum->link}">{$forum->title}</a>
                                            {if $forum->locked}
                                                <i class="fas fa-lock text-danger ml-2" title="Locked"></i>
                                            {/if}
                                        </h4>
                                        <p class="mineless-forum-desc">{$forum->description}</p>
                                        
                                        <!-- Sub-forums -->
                                        {if isset($forum->subforums) && count($forum->subforums) > 0}
                                            <div class="mineless-subforums">
                                                <span class="mineless-subforums-label"><i class="fas fa-sitemap mr-1"></i> Sub-forums:</span>
                                                {foreach from=$forum->subforums item=subforum}
                                                    <a href="{$subforum->link}" class="mineless-subforum-link">
                                                        <i class="fas fa-angle-right mr-1"></i>{$subforum->title}
                                                    </a>
                                                {/foreach}
                                            </div>
                                        {/if}
                                    </div>

                                    <!-- Stats -->
                                    <div class="col-md-2 text-center adv-forum-stats">
                                        <div class="mineless-stat">
                                            <span class="mineless-stat-value">{$forum->topics}</span>
                                            <span class="mineless-stat-label">Topics</span>
                                        </div>
                                        <div class="mineless-stat">
                                            <span class="mineless-stat-value">{$forum->posts}</span>
                                            <span class="mineless-stat-label">Posts</span>
                                        </div>
                                    </div>

                                    <!-- Last Post -->
                                    <div class="col-md-4">
                                        {if $forum->last_post}
                                            <div class="mineless-last-post">
                                                <div class="mineless-last-post-avatar">
                                                    <img src="https://crafatar.com/avatars/{$forum->last_post->avatar}?size=40&overlay" 
                                                         alt="{$forum->last_post->username}" 
                                                         class="mineless-avatar-sm"
                                                         onerror="this.src='{$DEFAULT_AVATAR}'">
                                                </div>
                                                <div class="mineless-last-post-info">
                                                    <a href="{$forum->last_post->link}" class="mineless-last-post-title">
                                                        {$forum->last_post->title|truncate:30}
                                                    </a>
                                                    <div class="mineless-last-post-meta">
                                                        <span>by <a href="{$forum->last_post->profile}">{$forum->last_post->username}</a></span>
                                                        <span class="mineless-time-ago" data-toggle="tooltip" title="{$forum->last_post->date}">
                                                            {$forum->last_post->date_friendly}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        {else}
                                            <div class="mineless-no-posts">
                                                <i class="fas fa-inbox mr-2"></i>No posts yet
                                            </div>
                                        {/if}
                                    </div>
                                </div>
                            </div>
                        {/foreach}
                    </div>
                </div>
            {/foreach}
        {else}
            <div class="mineless-empty-state text-center py-5">
                <i class="fas fa-folder-open fa-4x mb-3"></i>
                <h3>No forums yet</h3>
                <p>Forum is still under development.</p>
            </div>
        {/if}

        <!-- Online Users -->
        {if $ONLINE_USERS}
            <div class="mineless-online-users mt-4">
                <div class="mineless-section-header">
                    <i class="fas fa-users mr-2"></i>
                    <span>Online Users</span>
                    <span class="mineless-online-count">{$TOTAL_ONLINE} online</span>
                </div>
                <div class="mineless-online-list">
                    {if isset($ONLINE_USERS_LIST) && is_array($ONLINE_USERS_LIST) && count($ONLINE_USERS_LIST) > 0}
                        {foreach from=$ONLINE_USERS_LIST item=user}
                            <a href="{$user->profile}" class="mineless-online-user">
                                <img src="https://crafatar.com/avatars/{$user->id}?size=24&overlay" 
                                     alt="{$user->username}"
                                     class="mineless-online-avatar"
                                     onerror="this.src='{$DEFAULT_AVATAR}'">
                                <span style="color: {$user->group_colour}">{$user->username}</span>
                            </a>
                        {/foreach}
                    {else}
                        <span class="text-muted">No users online</span>
                    {/if}
                </div>
            </div>
        {/if}

        <!-- Forum Stats Footer -->
        <div class="mineless-forum-stats-footer mt-4">
            <div class="row">
                <div class="col-md-3 col-6">
                    <div class="mineless-stat-card">
                        <i class="fas fa-comments"></i>
                        <div class="mineless-stat-card-value">{$TOTAL_TOPICS}</div>
                        <div class="mineless-stat-card-label">Total Topics</div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="mineless-stat-card">
                        <i class="fas fa-comment-alt"></i>
                        <div class="mineless-stat-card-value">{$TOTAL_POSTS}</div>
                        <div class="mineless-stat-card-label">Total Posts</div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="mineless-stat-card">
                        <i class="fas fa-users"></i>
                        <div class="mineless-stat-card-value">{$TOTAL_USERS}</div>
                        <div class="mineless-stat-card-label">Members</div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="mineless-stat-card adv-newest-member">
                        <i class="fas fa-user-plus"></i>
                        <div class="mineless-stat-card-value">
                            <a href="{$NEWEST_MEMBER_PROFILE}">{$NEWEST_MEMBER}</a>
                        </div>
                        <div class="mineless-stat-card-label">Newest Member</div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<style>
/* Mineless Forum Index Styles */
.mineless-forum-index {
    background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
    min-height: 100vh;
}

.mineless-forum-header {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 12px;
    padding: 24px;
    border: 1px solid rgba(255, 215, 0, 0.2);
}

.mineless-title {
    color: #ffd700;
    font-weight: 700;
    font-size: 2rem;
    margin-bottom: 0.5rem;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
}

.mineless-subtitle {
    color: #a0a0a0;
    margin-bottom: 0;
}

.mineless-search-form .mineless-search-input {
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 215, 0, 0.3);
    color: #fff;
    border-radius: 8px 0 0 8px;
}

.mineless-search-form .mineless-search-input:focus {
    background: rgba(0, 0, 0, 0.5);
    border-color: #ffd700;
    box-shadow: 0 0 10px rgba(255, 215, 0, 0.3);
}

.mineless-search-form .mineless-search-btn {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    border: none;
    color: #1a1a2e;
    border-radius: 0 8px 8px 0;
    padding: 0 20px;
}

.mineless-forum-category {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-category-header {
    background: linear-gradient(135deg, rgba(255, 215, 0, 0.2) 0%, rgba(255, 170, 0, 0.1) 100%);
    padding: 16px 24px;
    display: flex;
    align-items: center;
    border-bottom: 2px solid rgba(255, 215, 0, 0.3);
}

.mineless-category-icon {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 16px;
    color: #1a1a2e;
    font-size: 1.2rem;
}

.mineless-category-title {
    color: #ffd700;
    font-weight: 600;
    margin: 0;
    flex: 1;
}

.mineless-category-decoration {
    width: 60px;
    height: 4px;
    background: linear-gradient(90deg, #ffd700, transparent);
    border-radius: 2px;
}

.mineless-forum-item {
    padding: 20px 24px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    transition: all 0.3s ease;
}

.mineless-forum-item:hover {
    background: rgba(255, 255, 255, 0.05);
}

.mineless-forum-item:last-child {
    border-bottom: none;
}

.mineless-forum-icon {
    width: 50px;
    height: 50px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    transition: all 0.3s ease;
}

.mineless-forum-icon.mineless-unread {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    color: #1a1a2e;
    box-shadow: 0 0 15px rgba(255, 215, 0, 0.4);
}

.mineless-forum-icon.mineless-read {
    background: rgba(255, 255, 255, 0.1);
    color: #888;
}

.mineless-forum-name a {
    color: #fff;
    font-weight: 600;
    font-size: 1.1rem;
    text-decoration: none;
    transition: color 0.3s;
}

.mineless-forum-name a:hover {
    color: #ffd700;
}

.mineless-forum-desc {
    color: #888;
    font-size: 0.9rem;
    margin: 4px 0 0 0;
}

.mineless-subforums {
    margin-top: 8px;
}

.mineless-subforums-label {
    color: #666;
    font-size: 0.8rem;
    margin-right: 8px;
}

.mineless-subforum-link {
    color: #ffd700;
    font-size: 0.85rem;
    text-decoration: none;
    margin-right: 12px;
    opacity: 0.8;
}

.mineless-subforum-link:hover {
    opacity: 1;
    color: #ffd700;
}

.mineless-forum-stats {
    display: flex;
    justify-content: center;
    gap: 20px;
}

.mineless-stat {
    text-align: center;
}

.mineless-stat-value {
    display: block;
    color: #ffd700;
    font-weight: 700;
    font-size: 1.2rem;
}

.mineless-stat-label {
    color: #666;
    font-size: 0.75rem;
    text-transform: uppercase;
}

.mineless-last-post {
    display: flex;
    align-items: center;
    background: rgba(255, 255, 255, 0.03);
    padding: 10px;
    border-radius: 8px;
}

.mineless-last-post-avatar img {
    width: 40px;
    height: 40px;
    border-radius: 6px;
    margin-right: 12px;
}

.mineless-last-post-title {
    color: #fff;
    font-weight: 500;
    text-decoration: none;
    display: block;
    font-size: 0.95rem;
}

.mineless-last-post-title:hover {
    color: #ffd700;
}

.mineless-last-post-meta {
    color: #888;
    font-size: 0.8rem;
}

.mineless-last-post-meta a {
    color: #ffd700;
}

.mineless-no-posts {
    color: #666;
    text-align: center;
    font-style: italic;
}

.mineless-online-users {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    padding: 20px 24px;
    border: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-section-header {
    color: #ffd700;
    font-weight: 600;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
}

.mineless-online-count {
    margin-left: auto;
    background: rgba(46, 204, 113, 0.2);
    color: #2ecc71;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
}

.mineless-online-list {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.mineless-online-user {
    display: inline-flex;
    align-items: center;
    background: rgba(255, 255, 255, 0.05);
    padding: 4px 10px;
    border-radius: 20px;
    text-decoration: none;
    font-size: 0.9rem;
    transition: all 0.3s;
}

.mineless-online-user:hover {
    background: rgba(255, 215, 0, 0.1);
    transform: translateY(-1px);
}

.mineless-online-avatar {
    width: 24px;
    height: 24px;
    border-radius: 4px;
    margin-right: 6px;
}

.mineless-forum-stats-footer {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    padding: 20px;
    border: 1px solid rgba(255, 215, 0, 0.1);
}

.mineless-stat-card {
    text-align: center;
    padding: 20px;
    background: rgba(0, 0, 0, 0.2);
    border-radius: 10px;
    transition: all 0.3s;
}

.mineless-stat-card:hover {
    transform: translateY(-3px);
    background: rgba(255, 215, 0, 0.05);
}

.mineless-stat-card i {
    font-size: 2rem;
    color: #ffd700;
    margin-bottom: 10px;
}

.mineless-stat-card-value {
    font-size: 1.5rem;
    font-weight: 700;
    color: #fff;
}

.mineless-stat-card-value a {
    color: #ffd700;
    text-decoration: none;
}

.mineless-stat-card-label {
    color: #888;
    font-size: 0.85rem;
}

@media (max-width: 768px) {
    .mineless-forum-stats {
        margin: 15px 0;
    }
    
    .mineless-last-post {
        margin-top: 15px;
    }
}
</style>

{include file='footer.tpl'}
