{include file='header.tpl'}

<div class="mineless-container py-5">
    <!-- Breadcrumb -->
    <nav class="mineless-breadcrumb mb-4">
        <a href="/" class="mineless-breadcrumb-item">{$HOME}</a>
        <span class="mineless-breadcrumb-separator">/</span>
        <a href="/forum" class="mineless-breadcrumb-item">{$FORUM}</a>
        <span class="mineless-breadcrumb-separator">/</span>
        <span class="mineless-breadcrumb-item active">{$SEARCH_RESULTS|default:"Search Results"}</span>
    </nav>

    <!-- Search Info -->
    <div class="search-info mb-4">
        <div class="mineless-alert adv-alert-info d-flex align-items-center justify-content-between">
            <div>
                <i class="icon search-icon me-2"></i>
                {if isset($RESULT_COUNT) && $RESULT_COUNT > 0}
                    <strong>{$RESULT_COUNT}</strong> {$RESULTS_FOUND|default:"results found"} 
                    <span class="text-muted">{$IN_TIME|default:"in"} {$SEARCH_TIME|default:"0"}ms</span>
                    {if isset($KEYWORD) && $KEYWORD != ''}
                        <span class="text-muted"> untuk "<strong>{$KEYWORD}</strong>"</span>
                    {/if}
                {else}
                    {$NO_RESULTS|default:"No results found"}
                    {if isset($KEYWORD) && $KEYWORD != ''}
                        <span class="text-muted"> untuk "<strong>{$KEYWORD}</strong>"</span>
                    {/if}
                {/if}
            </div>
            <a href="/forum/search" class="mineless-btn adv-btn-sm adv-btn-outline">
                <i class="icon arrow-left-icon me-1"></i>
                {$NEW_SEARCH|default:"New Search"}
            </a>
        </div>
    </div>

    <!-- Results List -->
    {if isset($RESULTS) && is_array($RESULTS) && count($RESULTS) > 0}
        <div class="mineless-card search-results">
            <div class="mineless-card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="icon file-text-icon me-2"></i>
                    {$RESULTS_TITLE|default:"Search Results"}
                </h5>
                {if isset($SORT_OPTIONS)}
                    <select class="mineless-form-select adv-form-select-sm" style="width: auto;" onchange="window.location.href=this.value">
                        {foreach from=$SORT_OPTIONS item=option}
                            <option value="{$option.url}" {if $option.active}selected{/if}>{$option.label}</option>
                        {/foreach}
                    </select>
                {/if}
            </div>
            <div class="mineless-list-group">
                {foreach from=$RESULTS item=result}
                    <div class="mineless-list-group-item search-result-item">
                        <div class="search-result-header d-flex justify-content-between align-items-start mb-2">
                            <div>
                                <h5 class="search-result-title mb-1">
                                    <a href="{$result.topic_url}" class="mineless-link">
                                        {if isset($result.highlighted_title)}
                                            {$result.highlighted_title}
                                        {else}
                                            {$result.title}
                                        {/if}
                                    </a>
                                </h5>
                                <div class="search-result-meta">
                                    <a href="{$result.forum_url}" class="mineless-badge adv-badge-secondary adv-badge-sm">
                                        <i class="icon folder-icon me-1"></i>
                                        {$result.forum_name}
                                    </a>
                                    {if isset($result.topic_type) && $result.topic_type != 'normal'}
                                        <span class="mineless-badge adv-badge-primary adv-badge-sm">
                                            {$result.topic_type_label}
                                        </span>
                                    {/if}
                                </div>
                            </div>
                            <div class="search-result-stats text-end">
                                <div class="stat-item">
                                    <i class="icon message-square-icon"></i>
                                    {$result.replies|number_format}
                                </div>
                            </div>
                        </div>
                        
                        <div class="search-result-excerpt">
                            {if isset($result.highlighted_content)}
                                <p class="mb-0 text-muted">...{$result.highlighted_content}...</p>
                            {else}
                                <p class="mb-0 text-muted">{$result.excerpt|truncate:200}</p>
                            {/if}
                        </div>
                        
                        <div class="search-result-footer d-flex justify-content-between align-items-center mt-3">
                            <div class="search-result-author">
                                <a href="{$result.author_url}" class="mineless-avatar adv-avatar-sm">
                                    {if isset($result.author_avatar)}
                                        <img src="{$result.author_avatar}" alt="{$result.author_name}">
                                    {else}
                                        <span>{$result.author_name|substr:0:1|upper}</span>
                                    {/if}
                                </a>
                                <a href="{$result.author_url}" class="mineless-link ms-2">{$result.author_name}</a>
                            </div>
                            <div class="search-result-date text-muted">
                                <i class="icon clock-icon me-1"></i>
                                {$result.date}
                                {if isset($result.post_number) && $result.post_number > 1}
                                    <span class="ms-2">#{$result.post_number}</span>
                                {/if}
                            </div>
                        </div>
                    </div>
                {/foreach}
            </div>
        </div>

        <!-- Pagination -->
        {if isset($PAGINATION)}
            <div class="mineless-pagination mt-4">
                {$PAGINATION}
            </div>
        {/if}
    {else}
        <!-- Empty State -->
        <div class="mineless-card">
            <div class="mineless-card-body text-center py-5">
                <div class="empty-icon mb-3">
                    <i class="icon search-x-icon" style="font-size: 4rem; color: var(--mineless-muted);"></i>
                </div>
                <h4>{$NO_RESULTS_TITLE|default:"No Results"}</h4>
                <p class="text-muted mb-4">
                    {$NO_RESULTS_TEXT|default:"Try different keywords or reduce search filters."}
                </p>
                <div class="suggestions">
                    <h6 class="mb-3">{$TRY_THESE|default:"Try these tips:"}</h6>
                    <ul class="list-unstyled text-muted">
                        <li><i class="icon check-icon me-2"></i>{$TIP_1|default:"Check your keyword spelling"}</li>
                        <li><i class="icon check-icon me-2"></i>{$TIP_2|default:"Use more general keywords"}</li>
                        <li><i class="icon check-icon me-2"></i>{$TIP_3|default:"Reduce number of filters"}</li>
                        <li><i class="icon check-icon me-2"></i>{$TIP_4|default:"Try different keywords"}</li>
                    </ul>
                </div>
                <a href="/forum/search" class="mineless-btn adv-btn-primary mt-3">
                    <i class="icon refresh-icon me-2"></i>
                    {$TRY_AGAIN|default:"Try Again"}
                </a>
            </div>
        </div>
    {/if}
</div>

<style>
.search-results .mineless-list-group-item {
    padding: 1.25rem;
    transition: background-color 0.2s ease;
}
.search-results .mineless-list-group-item:hover {
    background-color: var(--mineless-light);
}
.search-result-title {
    font-size: 1.125rem;
}
.search-result-title .highlight {
    background: linear-gradient(120deg, rgba(251, 191, 36, 0.3) 0%, rgba(251, 191, 36, 0.3) 100%);
    padding: 0 2px;
    border-radius: 2px;
    font-weight: 600;
}
.search-result-excerpt .highlight {
    background: linear-gradient(120deg, rgba(251, 191, 36, 0.3) 0%, rgba(251, 191, 36, 0.3) 100%);
    padding: 0 2px;
    border-radius: 2px;
    font-weight: 500;
}
.search-result-excerpt p {
    line-height: 1.6;
}
.search-result-meta {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
}
.search-result-stats {
    color: var(--mineless-muted);
    font-size: 0.875rem;
}
.search-result-stats .stat-item {
    display: flex;
    align-items: center;
    gap: 0.25rem;
}
.search-result-author {
    display: flex;
    align-items: center;
}
.search-result-date {
    font-size: 0.875rem;
}
.mineless-pagination {
    display: flex;
    justify-content: center;
}
.suggestions ul li {
    margin-bottom: 0.5rem;
}
.empty-icon {
    animation: pulse 2s infinite;
}
@keyframes pulse {
    0%, 100% { opacity: 0.5; }
    50% { opacity: 1; }
}
</style>

{include file='footer.tpl'}
