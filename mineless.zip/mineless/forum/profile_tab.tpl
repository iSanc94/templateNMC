{include file='header.tpl'}

<div class="mineless-container py-5">
    <!-- User Profile Header -->
    <div class="mineless-card mb-4">
        <div class="mineless-card-body p-4">
            <div class="d-flex align-items-center gap-4">
                <!-- Avatar -->
                <div class="profile-avatar">
                    {if isset($USER.avatar) && $USER.avatar}
                        <img src="{$USER.avatar}" alt="{$USER.username}" class="mineless-avatar adv-avatar-xl">
                    {else}
                        <div class="mineless-avatar adv-avatar-xl adv-avatar-placeholder">
                            <span>{$USER.username|substr:0:1|upper}</span>
                        </div>
                    {/if}
                </div>
                
                <!-- User Info -->
                <div class="profile-info flex-grow-1">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h2 class="profile-username mb-1">
                                {$USER.username}
                                {if isset($USER.group) && $USER.group}
                                    <span class="mineless-badge adv-badge-primary ms-2">{$USER.group}</span>
                                {/if}
                            </h2>
                            <p class="profile-title text-muted mb-2">
                                {if isset($USER.title) && $USER.title}
                                    {$USER.title}
                                {else}
                                    {$MEMBER|default:"Member"}
                                {/if}
                            </p>
                            <div class="profile-stats d-flex gap-3">
                                <span class="stat-item">
                                    <i class="icon message-square-icon me-1"></i>
                                    <strong>{$USER.post_count|number_format|default:"0"}</strong> {$POSTS|default:"Posts"}
                                </span>
                                <span class="stat-item">
                                    <i class="icon heart-icon me-1"></i>
                                    <strong>{$USER.reputation|number_format|default:"0"}</strong> {$REPUTATION|default:"Reputation"}
                                </span>
                                <span class="stat-item">
                                    <i class="icon calendar-icon me-1"></i>
                                    {$JOINED|default:"Joined"} {$USER.registered}
                                </span>
                            </div>
                        </div>
                        
                        <!-- Actions -->
                        <div class="profile-actions">
                            {if isset($CAN_EDIT) && $CAN_EDIT}
                                <a href="/user/settings" class="mineless-btn adv-btn-outline">
                                    <i class="icon settings-icon me-2"></i>
                                    {$EDIT_PROFILE|default:"Edit Profile"}
                                </a>
                            {/if}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Profile Tabs -->
    <div class="mineless-card mb-4">
        <div class="mineless-card-body p-0">
            <div class="profile-tabs">
                <a href="/profile/{$USER.username}" class="profile-tab">
                    <i class="icon user-icon me-2"></i>
                    {$TAB_OVERVIEW|default:"Overview"}
                </a>
                <a href="/profile/{$USER.username}/posts" class="profile-tab active">
                    <i class="icon message-square-icon me-2"></i>
                    {$TAB_POSTS|default:"Posts"}
                    {if isset($POSTS_COUNT)}<span class="mineless-badge adv-badge-secondary ms-2">{$POSTS_COUNT}</span>{/if}
                </a>
                {if isset($SHOW_TOPICS_TAB) && $SHOW_TOPICS_TAB}
                    <a href="/profile/{$USER.username}/topics" class="profile-tab">
                        <i class="icon file-text-icon me-2"></i>
                        {$TAB_TOPICS|default:"Topics"}
                    </a>
                {/if}
                {if isset($SHOW_REPUTATION_TAB) && $SHOW_REPUTATION_TAB}
                    <a href="/profile/{$USER.username}/reputation" class="profile-tab">
                        <i class="icon heart-icon me-2"></i>
                        {$TAB_REPUTATION|default:"Reputation"}
                    </a>
                {/if}
            </div>
        </div>
    </div>

    <!-- Posts List -->
    <div class="profile-posts">
        {if isset($POSTS) && is_array($POSTS) && count($POSTS) > 0}
            <div class="mineless-list-group">
                {foreach from=$POSTS item=post}
                    <div class="mineless-list-group-item post-item">
                        <!-- Post Header -->
                        <div class="post-header d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h5 class="post-topic-title mb-1">
                                    <a href="{$post.topic_url}" class="mineless-link">
                                        {if isset($post.topic_title)}
                                            {$post.topic_title}
                                        {else}
                                            {$post.title}
                                        {/if}
                                    </a>
                                </h5>
                                <div class="post-meta">
                                    <a href="{$post.forum_url}" class="mineless-badge adv-badge-secondary adv-badge-sm">
                                        <i class="icon folder-icon me-1"></i>
                                        {$post.forum_name}
                                    </a>
                                    <span class="text-muted ms-2">
                                        <i class="icon clock-icon me-1"></i>
                                        {$post.created}
                                    </span>
                                    {if isset($post.post_number)}
                                        <span class="mineless-badge adv-badge-light adv-badge-sm ms-2">
                                            #{$post.post_number}
                                        </span>
                                    {/if}
                                </div>
                            </div>
                            <div class="post-actions">
                                {if isset($post.can_edit) && $post.can_edit}
                                    <a href="{$post.edit_url}" class="mineless-btn adv-btn-sm adv-btn-text" title="{$EDIT|default:"Edit"}">
                                        <i class="icon edit-icon"></i>
                                    </a>
                                {/if}
                            </div>
                        </div>

                        <!-- Post Content -->
                        <div class="post-content">
                            <div class="post-excerpt">
                                {$post.content|strip_tags|truncate:300}
                            </div>
                            {if isset($post.has_more) && $post.has_more}
                                <a href="{$post.url}" class="mineless-link mt-2 d-inline-block">
                                    {$READ_MORE|default:"Read more"}
                                    <i class="icon arrow-right-icon ms-1"></i>
                                </a>
                            {/if}
                        </div>

                        <!-- Post Footer -->
                        <div class="post-footer d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                            <div class="post-stats">
                                <span class="stat-item me-3">
                                    <i class="icon heart-icon me-1 {if isset($post.likes) && $post.likes > 0}text-danger{/if}"></i>
                                    {$post.likes|number_format|default:"0"} {$LIKES|default:"Likes"}
                                </span>
                                {if isset($post.edited) && $post.edited}
                                    <span class="stat-item text-muted">
                                        <i class="icon edit-2-icon me-1"></i>
                                        {$EDITED|default:"Edited"} {$post.edited_date}
                                    </span>
                                {/if}
                            </div>
                            <a href="{$post.url}" class="mineless-btn adv-btn-sm adv-btn-outline">
                                {$VIEW_POST|default:"View Post"}
                                <i class="icon external-link-icon ms-1"></i>
                            </a>
                        </div>
                    </div>
                {/foreach}
            </div>

            <!-- Pagination -->
            {if isset($PAGINATION)}
                <div class="mineless-pagination mt-4">
                    {$PAGINATION}
                </div>
            {/if}
        {else}
            <!-- Empty State -->
            <div class="mineless-card">
                <div class="mineless-card-body text-center py-5">
                    <div class="empty-icon mb-3">
                        <i class="icon message-square-off-icon" style="font-size: 4rem; color: var(--mineless-muted);"></i>
                    </div>
                    <h4>{$NO_POSTS_TITLE|default:"No Posts Yet"}</h4>
                    <p class="text-muted mb-4">
                        {if isset($IS_OWN_PROFILE) && $IS_OWN_PROFILE}
                            {$NO_POSTS_OWN|default:"You haven't made any posts yet. Start discussing in the forum!"}
                        {else}
                            {$NO_POSTS_OTHER|default:"This user hasn't made any posts yet."}
                        {/if}
                    </p>
                    {if isset($IS_OWN_PROFILE) && $IS_OWN_PROFILE}
                        <a href="/forum" class="mineless-btn adv-btn-primary">
                            <i class="icon compass-icon me-2"></i>
                            {$BROWSE_FORUM|default:"Browse Forum"}
                        </a>
                    {/if}
                </div>
            </div>
        {/if}
    </div>
</div>

<style>
.profile-avatar .mineless-avatar-xl {
    width: 100px;
    height: 100px;
    font-size: 2.5rem;
}
.profile-username {
    font-size: 1.75rem;
    font-weight: 700;
}
.profile-stats .stat-item {
    color: var(--mineless-muted);
    font-size: 0.875rem;
}
.profile-stats .stat-item strong {
    color: var(--mineless-dark);
}
.profile-tabs {
    display: flex;
    border-bottom: none;
}
.profile-tab {
    padding: 1rem 1.5rem;
    color: var(--mineless-muted);
    text-decoration: none;
    border-bottom: 2px solid transparent;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
}
.profile-tab:hover {
    color: var(--mineless-dark);
    border-bottom-color: var(--mineless-border-color);
}
.profile-tab.active {
    color: var(--mineless-primary);
    border-bottom-color: var(--mineless-primary);
    font-weight: 500;
}
.post-item {
    padding: 1.5rem;
    transition: background-color 0.2s ease;
}
.post-item:hover {
    background-color: var(--mineless-light);
}
.post-topic-title {
    font-size: 1.125rem;
    font-weight: 600;
}
.post-topic-title a:hover {
    color: var(--mineless-primary);
}
.post-meta {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.5rem;
}
.post-excerpt {
    color: var(--mineless-body-color);
    line-height: 1.7;
}
.post-excerpt p {
    margin-bottom: 0.5rem;
}
.post-excerpt p:last-child {
    margin-bottom: 0;
}
.post-footer {
    border-color: var(--mineless-border-color) !important;
}
.post-stats .stat-item {
    color: var(--mineless-muted);
    font-size: 0.875rem;
}
.post-stats .stat-item i.text-danger {
    fill: currentColor;
}
.empty-icon {
    animation: float 3s ease-in-out infinite;
}
@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}
.mineless-pagination {
    display: flex;
    justify-content: center;
}
@media (max-width: 768px) {
    .profile-avatar .mineless-avatar-xl {
        width: 64px;
        height: 64px;
        font-size: 1.5rem;
    }
    .profile-username {
        font-size: 1.25rem;
    }
    .profile-tabs {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    .profile-tab {
        padding: 0.75rem 1rem;
        white-space: nowrap;
    }
    .post-meta {
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>

{include file='footer.tpl'}
