{include file='header.tpl'}

<div class="mineless-container py-5">
    <!-- Header -->
    <div class="mineless-page-header d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="mineless-title">{$FOLLOWING_TITLE|default:"Followed Topics"}</h1>
            <p class="mineless-subtitle mb-0">{$FOLLOWING_SUBTITLE|default:"Manage topics you follow to get notifications"}</p>
        </div>
        <a href="/forum" class="mineless-btn adv-btn-outline">
            <i class="icon arrow-left-icon me-2"></i>
            {$BACK_TO_FORUM|default:"Back to Forum"}
        </a>
    </div>

    <!-- Filter Tabs -->
    <div class="mineless-card mb-4">
        <div class="mineless-card-body p-0">
            <div class="mineless-tabs">
                <a href="/user/following" class="mineless-tab-item {if !isset($FILTER) || $FILTER == 'all'}active{/if}">
                    <i class="icon list-icon me-2"></i>
                    {$TAB_ALL|default:"All"}
                    {if isset($COUNT_ALL)}<span class="mineless-badge adv-badge-secondary ms-2">{$COUNT_ALL}</span>{/if}
                </a>
                <a href="/user/following?filter=unread" class="mineless-tab-item {if isset($FILTER) && $FILTER == 'unread'}active{/if}">
                    <i class="icon mail-icon me-2"></i>
                    {$TAB_UNREAD|default:"Unread"}
                    {if isset($COUNT_UNREAD) && $COUNT_UNREAD > 0}
                        <span class="mineless-badge adv-badge-danger ms-2">{$COUNT_UNREAD}</span>
                    {/if}
                </a>
                <a href="/user/following?filter=recent" class="mineless-tab-item {if isset($FILTER) && $FILTER == 'recent'}active{/if}">
                    <i class="icon clock-icon me-2"></i>
                    {$TAB_RECENT|default:"Recent"}
                </a>
            </div>
        </div>
    </div>

    <!-- Topics List -->
    {if isset($TOPICS) && is_array($TOPICS) && count($TOPICS) > 0}
        <div class="mineless-card following-topics">
            <div class="mineless-list-group">
                {foreach from=$TOPICS item=topic}
                    <div class="mineless-list-group-item topic-item" id="topic-{$topic.id}">
                        <div class="d-flex align-items-start gap-3">
                            <!-- Unread Indicator -->
                            {if isset($topic.unread) && $topic.unread}
                                <div class="unread-indicator">
                                    <span class="mineless-dot adv-dot-danger"></span>
                                </div>
                            {else}
                                <div class="unread-indicator">
                                    <span class="mineless-dot adv-dot-secondary"></span>
                                </div>
                            {/if}

                            <!-- Topic Content -->
                            <div class="topic-content flex-grow-1">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h5 class="topic-title mb-1">
                                            <a href="{$topic.url}" class="mineless-link">
                                                {if isset($topic.locked) && $topic.locked}
                                                    <i class="icon lock-icon text-muted me-1" title="{$LOCKED}"></i>
                                                {/if}
                                                {if isset($topic.sticky) && $topic.sticky}
                                                    <i class="icon pin-icon text-primary me-1" title="{$STICKY}"></i>
                                                {/if}
                                                {$topic.title}
                                            </a>
                                            {if isset($topic.unread) && $topic.unread}
                                                <span class="mineless-badge adv-badge-danger adv-badge-sm ms-2">{$NEW|default:"New"}</span>
                                            {/if}
                                        </h5>
                                        <div class="topic-meta text-muted">
                                            <a href="{$topic.forum_url}" class="mineless-link-muted">
                                                <i class="icon folder-icon me-1"></i>
                                                {$topic.forum_name}
                                            </a>
                                            <span class="mx-2">•</span>
                                            <span>
                                                <i class="icon message-square-icon me-1"></i>
                                                {$topic.replies|number_format} {$REPLIES|default:"replies"}
                                            </span>
                                            <span class="mx-2">•</span>
                                            <span>
                                                <i class="icon eye-icon me-1"></i>
                                                {$topic.views|number_format} {$VIEWS|default:"views"}
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Last Reply Info -->
                                <div class="last-reply mt-3 d-flex align-items-center">
                                    <a href="{$topic.last_reply_author_url}" class="mineless-avatar adv-avatar-xs me-2">
                                        {if isset($topic.last_reply_author_avatar)}
                                            <img src="{$topic.last_reply_author_avatar}" alt="{$topic.last_reply_author}">
                                        {else}
                                            <span>{$topic.last_reply_author|substr:0:1|upper}</span>
                                        {/if}
                                    </a>
                                    <div class="last-reply-info">
                                        <span class="text-muted">
                                            {$LAST_REPLY_BY|default:"Last reply by"} 
                                            <a href="{$topic.last_reply_author_url}" class="mineless-link">{$topic.last_reply_author}</a>
                                        </span>
                                        <span class="mx-1">•</span>
                                        <a href="{$topic.last_reply_url}" class="mineless-link-muted">
                                            {$topic.last_reply_date}
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Actions -->
                            <div class="topic-actions">
                                <form action="/forum/topic/{$topic.id}/unfollow" method="POST" class="unfollow-form" data-topic-id="{$topic.id}">
                                    <input type="hidden" name="token" value="{$TOKEN}">
                                    <button type="submit" class="mineless-btn adv-btn-sm adv-btn-outline-danger unfollow-btn" title="{$UNFOLLOW|default:"Unfollow"}">
                                        <i class="icon bell-off-icon"></i>
                                        <span class="d-none d-md-inline ms-1">{$UNFOLLOW|default:"Unfollow"}</span>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                {/foreach}
            </div>
        </div>

        <!-- Pagination -->
        {if isset($PAGINATION)}
            <div class="mineless-pagination mt-4">
                {$PAGINATION}
            </div>
        {/if}
    {else}
        <!-- Empty State -->
        <div class="mineless-card">
            <div class="mineless-card-body text-center py-5">
                <div class="empty-icon mb-3">
                    <i class="icon bell-off-icon" style="font-size: 4rem; color: var(--mineless-muted);"></i>
                </div>
                <h4>{$NO_FOLLOWING_TITLE|default:"No Followed Topics Yet"}</h4>
                <p class="text-muted mb-4">
                    {if isset($FILTER) && $FILTER == 'unread'}
                        {$NO_UNREAD_TEXT|default:"No unread topics. All topics are up to date!"}
                    {else}
                        {$NO_FOLLOWING_TEXT|default:"You haven't followed any topics yet. Click the 'Follow' button on interesting topics."}
                    {/if}
                </p>
                <a href="/forum" class="mineless-btn adv-btn-primary">
                    <i class="icon compass-icon me-2"></i>
                    {$BROWSE_FORUM|default:"Browse Forum"}
                </a>
            </div>
        </div>
    {/if}
</div>

<script>
document.querySelectorAll('.unfollow-form').forEach(form => {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const topicId = this.dataset.topicId;
        const topicItem = document.getElementById('topic-' + topicId);
        const btn = this.querySelector('.unfollow-btn');
        
        // Show loading state
        btn.disabled = true;
        btn.innerHTML = '<i class="icon loader-icon spinning"></i>';
        
        // Submit form via fetch
        fetch(this.action, {
            method: 'POST',
            body: new FormData(this)
        }).then(response => {
            if (response.ok) {
                // Fade out animation
                topicItem.style.transition = 'all 0.4s ease';
                topicItem.style.opacity = '0';
                topicItem.style.transform = 'translateX(20px)';
                
                setTimeout(() => {
                    topicItem.style.height = topicItem.offsetHeight + 'px';
                    topicItem.style.overflow = 'hidden';
                    
                    setTimeout(() => {
                        topicItem.style.height = '0';
                        topicItem.style.padding = '0';
                        topicItem.style.margin = '0';
                        
                        setTimeout(() => {
                            topicItem.remove();
                            
                            // Check if list is empty
                            const remainingTopics = document.querySelectorAll('.topic-item');
                            if (remainingTopics.length === 0) {
                                location.reload();
                            }
                        }, 300);
                    }, 50);
                }, 400);
            } else {
                btn.disabled = false;
                btn.innerHTML = '<i class="icon bell-off-icon"></i><span class="d-none d-md-inline ms-1">{$UNFOLLOW|default:"Unfollow"}</span>';
            }
        }).catch(error => {
            btn.disabled = false;
            btn.innerHTML = '<i class="icon bell-off-icon"></i><span class="d-none d-md-inline ms-1">{$UNFOLLOW|default:"Unfollow"}</span>';
        });
    });
});
</script>

<style>
.mineless-tabs {
    display: flex;
    border-bottom: none;
    padding: 0.5rem;
}
.mineless-tab-item {
    padding: 0.75rem 1.25rem;
    color: var(--mineless-muted);
    text-decoration: none;
    border-radius: var(--mineless-border-radius);
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
}
.mineless-tab-item:hover {
    background-color: var(--mineless-light);
    color: var(--mineless-dark);
}
.mineless-tab-item.active {
    background-color: var(--mineless-primary);
    color: white;
}
.topic-item {
    padding: 1.25rem;
    transition: background-color 0.2s ease;
}
.topic-item:hover {
    background-color: var(--mineless-light);
}
.topic-item:hover .topic-actions {
    opacity: 1;
}
.unread-indicator {
    padding-top: 0.25rem;
}
.mineless-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    display: block;
}
.mineless-dot-danger {
    background-color: var(--mineless-danger);
    box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.2);
}
.mineless-dot-secondary {
    background-color: var(--mineless-border-color);
}
.topic-title {
    font-size: 1.1rem;
}
.topic-meta {
    font-size: 0.875rem;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
}
.last-reply {
    font-size: 0.875rem;
}
.last-reply-info {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
}
.topic-actions {
    opacity: 0.7;
    transition: opacity 0.2s ease;
}
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
.spinning {
    animation: spin 1s linear infinite;
}
.empty-icon {
    animation: float 3s ease-in-out infinite;
}
@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}
@media (max-width: 768px) {
    .topic-actions {
        opacity: 1;
    }
    .last-reply-info {
        flex-direction: column;
        align-items: flex-start;
    }
    .last-reply-info span.mx-1 {
        display: none;
    }
}
</style>

{include file='footer.tpl'}
