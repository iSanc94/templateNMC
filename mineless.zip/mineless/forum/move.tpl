{include file='header.tpl'}

<div class="mineless-container py-5">
    <!-- Breadcrumb -->
    <nav class="mineless-breadcrumb mb-4">
        <a href="/" class="mineless-breadcrumb-item">{$HOME}</a>
        <span class="mineless-breadcrumb-separator">/</span>
        <a href="/forum" class="mineless-breadcrumb-item">{$FORUM}</a>
        <span class="mineless-breadcrumb-separator">/</span>
        <a href="{$TOPIC.forum_url}" class="mineless-breadcrumb-item">{$TOPIC.forum_name}</a>
        <span class="mineless-breadcrumb-separator">/</span>
        <a href="{$TOPIC.url}" class="mineless-breadcrumb-item">{$TOPIC.title|truncate:30}</a>
        <span class="mineless-breadcrumb-separator">/</span>
        <span class="mineless-breadcrumb-item active">{$MOVE_TITLE|default:"Move Topic"}</span>
    </nav>

    <!-- Page Header -->
    <div class="mineless-page-header mb-4">
        <h1 class="mineless-title">
            <i class="icon move-icon me-2"></i>
            {$MOVE_TITLE|default:"Move Topic"}
        </h1>
        <p class="mineless-subtitle mb-0">{$MOVE_SUBTITLE|default:"Move topic to another forum"}</p>
    </div>

    <div class="mineless-row">
        <!-- Topic Info -->
        <div class="mineless-col-lg-4 mb-4">
            <div class="mineless-card">
                <div class="mineless-card-header">
                    <h5 class="mb-0">
                        <i class="icon file-text-icon me-2"></i>
                        {$TOPIC_LABEL|default:"Topic"}
                    </h5>
                </div>
                <div class="mineless-card-body">
                    <h6 class="topic-title mb-3">{$TOPIC.title}</h6>
                    <div class="topic-stats">
                        <div class="stat-row d-flex justify-content-between mb-2">
                            <span class="text-muted">{$AUTHOR_LABEL|default:"Author"}:</span>
                            <a href="{$TOPIC.author_url}" class="mineless-link">{$TOPIC.author_name}</a>
                        </div>
                        <div class="stat-row d-flex justify-content-between mb-2">
                            <span class="text-muted">{$CURRENT_FORUM_LABEL|default:"Current Forum"}:</span>
                            <span class="mineless-badge adv-badge-secondary">{$TOPIC.forum_name}</span>
                        </div>
                        <div class="stat-row d-flex justify-content-between mb-2">
                            <span class="text-muted">{$POSTS_LABEL|default:"Posts"}:</span>
                            <span>{$TOPIC.posts|number_format}</span>
                        </div>
                        <div class="stat-row d-flex justify-content-between">
                            <span class="text-muted">{$CREATED_LABEL|default:"Created"}:</span>
                            <span>{$TOPIC.created}</span>
                        </div>
                    </div>
                    <div class="mt-3">
                        <a href="{$TOPIC.url}" class="mineless-btn adv-btn-sm adv-btn-outline w-100" target="_blank">
                            <i class="icon external-link-icon me-1"></i>
                            {$VIEW_TOPIC|default:"View Topic"}
                        </a>
                    </div>
                </div>
            </div>

            <!-- Move Guidelines -->
            <div class="mineless-card mt-4">
                <div class="mineless-card-header">
                    <h5 class="mb-0">
                        <i class="icon info-icon me-2"></i>
                        {$GUIDELINES_TITLE|default:"Information"}
                    </h5>
                </div>
                <div class="mineless-card-body">
                    <ul class="guidelines-list list-unstyled mb-0">
                        <li class="mb-2">
                            <i class="icon check-circle-icon text-success me-2"></i>
                            {$GUIDELINE_1|default:"Topic will be moved to the selected forum"}
                        </li>
                        <li class="mb-2">
                            <i class="icon check-circle-icon text-success me-2"></i>
                            {$GUIDELINE_2|default:"All posts and replies will be moved along"}
                        </li>
                        <li class="mb-2">
                            <i class="icon check-circle-icon text-success me-2"></i>
                            {$GUIDELINE_3|default:"Optional redirect link will direct from the old location"}
                        </li>
                        <li>
                            <i class="icon alert-circle-icon text-warning me-2"></i>
                            {$GUIDELINE_4|default:"This action will be recorded in the moderation log"}
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Move Form -->
        <div class="mineless-col-lg-8">
            <div class="mineless-card">
                <div class="mineless-card-header">
                    <h5 class="mb-0">
                        <i class="icon target-icon me-2"></i>
                        {$SELECT_DESTINATION_LABEL|default:"Select Destination Forum"}
                    </h5>
                </div>
                <div class="mineless-card-body p-4">
                    <form action="{$MOVE_ACTION}" method="POST" id="move-form" class="move-form">
                        <input type="hidden" name="token" value="{$TOKEN}">
                        <input type="hidden" name="topic_id" value="{$TOPIC.id}">

                        <!-- Forum Selection -->
                        <div class="mb-4">
                            <label for="target-forum" class="mineless-form-label">
                                {$TARGET_FORUM_LABEL|default:"Target Forum"}
                                <span class="text-danger">*</span>
                            </label>
                            <select name="target_forum_id" id="target-forum" class="mineless-form-select" required>
                                <option value="">{$SELECT_FORUM_PLACEHOLDER|default:"-- Select Forum --"}</option>
                                {if isset($FORUMS) && is_array($FORUMS) && count($FORUMS) > 0}
                                    {foreach from=$FORUMS item=forum}
                                        {if $forum.id != $TOPIC.forum_id}
                                            <option value="{$forum.id}">
                                                {section name=space loop=$forum.depth}&nbsp;&nbsp;&nbsp;&nbsp;{/section}
                                                {if $forum.depth > 0}└─ {/if}
                                                {$forum.name}
                                            </option>
                                        {/if}
                                    {/foreach}
                                {/if}
                            </select>
                            <div class="form-text text-muted mt-2">
                                <i class="icon info-icon me-1"></i>
                                {$FORUM_HELP|default:"Select target forum from the list above"}
                            </div>
                        </div>

                        <!-- Selected Forum Preview -->
                        <div id="forum-preview" class="forum-preview mb-4" style="display: none;">
                            <div class="preview-card">
                                <div class="d-flex align-items-center">
                                    <div class="preview-icon me-3">
                                        <i class="icon folder-icon text-primary" style="font-size: 2rem;"></i>
                                    </div>
                                    <div>
                                        <span class="mineless-badge adv-badge-primary mb-1">{$SELECTED_FORUM_LABEL|default:"Target Forum"}</span>
                                        <h6 id="preview-forum-name" class="mb-0"></h6>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Redirect Option -->
                        <div class="mb-4">
                            <label class="mineless-form-check">
                                <input type="checkbox" name="leave_redirect" id="leave-redirect" class="mineless-form-check-input" value="1" checked>
                                <span class="mineless-form-check-label">
                                    {$REDIRECT_LABEL|default:"Leave redirect link at old location"}
                                </span>
                            </label>
                            <div class="redirect-info mt-2 p-3 bg-light rounded">
                                <small class="text-muted">
                                    <i class="icon link-icon me-1"></i>
                                    {$REDIRECT_INFO|default:"Redirect link will automatically direct users accessing the old URL to the new location. Recommended to maintain shared links."}
                                </small>
                            </div>
                        </div>

                        <!-- Move Reason (Optional) -->
                        <div class="mb-4">
                            <label for="move-reason" class="mineless-form-label">
                                {$REASON_LABEL|default:"Move Reason"}
                                <span class="text-muted">({$OPTIONAL|default:"Optional"})</span>
                            </label>
                            <textarea name="reason" 
                                      id="move-reason" 
                                      class="mineless-form-control" 
                                      rows="3"
                                      placeholder="{$REASON_PLACEHOLDER|default:"Enter reason for moving topic..."}"></textarea>
                            <div class="form-text text-muted mt-2">
                                <i class="icon info-icon me-1"></i>
                                {$REASON_HELP|default:"Reason will be recorded in moderation log"}
                            </div>
                        </div>

                        <!-- Confirmation -->
                        <div class="move-confirm mb-4">
                            <label class="mineless-form-check">
                                <input type="checkbox" name="confirm_move" id="confirm-move" class="mineless-form-check-input" required>
                                <span class="mineless-form-check-label">
                                    {$CONFIRM_TEXT|default:"I am sure I want to move this topic"}
                                </span>
                            </label>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex gap-3">
                            <button type="submit" class="mineless-btn adv-btn-primary" id="move-btn" disabled>
                                <i class="icon move-icon me-2"></i>
                                <span class="btn-text">{$MOVE_BUTTON|default:"Move Topic"}</span>
                                <span class="btn-loading" style="display: none;">
                                    <i class="icon loader-icon spinning me-2"></i>
                                    {$MOVING|default:"Moving..."}
                                </span>
                            </button>
                            <a href="{$TOPIC.url}" class="mineless-btn adv-btn-outline">
                                {$CANCEL|default:"Cancel"}
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const forumSelect = document.getElementById('target-forum');
const forumPreview = document.getElementById('forum-preview');
const previewForumName = document.getElementById('preview-forum-name');
const confirmCheckbox = document.getElementById('confirm-move');
const moveBtn = document.getElementById('move-btn');

// Forum forums data for preview
const forumsData = {if isset($FORUMS_JSON)}{$FORUMS_JSON}{else}{}{/if};

forumSelect.addEventListener('change', function() {
    const selectedId = this.value;
    
    if (selectedId) {
        // Show preview
        const selectedOption = this.options[this.selectedIndex];
        previewForumName.textContent = selectedOption.text.trim().replace(/^[└─\s]+/, '');
        forumPreview.style.display = 'block';
        forumPreview.classList.add('fade-in');
    } else {
        forumPreview.style.display = 'none';
    }
    
    updateSubmitButton();
});

confirmCheckbox.addEventListener('change', updateSubmitButton);

function updateSubmitButton() {
    const hasForum = forumSelect.value !== '';
    const isConfirmed = confirmCheckbox.checked;
    moveBtn.disabled = !(hasForum && isConfirmed);
}

// Form submission
document.getElementById('move-form').addEventListener('submit', function(e) {
    const btn = document.getElementById('move-btn');
    btn.disabled = true;
    btn.querySelector('.btn-text').style.display = 'none';
    btn.querySelector('.btn-loading').style.display = 'inline-flex';
    btn.querySelector('.btn-loading').style.alignItems = 'center';
    
    // Add loading overlay to card
    const card = this.closest('.mineless-card');
    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay';
    overlay.innerHTML = `
        <div class="loading-content">
            <i class="icon loader-icon spinning" style="font-size: 2rem;"></i>
            <p class="mt-2 mb-0">{$MOVING|default:"Moving..."}</p>
        </div>
    `;
    card.style.position = 'relative';
    card.appendChild(overlay);
});
</script>

<style>
.stat-row {
    padding: 0.5rem 0;
    border-bottom: 1px solid var(--mineless-border-color);
}
.stat-row:last-child {
    border-bottom: none;
}
.guidelines-list li {
    display: flex;
    align-items: flex-start;
}
.forum-preview {
    animation: fadeIn 0.3s ease;
}
.preview-card {
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(59, 130, 246, 0.05) 100%);
    border: 1px solid rgba(59, 130, 246, 0.3);
    border-radius: var(--mineless-border-radius);
    padding: 1.25rem;
}
.preview-icon {
    width: 48px;
    height: 48px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}
.redirect-info {
    border-left: 3px solid var(--mineless-primary);
}
.mineless-form-select {
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 1rem center;
    padding-right: 2.5rem;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
.spinning {
    animation: spin 1s linear infinite;
}
.loading-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, 0.9);
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--mineless-border-radius);
    z-index: 10;
    animation: fadeIn 0.2s ease;
}
.loading-content {
    text-align: center;
    color: var(--mineless-primary);
}
.fade-in {
    animation: fadeIn 0.3s ease;
}
</style>

{include file='footer.tpl'}
