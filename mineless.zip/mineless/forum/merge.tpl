{include file='header.tpl'}

<div class="mineless-container py-5">
    <!-- Breadcrumb -->
    <nav class="mineless-breadcrumb mb-4">
        <a href="/" class="mineless-breadcrumb-item">{$HOME}</a>
        <span class="mineless-breadcrumb-separator">/</span>
        <a href="/forum" class="mineless-breadcrumb-item">{$FORUM}</a>
        <span class="mineless-breadcrumb-separator">/</span>
        <a href="{$SOURCE_TOPIC.forum_url}" class="mineless-breadcrumb-item">{$SOURCE_TOPIC.forum_name}</a>
        <span class="mineless-breadcrumb-separator">/</span>
        <a href="{$SOURCE_TOPIC.url}" class="mineless-breadcrumb-item">{$SOURCE_TOPIC.title|truncate:30}</a>
        <span class="mineless-breadcrumb-separator">/</span>
        <span class="mineless-breadcrumb-item active">{$MERGE_TITLE|default:"Merge Topics"}</span>
    </nav>

    <!-- Page Header -->
    <div class="mineless-page-header mb-4">
        <h1 class="mineless-title">
            <i class="icon git-merge-icon me-2"></i>
            {$MERGE_TITLE|default:"Gabung Topik"}
        </h1>
        <p class="mineless-subtitle mb-0">{$MERGE_SUBTITLE|default:"Merge this topic with another topic"}</p>
    </div>

    <div class="mineless-row">
        <!-- Source Topic Info -->
        <div class="mineless-col-lg-4 mb-4">
            <div class="mineless-card">
                <div class="mineless-card-header">
                    <h5 class="mb-0">
                        <i class="icon file-text-icon me-2"></i>
                        {$SOURCE_LABEL|default:"Source Topic"}
                    </h5>
                </div>
                <div class="mineless-card-body">
                    <h6 class="topic-title mb-3">{$SOURCE_TOPIC.title}</h6>
                    <div class="topic-stats">
                        <div class="stat-row d-flex justify-content-between mb-2">
                            <span class="text-muted">{$AUTHOR_LABEL|default:"Author"}:</span>
                            <a href="{$SOURCE_TOPIC.author_url}" class="mineless-link">{$SOURCE_TOPIC.author_name}</a>
                        </div>
                        <div class="stat-row d-flex justify-content-between mb-2">
                            <span class="text-muted">{$POSTS_LABEL|default:"Posts"}:</span>
                            <span>{$SOURCE_TOPIC.posts|number_format}</span>
                        </div>
                        <div class="stat-row d-flex justify-content-between mb-2">
                            <span class="text-muted">{$REPLIES_LABEL|default:"Replies"}:</span>
                            <span>{$SOURCE_TOPIC.replies|number_format}</span>
                        </div>
                        <div class="stat-row d-flex justify-content-between">
                            <span class="text-muted">{$CREATED_LABEL|default:"Created"}:</span>
                            <span>{$SOURCE_TOPIC.created}</span>
                        </div>
                    </div>
                    <div class="mt-3">
                        <a href="{$SOURCE_TOPIC.url}" class="mineless-btn adv-btn-sm adv-btn-outline w-100" target="_blank">
                            <i class="icon external-link-icon me-1"></i>
                            {$VIEW_TOPIC|default:"View Topic"}
                        </a>
                    </div>
                </div>
            </div>

            <!-- Merge Guidelines -->
            <div class="mineless-card mt-4">
                <div class="mineless-card-header">
                    <h5 class="mb-0">
                        <i class="icon info-icon me-2"></i>
                        {$GUIDELINES_TITLE|default:"Guidelines"}
                    </h5>
                </div>
                <div class="mineless-card-body">
                    <ul class="guidelines-list list-unstyled mb-0">
                        <li class="mb-2">
                            <i class="icon check-circle-icon text-success me-2"></i>
                            {$GUIDELINE_1|default:"All posts from source topic will be moved to target topic"}
                        </li>
                        <li class="mb-2">
                            <i class="icon check-circle-icon text-success me-2"></i>
                            {$GUIDELINE_2|default:"Source topic will be deleted after merging"}
                        </li>
                        <li class="mb-2">
                            <i class="icon check-circle-icon text-success me-2"></i>
                            {$GUIDELINE_3|default:"Target topic title will be kept"}
                        </li>
                        <li>
                            <i class="icon alert-circle-icon text-warning me-2"></i>
                            {$GUIDELINE_4|default:"This action cannot be undone"}
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Merge Form -->
        <div class="mineless-col-lg-8">
            <div class="mineless-card">
                <div class="mineless-card-header">
                    <h5 class="mb-0">
                        <i class="icon target-icon me-2"></i>
                        {$SELECT_TARGET_LABEL|default:"Select Target Topic"}
                    </h5>
                </div>
                <div class="mineless-card-body p-4">
                    <form action="{$MERGE_ACTION}" method="POST" id="merge-form" class="merge-form">
                        <input type="hidden" name="token" value="{$TOKEN}">
                        <input type="hidden" name="source_topic_id" value="{$SOURCE_TOPIC.id}">

                        <!-- Target Topic Search -->
                        <div class="mb-4">
                            <label for="target-topic" class="mineless-form-label">
                                {$TARGET_TOPIC_LABEL|default:"Target Topic"}
                                <span class="text-danger">*</span>
                            </label>
                            <div class="target-search-wrapper">
                                <div class="search-input-group">
                                    <i class="icon search-icon search-icon-left"></i>
                                    <input type="text" 
                                           id="target-topic-search" 
                                           class="mineless-form-control pl-5"
                                           placeholder="{$TARGET_SEARCH_PLACEHOLDER|default:"Search target topic..."}"
                                           autocomplete="off">
                                </div>
                                
                                <!-- Autocomplete Dropdown -->
                                <div id="target-autocomplete" class="autocomplete-dropdown" style="display: none;">
                                    <div class="autocomplete-loading">
                                        <i class="icon loader-icon spinning"></i>
                                        {$LOADING|default:"Loading..."}
                                    </div>
                                    <div class="autocomplete-results"></div>
                                </div>
                            </div>
                            
                            <!-- Selected Target -->
                            <input type="hidden" name="target_topic_id" id="target-topic-id" required>
                            <div id="selected-target" class="selected-target mt-3" style="display: none;">
                                <div class="selected-topic-card">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <span class="mineless-badge adv-badge-success mb-2">{$SELECTED_LABEL|default:"Selected"}</span>
                                            <h6 id="selected-title" class="mb-1"></h6>
                                            <p id="selected-meta" class="text-muted mb-0 small"></p>
                                        </div>
                                        <button type="button" class="mineless-btn adv-btn-sm adv-btn-text" onclick="clearSelection()">
                                            <i class="icon x-icon"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-text text-muted mt-2">
                                <i class="icon info-icon me-1"></i>
                                {$TARGET_HELP|default:"Type at least 3 characters to search topics"}
                            </div>
                        </div>

                        <!-- Merge Preview -->
                        <div id="merge-preview" class="merge-preview mb-4" style="display: none;">
                            <h6 class="preview-title mb-3">
                                <i class="icon eye-icon me-2"></i>
                                {$PREVIEW_LABEL|default:"Preview Result"}
                            </h6>
                            <div class="preview-content">
                                <div class="preview-item">
                                    <span class="text-muted">{$RESULT_TOPIC_LABEL|default:"Result Topic"}:</span>
                                    <strong id="preview-target-title"></strong>
                                </div>
                                <div class="preview-item">
                                    <span class="text-muted">{$TOTAL_POSTS_LABEL|default:"Total Posts"}:</span>
                                    <span id="preview-total-posts"></span>
                                </div>
                                <div class="preview-item">
                                    <span class="text-muted">{$SOURCE_DELETED_LABEL|default:"Source Topic"}:</span>
                                    <span class="text-danger">{$WILL_BE_DELETED|default:"Will be deleted"}</span>
                                </div>
                            </div>
                        </div>

                        <!-- Confirmation -->
                        <div class="merge-confirm mb-4">
                            <label class="mineless-form-check">
                                <input type="checkbox" name="confirm_merge" id="confirm-merge" class="mineless-form-check-input" required>
                                <span class="mineless-form-check-label">
                                    {$CONFIRM_TEXT|default:"I understand this action cannot be undone"}
                                </span>
                            </label>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex gap-3">
                            <button type="submit" class="mineless-btn adv-btn-warning" id="merge-btn" disabled>
                                <i class="icon git-merge-icon me-2"></i>
                                <span class="btn-text">{$MERGE_BUTTON|default:"Merge Topics"}</span>
                                <span class="btn-loading" style="display: none;">
                                    <i class="icon loader-icon spinning me-2"></i>
                                    {$MERGING|default:"Merging..."}
                                </span>
                            </button>
                            <a href="{$SOURCE_TOPIC.url}" class="mineless-btn adv-btn-outline">
                                {$CANCEL|default:"Cancel"}
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let searchTimeout;
const sourceTopicId = '{$SOURCE_TOPIC.id}';
const sourcePosts = parseInt('{$SOURCE_TOPIC.posts}') || 0;

// Target topic search
const searchInput = document.getElementById('target-topic-search');
const autocomplete = document.getElementById('target-autocomplete');
const autocompleteResults = autocomplete.querySelector('.autocomplete-results');

searchInput.addEventListener('input', function() {
    clearTimeout(searchTimeout);
    const query = this.value.trim();
    
    if (query.length < 3) {
        autocomplete.style.display = 'none';
        return;
    }
    
    searchTimeout = setTimeout(() => {
        searchTopics(query);
    }, 300);
});

// Hide autocomplete when clicking outside
document.addEventListener('click', function(e) {
    if (!e.target.closest('.target-search-wrapper')) {
        autocomplete.style.display = 'none';
    }
});

function searchTopics(query) {
    autocomplete.style.display = 'block';
    autocomplete.querySelector('.autocomplete-loading').style.display = 'block';
    autocompleteResults.innerHTML = '';
    
    fetch(`/forum/ajax/search-topics?q=${encodeURIComponent(query)}&exclude=${sourceTopicId}`)
        .then(response => response.json())
        .then(data => {
            autocomplete.querySelector('.autocomplete-loading').style.display = 'none';
            
            if (data.topics && data.topics.length > 0) {
                data.topics.forEach(topic => {
                    const item = document.createElement('div');
                    item.className = 'autocomplete-item';
                    item.innerHTML = `
                        <div class="item-title">${escapeHtml(topic.title)}</div>
                        <div class="item-meta">
                            <span>${escapeHtml(topic.forum_name)}</span>
                            <span>•</span>
                            <span>${topic.posts} post</span>
                        </div>
                    `;
                    item.addEventListener('click', () => selectTarget(topic));
                    autocompleteResults.appendChild(item);
                });
            } else {
                autocompleteResults.innerHTML = `
                    <div class="autocomplete-empty">
                        <i class="icon inbox-icon"></i>
                        <span>{$NO_TOPICS_FOUND|default:"No topics found"}</span>
                    </div>
                `;
            }
        })
        .catch(error => {
            autocomplete.querySelector('.autocomplete-loading').style.display = 'none';
            autocompleteResults.innerHTML = `
                <div class="autocomplete-error">
                    <i class="icon alert-circle-icon"></i>
                    <span>{$ERROR_LOADING|default:"Failed to load data"}</span>
                </div>
            `;
        });
}

function selectTarget(topic) {
    document.getElementById('target-topic-id').value = topic.id;
    document.getElementById('selected-title').textContent = topic.title;
    document.getElementById('selected-meta').innerHTML = `
        ${escapeHtml(topic.forum_name)} • ${topic.posts} post • ${topic.author}
    `;
    
    document.getElementById('selected-target').style.display = 'block';
    searchInput.value = '';
    autocomplete.style.display = 'none';
    
    // Show preview
    const totalPosts = sourcePosts + topic.posts;
    document.getElementById('preview-target-title').textContent = topic.title;
    document.getElementById('preview-total-posts').textContent = totalPosts.toLocaleString();
    document.getElementById('merge-preview').style.display = 'block';
    
    updateSubmitButton();
}

function clearSelection() {
    document.getElementById('target-topic-id').value = '';
    document.getElementById('selected-target').style.display = 'none';
    document.getElementById('merge-preview').style.display = 'none';
    document.getElementById('confirm-merge').checked = false;
    updateSubmitButton();
}

function updateSubmitButton() {
    const hasTarget = document.getElementById('target-topic-id').value !== '';
    const isConfirmed = document.getElementById('confirm-merge').checked;
    document.getElementById('merge-btn').disabled = !(hasTarget && isConfirmed);
}

document.getElementById('confirm-merge').addEventListener('change', updateSubmitButton);

// Form submission
document.getElementById('merge-form').addEventListener('submit', function(e) {
    const btn = document.getElementById('merge-btn');
    btn.disabled = true;
    btn.querySelector('.btn-text').style.display = 'none';
    btn.querySelector('.btn-loading').style.display = 'inline';
});

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
</script>

<style>
.search-input-group {
    position: relative;
}
.search-input-group .search-icon-left {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--mineless-muted);
}
.search-input-group .mineless-form-control {
    padding-left: 2.5rem;
}
.autocomplete-dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: white;
    border: 1px solid var(--mineless-border-color);
    border-radius: var(--mineless-border-radius);
    margin-top: 0.25rem;
    max-height: 300px;
    overflow-y: auto;
    z-index: 100;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
.autocomplete-loading, .autocomplete-empty, .autocomplete-error {
    padding: 1rem;
    text-align: center;
    color: var(--mineless-muted);
}
.autocomplete-item {
    padding: 0.75rem 1rem;
    cursor: pointer;
    border-bottom: 1px solid var(--mineless-border-color);
    transition: background-color 0.2s ease;
}
.autocomplete-item:hover {
    background-color: var(--mineless-light);
}
.autocomplete-item:last-child {
    border-bottom: none;
}
.autocomplete-item .item-title {
    font-weight: 500;
    margin-bottom: 0.25rem;
}
.autocomplete-item .item-meta {
    font-size: 0.75rem;
    color: var(--mineless-muted);
    display: flex;
    gap: 0.5rem;
}
.selected-topic-card {
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(16, 185, 129, 0.05) 100%);
    border: 1px solid rgba(16, 185, 129, 0.3);
    border-radius: var(--mineless-border-radius);
    padding: 1rem;
}
.merge-preview {
    background: var(--mineless-light);
    border-radius: var(--mineless-border-radius);
    padding: 1.25rem;
}
.preview-title {
    color: var(--mineless-dark);
}
.preview-item {
    display: flex;
    justify-content: space-between;
    padding: 0.5rem 0;
    border-bottom: 1px solid var(--mineless-border-color);
}
.preview-item:last-child {
    border-bottom: none;
}
.guidelines-list li {
    display: flex;
    align-items: flex-start;
}
.stat-row {
    padding: 0.5rem 0;
    border-bottom: 1px solid var(--mineless-border-color);
}
.stat-row:last-child {
    border-bottom: none;
}
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
.spinning {
    animation: spin 1s linear infinite;
}
.target-search-wrapper {
    position: relative;
}
</style>

{include file='footer.tpl'}
