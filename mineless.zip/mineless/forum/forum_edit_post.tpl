{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- Edit Post - Mineless Template -->
<div class="mineless-edit-post py-4">
    <div class="container">
        
        <!-- Header -->
        <div class="mineless-edit-header mb-4">
            <h1 class="mineless-title">
                <i class="fas fa-edit mr-2"></i>Edit Post
            </h1>
            <p class="mineless-subtitle">Mengedit post di topic: <a href="{$TOPIC->link}">{$TOPIC->title}</a></p>
        </div>

        <!-- Edit Form -->
        <form action="{$FORM_ACTION}" method="post" id="adv-edit-form">
            <div class="row">
                <!-- Main Editor -->
                <div class="col-lg-9">
                    <div class="mineless-edit-card">
                        
                        <!-- Editor Toolbar -->
                        <div class="mineless-editor-toolbar-Mineless">
                            <div class="mineless-toolbar-section">
                                <span class="mineless-toolbar-label">Format</span>
                                <div class="mineless-toolbar-group">
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="b" title="Bold">
                                        <i class="fas fa-bold"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="i" title="Italic">
                                        <i class="fas fa-italic"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="u" title="Underline">
                                        <i class="fas fa-underline"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="s" title="Strikethrough">
                                        <i class="fas fa-strikethrough"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="mineless-toolbar-divider"></div>
                            
                            <div class="mineless-toolbar-section">
                                <span class="mineless-toolbar-label">Insert</span>
                                <div class="mineless-toolbar-group">
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="url" title="Link">
                                        <i class="fas fa-link"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="img" title="Image">
                                        <i class="fas fa-image"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="video" title="Video">
                                        <i class="fas fa-video"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="mineless-toolbar-divider"></div>
                            
                            <div class="mineless-toolbar-section">
                                <span class="mineless-toolbar-label">Style</span>
                                <div class="mineless-toolbar-group">
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="quote" title="Quote">
                                        <i class="fas fa-quote-left"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="code" title="Code">
                                        <i class="fas fa-code"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="spoiler" title="Spoiler">
                                        <i class="fas fa-eye-slash"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="color" title="Color">
                                        <i class="fas fa-palette"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="mineless-toolbar-divider"></div>
                            
                            <div class="mineless-toolbar-section">
                                <span class="mineless-toolbar-label">Layout</span>
                                <div class="mineless-toolbar-group">
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="left" title="Align Left">
                                        <i class="fas fa-align-left"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="center" title="Align Center">
                                        <i class="fas fa-align-center"></i>
                                    </button>
                                    <button type="button" class="mineless-toolbar-btn-adv" data-bbcode="right" title="Align Right">
                                        <i class="fas fa-align-right"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Textarea -->
                        <textarea name="content" class="form-control adv-edit-textarea" 
                                  rows="15" required>{$POST->content_raw}</textarea>
                        
                        <!-- Character Count -->
                        <div class="mineless-edit-footer-bar">
                            <span class="mineless-char-info">
                                <span id="char-count">0</span> karakter
                            </span>
                            <button type="button" class="btn adv-btn-preview-sm" id="preview-toggle">
                                <i class="fas fa-eye mr-1"></i>Preview
                            </button>
                        </div>
                    </div>

                    <!-- Edit Reason -->
                    <div class="mineless-reason-card mt-3">
                        <label class="mineless-label-reason">
                            <i class="fas fa-info-circle mr-1"></i>Alasan Edit (opsional)
                        </label>
                        <input type="text" name="edit_reason" class="form-control adv-reason-input" 
                               placeholder="Jelaskan mengapa Anda mengedit post ini..." maxlength="200">
                        <small class="mineless-reason-hint">Alasan edit akan ditampilkan di post history</small>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="col-lg-3">
                    <!-- Preview Panel -->
                    <div class="mineless-sidebar-edit-card mb-3">
                        <div class="mineless-sidebar-edit-header">
                            <i class="fas fa-eye mr-2"></i>Preview
                        </div>
                        <div class="mineless-sidebar-edit-content">
                            <div class="mineless-preview-panel" id="preview-panel">
                                <div class="mineless-preview-placeholder">
                                    <i class="fas fa-eye-slash fa-2x mb-2"></i>
                                    <p>Klik Preview untuk melihat hasil</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Original Post Info -->
                    <div class="mineless-sidebar-edit-card mb-3">
                        <div class="mineless-sidebar-edit-header">
                            <i class="fas fa-info-circle mr-2"></i>Info Post
                        </div>
                        <div class="mineless-sidebar-edit-content">
                            <div class="mineless-post-info-item">
                                <span class="mineless-info-label">Diposting</span>
                                <span class="mineless-info-value">{$POST->date}</span>
                            </div>
                            {if $POST->edited}
                                <div class="mineless-post-info-item">
                                    <span class="mineless-info-label">Terakhir edit</span>
                                    <span class="mineless-info-value">{$POST->edited_date}</span>
                                </div>
                            {/if}
                        </div>
                    </div>

                    <!-- Quick Tips -->
                    <div class="mineless-sidebar-edit-card">
                        <div class="mineless-sidebar-edit-header">
                            <i class="fas fa-lightbulb mr-2"></i>Tips
                        </div>
                        <div class="mineless-sidebar-edit-content">
                            <ul class="mineless-tips-list">
                                <li>Gunakan spoiler untuk konten sensitif</li>
                                <li>Code block untuk sharing code</li>
                                <li>Quote untuk merespon user lain</li>
                                <li>Preview sebelum menyimpan</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Actions -->
            <div class="mineless-edit-actions">
                <button type="submit" class="btn adv-btn-save" id="save-btn">
                    <i class="fas fa-save mr-2"></i>
                    <span class="btn-text">Simpan Perubahan</span>
                    <span class="btn-loading d-none">
                        <i class="fas fa-spinner fa-spin mr-2"></i>Menyimpan...
                    </span>
                </button>
                <a href="{$TOPIC->link}" class="btn adv-btn-cancel-edit">
                    <i class="fas fa-times mr-2"></i>Batal
                </a>
            </div>

            <input type="hidden" name="token" value="{$TOKEN}">
        </form>

    </div>
</div>

<style>
/* Edit Post Styles */
.mineless-edit-post {
    background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
    min-height: 100vh;
}

.mineless-edit-header {
    text-align: center;
    padding: 20px 0;
}

.mineless-edit-header .mineless-title {
    color: #ffd700;
    font-weight: 700;
    font-size: 1.8rem;
    margin-bottom: 10px;
}

.mineless-edit-header .mineless-subtitle {
    color: #888;
    margin: 0;
}

.mineless-edit-header .mineless-subtitle a {
    color: #ffd700;
}

.mineless-edit-card {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-editor-toolbar-Mineless {
    background: linear-gradient(180deg, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0.3) 100%);
    padding: 15px 20px;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-toolbar-section {
    display: flex;
    align-items: center;
    gap: 8px;
}

.mineless-toolbar-label {
    color: #666;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.mineless-toolbar-group {
    display: flex;
    gap: 2px;
    background: rgba(255, 255, 255, 0.03);
    border-radius: 8px;
    padding: 3px;
}

.mineless-toolbar-btn-adv {
    background: transparent;
    border: none;
    color: #888;
    padding: 8px 12px;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s;
    font-size: 0.95rem;
}

.mineless-toolbar-btn-adv:hover {
    background: rgba(255, 215, 0, 0.15);
    color: #ffd700;
}

.mineless-toolbar-divider {
    width: 1px;
    height: 30px;
    background: rgba(255, 255, 255, 0.1);
}

.mineless-edit-textarea {
    background: rgba(0, 0, 0, 0.2);
    border: none;
    color: #ccc;
    padding: 20px;
    font-size: 1rem;
    line-height: 1.7;
    resize: vertical;
    min-height: 300px;
}

.mineless-edit-textarea:focus {
    background: rgba(0, 0, 0, 0.3);
    color: #fff;
    box-shadow: none;
}

.mineless-edit-footer-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 20px;
    background: rgba(0, 0, 0, 0.2);
    border-top: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-char-info {
    color: #666;
    font-size: 0.85rem;
}

.mineless-btn-preview-sm {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: #ccc;
    padding: 6px 16px;
    border-radius: 6px;
    font-size: 0.85rem;
}

.mineless-btn-preview-sm:hover {
    background: rgba(255, 215, 0, 0.1);
    border-color: rgba(255, 215, 0, 0.3);
    color: #ffd700;
}

.mineless-reason-card {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    padding: 20px;
    border: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-label-reason {
    color: #ccc;
    font-weight: 500;
    margin-bottom: 10px;
    display: block;
}

.mineless-label-reason i {
    color: #ffd700;
}

.mineless-reason-input {
    background: rgba(0, 0, 0, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #fff;
    border-radius: 8px;
    padding: 12px 15px;
}

.mineless-reason-input:focus {
    background: rgba(0, 0, 0, 0.3);
    border-color: rgba(255, 215, 0, 0.5);
    color: #fff;
    box-shadow: none;
}

.mineless-reason-hint {
    color: #666;
    font-size: 0.8rem;
    margin-top: 8px;
    display: block;
}

.mineless-sidebar-edit-card {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-sidebar-edit-header {
    background: rgba(0, 0, 0, 0.3);
    padding: 15px 20px;
    color: #ffd700;
    font-weight: 600;
    font-size: 0.95rem;
}

.mineless-sidebar-edit-content {
    padding: 20px;
}

.mineless-preview-panel {
    background: rgba(0, 0, 0, 0.2);
    border-radius: 8px;
    min-height: 150px;
    max-height: 300px;
    overflow-y: auto;
}

.mineless-preview-placeholder {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 150px;
    color: #666;
    text-align: center;
    padding: 20px;
}

.mineless-preview-placeholder i {
    color: #444;
}

.mineless-preview-content {
    padding: 15px;
    color: #ccc;
    font-size: 0.9rem;
}

.mineless-post-info-item {
    display: flex;
    justify-content: space-between;
    padding: 10px 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-post-info-item:last-child {
    border-bottom: none;
}

.mineless-info-label {
    color: #666;
    font-size: 0.85rem;
}

.mineless-info-value {
    color: #ccc;
    font-size: 0.85rem;
}

.mineless-tips-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.mineless-tips-list li {
    color: #888;
    font-size: 0.85rem;
    padding: 8px 0;
    padding-left: 20px;
    position: relative;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-tips-list li::before {
    content: "\\f0eb";
    font-family: "Font Awesome 5 Free";
    font-weight: 400;
    position: absolute;
    left: 0;
    color: #ffd700;
}

.mineless-tips-list li:last-child {
    border-bottom: none;
}

.mineless-edit-actions {
    display: flex;
    gap: 15px;
    margin-top: 30px;
    padding-top: 30px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.mineless-btn-save {
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    border: none;
    color: #1a1a2e;
    font-weight: 600;
    padding: 14px 35px;
    border-radius: 8px;
    transition: all 0.3s;
}

.mineless-btn-save:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(255, 215, 0, 0.3);
}

.mineless-btn-save:disabled {
    opacity: 0.7;
    cursor: not-allowed;
}

.mineless-btn-cancel-edit {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: #ccc;
    padding: 14px 35px;
    border-radius: 8px;
    transition: all 0.3s;
}

.mineless-btn-cancel-edit:hover {
    background: rgba(231, 76, 60, 0.1);
    border-color: rgba(231, 76, 60, 0.3);
    color: #e74c3c;
}

@media (max-width: 768px) {
    .mineless-edit-actions {
        flex-direction: column;
    }
    
    .mineless-edit-actions .btn {
        width: 100%;
    }
    
    .mineless-editor-toolbar-Mineless {
        padding: 10px;
    }
}
</style>

<script>
// Character Count
const textarea = document.querySelector('.mineless-edit-textarea');
const charCount = document.getElementById('char-count');

function updateCharCount() {
    charCount.textContent = textarea.value.length;
}

textarea.addEventListener('input', updateCharCount);
updateCharCount();

// BBCode Toolbar
document.querySelectorAll('.mineless-toolbar-btn-adv').forEach(btn => {
    btn.addEventListener('click', () => {
        const bbcode = btn.dataset.bbcode;
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selected = textarea.value.substring(start, end);
        
        let replacement = '';
        switch(bbcode) {
            case 'b': replacement = '[b]' + (selected || 'bold text') + '[/b]'; break;
            case 'i': replacement = '[i]' + (selected || 'italic text') + '[/i]'; break;
            case 'u': replacement = '[u]' + (selected || 'underlined text') + '[/u]'; break;
            case 's': replacement = '[s]' + (selected || 'strikethrough') + '[/s]'; break;
            case 'url': replacement = '[url=https://]' + (selected || 'link text') + '[/url]'; break;
            case 'img': replacement = '[img]' + (selected || 'image url') + '[/img]'; break;
            case 'video': replacement = '[video]' + (selected || 'video url') + '[/video]'; break;
            case 'quote': replacement = '[quote=User]' + (selected || 'quoted text') + '[/quote]'; break;
            case 'code': replacement = '[code]' + (selected || 'code here') + '[/code]'; break;
            case 'spoiler': replacement = '[spoiler]' + (selected || 'spoiler content') + '[/spoiler]'; break;
            case 'color': replacement = '[color=#ffd700]' + (selected || 'colored text') + '[/color]'; break;
            case 'left': replacement = '[left]' + (selected || 'left aligned') + '[/left]'; break;
            case 'center': replacement = '[center]' + (selected || 'center aligned') + '[/center]'; break;
            case 'right': replacement = '[right]' + (selected || 'right aligned') + '[/right]'; break;
            case 'list': replacement = '[list][*]item 1[*]item 2[/list]'; break;
        }
        
        textarea.value = textarea.value.substring(0, start) + replacement + textarea.value.substring(end);
        textarea.focus();
        updateCharCount();
    });
});

// Preview Toggle
document.getElementById('preview-toggle').addEventListener('click', () => {
    const panel = document.getElementById('preview-panel');
    const content = textarea.value.replace(/\n/g, '<br>');
    
    if (content.trim()) {
        panel.innerHTML = '<div class="mineless-preview-content">' + content + '</div>';
    } else {
        panel.innerHTML = `
            <div class="mineless-preview-placeholder">
                <i class="fas fa-eye-slash fa-2x mb-2"></i>
                <p>Konten kosong</p>
            </div>
        `;
    }
});

// Form Submit with Loading State
const form = document.getElementById('adv-edit-form');
const saveBtn = document.getElementById('save-btn');

form.addEventListener('submit', () => {
    saveBtn.disabled = true;
    saveBtn.querySelector('.btn-text').classList.add('d-none');
    saveBtn.querySelector('.btn-loading').classList.remove('d-none');
});
</script>

{include file='footer.tpl'}
