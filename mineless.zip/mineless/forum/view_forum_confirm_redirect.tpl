{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- Confirm Redirect - Mineless Template -->
<div class="mineless-redirect-confirm py-5">
    <div class="container">
        
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                
                <!-- Redirect Card -->
                <div class="mineless-redirect-card">
                    
                    <!-- Warning Header -->
                    <div class="mineless-redirect-header">
                        <div class="mineless-warning-icon">
                            <i class="fas fa-external-link-alt"></i>
                        </div>
                        <h1 class="mineless-redirect-title">Konfirmasi Redirect</h1>
                        <p class="mineless-redirect-subtitle">Anda akan meninggalkan situs ini</p>
                    </div>

                    <!-- Destination Preview -->
                    <div class="mineless-destination-section">
                        <label class="mineless-destination-label">
                            <i class="fas fa-globe mr-1"></i>Tujuan
                        </label>
                        <div class="mineless-destination-box">
                            <div class="mineless-destination-url">
                                <i class="fas fa-link mr-2"></i>
                                <span id="redirect-url">{$REDIRECT_URL}</span>
                            </div>
                            <div class="mineless-destination-domain">
                                <span class="mineless-domain-badge">
                                    <i class="fas fa-server mr-1"></i>
                                    {$REDIRECT_DOMAIN}
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Security Warning -->
                    <div class="mineless-security-warning">
                        <div class="mineless-warning-badge">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <div class="mineless-warning-content">
                            <h5>Peringatan Keamanan</h5>
                            <p>Link eksternal tidak dikontrol oleh {$SITE_NAME}. Hanya lanjutkan jika Anda mempercayai tujuan ini.</p>
                        </div>
                    </div>

                    <!-- Trust Indicators -->
                    <div class="mineless-trust-indicators">
                        <div class="mineless-trust-item">
                            <i class="fas fa-check-circle text-success"></i>
                            <span>HTTPS {($REDIRECT_IS_HTTPS) ? 'Aktif' : 'Tidak Aktif'}</span>
                        </div>
                        <div class="mineless-trust-item">
                            <i class="fas {($REDIRECT_IS_HTTPS) ? 'fa-check-circle text-success' : 'fa-exclamation-circle text-warning'}"></i>
                            <span>Domain: {$REDIRECT_DOMAIN}</span>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="mineless-redirect-actions">
                        <a href="{$REDIRECT_URL}" class="btn adv-btn-continue" target="_blank" rel="noopener noreferrer">
                            <i class="fas fa-external-link-alt mr-2"></i>
                            Lanjutkan
                            <span class="mineless-countdown">(5)</span>
                        </a>
                        <a href="{$BACK_URL}" class="btn adv-btn-goback">
                            <i class="fas fa-arrow-left mr-2"></i>
                            Kembali
                        </a>
                    </div>

                    <!-- Forum Info -->
                    <div class="mineless-forum-info mt-4">
                        <p class="mb-0">
                            <i class="fas fa-folder mr-1"></i>
                            Dari forum: <a href="{$FORUM->link}">{$FORUM->title}</a>
                        </p>
                    </div>

                </div>

                <!-- Additional Info -->
                <div class="mineless-redirect-footer text-center mt-4">
                    <p class="mineless-footer-text">
                        <i class="fas fa-info-circle mr-1"></i>
                        {$SITE_NAME} tidak bertanggung jawab atas konten eksternal.
                    </p>
                </div>

            </div>
        </div>

    </div>
</div>

<style>
/* Redirect Confirm Styles */
.mineless-redirect-confirm {
    background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
}

.mineless-redirect-card {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 16px;
    overflow: hidden;
    border: 1px solid rgba(255, 215, 0, 0.2);
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

/* Header */
.mineless-redirect-header {
    background: linear-gradient(135deg, rgba(255, 215, 0, 0.15) 0%, rgba(255, 170, 0, 0.05) 100%);
    padding: 40px 30px;
    text-align: center;
    border-bottom: 1px solid rgba(255, 215, 0, 0.2);
}

.mineless-warning-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    font-size: 2rem;
    color: #1a1a2e;
    animation: adv-pulse-warning 2s ease-in-out infinite;
}

@keyframes adv-pulse-warning {
    0%, 100% { 
        transform: scale(1);
        box-shadow: 0 0 0 0 rgba(255, 215, 0, 0.4);
    }
    50% { 
        transform: scale(1.05);
        box-shadow: 0 0 30px 10px rgba(255, 215, 0, 0.2);
    }
}

.mineless-redirect-title {
    color: #ffd700;
    font-weight: 700;
    font-size: 1.8rem;
    margin-bottom: 8px;
}

.mineless-redirect-subtitle {
    color: #888;
    margin: 0;
    font-size: 1rem;
}

/* Destination Section */
.mineless-destination-section {
    padding: 25px 30px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-destination-label {
    color: #666;
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 12px;
    display: block;
}

.mineless-destination-box {
    background: rgba(0, 0, 0, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    padding: 20px;
}

.mineless-destination-url {
    color: #fff;
    font-size: 0.95rem;
    word-break: break-all;
    margin-bottom: 12px;
    display: flex;
    align-items: flex-start;
}

.mineless-destination-url i {
    color: #ffd700;
    margin-top: 3px;
}

.mineless-destination-domain {
    display: flex;
    align-items: center;
}

.mineless-domain-badge {
    background: rgba(255, 215, 0, 0.1);
    border: 1px solid rgba(255, 215, 0, 0.3);
    color: #ffd700;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 500;
}

/* Security Warning */
.mineless-security-warning {
    padding: 25px 30px;
    display: flex;
    gap: 15px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-warning-badge {
    width: 50px;
    height: 50px;
    background: rgba(231, 76, 60, 0.1);
    border: 1px solid rgba(231, 76, 60, 0.3);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.mineless-warning-badge i {
    color: #e74c3c;
    font-size: 1.3rem;
}

.mineless-warning-content h5 {
    color: #e74c3c;
    font-weight: 600;
    margin-bottom: 5px;
    font-size: 1rem;
}

.mineless-warning-content p {
    color: #888;
    margin: 0;
    font-size: 0.9rem;
    line-height: 1.5;
}

/* Trust Indicators */
.mineless-trust-indicators {
    padding: 20px 30px;
    display: flex;
    gap: 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    flex-wrap: wrap;
}

.mineless-trust-item {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #888;
    font-size: 0.9rem;
}

.mineless-trust-item i {
    font-size: 1.1rem;
}

/* Actions */
.mineless-redirect-actions {
    padding: 25px 30px;
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.mineless-btn-continue {
    flex: 1;
    min-width: 150px;
    background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
    border: none;
    color: #1a1a2e;
    font-weight: 700;
    padding: 15px 30px;
    border-radius: 10px;
    transition: all 0.3s;
}

.mineless-btn-continue:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(255, 215, 0, 0.3);
    color: #1a1a2e;
    text-decoration: none;
}

.mineless-countdown {
    font-weight: 500;
    opacity: 0.8;
}

.mineless-btn-goback {
    flex: 1;
    min-width: 150px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #888;
    font-weight: 500;
    padding: 15px 30px;
    border-radius: 10px;
    transition: all 0.3s;
}

.mineless-btn-goback:hover {
    background: rgba(255, 255, 255, 0.1);
    border-color: rgba(255, 255, 255, 0.2);
    color: #fff;
    text-decoration: none;
}

/* Forum Info */
.mineless-forum-info {
    padding: 20px 30px;
    background: rgba(0, 0, 0, 0.2);
    border-top: 1px solid rgba(255, 255, 255, 0.05);
}

.mineless-forum-info p {
    color: #666;
    font-size: 0.9rem;
}

.mineless-forum-info a {
    color: #ffd700;
}

/* Footer */
.mineless-redirect-footer {
    color: #555;
    font-size: 0.85rem;
}

.mineless-footer-text i {
    color: #444;
}

@media (max-width: 576px) {
    .mineless-redirect-header {
        padding: 30px 20px;
    }
    
    .mineless-warning-icon {
        width: 60px;
        height: 60px;
        font-size: 1.5rem;
    }
    
    .mineless-redirect-title {
        font-size: 1.4rem;
    }
    
    .mineless-destination-section,
    .mineless-security-warning,
    .mineless-trust-indicators,
    .mineless-redirect-actions,
    .mineless-forum-info {
        padding: 20px;
    }
    
    .mineless-redirect-actions {
        flex-direction: column;
    }
    
    .mineless-btn-continue,
    .mineless-btn-goback {
        width: 100%;
    }
}
</style>

<script>
// Auto countdown redirect
let countdown = 5;
const countdownEl = document.querySelector('.mineless-countdown');
const continueBtn = document.querySelector('.mineless-btn-continue');

if (countdownEl && continueBtn) {
    const timer = setInterval(() => {
        countdown--;
        countdownEl.textContent = '(' + countdown + ')';
        
        if (countdown <= 0) {
            clearInterval(timer);
            countdownEl.textContent = '';
            // Uncomment untuk auto-redirect:
            // window.location.href = continueBtn.href;
        }
    }, 1000);
}
</script>

{include file='footer.tpl'}
