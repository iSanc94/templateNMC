{include file='header.tpl'}
{include file='navbar.tpl'}

<!-- HERO SECTION -->
<section class="mineless-hero" id="home">
    <!-- 3-Layer Parallax Background -->
    <div class="mineless-hero-parallax">
        <div class="mineless-hero-layer mineless-hero-layer-bg" data-speed="0.2"></div>
        <div class="mineless-hero-layer mineless-hero-layer-mid" data-speed="0.5"></div>
        <div class="mineless-hero-layer mineless-hero-layer-near" data-speed="0.8"></div>
    </div>
    
    <!-- Particles.js Container -->
    <div id="particles-js"></div>
    
    <!-- Hero Content -->
    <div class="mineless-hero-content">
        <div class="mineless-container">
            <div class="mineless-hero-text">
                <h1 class="mineless-hero-title" id="hero-title">
                    <span class="mineless-title-main">Welcome to</span>
                    <span class="mineless-title-highlight">{$SITE_NAME}</span>
                </h1>
                <p class="mineless-hero-subtitle" id="hero-subtitle">
                    Best <span id="typed-text"></span> Server
                </p>
                <p class="mineless-hero-description">
                    Join the greatest adventurer community. Build, battle, and explore a boundless world with thousands of other players.
                </p>
                
                <!-- CTA Buttons -->
                <div class="mineless-hero-buttons">
                    <a href="#join" class="mineless-btn adv-btn-primary">
                        <i class="fas fa-gamepad"></i>
                        Start Playing
                    </a>
                    <a href="#features" class="mineless-btn adv-btn-outline">
                        <i class="fas fa-info-circle"></i>
                        Learn More
                    </a>
                </div>
                
                <!-- Server IP Copy -->
                <div class="mineless-server-ip" id="server-ip-box">
                    <span class="mineless-ip-label">Server IP</span>
                    <div class="mineless-ip-container">
                        <code class="mineless-ip-address" id="server-ip">{$SITE_NAME}.net</code>
                        <button class="mineless-ip-copy" id="copy-ip-btn" data-clipboard-text="{$SITE_NAME}.net">
                            <i class="fas fa-copy"></i>
                            <span class="mineless-copy-tooltip">Copy</span>
                        </button>
                    </div>
                    <span class="mineless-ip-status {if $SERVER_ONLINE}online{else}offline{/if}">
                        <i class="fas fa-circle"></i>
                        {if $SERVER_ONLINE}Online{else}Offline{/if}
                    </span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Scroll Indicator -->
    <div class="mineless-scroll-indicator" id="scroll-indicator">
        <span class="mineless-scroll-text">Scroll Down</span>
        <div class="mineless-scroll-arrow">
            <i class="fas fa-chevron-down"></i>
        </div>
    </div>
</section>

<!-- STATS BAR -->
<section class="mineless-stats-bar" id="stats">
    <div class="mineless-container">
        <div class="mineless-stats-grid">
            <div class="mineless-stat-item" data-aos="fade-up" data-aos-delay="0">
                <div class="mineless-stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="mineless-stat-info">
                    <span class="mineless-stat-number" data-count="{$STATISTICS.member_count|default:'0'}">0</span>
                    <span class="mineless-stat-label">Total Members</span>
                </div>
            </div>
            
            <div class="mineless-stat-item" data-aos="fade-up" data-aos-delay="100">
                <div class="mineless-stat-icon">
                    <i class="fas fa-comments"></i>
                </div>
                <div class="mineless-stat-info">
                    <span class="mineless-stat-number" data-count="{$STATISTICS.post_count|default:'0'}">0</span>
                    <span class="mineless-stat-label">Total Posts</span>
                </div>
            </div>
            
            <div class="mineless-stat-item" data-aos="fade-up" data-aos-delay="200">
                <div class="mineless-stat-icon">
                    <i class="fas fa-server"></i>
                </div>
                <div class="mineless-stat-info">
                    <span class="mineless-stat-status {if $SERVER_ONLINE}online{else}offline{/if}">
                        {if $SERVER_ONLINE}Online{else}Offline{/if}
                    </span>
                    <span class="mineless-stat-label">Server Status</span>
                </div>
            </div>
            
            <div class="mineless-stat-item" data-aos="fade-up" data-aos-delay="300">
                <div class="mineless-stat-icon">
                    <i class="fas fa-gamepad"></i>
                </div>
                <div class="mineless-stat-info">
                    <span class="mineless-stat-number" data-count="{$ONLINE_PLAYERS|default:'0'}">0</span>
                    <span class="mineless-stat-separator">/</span>
                    <span class="mineless-stat-max" data-count="{$MAX_PLAYERS|default:'100'}">{$MAX_PLAYERS|default:'100'}</span>
                    <span class="mineless-stat-label">Players Online</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- BERITA TERBARU -->
<section class="mineless-section adv-news-section" id="news">
    <div class="mineless-container">
        <div class="mineless-section-header">
            <span class="mineless-section-tag">Information</span>
            <h2 class="mineless-section-title">Latest News</h2>
            <p class="mineless-section-desc">Latest updates and announcements from the server</p>
        </div>
        
        <div class="mineless-news-grid">
            {if isset($NEWS) && is_array($NEWS) && count($NEWS) > 0}
                {foreach from=$NEWS item=article name=news_loop}
                    {if $smarty.foreach.news_loop.index < 3}
                        <article class="mineless-news-card" data-aos="fade-up" data-aos-delay="{$smarty.foreach.news_loop.index * 100}">
                            <div class="mineless-news-image">
                                {if isset($article.image) && $article.image != ''}
                                    <img src="{$article.image}" alt="{$article.title}" loading="lazy" onerror="this.src='{$TEMPLATE.path}/img/news-default.svg';">
                                {else}
                                    <img src="{$TEMPLATE.path}/img/news-default.svg" alt="{$article.title}" loading="lazy">
                                {/if}
                                <div class="mineless-news-overlay"></div>
                                {if isset($article.category)}
                                    <span class="mineless-news-badge">{$article.category}</span>
                                {/if}
                            </div>
                            <div class="mineless-news-content">
                                <h3 class="mineless-news-title">
                                    <a href="{$article.url}">{$article.title}</a>
                                </h3>
                                <p class="mineless-news-excerpt">
                                    {if isset($article.excerpt)}
                                        {$article.excerpt|truncate:120:"..."}
                                    {else}
                                        {$article.content|strip_tags|truncate:120:"..."}
                                    {/if}
                                </p>
                                <div class="mineless-news-meta">
                                    <span class="mineless-news-date">
                                        <i class="far fa-calendar-alt"></i>
                                        {$article.date}
                                    </span>
                                    <span class="mineless-news-author">
                                        <i class="far fa-user"></i>
                                        {$article.author}
                                    </span>
                                </div>
                            </div>
                        </article>
                    {/if}
                {/foreach}
            {else}
                <!-- Default News Placeholder -->
                <article class="mineless-news-card" data-aos="fade-up">
                    <div class="mineless-news-image">
                        <img src="{$TEMPLATE.path}/img/news-default.svg" alt="Welcome" loading="lazy">
                        <div class="mineless-news-overlay"></div>
                        <span class="mineless-news-badge">Announcement</span>
                    </div>
                    <div class="mineless-news-content">
                        <h3 class="mineless-news-title">
                            <a href="#">Welcome to {$SITE_NAME}</a>
                        </h3>
                        <p class="mineless-news-excerpt">
                            Thank you for joining our community. Explore the adventure world that awaits you...
                        </p>
                        <div class="mineless-news-meta">
                            <span class="mineless-news-date">
                                <i class="far fa-calendar-alt"></i>
                                {$smarty.now|date_format:"%d %b %Y"}
                            </span>
                            <span class="mineless-news-author">
                                <i class="far fa-user"></i>
                                Admin
                            </span>
                        </div>
                    </div>
                </article>
            {/if}
        </div>
        
        <div class="mineless-section-footer">
            <a href="{$FORUM_URL}" class="mineless-link-arrow">
                View All News
                <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</section>

<!-- FORUM PREVIEW -->
<section class="mineless-section adv-forum-section" id="forum">
    <div class="mineless-container">
        <div class="mineless-section-header">
            <span class="mineless-section-tag">Community</span>
            <h2 class="mineless-section-title">Hot Discussions</h2>
            <p class="mineless-section-desc">Join discussions with our community</p>
        </div>
        
        <div class="mineless-forum-grid">
            {if isset($LATEST_DISCUSSIONS) && is_array($LATEST_DISCUSSIONS) && count($LATEST_DISCUSSIONS) > 0}
                {foreach from=$LATEST_DISCUSSIONS item=discussion name=forum_loop}
                    {if $smarty.foreach.forum_loop.index < 4}
                        <div class="mineless-forum-card" data-aos="fade-up" data-aos-delay="{$smarty.foreach.forum_loop.index * 100}">
                            <div class="mineless-forum-icon">
                                <i class="fas {if $smarty.foreach.forum_loop.index == 0}fa-comments{elseif $smarty.foreach.forum_loop.index == 1}fa-bullhorn{elseif $smarty.foreach.forum_loop.index == 2}fa-question-circle{else}fa-lightbulb{/if}"></i>
                            </div>
                            <div class="mineless-forum-info">
                                <h3 class="mineless-forum-name">{$discussion.forum_name}</h3>
                                <p class="mineless-forum-desc">{$discussion.forum_description|truncate:60:"..."}</p>
                                <div class="mineless-forum-stats">
                                    <span><i class="fas fa-folder"></i> {$discussion.topic_count|default:'0'} Topics</span>
                                    <span><i class="fas fa-comment"></i> {$discussion.reply_count|default:'0'} Posts</span>
                                </div>
                                {if isset($discussion.last_post)}
                                    <div class="mineless-forum-last">
                                        <img src="{$discussion.last_post.avatar}" alt="" class="mineless-forum-avatar">
                                        <span>{$discussion.last_post.author}</span>
                                        <small>{$discussion.last_post.date}</small>
                                    </div>
                                {/if}
                            </div>
                        </div>
                    {/if}
                {/foreach}
            {else}
                <!-- Default Forum Categories -->
                <div class="mineless-forum-card" data-aos="fade-up">
                    <div class="mineless-forum-icon">
                        <i class="fas fa-comments"></i>
                    </div>
                    <div class="mineless-forum-info">
                        <h3 class="mineless-forum-name">General</h3>
                        <p class="mineless-forum-desc">General discussion about the server and community</p>
                        <div class="mineless-forum-stats">
                            <span><i class="fas fa-folder"></i> 0 Topics</span>
                            <span><i class="fas fa-comment"></i> 0 Posts</span>
                        </div>
                    </div>
                </div>
                <div class="mineless-forum-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="mineless-forum-icon">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <div class="mineless-forum-info">
                        <h3 class="mineless-forum-name">Announcements</h3>
                        <p class="mineless-forum-desc">Official announcements from server staff</p>
                        <div class="mineless-forum-stats">
                            <span><i class="fas fa-folder"></i> 0 Topics</span>
                            <span><i class="fas fa-comment"></i> 0 Posts</span>
                        </div>
                    </div>
                </div>
                <div class="mineless-forum-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="mineless-forum-icon">
                        <i class="fas fa-question-circle"></i>
                    </div>
                    <div class="mineless-forum-info">
                        <h3 class="mineless-forum-name">Help</h3>
                        <p class="mineless-forum-desc">Need help? Ask here</p>
                        <div class="mineless-forum-stats">
                            <span><i class="fas fa-folder"></i> 0 Topics</span>
                            <span><i class="fas fa-comment"></i> 0 Posts</span>
                        </div>
                    </div>
                </div>
                <div class="mineless-forum-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="mineless-forum-icon">
                        <i class="fas fa-lightbulb"></i>
                    </div>
                    <div class="mineless-forum-info">
                        <h3 class="mineless-forum-name">Suggestions</h3>
                        <p class="mineless-forum-desc">Give suggestions for server improvements</p>
                        <div class="mineless-forum-stats">
                            <span><i class="fas fa-folder"></i> 0 Topics</span>
                            <span><i class="fas fa-comment"></i> 0 Posts</span>
                        </div>
                    </div>
                </div>
            {/if}
        </div>
        
        <div class="mineless-section-footer">
            <a href="{$FORUM_URL}" class="mineless-btn adv-btn-primary">
                <i class="fas fa-comments"></i>
                Visit Forum
            </a>
        </div>
    </div>
</section>

<!-- FITUR SERVER SECTION -->
<section class="mineless-section adv-features-section" id="features">
    <div class="mineless-container">
        <div class="mineless-section-header">
            <span class="mineless-section-tag">Gameplay</span>
            <h2 class="mineless-section-title">Server Features</h2>
            <p class="mineless-section-desc">Various game modes awaiting your adventure</p>
        </div>
        
        <div class="mineless-features-grid">
            <div class="mineless-feature-card" data-feature="survival">
                <div class="mineless-feature-icon">
                    <i class="fas fa-tree"></i>
                </div>
                <h3 class="mineless-feature-title">Survival</h3>
                <p class="mineless-feature-desc">Survive in the wild world, gather resources, and build your kingdom from scratch.</p>
                <div class="mineless-feature-glow"></div>
            </div>
            
            <div class="mineless-feature-card" data-feature="factions">
                <div class="mineless-feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h3 class="mineless-feature-title">Factions</h3>
                <p class="mineless-feature-desc">Form alliances, claim territory, and wage war against other factions for dominance.</p>
                <div class="mineless-feature-glow"></div>
            </div>
            
            <div class="mineless-feature-card" data-feature="skyblock">
                <div class="mineless-feature-icon">
                    <i class="fas fa-cloud"></i>
                </div>
                <h3 class="mineless-feature-title">Skyblock</h3>
                <p class="mineless-feature-desc">Start from a small island in the sky and develop it into a magnificent sky kingdom.</p>
                <div class="mineless-feature-glow"></div>
            </div>
            
            <div class="mineless-feature-card" data-feature="creative">
                <div class="mineless-feature-icon">
                    <i class="fas fa-paint-brush"></i>
                </div>
                <h3 class="mineless-feature-title">Creative</h3>
                <p class="mineless-feature-desc">Unleash your imagination with unlimited creative plots and unlimited resources.</p>
                <div class="mineless-feature-glow"></div>
            </div>
            
            <div class="mineless-feature-card" data-feature="pvp">
                <div class="mineless-feature-icon">
                    <i class="fas fa-fist-raised"></i>
                </div>
                <h3 class="mineless-feature-title">PvP Arena</h3>
                <p class="mineless-feature-desc">Test your combat skills in the PvP arena with various modes and exciting rewards.</p>
                <div class="mineless-feature-glow"></div>
            </div>
            
            <div class="mineless-feature-card" data-feature="rpg">
                <div class="mineless-feature-icon">
                    <i class="fas fa-dragon"></i>
                </div>
                <h3 class="mineless-feature-title">RPG Elements</h3>
                <p class="mineless-feature-desc">Level up your character, learn skills, and conquer dungeons with epic bosses.</p>
                <div class="mineless-feature-glow"></div>
            </div>
        </div>
    </div>
</section>

<!-- STAFF ONLINE MINI -->
<section class="mineless-section adv-staff-section" id="staff">
    <div class="mineless-container">
        <div class="mineless-section-header">
            <span class="mineless-section-tag">Team</span>
            <h2 class="mineless-section-title">Staff Online</h2>
            <p class="mineless-section-desc">Our team is ready to help anytime</p>
        </div>
        
        <div class="mineless-staff-grid">
            {if isset($STAFF_ONLINE) && is_array($STAFF_ONLINE) && count($STAFF_ONLINE) > 0}
                {foreach from=$STAFF_ONLINE item=staff name=staff_loop}
                    {if $smarty.foreach.staff_loop.index < 4}
                        <div class="mineless-staff-card" data-aos="fade-up" data-aos-delay="{$smarty.foreach.staff_loop.index * 100}">
                            <div class="mineless-staff-avatar">
                                <img src="https://crafatar.com/avatars/{$staff.uuid}?size=128&overlay" alt="{$staff.username}" loading="lazy">
                                <span class="mineless-staff-status online"></span>
                            </div>
                            <h4 class="mineless-staff-name">{$staff.username}</h4>
                            <span class="mineless-staff-rank" style="color: {$staff.group_color}">{$staff.group_name}</span>
                        </div>
                    {/if}
                {/foreach}
            {else}
                <!-- Default Staff Placeholders -->
                <div class="mineless-staff-card" data-aos="fade-up">
                    <div class="mineless-staff-avatar">
                        <img src="https://crafatar.com/avatars/069a79f444e94726a5befca90e38aaf5?size=128&overlay" alt="Notch" loading="lazy">
                        <span class="mineless-staff-status offline"></span>
                    </div>
                    <h4 class="mineless-staff-name">Notch</h4>
                    <span class="mineless-staff-rank" style="color: #AA0000">Owner</span>
                </div>
                <div class="mineless-staff-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="mineless-staff-avatar">
                        <img src="https://crafatar.com/avatars/853c80ef3c3749fdaa49938b13ada946?size=128&overlay" alt="Jeb" loading="lazy">
                        <span class="mineless-staff-status offline"></span>
                    </div>
                    <h4 class="mineless-staff-name">Jeb</h4>
                    <span class="mineless-staff-rank" style="color: #FFAA00">Admin</span>
                </div>
                <div class="mineless-staff-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="mineless-staff-avatar">
                        <img src="https://crafatar.com/avatars/0e336bf89f944a8db906cebb6db50f34?size=128&overlay" alt="Dinnerbone" loading="lazy">
                        <span class="mineless-staff-status offline"></span>
                    </div>
                    <h4 class="mineless-staff-name">Dinnerbone</h4>
                    <span class="mineless-staff-rank" style="color: #55FF55">Moderator</span>
                </div>
                <div class="mineless-staff-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="mineless-staff-avatar">
                        <img src="https://crafatar.com/avatars/7da8f25c28814d66ac7cad30c5cc1e70?size=128&overlay" alt="Developer" loading="lazy">
                        <span class="mineless-staff-status offline"></span>
                    </div>
                    <h4 class="mineless-staff-name">Developer</h4>
                    <span class="mineless-staff-rank" style="color: #00AAAA">Developer</span>
                </div>
            {/if}
        </div>
    </div>
</section>

<!-- JOIN STEPS -->
<section class="mineless-section adv-join-section" id="join">
    <div class="mineless-container">
        <div class="mineless-section-header">
            <span class="mineless-section-tag">Mulai</span>
            <h2 class="mineless-section-title">Cara Bergabung</h2>
            <p class="mineless-section-desc">Tiga langkah mudah untuk memulai petualanganmu</p>
        </div>
        
        <div class="mineless-steps-container">
            <!-- Connector Line -->
            <div class="mineless-steps-line">
                <div class="mineless-steps-progress"></div>
            </div>
            
            <div class="mineless-steps-grid">
                <div class="mineless-step-card" data-step="1">
                    <div class="mineless-step-number">
                        <span>1</span>
                    </div>
                    <div class="mineless-step-icon">
                        <i class="fas fa-download"></i>
                    </div>
                    <h3 class="mineless-step-title">Download Minecraft</h3>
                    <p class="mineless-step-desc">Beli dan download Minecraft Java Edition dari minecraft.net. Versi 1.8 - 1.20+ didukung.</p>
                    <a href="https://www.minecraft.net" target="_blank" class="mineless-step-link">
                        Beli Minecraft <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>
                
                <div class="mineless-step-card" data-step="2">
                    <div class="mineless-step-number">
                        <span>2</span>
                    </div>
                    <div class="mineless-step-icon">
                        <i class="fas fa-plus-circle"></i>
                    </div>
                    <h3 class="mineless-step-title">Tambah Server</h3>
                    <p class="mineless-step-desc">Buka Multiplayer, klik "Add Server", masukkan IP server kami: <strong>{$SITE_NAME}.net</strong></p>
                    <button class="mineless-step-link adv-copy-trigger" data-clipboard-text="{$SITE_NAME}.net">
                        Copy IP <i class="fas fa-copy"></i>
                    </button>
                </div>
                
                <div class="mineless-step-card" data-step="3">
                    <div class="mineless-step-number">
                        <span>3</span>
                    </div>
                    <div class="mineless-step-icon">
                        <i class="fas fa-play-circle"></i>
                    </div>
                    <h3 class="mineless-step-title">Bermain!</h3>
                    <p class="mineless-step-desc">Klik "Join Server" dan mulai petualanganmu di dunia {$SITE_NAME}!</p>
                    <span class="mineless-step-badge">
                        <i class="fas fa-check"></i> Siap!
                    </span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- DISCORD CTA -->
<section class="mineless-section adv-discord-section" id="discord">
    <div class="mineless-discord-bg"></div>
    <div class="mineless-container">
        <div class="mineless-discord-content">
            <div class="mineless-discord-logo" data-aos="zoom-in">
                <i class="fab fa-discord"></i>
                <div class="mineless-discord-orbits">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <div class="mineless-discord-text">
                <h2 class="mineless-discord-title">Bergabung dengan Discord</h2>
                <p class="mineless-discord-desc">Terhubung dengan komunitas kami, dapatkan update terbaru, event, dan dukungan langsung dari staff.</p>
                
                {if isset($DISCORD_MEMBERS) && $DISCORD_MEMBERS > 0}
                    <div class="mineless-discord-stats">
                        <span class="mineless-discord-members">
                            <i class="fas fa-users"></i>
                            <strong>{$DISCORD_MEMBERS}</strong> Members Online
                        </span>
                    </div>
                {/if}
                
                <a href="{$DISCORD_URL|default:'#'}" target="_blank" class="mineless-btn adv-btn-discord">
                    <i class="fab fa-discord"></i>
                    Join Discord
                </a>
            </div>
        </div>
    </div>
</section>

{include file='footer.tpl'}

<!-- Page Specific Scripts -->
<script>
    // Wait for DOM and GSAP to be ready
    document.addEventListener('DOMContentLoaded', function() {
        
        // Initialize Particles.js
        if (typeof particlesJS !== 'undefined') {
            particlesJS('particles-js', {
                particles: {
                    number: { value: 80, density: { enable: true, value_area: 800 } },
                    color: { value: '#d4af37' },
                    shape: { type: 'circle' },
                    opacity: { value: 0.5, random: true },
                    size: { value: 3, random: true },
                    line_linked: {
                        enable: true,
                        distance: 150,
                        color: '#d4af37',
                        opacity: 0.2,
                        width: 1
                    },
                    move: {
                        enable: true,
                        speed: 1,
                        direction: 'none',
                        random: true,
                        straight: false,
                        out_mode: 'out'
                    }
                },
                interactivity: {
                    detect_on: 'canvas',
                    events: {
                        onhover: { enable: true, mode: 'grab' },
                        onclick: { enable: true, mode: 'push' }
                    }
                }
            });
        }
        
        // Initialize Typed.js
        if (typeof Typed !== 'undefined') {
            new Typed('#typed-text', {
                strings: ['Survival', 'Factions', 'Skyblock', 'Creative', 'PvP'],
                typeSpeed: 80,
                backSpeed: 50,
                backDelay: 2000,
                loop: true,
                showCursor: true,
                cursorChar: '|'
            });
        }
        
        // GSAP Hero Animations
        if (typeof gsap !== 'undefined') {
            const heroTl = gsap.timeline({ defaults: { ease: 'power3.out' } });
            
            // Title reveal from bottom
            heroTl.from('#hero-title', {
                y: 60,
                opacity: 0,
                duration: 1.2
            })
            // Subtitle fade in with delay
            .from('#hero-subtitle', {
                y: 30,
                opacity: 0,
                duration: 0.8
            }, '-=0.4')
            // Description
            .from('.mineless-hero-description', {
                y: 30,
                opacity: 0,
                duration: 0.8
            }, '-=0.5')
            // Buttons
            .from('.mineless-hero-buttons', {
                y: 30,
                opacity: 0,
                duration: 0.8
            }, '-=0.5')
            // Server IP box
            .from('#server-ip-box', {
                y: 30,
                opacity: 0,
                duration: 0.8
            }, '-=0.5')
            // Scroll indicator
            .from('#scroll-indicator', {
                y: 20,
                opacity: 0,
                duration: 0.8
            }, '-=0.3');
            
            // Parallax effect on hero layers
            gsap.utils.toArray('.mineless-hero-layer').forEach(layer => {
                const speed = layer.dataset.speed || 0.5;
                gsap.to(layer, {
                    yPercent: speed * 50,
                    ease: 'none',
                    scrollTrigger: {
                        trigger: '.mineless-hero',
                        start: 'top top',
                        end: 'bottom top',
                        scrub: true
                    }
                });
            });
            
            // Stats Counter Animation
            gsap.utils.toArray('.mineless-stat-number[data-count]').forEach(stat => {
                const target = parseInt(stat.dataset.count) || 0;
                gsap.to(stat, {
                    innerHTML: target,
                    duration: 2,
                    snap: { innerHTML: 1 },
                    ease: 'power2.out',
                    scrollTrigger: {
                        trigger: stat,
                        start: 'top 80%',
                        toggleActions: 'play none none none'
                    }
                });
            });
            
            // Features Stagger Animation
            gsap.from('.mineless-feature-card', {
                y: 60,
                opacity: 0,
                duration: 0.8,
                stagger: 0.1,
                ease: 'power3.out',
                scrollTrigger: {
                    trigger: '.mineless-features-grid',
                    start: 'top 75%'
                }
            });
            
            // Steps Animation with Line Progress
            const stepsTl = gsap.timeline({
                scrollTrigger: {
                    trigger: '.mineless-steps-container',
                    start: 'top 70%'
                }
            });
            
            stepsTl.from('.mineless-step-number', {
                scale: 0,
                opacity: 0,
                duration: 0.6,
                stagger: 0.2,
                ease: 'back.out(1.7)'
            })
            .to('.mineless-steps-progress', {
                width: '100%',
                duration: 1.5,
                ease: 'power2.inOut'
            }, '-=0.8')
            .from('.mineless-step-card', {
                y: 40,
                opacity: 0,
                duration: 0.6,
                stagger: 0.15,
                ease: 'power3.out'
            }, '-=1');
        }
        
        // Copy to Clipboard functionality
        const copyBtns = document.querySelectorAll('[data-clipboard-text], .mineless-ip-copy');
        copyBtns.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const text = this.dataset.clipboardText || 
                    document.querySelector('#server-ip')?.textContent || 
                    '{$SITE_NAME}.net';
                
                navigator.clipboard.writeText(text).then(() => {
                    // Show checkmark animation
                    const originalIcon = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-check"></i>';
                    this.classList.add('copied');
                    
                    // Create floating check animation
                    const check = document.createElement('span');
                    check.className = 'adv-copy-check';
                    check.innerHTML = '<i class="fas fa-check"></i>';
                    document.body.appendChild(check);
                    
                    const rect = this.getBoundingClientRect();
                    check.style.left = rect.left + 'px';
                    check.style.top = rect.top + 'px';
                    
                    gsap.to(check, {
                        y: -30,
                        opacity: 0,
                        duration: 0.8,
                        onComplete: () => check.remove()
                    });
                    
                    setTimeout(() => {
                        this.innerHTML = originalIcon;
                        this.classList.remove('copied');
                    }, 2000);
                });
            });
        });
        
        // Scroll indicator click
        document.getElementById('scroll-indicator')?.addEventListener('click', () => {
            document.getElementById('stats').scrollIntoView({ behavior: 'smooth' });
        });
        
        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
        
        // Feature card hover effects
        document.querySelectorAll('.mineless-feature-card').forEach(card => {
            const icon = card.querySelector('.mineless-feature-icon');
            
            card.addEventListener('mouseenter', () => {
                gsap.to(icon, {
                    rotation: 360,
                    scale: 1.1,
                    duration: 0.6,
                    ease: 'back.out(1.7)'
                });
                gsap.to(card, {
                    y: -8,
                    boxShadow: '0 20px 40px rgba(212, 175, 55, 0.3)',
                    duration: 0.3
                });
            });
            
            card.addEventListener('mouseleave', () => {
                gsap.to(icon, {
                    rotation: 0,
                    scale: 1,
                    duration: 0.4,
                    ease: 'power2.out'
                });
                gsap.to(card, {
                    y: 0,
                    boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)',
                    duration: 0.3
                });
            });
        });
        
        // News card hover glow
        document.querySelectorAll('.mineless-news-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                gsap.to(card, {
                    y: -8,
                    duration: 0.3,
                    ease: 'power2.out'
                });
                card.style.borderColor = 'rgba(212, 175, 55, 0.5)';
                card.style.boxShadow = '0 20px 40px rgba(212, 175, 55, 0.2)';
            });
            
            card.addEventListener('mouseleave', () => {
                gsap.to(card, {
                    y: 0,
                    duration: 0.3,
                    ease: 'power2.out'
                });
                card.style.borderColor = 'rgba(212, 175, 55, 0.1)';
                card.style.boxShadow = 'none';
            });
        });
    });
</script>
