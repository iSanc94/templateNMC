<?php
/**
 * Mineless Template
 * For NamelessMC v2.2.0+
 */

// Ensure NamelessMC is loaded
if (!defined('ROOT_PATH')) {
    die('Direct access denied');
}

// Template Class
class Mineless_Template extends SmartyTemplateBase
{
    private $_template = array();
    private $_language;
    private $_user;
    private $_pages;

    public function __construct(Cache $cache, Language $language, User $user, Pages $pages)
    {
        $this->_template = array(
            'name' => 'Mineless',
            'version' => '1.0.0',
            'nl_version' => '2.2.0',
            'author' => 'Mineless Theme',
            'path' => (defined('CONFIG_PATH') ? CONFIG_PATH : '') . '/custom/templates/Mineless/',
        );

        parent::__construct(
            $this->_template['name'],
            $this->_template['version'],
            $this->_template['nl_version'],
            $this->_template['author'],
            __DIR__
        );

        $this->_settings = ROOT_PATH . '/custom/templates/Mineless/template_settings/settings.php';

        // Include required assets
        $this->assets()->include(array(
            AssetTree::FONT_AWESOME,
            AssetTree::JQUERY,
            AssetTree::JQUERY_COOKIE,
        ));

        // Add template variable
        $this->getEngine()->addVariable('TEMPLATE', $this->_template);

        // Store dependencies
        $this->_language = $language;
        $this->_user = $user;
        $this->_pages = $pages;
    }

    public function onPageLoad()
    {
        // Page load time
        if (defined('PAGE_START_TIME')) {
            $page_load = microtime(true) - PAGE_START_TIME;
            define('PAGE_LOAD_TIME', $this->_language->get('general', 'page_loaded_in', array('time' => round($page_load, 3))));
        }

        // Add CSS
        $this->addCSSFiles(array(
            $this->_template['path'] . 'css/custom.css' => array(),
        ));

        // Build JS variables
        $route = isset($_GET['route']) ? rtrim($_GET['route'], '/') : '/';
        
        $JSVariables = array(
            'siteName' => defined('SITE_NAME') ? Output::getClean(SITE_NAME) : '',
            'siteURL' => URL::build('/'),
            'fullSiteURL' => URL::getSelfURL() . ltrim(URL::build('/'), '/'),
            'page' => defined('PAGE') ? PAGE : '',
            'avatarSource' => AvatarSource::getUrlToFormat(),
            'copied' => $this->_language->get('general', 'copied'),
            'cookieNotice' => $this->_language->get('general', 'cookie_notice'),
            'noMessages' => $this->_language->get('user', 'no_messages'),
            'newMessage1' => $this->_language->get('user', '1_new_message'),
            'newMessagesX' => $this->_language->get('user', 'x_new_messages'),
            'noAlerts' => $this->_language->get('user', 'no_alerts'),
            'newAlert1' => $this->_language->get('user', '1_new_alert'),
            'newAlertsX' => $this->_language->get('user', 'x_new_alerts'),
            'bungeeInstance' => $this->_language->get('general', 'bungee_instance'),
            'andMoreX' => $this->_language->get('general', 'and_x_more'),
            'onePlayerOnline' => $this->_language->get('general', 'currently_1_player_online'),
            'xPlayersOnline' => $this->_language->get('general', 'currently_x_players_online'),
            'noPlayersOnline' => $this->_language->get('general', 'no_players_online'),
            'offline' => $this->_language->get('general', 'offline'),
            'confirmDelete' => $this->_language->get('general', 'confirm_deletion'),
            'debugging' => (defined('DEBUGGING') && DEBUGGING == 1) ? '1' : '0',
            'loggedIn' => $this->_user->isLoggedIn() ? '1' : '0',
            'cookie' => defined('COOKIE_NOTICE') ? '1' : '0',
            'loadingTime' => Settings::get('page_loading') === '1' && defined('PAGE_LOAD_TIME') ? PAGE_LOAD_TIME : '',
            'route' => $route,
            'csrfToken' => Token::get(),
        );

        // Build JS output
        $JSVars = '';
        $i = 0;
        foreach ($JSVariables as $var => $value) {
            $JSVars .= ($i == 0 ? 'const ' : ', ') . $var . ' = ' . json_encode($value);
            $i++;
        }
        $this->addJSScript($JSVars);

        // Add JS files
        $this->addJSFiles(array(
            $this->_template['path'] . 'js/core/core.js' => array(),
            $this->_template['path'] . 'js/core/user.js' => array(),
            $this->_template['path'] . 'js/core/pages.js' => array(),
        ));

        // Add AJAX scripts
        foreach ($this->_pages->getAjaxScripts() as $script) {
            $this->addJSScript('$.getJSON(' . json_encode($script) . ', function(data) {});');
        }
    }
}

// Initialize
$template = new Mineless_Template($cache, $language, $user, $pages);
$template_pagination = array('div' => 'ui mini pagination menu', 'a' => '{x}item');
