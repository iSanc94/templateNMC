{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-auth-section">
    <div class="mineless-auth-bg">
        <div class="mineless-auth-particles" id="auth-particles"></div>
        <div class="mineless-auth-illustration">
            <div class="mineless-hero-character">
                <svg viewBox="0 0 200 300" class="mineless-hero-svg">
                    <!-- Mineless Hero Character -->
                    <defs>
                        <linearGradient id="armorGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" style="stop-color:#D4AF37"/>
                            <stop offset="100%" style="stop-color:#8B6914"/>
                        </linearGradient>
                        <linearGradient id="capeGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" style="stop-color:#C84B11"/>
                            <stop offset="100%" style="stop-color:#8B2F0B"/>
                        </linearGradient>
                    </defs>
                    <!-- Cape -->
                    <path d="M70,80 Q100,70 130,80 L140,200 Q100,220 60,200 Z" fill="url(#capeGrad)" opacity="0.8">
                        <animate attributeName="d" values="M70,80 Q100,70 130,80 L140,200 Q100,220 60,200 Z;M70,80 Q100,75 130,80 L145,200 Q100,215 55,200 Z;M70,80 Q100,70 130,80 L140,200 Q100,220 60,200 Z" dur="3s" repeatCount="indefinite"/>
                    </path>
                    <!-- Body/Armor -->
                    <rect x="75" y="80" width="50" height="80" rx="10" fill="url(#armorGrad)"/>
                    <!-- Head -->
                    <circle cx="100" cy="60" r="25" fill="#F0E6D3"/>
                    <!-- Helmet -->
                    <path d="M70,50 Q100,20 130,50 L130,70 Q100,80 70,70 Z" fill="url(#armorGrad)"/>
                    <!-- Eyes -->
                    <circle cx="90" cy="60" r="3" fill="#0A0A0F">
                        <animate attributeName="opacity" values="1;0.2;1" dur="4s" repeatCount="indefinite"/>
                    </circle>
                    <circle cx="110" cy="60" r="3" fill="#0A0A0F">
                        <animate attributeName="opacity" values="1;0.2;1" dur="4s" repeatCount="indefinite"/>
                    </circle>
                    <!-- Sword -->
                    <rect x="140" y="40" width="8" height="100" fill="#C0C0C0" transform="rotate(15 144 90)"/>
                    <rect x="130" y="85" width="28" height="8" fill="#D4AF37" transform="rotate(15 144 90)"/>
                    <!-- Glow effect -->
                    <circle cx="100" cy="150" r="80" fill="url(#armorGrad)" opacity="0.1">
                        <animate attributeName="r" values="80;90;80" dur="2s" repeatCount="indefinite"/>
                        <animate attributeName="opacity" values="0.1;0.2;0.1" dur="2s" repeatCount="indefinite"/>
                    </circle>
                </svg>
            </div>
            <div class="mineless-floating-runes">
                <span class="mineless-rune">ᚦ</span>
                <span class="mineless-rune">ᚩ</span>
                <span class="mineless-rune">ᚱ</span>
            </div>
        </div>
    </div>
    
    <div class="mineless-auth-container">
        <div class="mineless-auth-card" data-animate="fade-in-up">
            <div class="mineless-auth-border"></div>
            
            <div class="mineless-auth-header">
                <div class="mineless-auth-icon">
                    <i class="fas fa-key"></i>
                </div>
                <h1 class="mineless-auth-title">{$SIGN_IN}</h1>
                <p class="mineless-auth-subtitle">Selamat datang kembali, petualang!</p>
            </div>
            
            {if isset($ERROR)}
                <div class="mineless-alert adv-alert-error adv-shake">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>{$ERROR}</span>
                </div>
            {/if}
            
            {if isset($SUCCESS)}
                <div class="mineless-alert adv-alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span>{$SUCCESS}</span>
                </div>
            {/if}
            
            <form action="" method="post" class="mineless-form" id="login-form">
                <input type="hidden" name="token" value="{$TOKEN}">
                
                <div class="mineless-form-group">
                    <label for="username" class="mineless-form-label">{$USERNAME}</label>
                    <div class="mineless-input-wrapper">
                        <i class="fas fa-user adv-input-icon"></i>
                        <input type="text" id="username" name="username" class="mineless-input" placeholder="{$USERNAME}" required>
                        <div class="mineless-input-line"></div>
                    </div>
                </div>
                
                <div class="mineless-form-group">
                    <label for="password" class="mineless-form-label">{$PASSWORD}</label>
                    <div class="mineless-input-wrapper">
                        <i class="fas fa-lock adv-input-icon"></i>
                        <input type="password" id="password" name="password" class="mineless-input" placeholder="{$PASSWORD}" required>
                        <button type="button" class="mineless-password-toggle" onclick="togglePassword('password', this)">
                            <i class="fas fa-eye"></i>
                        </button>
                        <div class="mineless-input-line"></div>
                    </div>
                </div>
                
                <div class="mineless-form-row">
                    <label class="mineless-checkbox">
                        <input type="checkbox" name="remember" id="remember" value="1">
                        <span class="mineless-checkbox-check"></span>
                        <span class="mineless-checkbox-label">{$REMEMBER_ME}</span>
                    </label>
                    <a href="{$FORGOT_PASSWORD_URL}" class="mineless-link">{$FORGOT_PASSWORD}</a>
                </div>
                
                <button type="submit" class="mineless-btn adv-btn-primary adv-btn-block adv-btn-lg">
                    <span class="mineless-btn-text">{$SIGN_IN}</span>
                    <i class="fas fa-arrow-right adv-btn-icon"></i>
                    <div class="mineless-btn-shine"></div>
                </button>
            </form>
            
            <div class="mineless-divider">
                <span class="mineless-divider-text">{$OR}</span>
            </div>
            
            <div class="mineless-oauth-buttons">
                {if isset($DISCORD_INTEGRATION) && $DISCORD_INTEGRATION}
                    <a href="{$DISCORD_LOGIN_URL}" class="mineless-btn adv-btn-oauth adv-btn-discord">
                        <i class="fab fa-discord"></i>
                        <span>Discord</span>
                    </a>
                {/if}
                {if isset($STEAM_INTEGRATION) && $STEAM_INTEGRATION}
                    <a href="{$STEAM_LOGIN_URL}" class="mineless-btn adv-btn-oauth adv-btn-steam">
                        <i class="fab fa-steam"></i>
                        <span>Steam</span>
                    </a>
                {/if}
                {if isset($GOOGLE_INTEGRATION) && $GOOGLE_INTEGRATION}
                    <a href="{$GOOGLE_LOGIN_URL}" class="mineless-btn adv-btn-oauth adv-btn-google">
                        <i class="fab fa-google"></i>
                        <span>Google</span>
                    </a>
                {/if}
            </div>
            
            <div class="mineless-auth-footer">
                <p>{$NO_ACCOUNT} <a href="{$REGISTER_URL}" class="mineless-link adv-link-bold">{$REGISTER}</a></p>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-auth-section {
    min-height: 100vh;
    display: flex;
    position: relative;
    overflow: hidden;
}

.mineless-auth-bg {
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, #0A0A0F 0%, #16161F 50%, #111118 100%);
}

.mineless-auth-particles {
    position: absolute;
    inset: 0;
    background-image: 
        radial-gradient(circle at 20% 80%, rgba(212, 175, 55, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 80% 20%, rgba(200, 75, 17, 0.1) 0%, transparent 50%);
}

.mineless-auth-illustration {
    position: absolute;
    left: 5%;
    top: 50%;
    transform: translateY(-50%);
    width: 45%;
    max-width: 600px;
}

.mineless-hero-character {
    width: 100%;
    animation: MinelessFloat 6s ease-in-out infinite;
}

.mineless-hero-svg {
    width: 100%;
    height: auto;
    filter: drop-shadow(0 0 30px rgba(212, 175, 55, 0.3));
}

.mineless-floating-runes {
    position: absolute;
    top: 0;
    right: 0;
}

.mineless-rune {
    position: absolute;
    font-size: 2rem;
    color: var(--mineless-gold);
    opacity: 0.3;
    animation: runeRotate 10s linear infinite;
}

.mineless-rune:nth-child(1) { top: 10%; right: 10%; animation-delay: 0s; }
.mineless-rune:nth-child(2) { top: 30%; right: 30%; animation-delay: -3s; }
.mineless-rune:nth-child(3) { top: 60%; right: 15%; animation-delay: -6s; }

.mineless-auth-container {
    margin-left: auto;
    width: 55%;
    max-width: 600px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem;
    position: relative;
    z-index: 1;
}

.mineless-auth-card {
    width: 100%;
    max-width: 450px;
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-xl);
    padding: 2.5rem;
    position: relative;
    overflow: hidden;
}

.mineless-auth-border {
    position: absolute;
    inset: 0;
    border-radius: var(--radius-xl);
    padding: 2px;
    background: linear-gradient(135deg, var(--mineless-gold), transparent, var(--mineless-gold));
    -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    animation: borderRotate 4s linear infinite;
}

.mineless-auth-header {
    text-align: center;
    margin-bottom: 2rem;
}

.mineless-auth-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 1.5rem;
    background: linear-gradient(135deg, var(--mineless-gold), #8B6914);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    color: var(--bg-primary);
    box-shadow: 0 0 30px rgba(212, 175, 55, 0.3);
    animation: magicPulse 2s ease-in-out infinite;
}

.mineless-auth-title {
    font-family: var(--font-display);
    font-size: 2rem;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
}

.mineless-auth-subtitle {
    color: var(--text-secondary);
    font-size: 0.95rem;
}

.mineless-alert {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem;
    border-radius: var(--radius-md);
    margin-bottom: 1.5rem;
    font-size: 0.9rem;
}

.mineless-alert-error {
    background: rgba(220, 53, 69, 0.1);
    border: 1px solid rgba(220, 53, 69, 0.3);
    color: #ff6b6b;
}

.mineless-alert-success {
    background: rgba(40, 167, 69, 0.1);
    border: 1px solid rgba(40, 167, 69, 0.3);
    color: #51cf66;
}

.mineless-shake {
    animation: shakeError 0.5s ease-in-out;
}

.mineless-form-group {
    margin-bottom: 1.5rem;
}

.mineless-form-label {
    display: block;
    margin-bottom: 0.5rem;
    color: var(--text-primary);
    font-weight: 500;
    font-size: 0.9rem;
}

.mineless-input-wrapper {
    position: relative;
}

.mineless-input-icon {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-secondary);
    transition: var(--transition-fast);
}

.mineless-input {
    width: 100%;
    padding: 0.875rem 1rem 0.875rem 2.75rem;
    background: var(--bg-secondary);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-md);
    color: var(--text-primary);
    font-size: 1rem;
    transition: var(--transition-fast);
}

.mineless-input:focus {
    outline: none;
    border-color: var(--mineless-gold);
    box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
}

.mineless-input:focus + .mineless-input-icon {
    color: var(--mineless-gold);
}

.mineless-password-toggle {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    padding: 0.25rem;
    transition: var(--transition-fast);
}

.mineless-password-toggle:hover {
    color: var(--mineless-gold);
}

.mineless-form-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.mineless-checkbox {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    cursor: pointer;
}

.mineless-checkbox input {
    display: none;
}

.mineless-checkbox-check {
    width: 20px;
    height: 20px;
    border: 2px solid rgba(212, 175, 55, 0.3);
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--transition-fast);
}

.mineless-checkbox input:checked + .mineless-checkbox-check {
    background: var(--mineless-gold);
    border-color: var(--mineless-gold);
}

.mineless-checkbox input:checked + .mineless-checkbox-check::after {
    content: '✓';
    color: var(--bg-primary);
    font-size: 0.75rem;
    font-weight: bold;
}

.mineless-checkbox-label {
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.mineless-link {
    color: var(--mineless-gold);
    text-decoration: none;
    font-size: 0.9rem;
    transition: var(--transition-fast);
}

.mineless-link:hover {
    text-decoration: underline;
}

.mineless-link-bold {
    font-weight: 600;
}

.mineless-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    border-radius: var(--radius-md);
    font-weight: 600;
    font-size: 0.95rem;
    cursor: pointer;
    transition: var(--transition-fast);
    border: none;
    position: relative;
    overflow: hidden;
}

.mineless-btn-primary {
    background: linear-gradient(135deg, var(--mineless-gold), #8B6914);
    color: var(--bg-primary);
}

.mineless-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(212, 175, 55, 0.3);
}

.mineless-btn-block {
    width: 100%;
}

.mineless-btn-lg {
    padding: 1rem 2rem;
    font-size: 1rem;
}

.mineless-btn-shine {
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    transition: 0.5s;
}

.mineless-btn:hover .mineless-btn-shine {
    left: 100%;
}

.mineless-divider {
    display: flex;
    align-items: center;
    margin: 1.5rem 0;
}

.mineless-divider::before,
.mineless-divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(212, 175, 55, 0.3), transparent);
}

.mineless-divider-text {
    padding: 0 1rem;
    color: var(--text-secondary);
    font-size: 0.85rem;
}

.mineless-oauth-buttons {
    display: flex;
    gap: 0.75rem;
    justify-content: center;
    flex-wrap: wrap;
}

.mineless-btn-oauth {
    flex: 1;
    min-width: 100px;
    background: var(--bg-secondary);
    border: 1px solid rgba(212, 175, 55, 0.2);
    color: var(--text-primary);
}

.mineless-btn-oauth:hover {
    border-color: var(--mineless-gold);
    transform: translateY(-2px);
}

.mineless-btn-discord:hover { background: #5865F2; color: white; }
.mineless-btn-steam:hover { background: #1b2838; color: white; }
.mineless-btn-google:hover { background: #4285F4; color: white; }

.mineless-auth-footer {
    text-align: center;
    margin-top: 1.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid rgba(212, 175, 55, 0.1);
    color: var(--text-secondary);
}

@media (max-width: 1024px) {
    .mineless-auth-illustration {
        display: none;
    }
    .mineless-auth-container {
        width: 100%;
        margin: 0 auto;
    }
}

@media (max-width: 480px) {
    .mineless-auth-card {
        padding: 1.5rem;
    }
    .mineless-auth-title {
        font-size: 1.5rem;
    }
}
</style>

<script>
function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Form animation
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('login-form');
    const inputs = form.querySelectorAll('.mineless-input');
    
    inputs.forEach((input, index) => {
        input.addEventListener('focus', () => {
            input.parentElement.classList.add('focused');
        });
        input.addEventListener('blur', () => {
            input.parentElement.classList.remove('focused');
        });
    });
});
</script>

{include file='footer.tpl'}