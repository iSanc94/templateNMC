{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-auth-section">
    <div class="mineless-auth-bg">
        <div class="mineless-auth-particles"></div>
        
        <!-- Shield Animation -->
        <div class="mineless-shield-container">
            <svg class="mineless-shield-svg" viewBox="0 0 200 240" id="security-shield">
                <defs>
                    <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:#D4AF37"/>
                        <stop offset="50%" style="stop-color:#C9AA5E"/>
                        <stop offset="100%" style="stop-color:#8B6914"/>
                    </linearGradient>
                    <linearGradient id="shieldInner" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" style="stop-color:#16161F"/>
                        <stop offset="100%" style="stop-color:#0A0A0F"/>
                    </linearGradient>
                </defs>
                
                <!-- Shield Outer -->
                <path d="M100,10 L180,50 L180,120 Q180,180 100,230 Q20,180 20,120 L20,50 Z" 
                      fill="url(#shieldGrad)" stroke="#D4AF37" stroke-width="3"/>
                
                <!-- Shield Inner -->
                <path d="M100,30 L160,60 L160,115 Q160,165 100,205 Q40,165 40,115 L40,60 Z" 
                      fill="url(#shieldInner)"/>
                
                <!-- Lock Icon -->
                <g id="shield-lock" transform="translate(70, 80)">
                    <rect x="10" y="30" width="40" height="35" rx="5" fill="#D4AF37"/>
                    <path d="M20,30 L20,20 Q20,5 30,5 Q40,5 40,20 L40,30" 
                          fill="none" stroke="#D4AF37" stroke-width="5" stroke-linecap="round"/>
                    <circle cx="30" cy="47" r="5" fill="#0A0A0F"/>
                    <rect x="28" y="47" width="4" height="10" fill="#0A0A0F"/>
                </g>
                
                <!-- Glow Effect -->
                <circle cx="100" cy="120" r="80" fill="url(#shieldGrad)" opacity="0.1">
                    <animate attributeName="r" values="80;90;80" dur="2s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.1;0.2;0.1" dur="2s" repeatCount="indefinite"/>
                </circle>
            </svg>
            
            <!-- Rune decorations -->
            <div class="mineless-shield-runes">
                <span class="mineless-rune-float">ᚦ</span>
                <span class="mineless-rune-float">ᚱ</span>
                <span class="mineless-rune-float">ᚢ</span>
                <span class="mineless-rune-float">ᚾ</span>
            </div>
        </div>
    </div>
    
    <div class="mineless-auth-container">
        <div class="mineless-auth-card" data-animate="fade-in-up">
            <div class="mineless-auth-border"></div>
            
            <div class="mineless-auth-header">
                <div class="mineless-auth-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h1 class="mineless-auth-title">{$TWO_FACTOR_AUTH}</h1>
                <p class="mineless-auth-subtitle">Masukkan kode dari aplikasi authenticator</p>
            </div>
            
            {if isset($ERROR)}
                <div class="mineless-alert adv-alert-error adv-shake">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>{$ERROR}</span>
                </div>
            {/if}
            
            <form action="" method="post" class="mineless-form" id="tfa-form">
                <input type="hidden" name="token" value="{$TOKEN}">
                
                <div class="mineless-form-group">
                    <label class="mineless-form-label">Kode Autentikasi</label>
                    <div class="mineless-otp-container">
                        <input type="text" maxlength="1" class="mineless-otp-box" name="otp_1" required autofocus>
                        <input type="text" maxlength="1" class="mineless-otp-box" name="otp_2" required>
                        <input type="text" maxlength="1" class="mineless-otp-box" name="otp_3" required>
                        <span class="mineless-otp-divider">-</span>
                        <input type="text" maxlength="1" class="mineless-otp-box" name="otp_4" required>
                        <input type="text" maxlength="1" class="mineless-otp-box" name="otp_5" required>
                        <input type="text" maxlength="1" class="mineless-otp-box" name="otp_6" required>
                    </div>
                    <input type="hidden" name="code" id="otp-full">
                </div>
                
                <div class="mineless-tfa-options">
                    <a href="#" class="mineless-link adv-recovery-link" onclick="showRecovery()">
                        <i class="fas fa-key"></i> Gunakan Kode Recovery
                    </a>
                </div>
                
                <!-- Recovery Code Input (Hidden by default) -->
                <div class="mineless-recovery-section" id="recovery-section" style="display: none;">
                    <div class="mineless-form-group">
                        <label for="recovery_code" class="mineless-form-label">Kode Recovery</label>
                        <div class="mineless-input-wrapper">
                            <i class="fas fa-key adv-input-icon"></i>
                            <input type="text" id="recovery_code" name="recovery_code" class="mineless-input" 
                                   placeholder="XXXX-XXXX-XXXX" maxlength="14">
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="mineless-btn adv-btn-primary adv-btn-block adv-btn-lg" id="submit-btn">
                    <span class="mineless-btn-text">Verifikasi</span>
                    <i class="fas fa-unlock adv-btn-icon"></i>
                </button>
            </form>
            
            <div class="mineless-resend-section">
                <span id="resend-timer">Kode baru dalam 30 detik</span>
                <button type="button" class="mineless-link" id="resend-btn" onclick="resendCode()" disabled>
                    Kirim Ulang Kode
                </button>
            </div>
            
            <div class="mineless-auth-footer">
                <a href="{$LOGIN_URL}" class="mineless-link">
                    <i class="fas fa-arrow-left"></i> Kembali ke Login
                </a>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-shield-container {
    position: absolute;
    left: 10%;
    top: 50%;
    transform: translateY(-50%);
    width: 350px;
}

.mineless-shield-svg {
    width: 100%;
    height: auto;
    filter: drop-shadow(0 0 30px rgba(212, 175, 55, 0.4));
    animation: shieldFloat 4s ease-in-out infinite;
}

@keyframes shieldFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-15px); }
}

#shield-lock {
    animation: lockPulse 2s ease-in-out infinite;
}

@keyframes lockPulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.7; }
}

.mineless-shield-runes {
    position: absolute;
    inset: 0;
    pointer-events: none;
}

.mineless-rune-float {
    position: absolute;
    font-size: 1.5rem;
    color: var(--mineless-gold);
    opacity: 0.3;
    animation: runeFloat 3s ease-in-out infinite;
}

.mineless-rune-float:nth-child(1) { top: 0; left: 20%; animation-delay: 0s; }
.mineless-rune-float:nth-child(2) { top: 20%; right: 10%; animation-delay: -0.7s; }
.mineless-rune-float:nth-child(3) { bottom: 30%; left: 5%; animation-delay: -1.4s; }
.mineless-rune-float:nth-child(4) { bottom: 10%; right: 25%; animation-delay: -2.1s; }

@keyframes runeFloat {
    0%, 100% { transform: translateY(0) rotate(0deg); opacity: 0.3; }
    50% { transform: translateY(-20px) rotate(10deg); opacity: 0.6; }
}

.mineless-otp-container {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.mineless-otp-box {
    width: 50px;
    height: 60px;
    text-align: center;
    font-size: 1.5rem;
    font-weight: 700;
    background: var(--bg-secondary);
    border: 2px solid rgba(212, 175, 55, 0.3);
    border-radius: var(--radius-md);
    color: var(--mineless-gold);
    transition: var(--transition-fast);
}

.mineless-otp-box:focus {
    outline: none;
    border-color: var(--mineless-gold);
    box-shadow: 0 0 0 4px rgba(212, 175, 55, 0.2);
    transform: translateY(-2px) scale(1.05);
}

.mineless-otp-box.filled {
    background: rgba(212, 175, 55, 0.1);
    border-color: var(--mineless-gold);
}

.mineless-otp-divider {
    font-size: 1.5rem;
    color: var(--text-secondary);
    font-weight: 300;
}

.mineless-tfa-options {
    text-align: center;
    margin: 1rem 0;
}

.mineless-recovery-link {
    font-size: 0.9rem;
}

.mineless-recovery-section {
    margin-bottom: 1.5rem;
    padding: 1rem;
    background: rgba(212, 175, 55, 0.05);
    border-radius: var(--radius-md);
    border: 1px solid rgba(212, 175, 55, 0.1);
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.mineless-resend-section {
    text-align: center;
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-resend-section span {
    color: var(--text-secondary);
    font-size: 0.85rem;
}

/* Success Animation */
.mineless-shield-svg.success #shield-lock {
    animation: lockOpen 0.5s ease forwards;
}

@keyframes lockOpen {
    0% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0); opacity: 0.5; }
}

.mineless-shield-svg.success {
    animation: shieldSuccess 0.5s ease;
}

@keyframes shieldSuccess {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); filter: drop-shadow(0 0 50px rgba(40, 167, 69, 0.6)); }
    100% { transform: scale(1); }
}

@media (max-width: 1024px) {
    .mineless-shield-container {
        display: none;
    }
}

@media (max-width: 480px) {
    .mineless-otp-box {
        width: 40px;
        height: 50px;
        font-size: 1.25rem;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
    initOTP();
    startResendTimer();
});

function initOTP() {
    const inputs = document.querySelectorAll('.mineless-otp-box');
    const fullInput = document.getElementById('otp-full');
    const form = document.getElementById('tfa-form');
    
    inputs.forEach((input, index) => {
        // Handle input
        input.addEventListener('input', (e) => {
            const value = e.target.value;
            
            // Only allow numbers
            if (!/^\d*$/.test(value)) {
                e.target.value = '';
                return;
            }
            
            // Update filled state
            input.classList.toggle('filled', value !== '');
            
            // Auto-advance
            if (value.length === 1) {
                if (index < inputs.length - 1) {
                    inputs[index + 1].focus();
                } else {
                    // Last input - combine and submit
                    combineOTP();
                    // Optional: auto-submit
                    // setTimeout(() => form.submit(), 200);
                }
            }
        });
        
        // Handle backspace
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Backspace' && input.value === '' && index > 0) {
                inputs[index - 1].focus();
            }
        });
        
        // Handle paste
        input.addEventListener('paste', (e) => {
            e.preventDefault();
            const pasteData = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
            
            pasteData.split('').forEach((char, i) => {
                if (inputs[i]) {
                    inputs[i].value = char;
                    inputs[i].classList.add('filled');
                }
            });
            
            combineOTP();
            
            // Focus next empty or last
            const nextEmpty = Array.from(inputs).find(inp => inp.value === '');
            if (nextEmpty) {
                nextEmpty.focus();
            } else {
                inputs[inputs.length - 1].focus();
            }
        });
    });
    
    function combineOTP() {
        let code = '';
        inputs.forEach(inp => code += inp.value);
        fullInput.value = code;
    }
}

function showRecovery() {
    const section = document.getElementById('recovery-section');
    const link = document.querySelector('.mineless-recovery-link');
    
    section.style.display = section.style.display === 'none' ? 'block' : 'none';
    link.innerHTML = section.style.display === 'none' 
        ? '<i class="fas fa-key"></i> Gunakan Kode Recovery'
        : '<i class="fas fa-shield-alt"></i> Gunakan OTP';
}

function startResendTimer() {
    let seconds = 30;
    const timer = document.getElementById('resend-timer');
    const btn = document.getElementById('resend-btn');
    
    btn.style.display = 'none';
    
    const interval = setInterval(() => {
        timer.textContent = `Kode baru dalam ${seconds} detik`;
        seconds--;
        
        if (seconds < 0) {
            clearInterval(interval);
            timer.style.display = 'none';
            btn.style.display = 'inline';
            btn.disabled = false;
        }
    }, 1000);
}

function resendCode() {
    // AJAX call to resend TFA code
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'token={$TOKEN}&resend=1'
    }).then(() => {
        location.reload();
    });
}

// Success animation
{if isset($SUCCESS)}
document.addEventListener('DOMContentLoaded', () => {
    const shield = document.getElementById('security-shield');
    shield.classList.add('success');
    
    // Create sparkle effect
    for (let i = 0; i < 20; i++) {
        setTimeout(() => createSparkle(), i * 50);
    }
});

function createSparkle() {
    const shield = document.getElementById('security-shield');
    const rect = shield.getBoundingClientRect();
    const sparkle = document.createElement('div');
    
    sparkle.style.cssText = `
        position: fixed;
        width: 10px;
        height: 10px;
        background: #D4AF37;
        border-radius: 50%;
        left: ${rect.left + rect.width / 2 + (Math.random() - 0.5) * 150}px;
        top: ${rect.top + rect.height / 2 + (Math.random() - 0.5) * 150}px;
        pointer-events: none;
        animation: sparkleFly 1s ease-out forwards;
    `;
    
    document.body.appendChild(sparkle);
    setTimeout(() => sparkle.remove(), 1000);
}
{/if}
</script>

{include file='footer.tpl'}