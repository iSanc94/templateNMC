<?php
/**
 * Mineless Template Settings
 * NamelessMC Template Configuration
 */

// Prevent direct access
if (!defined('NAMELESSMC')) {
    die();
}

// Handle form submission
if (Input::exists()) {
    if (Token::check()) {
        // Validate and save settings
        $settings_to_save = array(
            'accent_color' => Input::get('accent_color'),
            'server_ip' => Input::get('server_ip'),
            'server_port' => Input::get('server_port'),
            'typed_strings' => Input::get('typed_strings'),
            'particles_enabled' => Input::get('particles_enabled') === 'on' ? '1' : '0',
            'parallax_enabled' => Input::get('parallax_enabled') === 'on' ? '1' : '0',
            'dark_mode_default' => Input::get('dark_mode_default') === 'on' ? '1' : '0',
            'discord_invite' => Input::get('discord_invite'),
            'hero_title' => Input::get('hero_title'),
            'hero_subtitle' => Input::get('hero_subtitle'),
            'footer_tagline' => Input::get('footer_tagline'),
            'hero_bg_url' => Input::get('hero_bg_url'),
            'custom_css' => Input::get('custom_css'),
        );

        foreach ($settings_to_save as $key => $value) {
            $exists = DB::getInstance()->query(
                'SELECT id FROM nl2_template_settings WHERE template = ? AND setting = ?',
                array($template->getName(), $key)
            )->count();

            if ($exists) {
                DB::getInstance()->query(
                    'UPDATE nl2_template_settings SET value = ? WHERE template = ? AND setting = ?',
                    array($value, $template->getName(), $key)
                );
            } else {
                DB::getInstance()->query(
                    'INSERT INTO nl2_template_settings (template, setting, value) VALUES (?, ?, ?)',
                    array($template->getName(), $key, $value)
                );
            }
        }

        // Clear cache
        $cache->setCache('mineless_template_cache');
        $cache->eraseAll();

        Session::flash('admin_template_settings_success', $language->get('admin', 'successfully_updated'));
        Redirect::to(URL::build('/panel/core/templates/', 'action=settings&template=' . $template->getName()));
    } else {
        Session::flash('admin_template_settings_error', $language->get('general', 'invalid_token'));
    }
}

// Load current settings from cache or database
$cache->setCache('mineless_template_cache');
$settings = $cache->retrieve('template_settings');

if (!$settings) {
    $settings_data = DB::getInstance()->query(
        'SELECT setting, value FROM nl2_template_settings WHERE template = ?',
        array($template->getName())
    )->results();

    $settings = array();
    foreach ($settings_data as $item) {
        $settings[$item->setting] = $item->value;
    }

    // Set defaults if not exists
    $defaults = array(
        'accent_color' => '#D4AF37',
        'server_port' => '25565',
        'typed_strings' => 'Survival|Factions|Skyblock|Creative|PvP',
        'particles_enabled' => '1',
        'parallax_enabled' => '1',
        'dark_mode_default' => '1',
        'hero_title' => 'Welcome Adventurer',
        'hero_subtitle' => 'Premium Minecraft Server',
        'footer_tagline' => 'Forge Your Legend',
    );

    foreach ($defaults as $key => $value) {
        if (!isset($settings[$key]) || empty($settings[$key])) {
            $settings[$key] = $value;
        }
    }

    $cache->store('template_settings', $settings);
}

// Helper function for PHP < 7.0 compatibility
function mineless_get($array, $key, $default = '') {
    return isset($array[$key]) ? $array[$key] : $default;
}

// Assign variables to template for admin panel form
$smarty->assign(array(
    'TOKEN' => Token::get(),
    'SUBMIT' => $language->get('general', 'submit'),
    'ENABLED' => $language->get('admin', 'enabled'),
    'DISABLED' => $language->get('admin', 'disabled'),
    'SETTINGS_TEMPLATE' => ROOT_PATH . '/custom/templates/Mineless/template_settings/settings.tpl',
    
    // Accent Color
    'ACCENT_COLOR_LABEL' => 'Accent Color',
    'ACCENT_COLOR_VALUE' => Output::getClean(mineless_get($settings, 'accent_color', '#D4AF37')),
    
    // Server Settings
    'SERVER_IP_LABEL' => 'Server IP',
    'SERVER_IP_VALUE' => Output::getClean(mineless_get($settings, 'server_ip', '')),
    'SERVER_PORT_LABEL' => 'Server Port',
    'SERVER_PORT_VALUE' => Output::getClean(mineless_get($settings, 'server_port', '25565')),
    
    // Typed Strings
    'TYPED_STRINGS_LABEL' => 'Typed Strings',
    'TYPED_STRINGS_HELP' => 'Separate with | symbol',
    'TYPED_STRINGS_VALUE' => Output::getClean(mineless_get($settings, 'typed_strings', 'Survival|Factions|Skyblock|Creative|PvP')),
    
    // Toggles
    'PARTICLES_ENABLED_LABEL' => 'Enable Particles',
    'PARTICLES_ENABLED_VALUE' => mineless_get($settings, 'particles_enabled') === '1',
    'PARALLAX_ENABLED_LABEL' => 'Enable Parallax',
    'PARALLAX_ENABLED_VALUE' => mineless_get($settings, 'parallax_enabled') === '1',
    'DARK_MODE_DEFAULT_LABEL' => 'Dark Mode Default',
    'DARK_MODE_DEFAULT_VALUE' => mineless_get($settings, 'dark_mode_default') === '1',
    
    // Social & Content
    'DISCORD_INVITE_LABEL' => 'Discord Invite URL',
    'DISCORD_INVITE_VALUE' => Output::getClean(mineless_get($settings, 'discord_invite', '')),
    'HERO_TITLE_LABEL' => 'Hero Title',
    'HERO_TITLE_VALUE' => Output::getClean(mineless_get($settings, 'hero_title', 'Welcome Adventurer')),
    'HERO_SUBTITLE_LABEL' => 'Hero Subtitle',
    'HERO_SUBTITLE_VALUE' => Output::getClean(mineless_get($settings, 'hero_subtitle', 'Server Minecraft Premium')),
    'FOOTER_TAGLINE_LABEL' => 'Footer Tagline',
    'FOOTER_TAGLINE_VALUE' => Output::getClean(mineless_get($settings, 'footer_tagline', 'Forge Your Legend')),
    'HERO_BG_URL_LABEL' => 'Hero Background URL',
    'HERO_BG_URL_HELP' => 'Leave empty for default',
    'HERO_BG_URL_VALUE' => Output::getClean(mineless_get($settings, 'hero_bg_url', '')),
    'CUSTOM_CSS_LABEL' => 'Custom CSS',
    'CUSTOM_CSS_HELP' => 'Add your custom CSS here',
    'CUSTOM_CSS_VALUE' => Output::getClean(mineless_get($settings, 'custom_css', '')),
    
    // Flash messages
    'SUCCESS' => Session::flash('admin_template_settings_success'),
    'ERROR' => Session::flash('admin_template_settings_error'),
));

// Add variables for frontend template usage
$template->addVariables(array(
    'MINELESS_ACCENT_COLOR' => mineless_get($settings, 'accent_color', '#D4AF37'),
    'MINELESS_SERVER_IP' => mineless_get($settings, 'server_ip', ''),
    'MINELESS_SERVER_PORT' => mineless_get($settings, 'server_port', '25565'),
    'MINELESS_TYPED_STRINGS' => mineless_get($settings, 'typed_strings', 'Survival|Factions|Skyblock|Creative|PvP'),
    'MINELESS_PARTICLES_ENABLED' => mineless_get($settings, 'particles_enabled') === '1',
    'MINELESS_PARALLAX_ENABLED' => mineless_get($settings, 'parallax_enabled') === '1',
    'MINELESS_DARK_MODE_DEFAULT' => mineless_get($settings, 'dark_mode_default') === '1',
    'MINELESS_DISCORD_INVITE' => mineless_get($settings, 'discord_invite', ''),
    'MINELESS_HERO_TITLE' => mineless_get($settings, 'hero_title', 'Welcome Adventurer'),
    'MINELESS_HERO_SUBTITLE' => mineless_get($settings, 'hero_subtitle', 'Premium Minecraft Server'),
    'MINELESS_FOOTER_TAGLINE' => mineless_get($settings, 'footer_tagline', 'Forge Your Legend'),
    'MINELESS_HERO_BG_URL' => mineless_get($settings, 'hero_bg_url', ''),
    'MINELESS_CUSTOM_CSS' => mineless_get($settings, 'custom_css', ''),
));
