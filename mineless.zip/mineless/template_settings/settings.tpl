{* Mineless Template Settings Form *}

{if isset($SUCCESS)}
    <div class="alert alert-success adv-alert">{$SUCCESS}</div>
{/if}

{if isset($ERROR)}
    <div class="alert alert-danger adv-alert">{$ERROR}</div>
{/if}

<form method="post" id="mineless-settings-form" class="mineless-form">
    <input type="hidden" name="token" value="{$TOKEN}">
    
    <div class="mineless-settings-grid">
        
        {* Visual Settings *}
        <div class="mineless-card">
            <div class="mineless-card-header">
                <h5 class="mineless-card-title">
                    <i class="fas fa-palette"></i>
                    {$VISUAL_SETTINGS|default:'Visual Settings'}
                </h5>
            </div>
            <div class="mineless-card-body">
                
                {* Accent Color *}
                <div class="mineless-form-group">
                    <label for="accent_color" class="mineless-label">{$ACCENT_COLOR_LABEL}</label>
                    <div class="mineless-color-picker-wrapper">
                        <input type="color" 
                               id="accent_color" 
                               name="accent_color" 
                               class="mineless-color-picker" 
                               value="{$ACCENT_COLOR_VALUE}">
                        <input type="text" 
                               id="accent_color_text" 
                               class="mineless-input adv-color-text" 
                               value="{$ACCENT_COLOR_VALUE}" 
                               maxlength="7">
                        <div class="mineless-color-preview" style="background-color: {$ACCENT_COLOR_VALUE};"></div>
                    </div>
                </div>
                
                {* Dark Mode Default *}
                <div class="mineless-form-group">
                    <label class="mineless-toggle-label">
                        <span class="mineless-label-text">{$DARK_MODE_DEFAULT_LABEL}</span>
                        <div class="mineless-toggle">
                            <input type="checkbox" 
                                   id="dark_mode_default" 
                                   name="dark_mode_default" 
                                   class="mineless-toggle-input" 
                                   {if $DARK_MODE_DEFAULT_VALUE}checked{/if}>
                            <span class="mineless-toggle-slider"></span>
                        </div>
                    </label>
                </div>
                
            </div>
        </div>
        
        {* Server Settings *}
        <div class="mineless-card">
            <div class="mineless-card-header">
                <h5 class="mineless-card-title">
                    <i class="fas fa-server"></i>
                    {$SERVER_SETTINGS|default:'Server Settings'}
                </h5>
            </div>
            <div class="mineless-card-body">
                
                {* Server IP *}
                <div class="mineless-form-group">
                    <label for="server_ip" class="mineless-label">{$SERVER_IP_LABEL}</label>
                    <input type="text" 
                           id="server_ip" 
                           name="server_ip" 
                           class="mineless-input" 
                           value="{$SERVER_IP_VALUE}" 
                           placeholder="play.example.com">
                </div>
                
                {* Server Port *}
                <div class="mineless-form-group">
                    <label for="server_port" class="mineless-label">{$SERVER_PORT_LABEL}</label>
                    <input type="text" 
                           id="server_port" 
                           name="server_port" 
                           class="mineless-input" 
                           value="{$SERVER_PORT_VALUE}" 
                           placeholder="25565">
                </div>
                
            </div>
        </div>
        
        {* Hero Section Settings *}
        <div class="mineless-card">
            <div class="mineless-card-header">
                <h5 class="mineless-card-title">
                    <i class="fas fa-image"></i>
                    {$HERO_SETTINGS|default:'Hero Section'}
                </h5>
            </div>
            <div class="mineless-card-body">
                
                {* Hero Title *}
                <div class="mineless-form-group">
                    <label for="hero_title" class="mineless-label">{$HERO_TITLE_LABEL}</label>
                    <input type="text" 
                           id="hero_title" 
                           name="hero_title" 
                           class="mineless-input" 
                           value="{$HERO_TITLE_VALUE}">
                </div>
                
                {* Hero Subtitle *}
                <div class="mineless-form-group">
                    <label for="hero_subtitle" class="mineless-label">{$HERO_SUBTITLE_LABEL}</label>
                    <input type="text" 
                           id="hero_subtitle" 
                           name="hero_subtitle" 
                           class="mineless-input" 
                           value="{$HERO_SUBTITLE_VALUE}">
                </div>
                
                {* Typed Strings *}
                <div class="mineless-form-group">
                    <label for="typed_strings" class="mineless-label">{$TYPED_STRINGS_LABEL}</label>
                    <input type="text" 
                           id="typed_strings" 
                           name="typed_strings" 
                           class="mineless-input" 
                           value="{$TYPED_STRINGS_VALUE}">
                    <small class="mineless-help-text">{$TYPED_STRINGS_HELP|default:'Separate with pipe (|)'}</small>
                </div>
                
                {* Hero Background URL *}
                <div class="mineless-form-group">
                    <label for="hero_bg_url" class="mineless-label">{$HERO_BG_URL_LABEL}</label>
                    <input type="text" 
                           id="hero_bg_url" 
                           name="hero_bg_url" 
                           class="mineless-input" 
                           value="{$HERO_BG_URL_VALUE}" 
                           placeholder="https://example.com/image.jpg">
                    <small class="mineless-help-text">{$HERO_BG_URL_HELP|default:'Leave empty for default background'}</small>
                </div>
                
            </div>
        </div>
        
        {* Effect Settings *}
        <div class="mineless-card">
            <div class="mineless-card-header">
                <h5 class="mineless-card-title">
                    <i class="fas fa-magic"></i>
                    {$EFFECT_SETTINGS|default:'Effect Settings'}
                </h5>
            </div>
            <div class="mineless-card-body">
                
                {* Particles Enabled *}
                <div class="mineless-form-group">
                    <label class="mineless-toggle-label">
                        <span class="mineless-label-text">{$PARTICLES_ENABLED_LABEL}</span>
                        <div class="mineless-toggle">
                            <input type="checkbox" 
                                   id="particles_enabled" 
                                   name="particles_enabled" 
                                   class="mineless-toggle-input" 
                                   {if $PARTICLES_ENABLED_VALUE}checked{/if}>
                            <span class="mineless-toggle-slider"></span>
                        </div>
                    </label>
                </div>
                
                {* Parallax Enabled *}
                <div class="mineless-form-group">
                    <label class="mineless-toggle-label">
                        <span class="mineless-label-text">{$PARALLAX_ENABLED_LABEL}</span>
                        <div class="mineless-toggle">
                            <input type="checkbox" 
                                   id="parallax_enabled" 
                                   name="parallax_enabled" 
                                   class="mineless-toggle-input" 
                                   {if $PARALLAX_ENABLED_VALUE}checked{/if}>
                            <span class="mineless-toggle-slider"></span>
                        </div>
                    </label>
                </div>
                
            </div>
        </div>
        
        {* Social Settings *}
        <div class="mineless-card">
            <div class="mineless-card-header">
                <h5 class="mineless-card-title">
                    <i class="fab fa-discord"></i>
                    {$SOCIAL_SETTINGS|default:'Social Settings'}
                </h5>
            </div>
            <div class="mineless-card-body">
                
                {* Discord Invite *}
                <div class="mineless-form-group">
                    <label for="discord_invite" class="mineless-label">{$DISCORD_INVITE_LABEL}</label>
                    <input type="text" 
                           id="discord_invite" 
                           name="discord_invite" 
                           class="mineless-input" 
                           value="{$DISCORD_INVITE_VALUE}" 
                           placeholder="https://discord.gg/invite">
                </div>
                
            </div>
        </div>
        
        {* Footer Settings *}
        <div class="mineless-card">
            <div class="mineless-card-header">
                <h5 class="mineless-card-title">
                    <i class="fas fa-shoe-prints"></i>
                    {$FOOTER_SETTINGS|default:'Footer Settings'}
                </h5>
            </div>
            <div class="mineless-card-body">
                
                {* Footer Tagline *}
                <div class="mineless-form-group">
                    <label for="footer_tagline" class="mineless-label">{$FOOTER_TAGLINE_LABEL}</label>
                    <input type="text" 
                           id="footer_tagline" 
                           name="footer_tagline" 
                           class="mineless-input" 
                           value="{$FOOTER_TAGLINE_VALUE}">
                </div>
                
            </div>
        </div>
        
        {* Custom CSS *}
        <div class="mineless-card adv-card-full">
            <div class="mineless-card-header">
                <h5 class="mineless-card-title">
                    <i class="fas fa-code"></i>
                    {$CUSTOM_CSS_LABEL}
                </h5>
            </div>
            <div class="mineless-card-body">
                
                <div class="mineless-form-group">
                    <textarea id="custom_css" 
                              name="custom_css" 
                              class="mineless-textarea adv-code-textarea" 
                              rows="10" 
                              placeholder="/* Custom CSS */&#10;">{$CUSTOM_CSS_VALUE}</textarea>
                    <small class="mineless-help-text">{$CUSTOM_CSS_HELP|default:'Add custom CSS styles here'}</small>
                </div>
                
            </div>
        </div>
        
    </div>
    
    {* Submit Button *}
    <div class="mineless-form-actions">
        <button type="submit" class="mineless-btn adv-btn-primary" id="mineless-submit-btn">
            <span class="mineless-btn-text">{$SUBMIT}</span>
            <span class="mineless-btn-loader" style="display: none;">
                <i class="fas fa-spinner fa-spin"></i>
            </span>
        </button>
    </div>
    
</form>

<script>
{literal}
document.addEventListener('DOMContentLoaded', function() {
    
    // Color picker sync
    const colorPicker = document.getElementById('accent_color');
    const colorText = document.getElementById('accent_color_text');
    const colorPreview = document.querySelector('.mineless-color-preview');
    
    if (colorPicker && colorText) {
        colorPicker.addEventListener('input', function() {
            colorText.value = this.value;
            if (colorPreview) {
                colorPreview.style.backgroundColor = this.value;
            }
        });
        
        colorText.addEventListener('input', function() {
            if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                colorPicker.value = this.value;
                if (colorPreview) {
                    colorPreview.style.backgroundColor = this.value;
                }
            }
        });
    }
    
    // Form submission with loading state
    const form = document.getElementById('adv-settings-form');
    const submitBtn = document.getElementById('adv-submit-btn');
    const btnText = submitBtn.querySelector('.mineless-btn-text');
    const btnLoader = submitBtn.querySelector('.mineless-btn-loader');
    
    if (form && submitBtn) {
        form.addEventListener('submit', function() {
            submitBtn.disabled = true;
            btnText.style.display = 'none';
            btnLoader.style.display = 'inline-block';
        });
    }
    
});
{/literal}
</script>
