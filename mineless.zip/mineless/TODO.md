# Mineless Template - TODO List

## Priority: HIGH 🔴

### Testing & Verification
- [ ] Test Home page (index.tpl) on all screen sizes
- [ ] Test Forum page (forum_index.tpl) on all screen sizes
- [ ] Test Topic view page (view_topic.tpl)
- [ ] Test User profile page (profile.tpl)
- [ ] Test User settings page (settings.tpl)
- [ ] Test Login page (login.tpl)
- [ ] Test Register page (register.tpl)
- [ ] Test Portal page (portal.tpl)

### Critical Features
- [ ] Verify particles.js animation is working
- [ ] Verify Typed.js animation is working
- [ ] Test dark/light mode toggle
- [ ] Test all dropdown menus
- [ ] Test mobile sidebar menu
- [ ] Test server status widget

---

## Priority: MEDIUM 🟡

### Content & Assets
- [ ] Upload actual logo to `/uploads/logos/logo.png`
- [ ] Upload footer logo to `/uploads/logos/footer-logo.png`
- [ ] Create favicon
- [ ] Upload OG image for social media
- [ ] Replace placeholder news images

### Configuration
- [ ] Configure template settings in Admin Panel
- [ ] Set server IP address
- [ ] Set server query settings
- [ ] Configure social media links
- [ ] Set up analytics ID

### Translations (Remaining)
- [ ] Check for any remaining Indonesian text
- [ ] Verify all default values are in English
- [ ] Test with different language packs

---

## Priority: LOW 🟢

### Optimization
- [ ] Minify CSS files (custom.css, mineless.css)
- [ ] Optimize images (compress PNG/SVG)
- [ ] Enable gzip compression on server
- [ ] Add lazy loading to images
- [ ] Optimize FontAwesome (subset only used icons)

### Enhancements
- [ ] Add more particle effects
- [ ] Add more animations (GSAP)
- [ ] Add loading skeletons
- [ ] Add toast notifications
- [ ] Improve accessibility (ARIA labels)

### Documentation
- [ ] Create user documentation
- [ ] Create admin setup guide
- [ ] Document customization options
- [ ] Create troubleshooting guide

---

## Bugs to Fix 🐛

### Known Issues
- [ ] **Issue**: Footer layout may break on very small screens (<320px)
  - **Fix**: Add extra media query in emergency-fix.css

- [ ] **Issue**: Forum search placeholder may still show Indonesian
  - **Fix**: Check forum_index.tpl line 22

- [ ] **Issue**: Online users widget shows "Total Online online" (duplicate)
  - **Fix**: Check widget translation string

- [ ] **Issue**: Theme toggle may not persist
  - **Fix**: Check dark/light mode form submission

---

## Feature Requests ✨

### Potential Additions
- [ ] Add live chat widget
- [ ] Add server map integration
- [ ] Add donation/store integration
- [ ] Add Discord widget
- [ ] Add voting sites list
- [ ] Add server rules page
- [ ] Add staff team page
- [ ] Add gallery/screenshots section

---

## File Checklist 📁

### Core Files (Must Work)
- [x] template.php
- [x] info.json
- [x] header.tpl
- [x] navbar.tpl
- [x] footer.tpl
- [x] index.tpl

### Auth Files
- [x] login.tpl
- [x] register.tpl
- [x] forgot_password.tpl
- [x] change_password.tpl
- [x] tfa.tpl

### User Files
- [x] profile.tpl
- [x] user/settings.tpl
- [x] user/alerts.tpl
- [x] user/messaging.tpl
- [x] user/index.tpl
- [x] user/view_message.tpl

### Forum Files
- [x] forum/forum_index.tpl
- [x] forum/view_forum.tpl
- [x] forum/view_topic.tpl
- [x] forum/new_topic.tpl
- [x] forum/merge.tpl
- [x] forum/move.tpl
- [x] forum/search.tpl
- [x] forum/search_results.tpl
- [x] forum/following_topics.tpl
- [x] forum/profile_tab.tpl
- [x] forum/forum_edit_post.tpl

### Other Pages
- [x] portal.tpl
- [x] status.tpl
- [x] leaderboards.tpl
- [x] 404.tpl
- [x] 403.tpl

### Widgets
- [x] widgets/online_users.tpl
- [x] widgets/statistics.tpl
- [x] widgets/latest_posts.tpl
- [x] widgets/server_status.tpl
- [x] widgets/forum/latest_posts.tpl

---

## CSS Class Audit 🎨

### Classes to Verify
- [ ] `.mineless-navbar` - Fixed navbar
- [ ] `.mineless-hero` - Hero section
- [ ] `.mineless-btn--primary` - Primary buttons
- [ ] `.mineless-btn--outline` - Outline buttons
- [ ] `.mineless-card` - Card components
- [ ] `.mineless-section` - Section containers
- [ ] `.mineless-footer` - Footer section
- [ ] `.mineless-widget` - Widget containers

### Old Classes to Remove (if found)
- [ ] `.adv-btn-primary` → `.mineless-btn--primary`
- [ ] `.adv-btn-outline` → `.mineless-btn--outline`
- [ ] `.adv-card` → `.mineless-card`
- [ ] `.adv-hero` → `.mineless-hero`

---

## Testing Checklist ✅

### Browser Testing
- [ ] Chrome / Edge (Chromium)
- [ ] Firefox
- [ ] Safari (if available)
- [ ] Mobile Chrome (Android)
- [ ] Mobile Safari (iOS)

### Screen Sizes
- [ ] 320px (Small mobile)
- [ ] 375px (iPhone X)
- [ ] 768px (Tablet)
- [ ] 1024px (Small laptop)
- [ ] 1440px (Desktop)
- [ ] 1920px (Large desktop)

### Functionality
- [ ] All links work
- [ ] All forms submit correctly
- [ ] All buttons are clickable
- [ ] Dropdowns open/close
- [ ] Mobile menu opens/closes
- [ ] Scroll to top works

---

## Notes 📝

### Important Reminders
1. Always clear cache after making changes: `/cache/templates_c/`
2. Test on mobile before deploying
3. Backup database before major updates
4. Keep original files as backup

### Resources
- NamelessMC Docs: https://docs.namelessmc.com/
- Smarty Docs: https://www.smarty.net/docs/
- FontAwesome Icons: https://fontawesome.com/icons

---

*Created: 2026-03-26*
*Last Updated: 2026-03-26*
