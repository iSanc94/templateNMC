/**
 * Mineless Theme - User JavaScript
 * NamelessMC Template
 * ES6+ Vanilla JavaScript
 */

(function () {
    'use strict';

    // ============================================
    // Configuration
    // ============================================
    const CONFIG = {
        POPOVER_DELAY: 300,           // Delay before showing popover
        POPOVER_HIDE_DELAY: 200,      // Delay before hiding popover
        PREVIEW_CACHE_TIME: 60000,    // Cache preview data for 60 seconds
        FETCH_TIMEOUT: 5000           // 5 second fetch timeout
    };

    // ============================================
    // Utility Functions
    // ============================================
    const Utils = {
        /**
         * Debounce function
         */
        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },

        /**
         * Check if prefers reduced motion
         */
        prefersReducedMotion() {
            return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        },

        /**
         * Fetch with timeout
         */
        async fetchWithTimeout(url, options = {}) {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), CONFIG.FETCH_TIMEOUT);

            try {
                const response = await fetch(url, {
                    ...options,
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                return response;
            } catch (error) {
                clearTimeout(timeoutId);
                throw error;
            }
        }
    };

    // ============================================
    // User Popover Manager
    // ============================================
    const UserPopoverManager = {
        popover: null,
        activeLink: null,
        showTimeout: null,
        hideTimeout: null,
        cache: new Map(),

        init() {
            // Create popover element
            this.createPopoverElement();

            // Attach event listeners to username links
            this.attachListeners();
        },

        createPopoverElement() {
            this.popover = document.createElement('div');
            this.popover.className = 'user-popover';
            this.popover.setAttribute('role', 'tooltip');
            this.popover.style.cssText = `
                position: absolute;
                z-index: 1000;
                display: none;
                opacity: 0;
                transition: opacity 0.2s ease, transform 0.2s ease;
                pointer-events: none;
            `;
            document.body.appendChild(this.popover);
        },

        attachListeners() {
            document.addEventListener('mouseover', (e) => {
                const link = e.target.closest('.username-link, [data-user-preview]');
                if (!link) return;

                this.handleMouseEnter(link);
            });

            document.addEventListener('mouseout', (e) => {
                const link = e.target.closest('.username-link, [data-user-preview]');
                if (!link) return;

                this.handleMouseLeave(link);
            });
        },

        handleMouseEnter(link) {
            clearTimeout(this.hideTimeout);
            this.activeLink = link;

            this.showTimeout = setTimeout(async () => {
                const userId = link.dataset.userId || link.dataset.user;
                if (!userId) return;

                await this.showPopover(link, userId);
            }, CONFIG.POPOVER_DELAY);
        },

        handleMouseLeave(link) {
            clearTimeout(this.showTimeout);

            this.hideTimeout = setTimeout(() => {
                if (!this.popover.matches(':hover')) {
                    this.hidePopover();
                }
            }, CONFIG.POPOVER_HIDE_DELAY);
        },

        async showPopover(link, userId) {
            // Check cache
            const cached = this.cache.get(userId);
            if (cached && Date.now() - cached.timestamp < CONFIG.PREVIEW_CACHE_TIME) {
                this.renderPopover(cached.data, link);
                return;
            }

            // Show loading state
            this.popover.innerHTML = `
                <div class="popover-loading">
                    <div class="spinner"></div>
                    <span>Loading...</span>
                </div>
            `;
            this.positionPopover(link);

            try {
                const response = await Utils.fetchWithTimeout(`/api/user/${userId}/preview`, {
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                if (!response.ok) throw new Error('Failed to fetch user preview');

                const data = await response.json();

                // Cache result
                this.cache.set(userId, { data, timestamp: Date.now() });

                // Only render if still hovering the same link
                if (this.activeLink === link) {
                    this.renderPopover(data, link);
                }

            } catch (error) {
                console.warn('User preview fetch failed:', error);
                this.hidePopover();
            }
        },

        renderPopover(data, link) {
            this.popover.innerHTML = `
                <div class="popover-content">
                    <div class="popover-header">
                        <img src="${data.avatar}" alt="${data.username}" class="popover-avatar">
                        <div class="popover-info">
                            <div class="popover-username">
                                ${data.username}
                                ${data.is_staff ? '<span class="staff-badge">Staff</span>' : ''}
                                ${data.is_premium ? '<span class="premium-badge">Premium</span>' : ''}
                            </div>
                            <div class="popover-rank">${data.rank || 'Member'}</div>
                        </div>
                    </div>
                    <div class="popover-stats">
                        <div class="stat">
                            <span class="stat-value">${data.posts || 0}</span>
                            <span class="stat-label">Posts</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value">${data.reputation || 0}</span>
                            <span class="stat-label">Rep</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value">${this.formatJoinDate(data.joined)}</span>
                            <span class="stat-label">Joined</span>
                        </div>
                    </div>
                    ${data.bio ? `<div class="popover-bio">${this.truncateText(data.bio, 100)}</div>` : ''}
                    <div class="popover-actions">
                        <a href="/profile/${data.username}" class="btn btn-sm">View Profile</a>
                        <button class="btn btn-sm btn-outline" data-message-user="${data.id}">Message</button>
                    </div>
                </div>
            `;

            // Add hover listener to popover itself
            this.popover.addEventListener('mouseenter', () => {
                clearTimeout(this.hideTimeout);
            });

            this.popover.addEventListener('mouseleave', () => {
                this.hidePopover();
            });

            this.positionPopover(link);
        },

        positionPopover(link) {
            const linkRect = link.getBoundingClientRect();
            const popoverRect = this.popover.getBoundingClientRect();
            const viewportWidth = window.innerWidth;
            const viewportHeight = window.innerHeight;

            // Default position: below the link, centered
            let top = linkRect.bottom + window.scrollY + 8;
            let left = linkRect.left + window.scrollX + (linkRect.width / 2) - (popoverRect.width / 2);

            // Check if popover goes off right edge
            if (left + popoverRect.width > viewportWidth - 16) {
                left = viewportWidth - popoverRect.width - 16;
            }

            // Check if popover goes off left edge
            if (left < 16) {
                left = 16;
            }

            // Check if popover goes off bottom - flip to top
            if (top + popoverRect.height > viewportHeight + window.scrollY - 16) {
                top = linkRect.top + window.scrollY - popoverRect.height - 8;
                this.popover.classList.add('popover-flipped');
            } else {
                this.popover.classList.remove('popover-flipped');
            }

            this.popover.style.top = `${top}px`;
            this.popover.style.left = `${left}px`;
            this.popover.style.display = 'block';

            // Animate in
            requestAnimationFrame(() => {
                this.popover.style.opacity = '1';
                this.popover.style.transform = 'translateY(0)';
                this.popover.style.pointerEvents = 'auto';
            });
        },

        hidePopover() {
            this.popover.style.opacity = '0';
            this.popover.style.transform = 'translateY(10px)';
            this.popover.style.pointerEvents = 'none';

            setTimeout(() => {
                this.popover.style.display = 'none';
                this.activeLink = null;
            }, 200);
        },

        formatJoinDate(timestamp) {
            const date = new Date(timestamp);
            const now = new Date();
            const diffMonths = (now - date) / (1000 * 60 * 60 * 24 * 30);

            if (diffMonths < 1) return 'This month';
            if (diffMonths < 12) return `${Math.floor(diffMonths)}mo ago`;
            return `${Math.floor(diffMonths / 12)}y ago`;
        },

        truncateText(text, maxLength) {
            if (text.length <= maxLength) return text;
            return text.substring(0, maxLength).trim() + '...';
        }
    };

    // ============================================
    // Alert Manager
    // ============================================
    const AlertManager = {
        init() {
            this.initMarkAsRead();
            this.initMessageCount();
        },

        initMarkAsRead() {
            document.querySelectorAll('.alert-mark-read, [data-alert-read]').forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    const alertId = btn.dataset.alertId;
                    if (!alertId) return;

                    // Optimistic UI update
                    const alertItem = btn.closest('.alert-item, [data-alert]');
                    if (alertItem) {
                        alertItem.classList.remove('is-unread');
                        alertItem.classList.add('is-read');
                    }

                    try {
                        const response = await fetch(`/api/alerts/${alertId}/read`, {
                            method: 'POST',
                            headers: {
                                'Accept': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });

                        if (!response.ok) throw new Error('Failed to mark as read');

                        // Update badge count
                        this.updateUnreadCount(-1);

                    } catch (error) {
                        console.error('Mark as read failed:', error);
                        // Revert UI on error
                        if (alertItem) {
                            alertItem.classList.add('is-unread');
                            alertItem.classList.remove('is-read');
                        }
                    }
                });
            });

            // Mark all as read
            const markAllBtn = document.querySelector('.alerts-mark-all, [data-mark-all-read]');
            if (markAllBtn) {
                markAllBtn.addEventListener('click', async (e) => {
                    e.preventDefault();

                    try {
                        const response = await fetch('/api/alerts/read-all', {
                            method: 'POST',
                            headers: {
                                'Accept': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });

                        if (!response.ok) throw new Error('Failed to mark all as read');

                        // Update all UI
                        document.querySelectorAll('.alert-item.is-unread, [data-alert].is-unread').forEach(item => {
                            item.classList.remove('is-unread');
                            item.classList.add('is-read');
                        });

                        this.updateUnreadCount(0, true);

                    } catch (error) {
                        console.error('Mark all as read failed:', error);
                    }
                });
            }
        },

        initMessageCount() {
            this.updateMessageBadge();
        },

        updateUnreadCount(change, setToZero = false) {
            const badge = document.querySelector('.alerts-badge, [data-alerts-count]');
            if (!badge) return;

            let current = parseInt(badge.textContent, 10) || 0;
            let newCount = setToZero ? 0 : Math.max(0, current + change);

            badge.textContent = newCount > 99 ? '99+' : newCount;
            badge.classList.toggle('has-alerts', newCount > 0);
            badge.style.display = newCount > 0 ? 'flex' : 'none';
        },

        updateMessageBadge() {
            const badge = document.querySelector('.messages-badge, [data-messages-count]');
            if (!badge) return;

            // Initial fetch for message count
            this.fetchMessageCount();

            // Poll every 30 seconds
            setInterval(() => this.fetchMessageCount(), 30000);
        },

        async fetchMessageCount() {
            try {
                const response = await Utils.fetchWithTimeout('/api/messages/unread', {
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                if (!response.ok) return;

                const data = await response.json();
                this.renderMessageBadge(data.count);

            } catch (error) {
                console.warn('Message count fetch failed:', error);
            }
        },

        renderMessageBadge(count) {
            const badges = document.querySelectorAll('.messages-badge, [data-messages-count]');

            badges.forEach(badge => {
                badge.textContent = count > 99 ? '99+' : count;
                badge.classList.toggle('has-messages', count > 0);
                badge.style.display = count > 0 ? 'flex' : 'none';

                // Pulse on new message
                const currentCount = parseInt(badge.dataset.lastCount, 10) || 0;
                if (count > currentCount && currentCount > 0) {
                    badge.classList.add('is-pulse');
                    setTimeout(() => badge.classList.remove('is-pulse'), 1000);
                }
                badge.dataset.lastCount = count;
            });
        }
    };

    // ============================================
    // Avatar Upload Manager
    // ============================================
    const AvatarUploadManager = {
        init() {
            const input = document.querySelector('#avatar-upload, [data-avatar-upload]');
            if (!input) return;

            const preview = document.querySelector('#avatar-preview, [data-avatar-preview]');

            input.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (!file) return;

                // Validate file type
                if (!file.type.startsWith('image/')) {
                    alert('Please select an image file.');
                    input.value = '';
                    return;
                }

                // Validate file size (max 5MB)
                if (file.size > 5 * 1024 * 1024) {
                    alert('File size must be less than 5MB.');
                    input.value = '';
                    return;
                }

                // Preview image
                if (preview) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                        preview.src = event.target.result;
                        preview.classList.add('has-preview');
                    };
                    reader.readAsDataURL(file);
                }

                // Optional: Auto-submit form
                const form = input.closest('form');
                if (form && form.dataset.autoSubmit === 'true') {
                    form.submit();
                }
            });

            // Drag and drop support
            const dropZone = document.querySelector('.avatar-dropzone, [data-avatar-dropzone]');
            if (dropZone) {
                this.initDragDrop(dropZone, input);
            }
        },

        initDragDrop(dropZone, input) {
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                dropZone.addEventListener(eventName, (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                });
            });

            ['dragenter', 'dragover'].forEach(eventName => {
                dropZone.addEventListener(eventName, () => {
                    dropZone.classList.add('is-dragover');
                });
            });

            ['dragleave', 'drop'].forEach(eventName => {
                dropZone.addEventListener(eventName, () => {
                    dropZone.classList.remove('is-dragover');
                });
            });

            dropZone.addEventListener('drop', (e) => {
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    input.files = files;
                    input.dispatchEvent(new Event('change'));
                }
            });
        }
    };

    // ============================================
    // Session Timeout Warning Modal
    // ============================================
    const SessionTimeoutModal = {
        modal: null,
        countdownInterval: null,

        init() {
            this.modal = document.getElementById('session-timeout-modal');
            if (!this.modal) return;

            const extendBtn = this.modal.querySelector('[data-extend-session]');
            const logoutBtn = this.modal.querySelector('[data-logout]');

            if (extendBtn) {
                extendBtn.addEventListener('click', () => this.extendSession());
            }

            if (logoutBtn) {
                logoutBtn.addEventListener('click', () => {
                    window.location.href = '/logout';
                });
            }

            // Listen for session warning event
            document.addEventListener('sessionWarning', (e) => {
                this.show(e.detail?.expiresIn || 600);
            });
        },

        show(secondsRemaining) {
            if (!this.modal) return;

            this.modal.classList.add('is-active');
            this.modal.style.display = 'flex';

            // Start countdown
            let remaining = secondsRemaining;
            const countdownEl = this.modal.querySelector('.countdown');

            this.countdownInterval = setInterval(() => {
                remaining--;

                if (countdownEl) {
                    const minutes = Math.floor(remaining / 60);
                    const seconds = remaining % 60;
                    countdownEl.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
                }

                if (remaining <= 0) {
                    clearInterval(this.countdownInterval);
                    window.location.href = '/logout?timeout=1';
                }
            }, 1000);
        },

        hide() {
            if (!this.modal) return;

            this.modal.classList.remove('is-active');
            this.modal.style.display = 'none';

            if (this.countdownInterval) {
                clearInterval(this.countdownInterval);
            }
        },

        async extendSession() {
            try {
                const response = await fetch('/api/session/extend', {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                if (response.ok) {
                    this.hide();
                } else {
                    throw new Error('Failed to extend session');
                }
            } catch (error) {
                console.error('Session extension failed:', error);
                alert('Failed to extend session. Please save your work and refresh.');
            }
        }
    };

    // ============================================
    // User Menu Dropdown
    // ============================================
    const UserMenuManager = {
        init() {
            const toggle = document.querySelector('.user-menu-toggle, [data-user-menu]');
            if (!toggle) return;

            const menu = document.querySelector('.user-menu-dropdown, [data-user-dropdown]');
            if (!menu) return;

            toggle.addEventListener('click', (e) => {
                e.preventDefault();
                const isOpen = menu.classList.toggle('is-open');
                toggle.classList.toggle('is-active', isOpen);
                toggle.setAttribute('aria-expanded', isOpen);
            });

            // Close on outside click
            document.addEventListener('click', (e) => {
                if (!toggle.contains(e.target) && !menu.contains(e.target)) {
                    menu.classList.remove('is-open');
                    toggle.classList.remove('is-active');
                    toggle.setAttribute('aria-expanded', 'false');
                }
            });

            // Close on escape
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && menu.classList.contains('is-open')) {
                    menu.classList.remove('is-open');
                    toggle.classList.remove('is-active');
                    toggle.setAttribute('aria-expanded', 'false');
                }
            });
        }
    };

    // ============================================
    // Initialize All Modules
    // ============================================
    function init() {
        UserPopoverManager.init();
        AlertManager.init();
        AvatarUploadManager.init();
        SessionTimeoutModal.init();
        UserMenuManager.init();
    }

    // Start when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Expose modules globally
    window.MinelessUser = {
        UserPopoverManager,
        AlertManager,
        AvatarUploadManager,
        SessionTimeoutModal,
        UserMenuManager
    };
})();
