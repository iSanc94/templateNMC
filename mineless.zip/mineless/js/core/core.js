/**
 * Mineless Theme - Core JavaScript
 * NamelessMC Template
 * ES6+ Vanilla JavaScript
 */

(function () {
    'use strict';

    // ============================================
    // Utility Functions
    // ============================================
    const Utils = {
        /**
         * Check if user prefers reduced motion
         */
        prefersReducedMotion: () => window.matchMedia('(prefers-reduced-motion: reduce)').matches,

        /**
         * Throttle function execution
         */
        throttle: (func, limit) => {
            let inThrottle;
            return function (...args) {
                if (!inThrottle) {
                    func.apply(this, args);
                    inThrottle = true;
                    setTimeout(() => inThrottle = false, limit);
                }
            };
        },

        /**
         * Debounce function execution
         */
        debounce: (func, wait) => {
            let timeout;
            return function (...args) {
                clearTimeout(timeout);
                timeout = setTimeout(() => func.apply(this, args), wait);
            };
        },

        /**
         * Check if element is in viewport
         */
        isInViewport: (element, threshold = 0) => {
            const rect = element.getBoundingClientRect();
            return (
                rect.top <= (window.innerHeight || document.documentElement.clientHeight) - threshold &&
                rect.bottom >= threshold
            );
        }
    };

    // ============================================
    // Theme Manager
    // ============================================
    const ThemeManager = {
        STORAGE_KEY: 'mineless-theme',
        DARK_CLASS: 'dark-mode',

        init() {
            const toggleBtn = document.querySelector('#theme-toggle, .theme-toggle, [data-theme-toggle]');
            if (!toggleBtn) return;

            // Check saved preference
            const savedTheme = localStorage.getItem(this.STORAGE_KEY);
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

            if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
                document.documentElement.classList.add(this.DARK_CLASS);
            }

            // Toggle handler
            toggleBtn.addEventListener('click', () => {
                const isDark = document.documentElement.classList.toggle(this.DARK_CLASS);
                localStorage.setItem(this.STORAGE_KEY, isDark ? 'dark' : 'light');

                // Trigger event for other components
                window.dispatchEvent(new CustomEvent('themeChanged', { detail: { isDark } }));
            });
        }
    };

    // ============================================
    // Back to Top Button
    // ============================================
    const BackToTop = {
        SHOW_THRESHOLD: 300,

        init() {
            const btn = document.querySelector('#back-to-top, .back-to-top');
            if (!btn) return;

            const toggleVisibility = Utils.throttle(() => {
                if (window.scrollY > this.SHOW_THRESHOLD) {
                    btn.classList.add('is-visible');
                } else {
                    btn.classList.remove('is-visible');
                }
            }, 100);

            window.addEventListener('scroll', toggleVisibility, { passive: true });

            btn.addEventListener('click', (e) => {
                e.preventDefault();
                window.scrollTo({
                    top: 0,
                    behavior: Utils.prefersReducedMotion() ? 'auto' : 'smooth'
                });
            });
        }
    };

    // ============================================
    // Navbar Scroll Effect
    // ============================================
    const NavbarScroll = {
        SCROLL_THRESHOLD: 80,

        init() {
            const navbar = document.querySelector('.navbar, .main-nav, header nav');
            if (!navbar) return;

            const handleScroll = Utils.throttle(() => {
                if (window.scrollY > this.SCROLL_THRESHOLD) {
                    navbar.classList.add('scrolled');
                } else {
                    navbar.classList.remove('scrolled');
                }
            }, 50);

            window.addEventListener('scroll', handleScroll, { passive: true });
        }
    };

    // ============================================
    // Hamburger Menu
    // ============================================
    const HamburgerMenu = {
        init() {
            const hamburger = document.querySelector('.hamburger, .menu-toggle, [data-menu-toggle]');
            const menu = document.querySelector('.nav-menu, .main-menu, [data-nav-menu]');

            if (!hamburger || !menu) return;

            hamburger.addEventListener('click', () => {
                const isOpen = hamburger.classList.toggle('is-open');
                menu.classList.toggle('is-open', isOpen);
                hamburger.setAttribute('aria-expanded', isOpen);
                menu.setAttribute('aria-hidden', !isOpen);

                // Animate hamburger lines
                const lines = hamburger.querySelectorAll('span, .line');
                if (!Utils.prefersReducedMotion() && lines.length >= 3) {
                    if (isOpen) {
                        lines[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                        lines[1].style.opacity = '0';
                        lines[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
                    } else {
                        lines[0].style.transform = '';
                        lines[1].style.opacity = '';
                        lines[2].style.transform = '';
                    }
                }
            });

            // Close menu on outside click
            document.addEventListener('click', (e) => {
                if (!hamburger.contains(e.target) && !menu.contains(e.target) && hamburger.classList.contains('is-open')) {
                    hamburger.classList.remove('is-open');
                    menu.classList.remove('is-open');
                    hamburger.setAttribute('aria-expanded', 'false');
                    menu.setAttribute('aria-hidden', 'true');
                }
            });

            // Close on escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && hamburger.classList.contains('is-open')) {
                    hamburger.classList.remove('is-open');
                    menu.classList.remove('is-open');
                    hamburger.setAttribute('aria-expanded', 'false');
                    menu.setAttribute('aria-hidden', 'true');
                }
            });
        }
    };

    // ============================================
    // GSAP & ScrollTrigger Registration
    // ============================================
    const GSAPManager = {
        init() {
            if (typeof gsap === 'undefined') return;

            // Register ScrollTrigger
            if (typeof ScrollTrigger !== 'undefined') {
                gsap.registerPlugin(ScrollTrigger);
            }

            // Respect reduced motion preference
            if (Utils.prefersReducedMotion()) {
                gsap.globalTimeline.timeScale(0);
            }
        },

        /**
         * Create scroll-triggered animation
         */
        createScrollTrigger(element, animation, options = {}) {
            if (Utils.prefersReducedMotion() || typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
                return;
            }

            return gsap.to(element, {
                ...animation,
                scrollTrigger: {
                    trigger: element,
                    start: 'top 80%',
                    toggleActions: 'play none none none',
                    ...options
                }
            });
        }
    };

    // ============================================
    // Lazy Load Images with IntersectionObserver
    // ============================================
    const LazyLoader = {
        init() {
            const images = document.querySelectorAll('img[data-src], img[loading="lazy"]');
            if (images.length === 0) return;

            // Skip if no IntersectionObserver support
            if (!('IntersectionObserver' in window)) {
                images.forEach(img => this.loadImage(img));
                return;
            }

            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        this.loadImage(entry.target);
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                rootMargin: '50px 0px',
                threshold: 0.01
            });

            images.forEach(img => imageObserver.observe(img));
        },

        loadImage(img) {
            const src = img.dataset.src;
            if (src) {
                img.src = src;
                img.removeAttribute('data-src');
            }
            img.classList.add('is-loaded');
        }
    };

    // ============================================
    // Copy to Clipboard Utility
    // ============================================
    const ClipboardManager = {
        init() {
            const copyBtns = document.querySelectorAll('[data-copy], .copy-btn, .copy-ip');
            copyBtns.forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const textToCopy = btn.dataset.copy || btn.textContent.trim();
                    this.copy(textToCopy, btn);
                });
            });
        },

        async copy(text, triggerElement = null) {
            try {
                await navigator.clipboard.writeText(text);
                this.showFeedback(triggerElement, 'success');
            } catch (err) {
                // Fallback for older browsers
                const textarea = document.createElement('textarea');
                textarea.value = text;
                textarea.style.position = 'fixed';
                textarea.style.opacity = '0';
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                this.showFeedback(triggerElement, 'success');
            }
        },

        showFeedback(element, type) {
            if (!element) return;

            const originalText = element.innerHTML;
            element.innerHTML = '<i class="fas fa-check"></i> Copied!';
            element.classList.add('is-copied');

            setTimeout(() => {
                element.innerHTML = originalText;
                element.classList.remove('is-copied');
            }, 2000);
        }
    };

    // ============================================
    // Konami Code Easter Egg
    // ============================================
    const KonamiCode = {
        CODE: ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'],
        input: [],

        init() {
            document.addEventListener('keydown', (e) => {
                this.input.push(e.key);
                this.input = this.input.slice(-this.CODE.length);

                if (this.input.join(',') === this.CODE.join(',')) {
                    this.activate();
                }
            });
        },

        activate() {
            // Magic effect - colorful particles or screen flash
            if (typeof gsap !== 'undefined' && !Utils.prefersReducedMotion()) {
                this.createMagicEffect();
            }

            // Show secret message
            this.showSecretMessage();

            // Dispatch custom event
            window.dispatchEvent(new CustomEvent('konamiActivated'));
        },

        createMagicEffect() {
            const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeaa7', '#dfe6e9'];
            const container = document.createElement('div');
            container.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:9999';
            document.body.appendChild(container);

            for (let i = 0; i < 50; i++) {
                const particle = document.createElement('div');
                particle.style.cssText = `
                    position: absolute;
                    width: 10px;
                    height: 10px;
                    background: ${colors[Math.floor(Math.random() * colors.length)]};
                    border-radius: 50%;
                    left: 50%;
                    top: 50%;
                `;
                container.appendChild(particle);

                gsap.to(particle, {
                    x: (Math.random() - 0.5) * window.innerWidth,
                    y: (Math.random() - 0.5) * window.innerHeight,
                    scale: Math.random() * 2 + 0.5,
                    opacity: 0,
                    duration: 1 + Math.random(),
                    ease: 'power2.out',
                    onComplete: () => particle.remove()
                });
            }

            setTimeout(() => container.remove(), 2000);
        },

        showSecretMessage() {
            const message = document.createElement('div');
            message.className = 'konami-message';
            message.innerHTML = `
                <div style="
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    padding: 2rem 3rem;
                    border-radius: 1rem;
                    font-size: 1.5rem;
                    font-weight: bold;
                    text-align: center;
                    z-index: 10000;
                    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                ">
                    🎮 Secret Code Activated! 🎮
                    <div style="font-size: 0.9rem; margin-top: 0.5rem; opacity: 0.9;">
                        You found the Konami Code!
                    </div>
                </div>
            `;
            document.body.appendChild(message);

            if (typeof gsap !== 'undefined' && !Utils.prefersReducedMotion()) {
                gsap.from(message.firstElementChild, {
                    scale: 0,
                    rotation: -10,
                    duration: 0.5,
                    ease: 'back.out(1.7)'
                });
            }

            setTimeout(() => {
                if (typeof gsap !== 'undefined') {
                    gsap.to(message, {
                        opacity: 0,
                        duration: 0.3,
                        onComplete: () => message.remove()
                    });
                } else {
                    message.remove();
                }
            }, 3000);
        }
    };

    // ============================================
    // Loading Bar Animation
    // ============================================
    const LoadingBar = {
        init() {
            const loadingBar = document.querySelector('.loading-bar, #loading-bar');
            if (!loadingBar) return;

            // Animate on page load
            if (!Utils.prefersReducedMotion() && typeof gsap !== 'undefined') {
                gsap.to(loadingBar, {
                    width: '100%',
                    duration: 1.5,
                    ease: 'power2.inOut',
                    onComplete: () => {
                        gsap.to(loadingBar, {
                            opacity: 0,
                            duration: 0.3,
                            onComplete: () => {
                                loadingBar.style.display = 'none';
                            }
                        });
                    }
                });
            } else {
                loadingBar.style.width = '100%';
                setTimeout(() => {
                    loadingBar.style.opacity = '0';
                    setTimeout(() => loadingBar.style.display = 'none', 300);
                }, 500);
            }
        }
    };

    // ============================================
    // Initialize All Modules
    // ============================================
    function init() {
        ThemeManager.init();
        BackToTop.init();
        NavbarScroll.init();
        HamburgerMenu.init();
        GSAPManager.init();
        LazyLoader.init();
        ClipboardManager.init();
        KonamiCode.init();
        LoadingBar.init();

        // Mark document as ready
        document.body.classList.add('js-loaded');
    }

    // Start when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Expose utilities globally for other modules
    window.MinelessCore = {
        Utils,
        GSAPManager,
        ClipboardManager
    };
})();
