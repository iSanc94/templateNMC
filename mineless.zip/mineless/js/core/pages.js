/**
 * Mineless Theme - Page-Specific JavaScript
 * NamelessMC Template
 * ES6+ Vanilla JavaScript
 */

(function () {
    'use strict';

    // ============================================
    // Utility Functions
    // ============================================
    const prefersReducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const throttle = (func, limit) => {
        let inThrottle;
        return function (...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    };

    // ============================================
    // Homepage Module
    // ============================================
    const Homepage = {
        init() {
            this.initParticles();
            this.initTyped();
            this.initParallax();
            this.initStatsCounter();
            this.initSectionAnimations();
        },

        initParticles() {
            const particlesContainer = document.getElementById('particles-js');
            if (!particlesContainer || typeof particlesJS === 'undefined') return;

            // Detect device type
            const isMobile = window.matchMedia('(pointer: coarse)').matches;
            const isTablet = window.matchMedia('(min-width: 768px) and (max-width: 1024px)').matches;

            let particleCount = 80; // Desktop default
            if (isMobile) {
                particleCount = 0; // Disable on mobile
                return;
            } else if (isTablet) {
                particleCount = 30;
            }

            particlesJS('particles-js', {
                particles: {
                    number: { value: particleCount, density: { enable: true, value_area: 800 } },
                    color: { value: '#ffffff' },
                    shape: { type: 'circle' },
                    opacity: { value: 0.5, random: true },
                    size: { value: 3, random: true },
                    line_linked: {
                        enable: true,
                        distance: 150,
                        color: '#ffffff',
                        opacity: 0.4,
                        width: 1
                    },
                    move: {
                        enable: true,
                        speed: 2,
                        direction: 'none',
                        random: true,
                        straight: false,
                        out_mode: 'out',
                        bounce: false
                    }
                },
                interactivity: {
                    detect_on: 'canvas',
                    events: {
                        onhover: { enable: !isMobile, mode: 'grab' },
                        onclick: { enable: true, mode: 'push' },
                        resize: true
                    },
                    modes: {
                        grab: { distance: 140, line_linked: { opacity: 1 } },
                        push: { particles_nb: 4 }
                    }
                },
                retina_detect: true
            });
        },

        initTyped() {
            const typedElement = document.getElementById('typed-text');
            if (!typedElement || typeof Typed === 'undefined') return;

            const strings = JSON.parse(typedElement.dataset.strings || '["Welcome to Mineless", "Join our community", "Start your journey"]');

            new Typed('#typed-text', {
                strings,
                typeSpeed: 50,
                backSpeed: 30,
                backDelay: 2000,
                startDelay: 500,
                loop: true,
                showCursor: true,
                cursorChar: '|'
            });
        },

        initParallax() {
            if (prefersReducedMotion()) return;

            const parallaxLayers = document.querySelectorAll('[data-parallax]');
            if (parallaxLayers.length === 0) return;

            const handleScroll = throttle(() => {
                const scrollY = window.scrollY;
                parallaxLayers.forEach(layer => {
                    const speed = parseFloat(layer.dataset.parallax) || 0.5;
                    const yPos = -(scrollY * speed);
                    layer.style.transform = `translateY(${yPos}px)`;
                });
            }, 16);

            window.addEventListener('scroll', handleScroll, { passive: true });
        },

        initStatsCounter() {
            const stats = document.querySelectorAll('.stat-number[data-count]');
            if (stats.length === 0) return;

            const animateCount = (element, target, duration = 2000) => {
                if (prefersReducedMotion()) {
                    element.textContent = target;
                    return;
                }

                const start = 0;
                const startTime = performance.now();

                const updateCount = (currentTime) => {
                    const elapsed = currentTime - startTime;
                    const progress = Math.min(elapsed / duration, 1);

                    // Ease out quart
                    const easeOut = 1 - Math.pow(1 - progress, 4);
                    const current = Math.floor(start + (target - start) * easeOut);

                    element.textContent = current.toLocaleString();

                    if (progress < 1) {
                        requestAnimationFrame(updateCount);
                    } else {
                        element.textContent = target.toLocaleString();
                    }
                };

                requestAnimationFrame(updateCount);
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const target = parseInt(entry.target.dataset.count, 10);
                        animateCount(entry.target, target);
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.5 });

            stats.forEach(stat => observer.observe(stat));
        },

        initSectionAnimations() {
            if (prefersReducedMotion() || typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;

            const sections = document.querySelectorAll('.section-animate, .feature-card, .hero-content');

            sections.forEach((section, index) => {
                gsap.from(section, {
                    y: 50,
                    opacity: 0,
                    duration: 0.8,
                    delay: index * 0.1,
                    ease: 'power2.out',
                    scrollTrigger: {
                        trigger: section,
                        start: 'top 85%',
                        toggleActions: 'play none none none'
                    }
                });
            });
        }
    };

    // ============================================
    // Forum Module
    // ============================================
    const Forum = {
        init() {
            this.initSpoilers();
            this.initCodeCopy();
            this.initReactions();
            this.initLikeButtons();
        },

        initSpoilers() {
            document.querySelectorAll('.spoiler-header, [data-spoiler-toggle]').forEach(header => {
                header.addEventListener('click', () => {
                    const spoiler = header.closest('.spoiler, [data-spoiler]');
                    if (!spoiler) return;

                    const isOpen = spoiler.classList.toggle('is-open');
                    header.setAttribute('aria-expanded', isOpen);

                    const content = spoiler.querySelector('.spoiler-content, [data-spoiler-content]');
                    if (content) {
                        content.style.maxHeight = isOpen ? `${content.scrollHeight}px` : '0';
                    }
                });
            });
        },

        initCodeCopy() {
            document.querySelectorAll('pre code, .code-block').forEach(block => {
                const wrapper = block.closest('pre, .code-block-wrapper');
                if (!wrapper || wrapper.querySelector('.copy-code-btn')) return;

                const btn = document.createElement('button');
                btn.className = 'copy-code-btn';
                btn.innerHTML = '<i class="fas fa-copy"></i>';
                btn.setAttribute('aria-label', 'Copy code');
                btn.setAttribute('title', 'Copy to clipboard');

                btn.addEventListener('click', async () => {
                    const code = block.textContent;
                    try {
                        await navigator.clipboard.writeText(code);
                        btn.innerHTML = '<i class="fas fa-check"></i>';
                        btn.classList.add('is-copied');
                        setTimeout(() => {
                            btn.innerHTML = '<i class="fas fa-copy"></i>';
                            btn.classList.remove('is-copied');
                        }, 2000);
                    } catch (err) {
                        console.error('Failed to copy:', err);
                    }
                });

                wrapper.style.position = 'relative';
                wrapper.appendChild(btn);
            });
        },

        initReactions() {
            document.querySelectorAll('.reaction-btn, [data-reaction]').forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    e.preventDefault();

                    const reactionId = btn.dataset.reaction;
                    const postId = btn.closest('[data-post-id]')?.dataset.postId;

                    // Optimistic UI update
                    const countEl = btn.querySelector('.reaction-count, .count');
                    const isActive = btn.classList.contains('is-active');

                    if (isActive) {
                        btn.classList.remove('is-active');
                        if (countEl) {
                            const current = parseInt(countEl.textContent, 10) || 0;
                            countEl.textContent = Math.max(0, current - 1);
                        }
                    } else {
                        btn.classList.add('is-active');
                        if (countEl) {
                            const current = parseInt(countEl.textContent, 10) || 0;
                            countEl.textContent = current + 1;
                        }

                        // Heart beat animation
                        if (!prefersReducedMotion()) {
                            btn.style.transform = 'scale(1.3)';
                            setTimeout(() => btn.style.transform = '', 200);
                        }
                    }

                    // API call
                    try {
                        const response = await fetch('/forum/react', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            },
                            body: JSON.stringify({ post_id: postId, reaction_id: reactionId })
                        });

                        if (!response.ok) throw new Error('Reaction failed');
                    } catch (err) {
                        // Revert on error
                        console.error('Reaction error:', err);
                        if (isActive) {
                            btn.classList.add('is-active');
                            if (countEl) {
                                const current = parseInt(countEl.textContent, 10) || 0;
                                countEl.textContent = current + 1;
                            }
                        } else {
                            btn.classList.remove('is-active');
                            if (countEl) {
                                const current = parseInt(countEl.textContent, 10) || 0;
                                countEl.textContent = Math.max(0, current - 1);
                            }
                        }
                    }
                });
            });
        },

        initLikeButtons() {
            document.querySelectorAll('.like-btn, [data-like]').forEach(btn => {
                btn.addEventListener('click', function () {
                    if (prefersReducedMotion()) return;

                    // Heart beat animation
                    this.style.animation = 'none';
                    this.offsetHeight; // Trigger reflow
                    this.style.animation = 'heartBeat 0.8s ease';

                    setTimeout(() => {
                        this.style.animation = '';
                    }, 800);
                });
            });
        }
    };

    // ============================================
    // Profile Module
    // ============================================
    const Profile = {
        init() {
            this.initTabs();
            this.initAvatarFloat();
        },

        initTabs() {
            const tabContainer = document.querySelector('.profile-tabs, [data-tabs]');
            if (!tabContainer) return;

            const tabs = tabContainer.querySelectorAll('.tab-btn, [data-tab]');
            const panels = document.querySelectorAll('.tab-panel, [data-tab-panel]');
            const inkBar = tabContainer.querySelector('.ink-bar, .tab-indicator');

            const updateInkBar = (activeTab) => {
                if (!inkBar) return;
                const rect = activeTab.getBoundingClientRect();
                const containerRect = tabContainer.getBoundingClientRect();
                inkBar.style.width = `${rect.width}px`;
                inkBar.style.transform = `translateX(${rect.left - containerRect.left}px)`;
            };

            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    const targetPanel = tab.dataset.tab;

                    // Update active tab
                    tabs.forEach(t => t.classList.remove('is-active'));
                    tab.classList.add('is-active');

                    // Update ink bar
                    updateInkBar(tab);

                    // Show target panel
                    panels.forEach(panel => {
                        const isTarget = panel.dataset.tabPanel === targetPanel;
                        panel.classList.toggle('is-active', isTarget);
                        panel.style.display = isTarget ? 'block' : 'none';
                    });
                });
            });

            // Initialize ink bar position
            const activeTab = tabContainer.querySelector('.is-active, .active');
            if (activeTab && inkBar) {
                setTimeout(() => updateInkBar(activeTab), 0);
                window.addEventListener('resize', throttle(() => updateInkBar(activeTab), 100));
            }
        },

        initAvatarFloat() {
            if (prefersReducedMotion() || typeof gsap === 'undefined') return;

            const avatar = document.querySelector('.profile-avatar img, .avatar-large');
            if (!avatar) return;

            gsap.to(avatar, {
                y: -10,
                duration: 2,
                ease: 'sine.inOut',
                yoyo: true,
                repeat: -1
            });
        }
    };

    // ============================================
    // Leaderboard Module
    // ============================================
    const Leaderboard = {
        init() {
            this.initPodiumAnimation();
        },

        initPodiumAnimation() {
            if (prefersReducedMotion() || typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;

            const podium = document.querySelector('.podium, .leaderboard-podium');
            if (!podium) return;

            const positions = podium.querySelectorAll('.podium-place, .podium-item');

            gsap.from(positions, {
                y: 100,
                opacity: 0,
                duration: 0.8,
                stagger: 0.2,
                ease: 'back.out(1.7)',
                scrollTrigger: {
                    trigger: podium,
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                }
            });
        }
    };

    // ============================================
    // Login Module
    // ============================================
    const Login = {
        init() {
            this.initFormShake();
            this.initPasswordToggle();
        },

        initFormShake() {
            const form = document.querySelector('#login-form, .login-form');
            if (!form) return;

            // Check for error parameter or class
            const hasError = form.classList.contains('has-error') ||
                new URLSearchParams(window.location.search).has('error');

            if (hasError && !prefersReducedMotion()) {
                form.style.animation = 'shake 0.5s ease';
                setTimeout(() => form.style.animation = '', 500);
            }
        },

        initPasswordToggle() {
            document.querySelectorAll('.password-toggle, [data-password-toggle]').forEach(toggle => {
                const input = toggle.closest('.input-group, .form-group')?.querySelector('input[type="password"], input[type="text"]') ||
                    document.querySelector(toggle.dataset.target);

                if (!input) return;

                toggle.addEventListener('click', () => {
                    const isPassword = input.type === 'password';
                    input.type = isPassword ? 'text' : 'password';
                    toggle.classList.toggle('is-visible', isPassword);
                    toggle.innerHTML = isPassword ?
                        '<i class="fas fa-eye-slash"></i>' :
                        '<i class="fas fa-eye"></i>';
                });
            });
        }
    };

    // ============================================
    // Register Module
    // ============================================
    const Register = {
        init() {
            this.initMultiStepWizard();
            this.initPasswordStrength();
        },

        initMultiStepWizard() {
            const wizard = document.querySelector('.register-wizard, [data-wizard]');
            if (!wizard) return;

            const steps = wizard.querySelectorAll('.wizard-step, [data-wizard-step]');
            const progressBar = wizard.querySelector('.wizard-progress, [data-wizard-progress]');
            const nextBtns = wizard.querySelectorAll('.wizard-next, [data-wizard-next]');
            const prevBtns = wizard.querySelectorAll('.wizard-prev, [data-wizard-prev]');

            let currentStep = 0;

            const updateProgress = () => {
                if (progressBar) {
                    const progress = ((currentStep + 1) / steps.length) * 100;
                    progressBar.style.width = `${progress}%`;
                }
            };

            const showStep = (index) => {
                steps.forEach((step, i) => {
                    step.classList.toggle('is-active', i === index);
                    step.style.display = i === index ? 'block' : 'none';
                });
                updateProgress();
            };

            nextBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    if (currentStep < steps.length - 1) {
                        currentStep++;
                        showStep(currentStep);
                    }
                });
            });

            prevBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    if (currentStep > 0) {
                        currentStep--;
                        showStep(currentStep);
                    }
                });
            });

            showStep(0);
        },

        initPasswordStrength() {
            const passwordInput = document.querySelector('#password, .password-strength-input');
            const strengthBar = document.querySelector('.password-strength-bar, [data-strength-bar]');
            const strengthText = document.querySelector('.password-strength-text, [data-strength-text]');

            if (!passwordInput || !strengthBar) return;

            const calculateStrength = (password) => {
                let score = 0;
                if (password.length >= 8) score++;
                if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
                if (/\d/.test(password)) score++;
                if (/[^a-zA-Z0-9]/.test(password)) score++;
                return score;
            };

            const getStrengthLabel = (score) => {
                const labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
                return labels[score] || 'Very Weak';
            };

            const getStrengthColor = (score) => {
                const colors = ['#ff4444', '#ff8844', '#ffaa44', '#44aa44', '#44ff44'];
                return colors[score] || '#ff4444';
            };

            passwordInput.addEventListener('input', (e) => {
                const password = e.target.value;
                const score = calculateStrength(password);
                const percentage = (score / 4) * 100;

                strengthBar.style.width = `${percentage}%`;
                strengthBar.style.backgroundColor = getStrengthColor(score);

                if (strengthText) {
                    strengthText.textContent = password ? getStrengthLabel(score) : '';
                }
            });

            // Check for successful registration
            if (new URLSearchParams(window.location.search).has('registered')) {
                this.triggerConfetti();
            }
        },

        triggerConfetti() {
            if (typeof confetti === 'undefined') return;

            const duration = 3000;
            const end = Date.now() + duration;

            const frame = () => {
                confetti({
                    particleCount: 3,
                    angle: 60,
                    spread: 55,
                    origin: { x: 0 },
                    colors: ['#667eea', '#764ba2', '#f093fb']
                });
                confetti({
                    particleCount: 3,
                    angle: 120,
                    spread: 55,
                    origin: { x: 1 },
                    colors: ['#667eea', '#764ba2', '#f093fb']
                });

                if (Date.now() < end) {
                    requestAnimationFrame(frame);
                }
            };

            frame();
        }
    };

    // ============================================
    // TFA Module (Two-Factor Authentication)
    // ============================================
    const TFA = {
        init() {
            this.initOTPInputs();
        },

        initOTPInputs() {
            const form = document.querySelector('#tfa-form, .tfa-form, [data-tfa-form]');
            if (!form) return;

            const inputs = form.querySelectorAll('.otp-input, [data-otp-input]');
            if (inputs.length === 0) return;

            inputs.forEach((input, index) => {
                // Auto-advance on input
                input.addEventListener('input', (e) => {
                    const value = e.target.value;

                    if (value.length === 1) {
                        if (index < inputs.length - 1) {
                            inputs[index + 1].focus();
                        } else {
                            // Last input - check if all filled
                            const allFilled = Array.from(inputs).every(inp => inp.value.length === 1);
                            if (allFilled) {
                                form.submit();
                            }
                        }
                    }
                });

                // Handle backspace
                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Backspace' && !input.value && index > 0) {
                        inputs[index - 1].focus();
                    }
                });

                // Handle paste
                input.addEventListener('paste', (e) => {
                    e.preventDefault();
                    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').split('');

                    inputs.forEach((inp, i) => {
                        if (pasted[i]) {
                            inp.value = pasted[i];
                            if (i < inputs.length - 1) {
                                inputs[i + 1].focus();
                            }
                        }
                    });

                    // Auto-submit if all filled
                    const allFilled = Array.from(inputs).every(inp => inp.value.length === 1);
                    if (allFilled) {
                        form.submit();
                    }
                });
            });
        }
    };

    // ============================================
    // Error Pages Module
    // ============================================
    const ErrorPages = {
        init() {
            this.init404Animation();
            this.initCompassAnimation();
        },

        init404Animation() {
            const character = document.querySelector('.error-404-character, [data-404-char]');
            if (!character) return;

            // CSS character walk animation via class toggle
            const walk = () => {
                character.classList.add('is-walking');
                setTimeout(() => {
                    character.classList.remove('is-walking');
                }, 500);
            };

            setInterval(walk, 2000);
        },

        initCompassAnimation() {
            const compass = document.querySelector('.compass, [data-compass]');
            if (!compass || prefersReducedMotion()) return;

            // Start compass rotation animation
            compass.style.animation = 'compassRotate 4s ease-in-out infinite';
        }
    };

    // ============================================
    // Page Router
    // ============================================
    function init() {
        const body = document.body;
        const pageData = body.dataset.page || '';

        // Detect page by body class or data-page attribute
        const isHomepage = body.classList.contains('page-home') ||
            body.classList.contains('homepage') ||
            pageData === 'home' ||
            document.querySelector('.hero-section, #particles-js');

        const isForum = body.classList.contains('page-forum') ||
            body.classList.contains('forum') ||
            pageData === 'forum' ||
            document.querySelector('.forum-container, .topic-list');

        const isProfile = body.classList.contains('page-profile') ||
            body.classList.contains('profile') ||
            pageData === 'profile' ||
            document.querySelector('.profile-container, .profile-header');

        const isLeaderboard = body.classList.contains('page-leaderboard') ||
            body.classList.contains('leaderboard') ||
            pageData === 'leaderboard' ||
            document.querySelector('.leaderboard-container, .podium');

        const isLogin = body.classList.contains('page-login') ||
            pageData === 'login' ||
            document.querySelector('#login-form, .login-form');

        const isRegister = body.classList.contains('page-register') ||
            pageData === 'register' ||
            document.querySelector('#register-form, .register-form, .register-wizard');

        const isTFA = body.classList.contains('page-tfa') ||
            pageData === 'tfa' ||
            document.querySelector('#tfa-form, .tfa-form, .otp-input');

        const isErrorPage = body.classList.contains('page-error') ||
            pageData === 'error' ||
            document.querySelector('.error-page, .error-404');

        // Initialize modules based on page
        if (isHomepage) Homepage.init();
        if (isForum) Forum.init();
        if (isProfile) Profile.init();
        if (isLeaderboard) Leaderboard.init();
        if (isLogin) Login.init();
        if (isRegister) Register.init();
        if (isTFA) TFA.init();
        if (isErrorPage) ErrorPages.init();
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Expose modules globally
    window.MinelessPages = {
        Homepage,
        Forum,
        Profile,
        Leaderboard,
        Login,
        Register,
        TFA,
        ErrorPages
    };
})();
