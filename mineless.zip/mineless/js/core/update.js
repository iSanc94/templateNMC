/**
 * Mineless Theme - Live Updates & Polling JavaScript
 * NamelessMC Template
 * ES6+ Vanilla JavaScript
 */

(function () {
    'use strict';

    // ============================================
    // Configuration
    // ============================================
    const CONFIG = {
        SERVER_STATUS_INTERVAL: 60000,    // 60 seconds
        NOTIFICATION_INTERVAL: 30000,     // 30 seconds
        ONLINE_USERS_INTERVAL: 60000,     // 60 seconds
        TIMEOUT_WARNING: 600000,          // 10 minutes before timeout
        RETRY_DELAY: 5000,                // 5 seconds retry delay
        MAX_RETRIES: 3
    };

    // ============================================
    // Utility Functions
    // ============================================
    const Utils = {
        /**
         * Format number with locale
         */
        formatNumber(num) {
            return new Intl.NumberFormat().format(num);
        },

        /**
         * Debounce function
         */
        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },

        /**
         * Check if page is visible
         */
        isPageVisible() {
            return document.visibilityState === 'visible';
        }
    };

    // ============================================
    // Server Status Manager
    // ============================================
    const ServerStatusManager = {
        intervalId: null,
        retryCount: 0,

        init() {
            const widget = document.querySelector('.server-status-widget, [data-server-status]');
            if (!widget) return;

            // Initial check
            this.checkStatus();

            // Start polling
            this.startPolling();

            // Pause polling when page is hidden
            document.addEventListener('visibilitychange', () => {
                if (Utils.isPageVisible()) {
                    this.startPolling();
                    this.checkStatus(); // Immediate check on visibility
                } else {
                    this.stopPolling();
                }
            });
        },

        startPolling() {
            if (this.intervalId) return;
            this.intervalId = setInterval(() => this.checkStatus(), CONFIG.SERVER_STATUS_INTERVAL);
        },

        stopPolling() {
            if (this.intervalId) {
                clearInterval(this.intervalId);
                this.intervalId = null;
            }
        },

        async checkStatus() {
            const widget = document.querySelector('.server-status-widget, [data-server-status]');
            if (!widget) return;

            const serverId = widget.dataset.serverId || 'default';

            try {
                const response = await fetch(`/api/server/status?id=${serverId}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                if (!response.ok) throw new Error(`HTTP ${response.status}`);

                const data = await response.json();
                this.updateWidget(widget, data);
                this.retryCount = 0;

            } catch (error) {
                console.warn('Server status check failed:', error);
                this.handleError(widget);
            }
        },

        updateWidget(widget, data) {
            const statusEl = widget.querySelector('.status-indicator, [data-status]');
            const playersEl = widget.querySelector('.player-count, [data-players]');
            const maxPlayersEl = widget.querySelector('.max-players, [data-max-players]');
            const motdEl = widget.querySelector('.server-motd, [data-motd]');
            const versionEl = widget.querySelector('.server-version, [data-version]');
            const pingEl = widget.querySelector('.server-ping, [data-ping]');

            // Update status indicator
            if (statusEl) {
                const isOnline = data.online;
                statusEl.classList.remove('online', 'offline', 'is-online', 'is-offline');
                statusEl.classList.add(isOnline ? 'online' : 'offline');
                statusEl.setAttribute('data-status', isOnline ? 'online' : 'offline');

                const statusText = statusEl.querySelector('.status-text');
                if (statusText) {
                    statusText.textContent = isOnline ? 'Online' : 'Offline';
                }
            }

            // Update player count with animation
            if (playersEl && data.players !== undefined) {
                const currentPlayers = parseInt(playersEl.textContent.replace(/,/g, ''), 10) || 0;
                const newPlayers = data.players;

                if (currentPlayers !== newPlayers) {
                    this.animateNumber(playersEl, currentPlayers, newPlayers);
                }
            }

            // Update max players
            if (maxPlayersEl && data.max_players !== undefined) {
                maxPlayersEl.textContent = Utils.formatNumber(data.max_players);
            }

            // Update MOTD
            if (motdEl && data.motd) {
                motdEl.textContent = data.motd;
            }

            // Update version
            if (versionEl && data.version) {
                versionEl.textContent = data.version;
            }

            // Update ping
            if (pingEl && data.ping !== undefined) {
                pingEl.textContent = `${data.ping}ms`;
                pingEl.classList.remove('good', 'medium', 'poor');

                if (data.ping < 50) pingEl.classList.add('good');
                else if (data.ping < 150) pingEl.classList.add('medium');
                else pingEl.classList.add('poor');
            }

            // Update last checked timestamp
            widget.dataset.lastChecked = Date.now();
        },

        animateNumber(element, from, to) {
            const duration = 500;
            const start = performance.now();

            const animate = (currentTime) => {
                const elapsed = currentTime - start;
                const progress = Math.min(elapsed / duration, 1);
                const easeOut = 1 - Math.pow(1 - progress, 3);
                const current = Math.floor(from + (to - from) * easeOut);

                element.textContent = Utils.formatNumber(current);

                if (progress < 1) {
                    requestAnimationFrame(animate);
                } else {
                    element.textContent = Utils.formatNumber(to);
                }
            };

            requestAnimationFrame(animate);
        },

        handleError(widget) {
            this.retryCount++;

            if (this.retryCount >= CONFIG.MAX_RETRIES) {
                const statusEl = widget.querySelector('.status-indicator, [data-status]');
                if (statusEl) {
                    statusEl.classList.remove('online', 'is-online');
                    statusEl.classList.add('offline', 'is-offline');
                    statusEl.setAttribute('data-status', 'unknown');

                    const statusText = statusEl.querySelector('.status-text');
                    if (statusText) {
                        statusText.textContent = 'Connection Error';
                    }
                }
            }
        }
    };

    // ============================================
    // Notification Manager
    // ============================================
    const NotificationManager = {
        intervalId: null,
        lastCount: 0,

        init() {
            const badge = document.querySelector('.notification-badge, [data-notification-count]');
            if (!badge) return;

            // Initial check
            this.checkNotifications();

            // Start polling
            this.startPolling();

            // Pause when hidden
            document.addEventListener('visibilitychange', () => {
                if (Utils.isPageVisible()) {
                    this.startPolling();
                } else {
                    this.stopPolling();
                }
            });
        },

        startPolling() {
            if (this.intervalId) return;
            this.intervalId = setInterval(() => this.checkNotifications(), CONFIG.NOTIFICATION_INTERVAL);
        },

        stopPolling() {
            if (this.intervalId) {
                clearInterval(this.intervalId);
                this.intervalId = null;
            }
        },

        async checkNotifications() {
            try {
                const response = await fetch('/api/notifications/count', {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                if (!response.ok) throw new Error(`HTTP ${response.status}`);

                const data = await response.json();
                this.updateBadge(data.count);

            } catch (error) {
                console.warn('Notification check failed:', error);
            }
        },

        updateBadge(count) {
            const badges = document.querySelectorAll('.notification-badge, [data-notification-count]');

            badges.forEach(badge => {
                const currentCount = parseInt(badge.textContent, 10) || 0;

                // Update text
                badge.textContent = count > 99 ? '99+' : count;

                // Toggle visibility
                badge.classList.toggle('has-notifications', count > 0);
                badge.style.display = count > 0 ? 'flex' : 'none';

                // Pulse animation on new notification
                if (count > this.lastCount && currentCount > 0) {
                    badge.classList.add('is-pulse');
                    setTimeout(() => badge.classList.remove('is-pulse'), 1000);
                }
            });

            // Update page title
            if (count > 0 && count > this.lastCount) {
                this.updatePageTitle(count);
            } else if (count === 0) {
                this.resetPageTitle();
            }

            this.lastCount = count;
        },

        updatePageTitle(count) {
            const title = document.title;
            if (!title.startsWith('(')) {
                document.title = `(${count}) ${title}`;
            } else {
                document.title = title.replace(/\(\d+\)/, `(${count})`);
            }
        },

        resetPageTitle() {
            document.title = document.title.replace(/^\(\d+\)\s*/, '');
        }
    };

    // ============================================
    // Online Users Manager
    // ============================================
    const OnlineUsersManager = {
        intervalId: null,

        init() {
            const widget = document.querySelector('.online-users-widget, [data-online-users]');
            if (!widget) return;

            // Initial check
            this.refreshCount();

            // Start polling
            this.startPolling();

            // Pause when hidden
            document.addEventListener('visibilitychange', () => {
                if (Utils.isPageVisible()) {
                    this.startPolling();
                } else {
                    this.stopPolling();
                }
            });
        },

        startPolling() {
            if (this.intervalId) return;
            this.intervalId = setInterval(() => this.refreshCount(), CONFIG.ONLINE_USERS_INTERVAL);
        },

        stopPolling() {
            if (this.intervalId) {
                clearInterval(this.intervalId);
                this.intervalId = null;
            }
        },

        async refreshCount() {
            const widget = document.querySelector('.online-users-widget, [data-online-users]');
            if (!widget) return;

            try {
                const response = await fetch('/api/users/online', {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                if (!response.ok) throw new Error(`HTTP ${response.status}`);

                const data = await response.json();
                this.updateWidget(widget, data);

            } catch (error) {
                console.warn('Online users check failed:', error);
            }
        },

        updateWidget(widget, data) {
            const countEl = widget.querySelector('.online-count, [data-count]');
            const listEl = widget.querySelector('.online-list, [data-list]');
            const guestsEl = widget.querySelector('.guests-count, [data-guests]');

            // Update count
            if (countEl && data.count !== undefined) {
                const currentCount = parseInt(countEl.textContent.replace(/,/g, ''), 10) || 0;
                if (currentCount !== data.count) {
                    this.animateNumber(countEl, currentCount, data.count);
                }
            }

            // Update guests count
            if (guestsEl && data.guests !== undefined) {
                guestsEl.textContent = Utils.formatNumber(data.guests);
            }

            // Update user list
            if (listEl && data.users) {
                const currentUsers = listEl.dataset.users ? JSON.parse(listEl.dataset.users) : [];
                const newUsers = data.users;

                // Check if list changed
                const hasChanged = JSON.stringify(currentUsers) !== JSON.stringify(newUsers);

                if (hasChanged) {
                    listEl.innerHTML = newUsers.map(user => `
                        <a href="/profile/${user.username}" class="online-user" title="${user.username}">
                            <img src="${user.avatar}" alt="${user.username}" class="online-avatar" loading="lazy">
                            <span class="online-username">${user.username}</span>
                        </a>
                    `).join('');

                    listEl.dataset.users = JSON.stringify(newUsers);
                }
            }
        },

        animateNumber(element, from, to) {
            const duration = 400;
            const start = performance.now();

            const animate = (currentTime) => {
                const elapsed = currentTime - start;
                const progress = Math.min(elapsed / duration, 1);
                const current = Math.floor(from + (to - from) * progress);

                element.textContent = Utils.formatNumber(current);

                if (progress < 1) {
                    requestAnimationFrame(animate);
                } else {
                    element.textContent = Utils.formatNumber(to);
                }
            };

            requestAnimationFrame(animate);
        }
    };

    // ============================================
    // Session Timeout Manager
    // ============================================
    const SessionManager = {
        timeoutWarningShown: false,

        init() {
            const modal = document.getElementById('session-timeout-modal');
            if (!modal) return;

            // Get session expiry from meta tag or data attribute
            const expiryMeta = document.querySelector('meta[name="session-expires"]');
            const expiryData = document.body.dataset.sessionExpires;

            if (!expiryMeta && !expiryData) return;

            const expiryTime = parseInt(expiryMeta?.content || expiryData, 10);
            if (!expiryTime) return;

            this.checkSession(expiryTime);
        },

        checkSession(expiryTime) {
            const now = Date.now();
            const timeUntilExpiry = expiryTime - now;
            const warningTime = timeUntilExpiry - CONFIG.TIMEOUT_WARNING;

            if (warningTime > 0) {
                // Schedule warning
                setTimeout(() => this.showWarning(), warningTime);
            }
        },

        showWarning() {
            if (this.timeoutWarningShown) return;

            const modal = document.getElementById('session-timeout-modal');
            if (!modal) return;

            this.timeoutWarningShown = true;

            // Show modal
            modal.classList.add('is-active');
            modal.style.display = 'flex';

            // Countdown timer
            const countdownEl = modal.querySelector('.timeout-countdown');
            let secondsLeft = Math.floor(CONFIG.TIMEOUT_WARNING / 1000);

            const updateCountdown = () => {
                if (countdownEl) {
                    const minutes = Math.floor(secondsLeft / 60);
                    const seconds = secondsLeft % 60;
                    countdownEl.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
                }

                secondsLeft--;

                if (secondsLeft >= 0) {
                    setTimeout(updateCountdown, 1000);
                }
            };

            updateCountdown();

            // Extend session button
            const extendBtn = modal.querySelector('.extend-session-btn, [data-extend-session]');
            if (extendBtn) {
                extendBtn.addEventListener('click', () => this.extendSession(modal));
            }

            // Logout button
            const logoutBtn = modal.querySelector('.logout-btn, [data-logout]');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', () => {
                    window.location.href = '/logout';
                });
            }
        },

        async extendSession(modal) {
            try {
                const response = await fetch('/api/session/extend', {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                if (response.ok) {
                    // Hide modal
                    modal.classList.remove('is-active');
                    modal.style.display = 'none';
                    this.timeoutWarningShown = false;

                    // Reinitialize with new expiry
                    const data = await response.json();
                    if (data.newExpiry) {
                        this.checkSession(data.newExpiry);
                    }
                } else {
                    throw new Error('Failed to extend session');
                }
            } catch (error) {
                console.error('Session extension failed:', error);
                alert('Failed to extend session. Please refresh the page.');
            }
        }
    };

    // ============================================
    // Initialize All Modules
    // ============================================
    function init() {
        ServerStatusManager.init();
        NotificationManager.init();
        OnlineUsersManager.init();
        SessionManager.init();
    }

    // Start when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Expose managers globally
    window.MinelessUpdates = {
        ServerStatusManager,
        NotificationManager,
        OnlineUsersManager,
        SessionManager
    };
})();
