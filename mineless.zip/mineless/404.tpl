{include file='header.tpl'}

<section class="mineless-error-section">
    <div class="mineless-error-bg">
        <div class="mineless-wilderness-overlay"></div>
        <div class="mineless-compass-container">
            <div class="mineless-compass" id="compass">
                <div class="mineless-compass-rose">
                    <i class="fas fa-location-arrow"></i>
                </div>
                <div class="mineless-compass-ring"></div>
            </div>
        </div>
    </div>
    
    <div class="mineless-error-container">
        <div class="mineless-error-content">
            <!-- Lost Character -->
            <div class="mineless-lost-character">
                <svg viewBox="0 0 150 200" class="mineless-character-svg">
                    <defs>
                        <linearGradient id="skin" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" style="stop-color:#F0E6D3"/>
                            <stop offset="100%" style="stop-color:#D4C4A8"/>
                        </linearGradient>
                    </defs>
                    <!-- Body -->
                    <rect x="45" y="80" width="60" height="70" rx="5" fill="#8B4513"/>
                    <!-- Head -->
                    <circle cx="75" cy="55" r="30" fill="url(#skin)"/>
                    <!-- Eyes (confused) -->
                    <circle cx="65" cy="50" r="3" fill="#333"/>
                    <circle cx="85" cy="50" r="3" fill="#333"/>
                    <!-- Question marks -->
                    <text x="110" y="40" fill="#D4AF37" font-size="20" font-weight="bold">?</text>
                    <text x="25" y="35" fill="#D4AF37" font-size="15" font-weight="bold">?</text>
                    <!-- Arms (shrugging) -->
                    <path d="M45,90 Q30,100 35,85" fill="none" stroke="url(#skin)" stroke-width="8" stroke-linecap="round"/>
                    <path d="M105,90 Q120,100 115,85" fill="none" stroke="url(#skin)" stroke-width="8" stroke-linecap="round"/>
                </svg>
            </div>
            
            <h1 class="mineless-error-code">404</h1>
            <h2 class="mineless-error-title">Tersesat di Alam Liar</h2>
            <p class="mineless-error-message">
                Seperti Steve yang tersesat di dunia yang belum di-generate, halaman yang kamu cari tidak ditemukan.
                <br><br>
                <em>"Mungkin Creeper sudah menghancurkannya?"</em>
            </p>
            
            <div class="mineless-error-actions">
                <a href="{$SITE_HOME}" class="mineless-btn adv-btn-primary">
                    <i class="fas fa-home"></i>
                    <span>Pulang dengan Aman</span>
                </a>
                <button onclick="history.back()" class="mineless-btn adv-btn-outline">
                    <i class="fas fa-arrow-left"></i>
                    <span>Kembali ke Jalur</span>
                </button>
            </div>
            
            <div class="mineless-error-tips">
                <h3>Tips Bertahan Hidup:</h3>
                <ul>
                    <li><i class="fas fa-check"></i> Jangan buka inventory saat berjalan</li>
                    <li><i class="fas fa-check"></i> Hindari mobil bertabrak di malam hari</li>
                    <li><i class="fas fa-check"></i> Jika melihat Herobrine, segera restart server</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<style>
.mineless-error-section {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(180deg, #87CEEB 0%, #E0F6FF 50%, #90EE90 100%);
    position: relative;
    overflow: hidden;
}

.mineless-wilderness-overlay {
    position: absolute;
    inset: 0;
    background: 
        radial-gradient(ellipse at 30% 100%, rgba(34, 139, 34, 0.3) 0%, transparent 50%),
        radial-gradient(ellipse at 70% 100%, rgba(34, 139, 34, 0.3) 0%, transparent 50%);
}

.mineless-compass-container {
    position: absolute;
    top: 10%;
    right: 10%;
    opacity: 0.3;
}

.mineless-compass {
    width: 150px;
    height: 150px;
    position: relative;
    animation: compassSpin 4s ease-in-out infinite;
}

@keyframes compassSpin {
    0%, 100% { transform: rotate(-20deg); }
    25% { transform: rotate(20deg); }
    50% { transform: rotate(-10deg); }
    75% { transform: rotate(30deg); }
}

.mineless-compass-rose {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 4rem;
    color: #8B4513;
}

.mineless-compass-ring {
    position: absolute;
    inset: 0;
    border: 4px solid #8B4513;
    border-radius: 50%;
}

.mineless-error-container {
    position: relative;
    z-index: 10;
    text-align: center;
    padding: 2rem;
}

.mineless-lost-character {
    width: 150px;
    height: 200px;
    margin: 0 auto 1rem;
    animation: characterIdle 2s ease-in-out infinite;
}

@keyframes characterIdle {
    0%, 100% { transform: translateY(0) rotate(0deg); }
    25% { transform: translateY(-5px) rotate(-2deg); }
    75% { transform: translateY(-5px) rotate(2deg); }
}

.mineless-error-code {
    font-family: var(--font-display);
    font-size: 8rem;
    font-weight: 700;
    background: linear-gradient(180deg, #228B22, #8B4513);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1;
    margin-bottom: 1rem;
}

.mineless-error-title {
    font-family: var(--font-display);
    font-size: 2rem;
    color: #2F4F4F;
    margin-bottom: 1rem;
}

.mineless-error-message {
    color: #556B2F;
    font-size: 1.1rem;
    max-width: 500px;
    margin: 0 auto 2rem;
    line-height: 1.6;
}

.mineless-error-message em {
    color: #8B4513;
    font-style: italic;
}

.mineless-error-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
    margin-bottom: 2rem;
}

.mineless-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.875rem 1.5rem;
    border-radius: var(--radius-md);
    font-weight: 600;
    text-decoration: none;
    transition: var(--transition-fast);
    border: none;
    cursor: pointer;
    font-size: 1rem;
}

.mineless-btn-primary {
    background: linear-gradient(135deg, #228B22, #2E8B57);
    color: white;
}

.mineless-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(34, 139, 34, 0.3);
}

.mineless-btn-outline {
    background: rgba(255,255,255,0.8);
    border: 2px solid #8B4513;
    color: #8B4513;
}

.mineless-btn-outline:hover {
    background: #8B4513;
    color: white;
}

.mineless-error-tips {
    background: rgba(255,255,255,0.8);
    border-radius: var(--radius-lg);
    padding: 1.5rem;
    max-width: 400px;
    margin: 0 auto;
}

.mineless-error-tips h3 {
    color: #2F4F4F;
    margin-bottom: 1rem;
    font-family: var(--font-display);
}

.mineless-error-tips ul {
    list-style: none;
    text-align: left;
}

.mineless-error-tips li {
    padding: 0.5rem 0;
    color: #556B2F;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.mineless-error-tips li i {
    color: #228B22;
}

@media (max-width: 768px) {
    .mineless-error-code {
        font-size: 5rem;
    }
    
    .mineless-error-title {
        font-size: 1.5rem;
    }
    
    .mineless-compass-container {
        display: none;
    }
}
</style>

<script>
// Particle burst on button click
document.querySelectorAll('.mineless-btn-primary').forEach(btn => {
    btn.addEventListener('click', function(e) {
        const rect = this.getBoundingClientRect();
        createParticleBurst(rect.left + rect.width/2, rect.top + rect.height/2);
    });
});

function createParticleBurst(x, y) {
    for (let i = 0; i < 20; i++) {
        const particle = document.createElement('div');
        particle.style.cssText = `
            position: fixed;
            width: 8px;
            height: 8px;
            background: #228B22;
            border-radius: 50%;
            left: ${x}px;
            top: ${y}px;
            pointer-events: none;
            z-index: 9999;
        `;
        
        const angle = (Math.PI * 2 * i) / 20;
        const velocity = 5 + Math.random() * 5;
        const vx = Math.cos(angle) * velocity;
        const vy = Math.sin(angle) * velocity;
        
        document.body.appendChild(particle);
        
        let posX = x;
        let posY = y;
        let opacity = 1;
        
        const animate = () => {
            posX += vx;
            posY += vy + 2;
            opacity -= 0.02;
            
            particle.style.left = posX + 'px';
            particle.style.top = posY + 'px';
            particle.style.opacity = opacity;
            
            if (opacity > 0) {
                requestAnimationFrame(animate);
            } else {
                particle.remove();
            }
        };
        
        requestAnimationFrame(animate);
    }
}
</script>

{include file='footer.tpl'}