{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-members-section">
    <div class="mineless-container">
        <div class="mineless-members-header">
            <h1 class="mineless-section-title"><i class="fas fa-users"></i> {$MEMBERS}</h1>
            <p class="mineless-section-subtitle">{$TOTAL_USERS} petualang telah bergabung</p>
        </div>
        
        <!-- Search & Filter -->
        <div class="mineless-members-filter">
            <div class="mineless-search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="member-search" placeholder="Cari member..." value="{$SEARCH|default:''}">
            </div>
            
            <div class="mineless-filter-group">
                <select id="group-filter" class="mineless-select">
                    <option value="">Semua Grup</option>
                    {if isset($GROUPS)}
                        {foreach from=$GROUPS item=group}
                            <option value="{$group.id}" {if $SELECTED_GROUP == $group.id}selected{/if}>{$group.name}</option>
                        {/foreach}
                    {/if}
                </select>
                
                <select id="sort-filter" class="mineless-select">
                    <option value="joined" {if $SORT == 'joined'}selected{/if}>Bergabung</option>
                    <option value="username" {if $SORT == 'username'}selected{/if}>Username</option>
                    <option value="posts" {if $SORT == 'posts'}selected{/if}>Posts</option>
                </select>
                
                <div class="mineless-view-toggle">
                    <button class="mineless-view-btn active" data-view="grid">
                        <i class="fas fa-th-large"></i>
                    </button>
                    <button class="mineless-view-btn" data-view="list">
                        <i class="fas fa-list"></i>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Members Grid -->
        <div class="mineless-members-grid active" id="members-grid">
            {if isset($MEMBERS) && is_array($MEMBERS) && count($MEMBERS) > 0}
                {foreach from=$MEMBERS item=member}
                    <div class="mineless-member-card">
                        <div class="mineless-member-avatar-wrap">
                            <img src="{$member.avatar}" alt="{$member.username}" class="mineless-member-avatar">
                            {if $member.online}
                                <span class="mineless-online-indicator"></span>
                            {/if}
                        </div>
                        <div class="mineless-member-info">
                            <a href="{$member.profile}" class="mineless-member-name" style="{$member.style}">
                                {$member.username}
                            </a>
                            <span class="mineless-member-group" style="color: {$member.group_color}">
                                {$member.group_name}
                            </span>
                            <div class="mineless-member-stats">
                                <span><i class="fas fa-comment"></i> {$member.posts|default:0}</span>
                                <span><i class="fas fa-calendar"></i> {$member.joined|truncate:10}</span>
                            </div>
                        </div>
                    </div>
                {/foreach}
            {else}
                <div class="mineless-empty-state wide">
                    <i class="fas fa-search"></i>
                    <p>{$NO_MEMBERS}</p>
                </div>
            {/if}
        </div>
        
        <!-- Members List (Hidden by default) -->
        <div class="mineless-members-list" id="members-list">
            {if isset($MEMBERS) && is_array($MEMBERS) && count($MEMBERS) > 0}
                <table class="mineless-members-table">
                    <thead>
                        <tr>
                            <th>Member</th>
                            <th>Grup</th>
                            <th>Posts</th>
                            <th>Bergabung</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {foreach from=$MEMBERS item=member}
                            <tr>
                                <td>
                                    <div class="mineless-table-user">
                                        <img src="{$member.avatar}" alt="">
                                        <a href="{$member.profile}" style="{$member.style}">{$member.username}</a>
                                    </div>
                                </td>
                                <td><span style="color: {$member.group_color}">{$member.group_name}</span></td>
                                <td>{$member.posts|default:0}</td>
                                <td>{$member.joined}</td>
                                <td>
                                    {if $member.online}
                                        <span class="mineless-status-badge online">Online</span>
                                    {else}
                                        <span class="mineless-status-badge offline">Offline</span>
                                    {/if}
                                </td>
                            </tr>
                        {/foreach}
                    </tbody>
                </table>
            {/if}
        </div>
        
        <!-- Pagination -->
        {if isset($PAGINATION)}
            <div class="mineless-pagination-wrap">
                {$PAGINATION}
            </div>
        {/if}
    </div>
</section>

<style>
.mineless-members-section {
    min-height: 100vh;
    padding: 3rem 0;
    background: var(--bg-primary);
}

.mineless-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1.5rem;
}

.mineless-members-header {
    text-align: center;
    margin-bottom: 2rem;
}

.mineless-section-title {
    font-family: var(--font-display);
    font-size: 2.5rem;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
}

.mineless-section-title i {
    color: var(--mineless-gold);
}

.mineless-section-subtitle {
    color: var(--text-secondary);
}

/* Filter */
.mineless-members-filter {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
    padding: 1rem;
    background: var(--bg-card);
    border-radius: var(--radius-lg);
    border: 1px solid rgba(212, 175, 55, 0.1);
}

.mineless-search-box {
    position: relative;
    flex: 1;
    min-width: 250px;
}

.mineless-search-box i {
    position: absolute;
    left: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-secondary);
}

.mineless-search-box input {
    width: 100%;
    padding: 0.75rem 1rem 0.75rem 2.5rem;
    background: var(--bg-secondary);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-md);
    color: var(--text-primary);
}

.mineless-filter-group {
    display: flex;
    gap: 0.75rem;
    align-items: center;
}

.mineless-select {
    padding: 0.75rem 2rem 0.75rem 1rem;
    background: var(--bg-secondary);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-md);
    color: var(--text-primary);
    cursor: pointer;
}

.mineless-view-toggle {
    display: flex;
    gap: 0.25rem;
    background: var(--bg-secondary);
    padding: 0.25rem;
    border-radius: var(--radius-md);
}

.mineless-view-btn {
    padding: 0.5rem 0.75rem;
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    border-radius: var(--radius-sm);
    transition: var(--transition-fast);
}

.mineless-view-btn.active {
    background: var(--mineless-gold);
    color: var(--bg-primary);
}

/* Grid View */
.mineless-members-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 1.5rem;
    display: none;
}

.mineless-members-grid.active {
    display: grid;
}

.mineless-member-card {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    padding: 1.5rem;
    text-align: center;
    transition: var(--transition-fast);
}

.mineless-member-card:hover {
    transform: translateY(-5px);
    border-color: rgba(212, 175, 55, 0.3);
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}

.mineless-member-avatar-wrap {
    position: relative;
    display: inline-block;
    margin-bottom: 1rem;
}

.mineless-member-avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    border: 3px solid rgba(212, 175, 55, 0.2);
}

.mineless-online-indicator {
    position: absolute;
    bottom: 5px;
    right: 5px;
    width: 16px;
    height: 16px;
    background: #28a745;
    border: 3px solid var(--bg-card);
    border-radius: 50%;
}

.mineless-member-name {
    display: block;
    font-weight: 600;
    text-decoration: none;
    margin-bottom: 0.25rem;
}

.mineless-member-group {
    font-size: 0.85rem;
    display: block;
    margin-bottom: 0.75rem;
}

.mineless-member-stats {
    display: flex;
    justify-content: center;
    gap: 1rem;
    font-size: 0.85rem;
    color: var(--text-secondary);
}

.mineless-member-stats i {
    color: var(--mineless-gold);
}

/* List View */
.mineless-members-list {
    display: none;
    background: var(--bg-card);
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.mineless-members-list.active {
    display: block;
}

.mineless-members-table {
    width: 100%;
    border-collapse: collapse;
}

.mineless-members-table th {
    padding: 1rem;
    text-align: left;
    background: rgba(212, 175, 55, 0.05);
    color: var(--text-secondary);
    font-weight: 500;
    font-size: 0.9rem;
}

.mineless-members-table td {
    padding: 1rem;
    border-top: 1px solid rgba(212, 175, 55, 0.05);
}

.mineless-table-user {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.mineless-table-user img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
}

.mineless-table-user a {
    text-decoration: none;
    font-weight: 500;
}

.mineless-status-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 50px;
    font-size: 0.8rem;
}

.mineless-status-badge.online {
    background: rgba(40, 167, 69, 0.1);
    color: #28a745;
}

.mineless-status-badge.offline {
    background: rgba(108, 117, 125, 0.1);
    color: var(--text-secondary);
}

.mineless-empty-state {
    text-align: center;
    padding: 4rem 2rem;
    color: var(--text-secondary);
    grid-column: 1 / -1;
}

.mineless-empty-state i {
    font-size: 3rem;
    margin-bottom: 1rem;
    opacity: 0.5;
}

.mineless-empty-state.wide {
    background: var(--bg-card);
    border-radius: var(--radius-lg);
}

.mineless-pagination-wrap {
    margin-top: 2rem;
    display: flex;
    justify-content: center;
}

@media (max-width: 768px) {
    .mineless-members-filter {
        flex-direction: column;
    }
    
    .mineless-filter-group {
        width: 100%;
        justify-content: space-between;
    }
}
</style>

<script>
document.querySelectorAll('.mineless-view-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.mineless-view-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const view = btn.dataset.view;
        document.getElementById('members-grid').classList.toggle('active', view === 'grid');
        document.getElementById('members-list').classList.toggle('active', view === 'list');
    });
});

document.getElementById('member-search')?.addEventListener('input', function() {
    const query = this.value.toLowerCase();
    document.querySelectorAll('.mineless-member-card, .mineless-members-table tbody tr').forEach(el => {
        const name = el.textContent.toLowerCase();
        el.style.display = name.includes(query) ? '' : 'none';
    });
});
</script>

{include file='footer.tpl'}