{include file='header.tpl'}
{include file='navbar.tpl'}

<section class="mineless-leaderboard-section">
    <div class="mineless-container">
        <!-- Header -->
        <div class="mineless-leaderboard-header">
            <div class="mineless-trophy-icon-lg">
                <i class="fas fa-trophy"></i>
                <div class="mineless-trophy-glow"></div>
            </div>
            <h1 class="mineless-section-title">{$LEADERBOARDS}</h1>
            <p class="mineless-section-subtitle">Para petualang terbaik di server kami</p>
        </div>
        
        <!-- Filter Tabs -->
        <div class="mineless-leaderboard-tabs">
            <button class="mineless-tab-btn active" data-filter="posts">
                <i class="fas fa-comment"></i> Most Posts
            </button>
            <button class="mineless-tab-btn" data-filter="likes">
                <i class="fas fa-heart"></i> Most Likes
            </button>
            <button class="mineless-tab-btn" data-filter="reactions">
                <i class="fas fa-smile"></i> Most Reactions
            </button>
        </div>
        
        <!-- Top 3 Podium -->
        <div class="mineless-podium">
            <!-- 2nd Place -->
            {if isset($TOP_USERS[1])}
            <div class="mineless-podium-item second" data-rank="2">
                <div class="mineless-podium-avatar">
                    <img src="{$TOP_USERS[1].avatar}" alt="{$TOP_USERS[1].username}">
                    <div class="mineless-podium-rank">
                        <i class="fas fa-medal"></i>
                    </div>
                </div>
                <div class="mineless-podium-info">
                    <a href="{$TOP_USERS[1].profile}" class="mineless-podium-name" style="{$TOP_USERS[1].style}">
                        {$TOP_USERS[1].username}
                    </a>
                    <span class="mineless-podium-score">{$TOP_USERS[1].score}</span>
                </div>
                <div class="mineless-podium-base silver"></div>
            </div>
            {/if}
            
            <!-- 1st Place -->
            {if isset($TOP_USERS[0])}
            <div class="mineless-podium-item first" data-rank="1">
                <div class="mineless-podium-crown">
                    <i class="fas fa-crown"></i>
                </div>
                <div class="mineless-podium-avatar">
                    <img src="{$TOP_USERS[0].avatar}" alt="{$TOP_USERS[0].username}">
                    <div class="mineless-podium-rank">
                        <i class="fas fa-trophy"></i>
                    </div>
                </div>
                <div class="mineless-podium-info">
                    <a href="{$TOP_USERS[0].profile}" class="mineless-podium-name" style="{$TOP_USERS[0].style}">
                        {$TOP_USERS[0].username}
                    </a>
                    <span class="mineless-podium-score">{$TOP_USERS[0].score}</span>
                </div>
                <div class="mineless-podium-base gold"></div>
            </div>
            {/if}
            
            <!-- 3rd Place -->
            {if isset($TOP_USERS[2])}
            <div class="mineless-podium-item third" data-rank="3">
                <div class="mineless-podium-avatar">
                    <img src="{$TOP_USERS[2].avatar}" alt="{$TOP_USERS[2].username}">
                    <div class="mineless-podium-rank">
                        <i class="fas fa-award"></i>
                    </div>
                </div>
                <div class="mineless-podium-info">
                    <a href="{$TOP_USERS[2].profile}" class="mineless-podium-name" style="{$TOP_USERS[2].style}">
                        {$TOP_USERS[2].username}
                    </a>
                    <span class="mineless-podium-score">{$TOP_USERS[2].score}</span>
                </div>
                <div class="mineless-podium-base bronze"></div>
            </div>
            {/if}
        </div>
        
        <!-- Ranking Table -->
        <div class="mineless-ranking-table-wrap">
            <table class="mineless-ranking-table">
                <thead>
                    <tr>
                        <th class="mineless-rank-col">Rank</th>
                        <th class="mineless-user-col">Player</th>
                        <th class="mineless-score-col">Score</th>
                        <th class="mineless-trend-col">Trend</th>
                    </tr>
                </thead>
                <tbody>
                    {if isset($LEADERBOARD_USERS)}
                        {foreach from=$LEADERBOARD_USERS item=user name=leaderboard}
                            <tr class="mineless-ranking-row" style="animation-delay: {$smarty.foreach.leaderboard.index * 0.05}s">
                                <td class="mineless-rank-cell">
                                    <span class="mineless-rank-number">{$user.rank}</span>
                                </td>
                                <td class="mineless-user-cell">
                                    <img src="{$user.avatar}" alt="" class="mineless-rank-avatar">
                                    <a href="{$user.profile}" class="mineless-rank-username" style="{$user.style}">
                                        {$user.username}
                                    </a>
                                </td>
                                <td class="mineless-score-cell">
                                    <span class="mineless-score-value">{$user.value}</span>
                                </td>
                                <td class="mineless-trend-cell">
                                    {if $user.trend == 'up'}
                                        <span class="mineless-trend up"><i class="fas fa-arrow-up"></i></span>
                                    {elseif $user.trend == 'down'}
                                        <span class="mineless-trend down"><i class="fas fa-arrow-down"></i></span>
                                    {else}
                                        <span class="mineless-trend same"><i class="fas fa-minus"></i></span>
                                    {/if}
                                </td>
                            </tr>
                        {/foreach}
                    {/if}
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        {if isset($PAGINATION)}
            <div class="mineless-pagination-wrap">
                {$PAGINATION}
            </div>
        {/if}
    </div>
</section>

<style>
.mineless-leaderboard-section {
    min-height: 100vh;
    padding: 4rem 0;
    background: linear-gradient(180deg, var(--bg-primary) 0%, var(--bg-secondary) 100%);
}

.mineless-container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 0 1.5rem;
}

.mineless-leaderboard-header {
    text-align: center;
    margin-bottom: 3rem;
}

.mineless-trophy-icon-lg {
    width: 100px;
    height: 100px;
    margin: 0 auto 1.5rem;
    background: linear-gradient(135deg, var(--mineless-gold), var(--mineless-ember));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    color: var(--bg-primary);
    position: relative;
    animation: magicPulse 2s ease-in-out infinite;
}

.mineless-trophy-glow {
    position: absolute;
    inset: -20px;
    background: radial-gradient(circle, rgba(212,175,55,0.4) 0%, transparent 70%);
    animation: glowPulse 3s ease-in-out infinite;
}

.mineless-section-title {
    font-family: var(--font-display);
    font-size: 2.5rem;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
}

.mineless-section-subtitle {
    color: var(--text-secondary);
    font-size: 1.1rem;
}

.mineless-leaderboard-tabs {
    display: flex;
    justify-content: center;
    gap: 1rem;
    margin-bottom: 3rem;
    flex-wrap: wrap;
}

.mineless-tab-btn {
    padding: 0.75rem 1.5rem;
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: var(--radius-md);
    color: var(--text-secondary);
    font-size: 0.95rem;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    transition: var(--transition-fast);
}

.mineless-tab-btn:hover {
    border-color: var(--mineless-gold);
    color: var(--mineless-gold);
}

.mineless-tab-btn.active {
    background: var(--mineless-gold);
    border-color: var(--mineless-gold);
    color: var(--bg-primary);
}

/* Podium */
.mineless-podium {
    display: flex;
    justify-content: center;
    align-items: flex-end;
    gap: 2rem;
    margin-bottom: 4rem;
    padding: 2rem 0;
}

.mineless-podium-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    animation: podiumRise 0.8s ease forwards;
    opacity: 0;
    transform: translateY(50px);
}

.mineless-podium-item.first {
    order: 2;
    animation-delay: 0.2s;
    z-index: 3;
}

.mineless-podium-item.second {
    order: 1;
    animation-delay: 0.4s;
}

.mineless-podium-item.third {
    order: 3;
    animation-delay: 0.6s;
}

@keyframes podiumRise {
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.mineless-podium-crown {
    position: absolute;
    top: -30px;
    font-size: 2rem;
    color: var(--mineless-gold);
    animation: crownBounce 2s ease-in-out infinite;
    filter: drop-shadow(0 0 10px var(--mineless-gold));
}

@keyframes crownBounce {
    0%, 100% { transform: translateY(0) rotate(-5deg); }
    50% { transform: translateY(-10px) rotate(5deg); }
}

.mineless-podium-avatar {
    position: relative;
    margin-bottom: 1rem;
}

.mineless-podium-avatar img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    border: 4px solid;
    object-fit: cover;
}

.mineless-podium-item.first .mineless-podium-avatar img {
    width: 120px;
    height: 120px;
    border-color: var(--mineless-gold);
    box-shadow: 0 0 30px rgba(212, 175, 55, 0.4);
}

.mineless-podium-item.second .mineless-podium-avatar img {
    border-color: #C0C0C0;
    box-shadow: 0 0 20px rgba(192, 192, 192, 0.3);
}

.mineless-podium-item.third .mineless-podium-avatar img {
    border-color: #CD7F32;
    box-shadow: 0 0 20px rgba(205, 127, 50, 0.3);
}

.mineless-podium-rank {
    position: absolute;
    bottom: -5px;
    right: -5px;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    border: 3px solid var(--bg-card);
}

.mineless-podium-item.first .mineless-podium-rank {
    background: var(--mineless-gold);
    color: var(--bg-primary);
}

.mineless-podium-item.second .mineless-podium-rank {
    background: #C0C0C0;
    color: var(--bg-primary);
}

.mineless-podium-item.third .mineless-podium-rank {
    background: #CD7F32;
    color: var(--bg-primary);
}

.mineless-podium-info {
    text-align: center;
    margin-bottom: 1rem;
}

.mineless-podium-name {
    display: block;
    font-weight: 600;
    font-size: 1.1rem;
    text-decoration: none;
    margin-bottom: 0.25rem;
}

.mineless-podium-score {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--mineless-gold);
}

.mineless-podium-base {
    width: 140px;
    border-radius: var(--radius-md) var(--radius-md) 0 0;
    position: relative;
}

.mineless-podium-item.first .mineless-podium-base {
    height: 120px;
    background: linear-gradient(180deg, rgba(212,175,55,0.3) 0%, rgba(212,175,55,0.1) 100%);
    border: 2px solid var(--mineless-gold);
    border-bottom: none;
}

.mineless-podium-item.second .mineless-podium-base {
    height: 80px;
    background: linear-gradient(180deg, rgba(192,192,192,0.3) 0%, rgba(192,192,192,0.1) 100%);
    border: 2px solid #C0C0C0;
    border-bottom: none;
}

.mineless-podium-item.third .mineless-podium-base {
    height: 50px;
    background: linear-gradient(180deg, rgba(205,127,50,0.3) 0%, rgba(205,127,50,0.1) 100%);
    border: 2px solid #CD7F32;
    border-bottom: none;
}

/* Ranking Table */
.mineless-ranking-table-wrap {
    background: var(--bg-card);
    border: 1px solid rgba(212, 175, 55, 0.1);
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.mineless-ranking-table {
    width: 100%;
    border-collapse: collapse;
}

.mineless-ranking-table th {
    padding: 1rem 1.5rem;
    text-align: left;
    background: rgba(212, 175, 55, 0.05);
    color: var(--text-secondary);
    font-weight: 500;
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.mineless-ranking-table td {
    padding: 1rem 1.5rem;
    border-top: 1px solid rgba(212, 175, 55, 0.05);
}

.mineless-ranking-row {
    animation: fadeInUp 0.5s ease forwards;
    opacity: 0;
    transform: translateY(20px);
    transition: var(--transition-fast);
}

.mineless-ranking-row:hover {
    background: rgba(212, 175, 55, 0.03);
}

.mineless-rank-col, .mineless-rank-cell {
    width: 80px;
    text-align: center;
}

.mineless-rank-number {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    background: var(--bg-secondary);
    border-radius: 50%;
    font-weight: 600;
    color: var(--text-secondary);
}

.mineless-user-col, .mineless-user-cell {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.mineless-rank-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
}

.mineless-rank-username {
    font-weight: 500;
    text-decoration: none;
}

.mineless-rank-username:hover {
    text-decoration: underline;
}

.mineless-score-col, .mineless-score-cell {
    text-align: right;
}

.mineless-score-value {
    font-weight: 600;
    color: var(--mineless-gold);
    font-size: 1.1rem;
}

.mineless-trend-col, .mineless-trend-cell {
    text-align: center;
    width: 60px;
}

.mineless-trend {
    font-size: 0.85rem;
}

.mineless-trend.up {
    color: #28a745;
}

.mineless-trend.down {
    color: #dc3545;
}

.mineless-trend.same {
    color: var(--text-secondary);
}

.mineless-pagination-wrap {
    margin-top: 2rem;
    display: flex;
    justify-content: center;
}

@keyframes fadeInUp {
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 768px) {
    .mineless-podium {
        flex-direction: column;
        align-items: center;
    }
    
    .mineless-podium-item {
        order: unset !important;
    }
    
    .mineless-podium-base {
        width: 200px;
        height: 40px !important;
        border-radius: var(--radius-md);
        border: 2px solid !important;
    }
    
    .mineless-ranking-table th,
    .mineless-ranking-table td {
        padding: 0.75rem;
    }
    
    .mineless-trend-col,
    .mineless-trend-cell {
        display: none;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    animatePodium();
});

function initTabs() {
    const tabs = document.querySelectorAll('.mineless-tab-btn');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            const filter = tab.dataset.filter;
            // Reload page with filter or fetch via AJAX
            window.location.href = '{$LEADERBOARD_URL}?filter=' + filter;
        });
    });
}

function animatePodium() {
    const items = document.querySelectorAll('.mineless-podium-item');
    
    items.forEach((item, index) => {
        setTimeout(() => {
            item.style.opacity = '1';
            item.style.transform = 'translateY(0)';
        }, index * 200);
    });
}
</script>

{include file='footer.tpl'}